import {
  useEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type ReactNode,
} from "react";
import { cn } from "../utils/cn";
import { Link } from "../lib/router";
import { prefersReducedMotion } from "../lib/grid";

/* ---------------- Buttons ---------------- */

type BtnVariant = "primary" | "ghost";
type BtnSize = "sm" | "md" | "lg";

const shellSize: Record<BtnSize, string> = {
  sm: "btn-shell-sm",
  md: "btn-shell-md",
  lg: "btn-shell-lg",
};

function btnShellClass(variant: BtnVariant, size: BtnSize) {
  return cn(
    "btn-shell",
    variant === "primary" ? "btn-primary-shell" : "btn-ghost-shell",
    shellSize[size]
  );
}

export function ButtonLink({
  to,
  children,
  variant = "primary",
  size = "md",
  className,
  onClick,
}: {
  to: string;
  children: ReactNode;
  variant?: BtnVariant;
  size?: BtnSize;
  className?: string;
  onClick?: () => void;
}) {
  return (
    <Link to={to} onClick={onClick} className={cn(btnShellClass(variant, size), className)}>
      <span className={cn("btn-core", shellSize[size])}>{children}</span>
    </Link>
  );
}

export function Button({
  variant = "primary",
  size = "md",
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: BtnSize }) {
  return (
    <button {...props} className={cn(btnShellClass(variant, size), className)}>
      <span className={cn("btn-core", shellSize[size])}>{children}</span>
    </button>
  );
}

/* ---------------- Reveal on scroll ---------------- */

export function Reveal({
  children,
  delay = 0,
  className,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReducedMotion()) {
      setInView(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setInView(true);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -36px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      style={delay ? { transitionDelay: `${delay}ms` } : undefined}
      className={cn("reveal", inView && "is-in", className)}
    >
      {children}
    </div>
  );
}

/* ---------------- Section header ---------------- */

export function SectionHead({
  index,
  label,
  title,
  className,
}: {
  index: string;
  label: string;
  title: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("relative mb-12 md:mb-16", className)}>
      <div
        aria-hidden="true"
        className="ghost-num pointer-events-none absolute -top-6 right-0 hidden text-[9rem] opacity-40 md:block lg:text-[11rem]"
      >
        {index}
      </div>
      <Reveal>
        <p className="mono-label mb-4 flex items-center gap-3">
          <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
          <span>
            {index} — {label}
          </span>
        </p>
        <h2 className="display max-w-2xl text-3xl font-bold uppercase leading-[1.05] tracking-tight sm:text-4xl lg:text-[2.9rem]">
          {title}
        </h2>
      </Reveal>
    </div>
  );
}

/* ---------------- Animated numbers ---------------- */

export function useAnimatedNumber(target: number, duration = 750): number {
  const [val, setVal] = useState(target);
  const prevRef = useRef(target);

  useEffect(() => {
    const from = prevRef.current;
    prevRef.current = target;
    if (from === target) return;
    if (prefersReducedMotion()) {
      setVal(target);
      return;
    }
    let raf = 0;
    const t0 = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / duration);
      const e = 1 - Math.pow(1 - p, 3);
      setVal(Math.round(from + (target - from) * e));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);

  return val;
}

export function useInView<T extends HTMLElement>(threshold = 0.3) {
  const ref = useRef<T>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setInView(true);
          io.disconnect();
        }
      },
      { threshold }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);

  return { ref, inView };
}

export function Stat({ value, suffix, label, delay = 0 }: { value: number; suffix: string; label: string; delay?: number }) {
  const { ref, inView } = useInView<HTMLDivElement>(0.4);
  const n = useAnimatedNumber(inView ? value : 0, 1200);
  return (
    <div ref={ref} className="reveal is-in text-center md:text-left" style={{ transitionDelay: `${delay}ms` }}>
      <div className="display text-4xl font-bold tracking-tight text-[var(--text)] sm:text-5xl">
        {n}
        <span className="text-[var(--blue)]">{suffix}</span>
      </div>
      <div className="mono-label mt-3">{label}</div>
    </div>
  );
}

/* ---------------- Octagon node ---------------- */

export function OctagonNode({
  active,
  size = 44,
  children,
}: {
  active?: boolean;
  size?: number;
  children?: ReactNode;
}) {
  return (
    <div
      style={{ width: size, height: size }}
      className={cn(
        "clip-oct-sm p-px transition-all duration-300",
        active
          ? "bg-[var(--blue)] [filter:drop-shadow(0_0_14px_var(--glow))]"
          : "bg-[var(--border-strong)]"
      )}
    >
      <div
        className={cn(
          "clip-oct-sm flex h-full w-full items-center justify-center transition-colors duration-300",
          active ? "bg-[var(--blue)] text-white" : "bg-[var(--surface-2)] text-[var(--text-2)]"
        )}
      >
        {children}
      </div>
    </div>
  );
}
