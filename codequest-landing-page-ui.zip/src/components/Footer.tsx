import { useState } from "react";
import { Link } from "../lib/router";
import { GitHubIcon, LinkedInIcon, MailIcon, XIcon } from "./icons";
import { Wordmark } from "./Navbar";

const platformLinks = [
  { label: "Home", to: "/" },
  { label: "Timeline", to: "/timeline" },
  { label: "Gallery", to: "/gallery" },
  { label: "Competitions", to: "/?s=season" },
  { label: "Leaderboard", to: "/?s=rankings" },
];

const companyLinks = [
  { label: "About Us", to: "/about" },
  { label: "Contact", to: "/contact" },
];

const legal: Record<string, { title: string; body: string }> = {
  terms: {
    title: "Terms of Participation",
    body: "Participation in CodeQuest is open to enrolled students of partner schools. All participants must be verified through their school, and all competition results are final once published. CodeQuest reserves the right to disqualify accounts using unauthorized assistance or tooling.",
  },
  privacy: {
    title: "Privacy Policy",
    body: "CodeQuest collects only the information required to run the competition: your name, school, and competition results. We never sell participant data, and leaderboard entries display only your chosen display name. Account data can be requested or deleted through our contact channel.",
  },
};

const socials = [
  { label: "GitHub", icon: GitHubIcon, href: "https://github.com" },
  { label: "X", icon: XIcon, href: "https://x.com" },
  { label: "LinkedIn", icon: LinkedInIcon, href: "https://linkedin.com" },
  { label: "Email", icon: MailIcon, href: "mailto:hello@codequest.dev" },
];

export default function Footer() {
  const [modal, setModal] = useState<null | "terms" | "privacy">(null);

  return (
    <footer className="relative z-10 border-t border-[var(--border)] bg-[var(--surface)] backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Wordmark />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-[var(--text-2)]">
              Think. Build. Compete. A season of ranked coding rounds for
              the best young developers in the region.
            </p>
            <div className="mt-6 flex gap-2.5">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={s.label}
                  className="clip-oct-sm flex h-9 w-9 items-center justify-center border border-[var(--border-strong)] text-[var(--text-2)] transition-all duration-300 hover:-translate-y-0.5 hover:border-[var(--blue)] hover:text-[var(--blue)]"
                >
                  <s.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="mono-label mb-4">Platform</h3>
            <ul className="space-y-2.5">
              {platformLinks.map((l) => (
                <li key={l.label}>
                  <Link
                    to={l.to}
                    className="text-sm font-medium text-[var(--text-2)] transition-colors hover:text-[var(--blue)]"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mono-label mb-4">Company</h3>
            <ul className="space-y-2.5">
              {companyLinks.map((l) => (
                <li key={l.label}>
                  <Link
                    to={l.to}
                    className="text-sm font-medium text-[var(--text-2)] transition-colors hover:text-[var(--blue)]"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mono-label mb-4">Legal</h3>
            <ul className="space-y-2.5">
              <li>
                <button
                  onClick={() => setModal("terms")}
                  className="text-sm font-medium text-[var(--text-2)] transition-colors hover:text-[var(--blue)]"
                >
                  Terms
                </button>
              </li>
              <li>
                <Link
                  to="/privacy"
                  className="text-sm font-medium text-[var(--text-2)] transition-colors hover:text-[var(--blue)]"
                >
                  Privacy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-3 border-t border-[var(--border)] pt-6 sm:flex-row sm:items-center">
          <p className="text-xs text-[var(--text-3)]">
            © 2026 CodeQuest. All rights reserved.
          </p>
          <p className="mono-label">Grid online :: Season 01</p>
        </div>
      </div>

      {/* Legal modal */}
      {modal && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/60 p-5 backdrop-blur-sm"
          onClick={() => setModal(null)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label={legal[modal].title}
            className="panel-solid panel-in clip-oct w-full max-w-md p-7"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <h3 className="display text-lg font-bold uppercase tracking-tight">
                {legal[modal].title}
              </h3>
              <button
                onClick={() => setModal(null)}
                className="mono-label cursor-pointer transition-colors hover:text-[var(--blue)]"
              >
                Close
              </button>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-[var(--text-2)]">
              {legal[modal].body}
            </p>
            <p className="mono-label mt-6 opacity-60">CodeQuest :: Season 01</p>
          </div>
        </div>
      )}
    </footer>
  );
}
