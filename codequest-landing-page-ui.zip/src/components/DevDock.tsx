import { useState } from "react";
import { cn } from "../utils/cn";
import { Link, parseRoute, useRoute } from "../lib/router";
import { dashboards, normalizeDashboardPath, SHOW_DEV_DOCK } from "../lib/dashboards";
import { OctagonNode } from "./ui";
import { ArrowRight } from "./icons";

const STORE_KEY = "cq-dock-open";

/**
 * TEMPORARY preview dock — jump straight into the dashboards while
 * authentication does not exist yet. Remove by setting SHOW_DEV_DOCK=false
 * in src/lib/dashboards.ts, or deleting this component from App.tsx.
 */
export default function DevDock() {
  const route = useRoute();
  const current = normalizeDashboardPath(parseRoute(route).path);

  const [open, setOpen] = useState<boolean>(() => {
    try {
      const s = sessionStorage.getItem(STORE_KEY);
      if (s !== null) return s === "1";
    } catch {
      /* ignore */
    }
    return typeof window !== "undefined" ? window.innerWidth >= 640 : true;
  });

  const set = (v: boolean) => {
    setOpen(v);
    try {
      sessionStorage.setItem(STORE_KEY, v ? "1" : "0");
    } catch {
      /* ignore */
    }
  };

  if (!SHOW_DEV_DOCK) return null;

  return (
    <div className="pointer-events-none fixed bottom-4 left-4 right-4 z-[55] flex justify-end sm:left-auto sm:right-5 sm:bottom-5">
      {open ? (
        <div className="panel-in pointer-events-auto w-full [filter:drop-shadow(0_14px_30px_rgba(0,0,0,0.35))] sm:w-[310px]">
          <div className="clip-oct bg-[var(--blue)]/60 p-px">
            <div className="clip-oct bg-[var(--surface-solid)] p-4">
              <div className="flex items-center justify-between gap-3">
                <p className="mono-label flex items-center gap-2.5 text-[10px] text-[var(--blue)]">
                  <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />
                  Temp · Dashboard preview
                </p>
                <button
                  onClick={() => set(false)}
                  aria-label="Hide dashboard preview dock"
                  className="mono-label cursor-pointer text-[10px] transition-colors hover:text-[var(--blue)]"
                >
                  Hide
                </button>
              </div>

              <ul className="mt-3.5 space-y-1.5">
                {dashboards.map((d) => {
                  const active = current === d.path;
                  return (
                    <li key={d.id}>
                      <Link
                        to={d.path}
                        aria-current={active ? "page" : undefined}
                        className={cn(
                          "group flex items-center gap-3 border px-2.5 py-2 transition-all duration-200",
                          active
                            ? "border-[var(--blue)] bg-[var(--blue-soft)]"
                            : "border-[var(--border)] hover:border-[var(--blue)] hover:bg-[var(--blue-soft)]"
                        )}
                      >
                        <OctagonNode active={active} size={30}>
                          <span className="font-mono text-[9.5px] font-semibold">{d.num}</span>
                        </OctagonNode>
                        <span className="min-w-0 flex-1">
                          <span
                            className={cn(
                              "block font-display text-[13px] font-semibold leading-tight transition-colors",
                              active ? "text-[var(--blue)]" : "text-[var(--text)] group-hover:text-[var(--blue)]"
                            )}
                          >
                            {d.label} dashboard
                          </span>
                          <span className="mt-0.5 block truncate font-mono text-[10px] tracking-wide text-[var(--text-3)]">
                            #{d.path}
                          </span>
                        </span>
                        <ArrowRight
                          className={cn(
                            "h-3.5 w-3.5 shrink-0 transition-all duration-200",
                            active
                              ? "text-[var(--blue)]"
                              : "text-[var(--text-3)] group-hover:translate-x-0.5 group-hover:text-[var(--blue)]"
                          )}
                        />
                      </Link>
                    </li>
                  );
                })}
              </ul>

              <p className="mt-3 font-mono text-[9.5px] leading-relaxed tracking-wider text-[var(--text-3)]">
                Temporary navigation — removed once sign-in routes users automatically.
              </p>
            </div>
          </div>
        </div>
      ) : (
        <button
          onClick={() => set(true)}
          aria-label="Show dashboard preview dock"
          className="panel-in pointer-events-auto cursor-pointer [filter:drop-shadow(0_8px_20px_rgba(0,0,0,0.3))]"
        >
          <span className="clip-oct-sm block bg-[var(--blue)]/60 p-px transition-colors hover:bg-[var(--blue)]">
            <span className="clip-oct-sm flex items-center gap-2.5 bg-[var(--surface-solid)] px-3.5 py-2.5">
              <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />
              <span className="font-mono text-[10.5px] font-semibold tracking-[0.18em] text-[var(--text)]">
                DASHBOARDS
              </span>
            </span>
          </span>
        </button>
      )}
    </div>
  );
}
