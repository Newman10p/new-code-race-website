import { useEffect, useRef } from "react";
import { gridRuntime, hexToRgb, lerpColor, prefersReducedMotion } from "../lib/grid";
import type { Theme } from "../lib/theme";

type RGB = [number, number, number];

type Palette = {
  cell: RGB;
  border: RGB;
  blue: RGB;
  blueBright: RGB;
  glow: RGB;
  vignette: string;
};

const DARK: Palette = {
  cell: hexToRgb("#11151a"),
  border: hexToRgb("#1c232c"),
  blue: hexToRgb("#4d9cff"),
  blueBright: hexToRgb("#a8d1ff"),
  glow: hexToRgb("#4d9cff"),
  vignette: "rgba(0,0,0,0.4)",
};

const LIGHT: Palette = {
  cell: hexToRgb("#e9edf2"),
  border: hexToRgb("#d9e0e8"),
  blue: hexToRgb("#3b82f6"),
  blueBright: hexToRgb("#1d4ed8"),
  glow: hexToRgb("#3b82f6"),
  vignette: "rgba(18,32,50,0.07)",
};

type Cell = {
  x: number;
  y: number;
  a: number; // current activation 0..1
  target: number;
  axis: 0 | 1; // flip axis
  phase: number;
  shimmer: boolean;
  dist: number;
};

const K = 0.41421356; // regular octagon chamfer ratio

function octPath(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rx: number,
  ry: number
) {
  const cxx = rx * K;
  const cyy = ry * K;
  ctx.beginPath();
  ctx.moveTo(cx - rx + cxx, cy - ry);
  ctx.lineTo(cx + rx - cxx, cy - ry);
  ctx.lineTo(cx + rx, cy - ry + cyy);
  ctx.lineTo(cx + rx, cy + ry - cyy);
  ctx.lineTo(cx + rx - cxx, cy + ry);
  ctx.lineTo(cx - rx + cxx, cy + ry);
  ctx.lineTo(cx - rx, cy + ry - cyy);
  ctx.lineTo(cx - rx, cy - ry + cyy);
  ctx.closePath();
}

export default function OctagonCanvas({
  theme,
  active,
}: {
  theme: Theme;
  active: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const activeRef = useRef(active);

  useEffect(() => {
    activeRef.current = active;
  }, [active]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const cv: HTMLCanvasElement = canvas;
    const cx: CanvasRenderingContext2D = ctx;

    const reduced = prefersReducedMotion();
    const pal = theme === "light" ? LIGHT : DARK;

    let W = 0;
    let H = 0;
    let dpr = 1;
    let P = 60;
    let R = 140;
    let r = 25;
    let cols = 0;
    let rows = 0;
    let ox = 0;
    let oy = 0;
    let maxDist = 0;
    let cells: Cell[] = [];
    let shimmerCells: number[] = [];
    let base: HTMLCanvasElement | null = null;

    let px = -1e4;
    let py = -1e4;
    let pointerActive = false;

    let energy = gridRuntime.energy;
    let birthStarted = reduced || activeRef.current;
    let birthT = birthStarted ? 1 : 0;

    const activeSet = new Set<number>();
    let raf = 0;
    let last = performance.now();
    let running = true;

    function build() {
      W = window.innerWidth;
      H = window.innerHeight;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      P = W < 640 ? 42 : W < 1024 ? 52 : 60;
      R = P * 2.35;
      r = P * 0.415;

      cv.width = Math.round(W * dpr);
      cv.height = Math.round(H * dpr);
      cv.style.width = `${W}px`;
      cv.style.height = `${H}px`;
      cx.setTransform(dpr, 0, 0, dpr, 0, 0);

      cols = Math.ceil(W / P) + 2;
      rows = Math.ceil(H / P) + 2;
      ox = W / 2 - ((cols - 1) / 2) * P;
      oy = H / 2 - ((rows - 1) / 2) * P;
      maxDist = Math.hypot(W, H) / 2 + P * 2;

      cells = [];
      shimmerCells = [];
      let i = 0;
      for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
          const x = ox + col * P;
          const y = oy + row * P;
          const phase = Math.random();
          cells.push({
            x,
            y,
            a: 0,
            target: 0,
            axis: (row + col) % 2 === 0 ? 0 : 1,
            phase,
            shimmer: phase < 0.045,
            dist: Math.hypot(x - W / 2, y - H / 2),
          });
          if (phase < 0.045) shimmerCells.push(i);
          i++;
        }
      }
      activeSet.clear();

      // Pre-render the static base field (inactive cells + vignette).
      base = document.createElement("canvas");
      base.width = cv.width;
      base.height = cv.height;
      const bctx = base.getContext("2d");
      if (!bctx) return;
      bctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      bctx.fillStyle = lerpColor(pal.cell, pal.cell, 0);
      bctx.strokeStyle = lerpColor(pal.border, pal.border, 0);
      bctx.lineWidth = 1;
      for (const c of cells) {
        octPath(bctx, c.x, c.y, r, r);
        bctx.fill();
        bctx.stroke();
      }
      const g = bctx.createRadialGradient(
        W / 2,
        H / 2,
        Math.min(W, H) * 0.25,
        W / 2,
        H / 2,
        Math.max(W, H) * 0.75
      );
      g.addColorStop(0, "rgba(0,0,0,0)");
      g.addColorStop(1, pal.vignette);
      bctx.fillStyle = g;
      bctx.fillRect(0, 0, W, H);
    }

    function pointerBurst(x: number, y: number) {
      const rad = P * 2.6;
      const col0 = Math.max(0, Math.floor((x - rad - ox) / P));
      const col1 = Math.min(cols - 1, Math.ceil((x + rad - ox) / P));
      const row0 = Math.max(0, Math.floor((y - rad - oy) / P));
      const row1 = Math.min(rows - 1, Math.ceil((y + rad - oy) / P));
      for (let row = row0; row <= row1; row++) {
        for (let col = col0; col <= col1; col++) {
          const i = row * cols + col;
          const c = cells[i];
          const d = Math.hypot(c.x - x, c.y - y);
          if (d < rad) {
            const t = (1 - d / rad) * 0.85;
            if (t > c.target) c.target = t;
            activeSet.add(i);
          }
        }
      }
    }

    const onMove = (e: PointerEvent) => {
      px = e.clientX;
      py = e.clientY;
      pointerActive = true;
    };
    const onDown = (e: PointerEvent) => {
      px = e.clientX;
      py = e.clientY;
      pointerActive = true;
      if (!reduced) pointerBurst(px, py);
    };
    const onUp = (e: PointerEvent) => {
      if (e.pointerType === "touch") pointerActive = false;
    };
    const clearPointer = () => {
      pointerActive = false;
    };

    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerdown", onDown, { passive: true });
    window.addEventListener("pointerup", onUp, { passive: true });
    window.addEventListener("pointercancel", onUp, { passive: true });
    window.addEventListener("blur", clearPointer);
    document.addEventListener("mouseleave", clearPointer);

    let resizeTimer = 0;
    const onResize = () => {
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(build, 120);
    };
    window.addEventListener("resize", onResize);

    const onVis = () => {
      if (document.hidden) {
        cancelAnimationFrame(raf);
        running = false;
      } else if (!running) {
        running = true;
        last = performance.now();
        raf = requestAnimationFrame(loop);
      }
    };
    document.addEventListener("visibilitychange", onVis);

    function drawCell(c: Cell) {
      const t = c.a;
      const flip = reduced ? 1 : Math.max(Math.abs(Math.cos(t * Math.PI)), 0.06);
      const scale = reduced ? 1 + 0.04 * t : (0.92 + 0.16 * t) * flip;
      const rx = r * (c.axis === 0 ? scale : 1);
      const ry = r * (c.axis === 1 ? scale : 1);
      const lift = 1.6 * t;
      const fill = lerpColor(pal.cell, pal.blue, t);
      const stroke = lerpColor(pal.border, pal.blueBright, Math.min(1, t * 1.25));

      ctx!.save();
      if (t > 0.22) {
        ctx!.shadowColor = `rgba(${pal.glow[0]},${pal.glow[1]},${pal.glow[2]},${0.55 * t})`;
        ctx!.shadowBlur = 16 * t;
      }
      ctx!.fillStyle = fill;
      ctx!.strokeStyle = stroke;
      ctx!.lineWidth = 1;
      octPath(ctx!, c.x, c.y - lift, rx, ry);
      ctx!.fill();
      ctx!.stroke();
      ctx!.restore();
    }

    function loop(now: number) {
      if (!running) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      // Ambient energy (boosted near the final CTA).
      energy += (gridRuntime.targetEnergy - energy) * Math.min(1, 2 * dt);

      // Reset targets, then apply influences.
      for (const i of activeSet) cells[i].target = 0;

      if (pointerActive && !reduced) {
        const col0 = Math.max(0, Math.floor((px - R - ox) / P));
        const col1 = Math.min(cols - 1, Math.ceil((px + R - ox) / P));
        const row0 = Math.max(0, Math.floor((py - R - oy) / P));
        const row1 = Math.min(rows - 1, Math.ceil((py + R - oy) / P));
        for (let row = row0; row <= row1; row++) {
          for (let col = col0; col <= col1; col++) {
            const i = row * cols + col;
            const c = cells[i];
            const d = Math.hypot(c.x - px, c.y - py);
            if (d < R) {
              const w = 1 - d / R;
              let t = w * w * 0.42; // neighbor falloff
              if (d < P * 0.55) t = 1; // cell under the cursor
              if (t > c.target) c.target = t;
              activeSet.add(i);
            }
          }
        }
      } else if (pointerActive && reduced) {
        // Reduced motion: gentle tint only, no flip.
        const col0 = Math.max(0, Math.floor((px - R * 0.8 - ox) / P));
        const col1 = Math.min(cols - 1, Math.ceil((px + R * 0.8 - ox) / P));
        const row0 = Math.max(0, Math.floor((py - R * 0.8 - oy) / P));
        const row1 = Math.min(rows - 1, Math.ceil((py + R * 0.8 - oy) / P));
        for (let row = row0; row <= row1; row++) {
          for (let col = col0; col <= col1; col++) {
            const i = row * cols + col;
            const c = cells[i];
            const d = Math.hypot(c.x - px, c.y - py);
            const rad = R * 0.8;
            if (d < rad) {
              const w = 1 - d / rad;
              const t = Math.max(w * 0.3, d < P * 0.55 ? 0.75 : 0);
              if (t > c.target) c.target = t;
              activeSet.add(i);
            }
          }
        }
      }

      // Ambient shimmer when the environment is "energized".
      if (!reduced && energy > 0.16) {
        const s = (Math.sin(now * 0.0011) + 1) / 2;
        for (const i of shimmerCells) {
          const c = cells[i];
          const t = energy * (0.16 + 0.2 * ((Math.sin(now * 0.0011 + c.phase * 62.8) + 1) / 2)) * (0.6 + 0.4 * s);
          if (t > c.target) c.target = t;
          activeSet.add(i);
        }
      }

      // Birth sweep — the environment "wakes up" after the splash.
      if (!reduced && activeRef.current && !birthStarted) {
        birthStarted = true;
        birthT = 0;
      }
      if (!reduced && birthStarted && birthT < 1) {
        birthT = Math.min(1, birthT + dt / 1.9);
        const ring = birthT * maxDist;
        const band = P * 2.1;
        for (let i = 0; i < cells.length; i++) {
          const c = cells[i];
          const dd = Math.abs(c.dist - ring);
          if (dd < band) {
            const t = (1 - dd / band) * 0.7;
            if (t > c.target) c.target = t;
            activeSet.add(i);
          }
        }
      }

      // Integrate activations.
      const k = reduced ? 9 : 13;
      const f = Math.min(1, k * dt);
      for (const i of [...activeSet]) {
        const c = cells[i];
        c.a += (c.target - c.a) * f;
        if (c.a < 0.004 && c.target <= 0.0005) {
          c.a = 0;
          activeSet.delete(i);
        }
      }

      // Draw.
      ctx!.clearRect(0, 0, W, H);
      if (base) ctx!.drawImage(base, 0, 0, W, H);
      for (const i of activeSet) {
        const c = cells[i];
        if (c.a > 0.006) drawCell(c);
      }

      raf = requestAnimationFrame(loop);
    }

    build();
    raf = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.clearTimeout(resizeTimer);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      window.removeEventListener("blur", clearPointer);
      document.removeEventListener("mouseleave", clearPointer);
      window.removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [theme]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0"
    />
  );
}
