import { useCommunications } from "../../lib/communicationsStore";
import { timeLabel } from "../../data/communicationsData";
import { BellIcon } from "../icons";

export default function NotificationPopover({ open, onClose, onNavigate }: { open: boolean; onClose: () => void; onNavigate: (tab: string) => void }) {
  const { state, unread, setNotifications, updateNotification } = useCommunications();
  if (!open) return null;
  const items = state.notifications.filter((n) => !n.is_archived && !n.deleted).slice(0, 5);
  return <><div className="fixed inset-0 z-40" onClick={onClose} /><div className="panel-in absolute right-0 top-12 z-50 w-[min(380px,calc(100vw-2rem))] border border-[var(--border-strong)] bg-[var(--surface-solid)] shadow-2xl">
    <div className="flex items-center justify-between border-b border-[var(--border)] p-3.5"><h2 className="display text-sm font-bold">Notifications <span className="font-mono text-xs text-[var(--blue)]">{unread} unread</span></h2><button onClick={() => setNotifications((rows) => rows.map((n) => ({ ...n, is_read: true, read_at: n.read_at || new Date().toISOString() })))} className="font-mono text-[10px] text-[var(--blue)]">Mark all read</button></div>
    <div className="max-h-[360px] divide-y divide-[var(--border)] overflow-y-auto">{items.length ? items.map((n) => <button key={n.id} onClick={() => { updateNotification(n.id, { is_read: true, read_at: new Date().toISOString() }); onNavigate(n.related_entity?.tab || "announcements"); onClose(); }} className="flex w-full gap-3 p-3 text-left hover:bg-[var(--surface-2)]"><BellIcon className="mt-0.5 h-4 w-4 shrink-0 text-[var(--blue)]" /><span className="min-w-0"><span className="block text-xs font-semibold text-[var(--text)]">{n.title}{!n.is_read && <span className="ml-2 inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />}</span><span className="mt-1 block text-[11px] leading-relaxed text-[var(--text-2)]">{n.message}</span><span className="mt-1 block font-mono text-[10px] text-[var(--text-3)]">{timeLabel(n.created_at)} · {n.source_type}</span></span></button>) : <p className="p-6 text-center text-xs text-[var(--text-3)]">All caught up.</p>}</div>
    <button onClick={() => { onNavigate("announcements"); onClose(); }} className="w-full border-t border-[var(--border)] p-3 font-mono text-[11px] text-[var(--blue)] hover:bg-[var(--blue-soft)]">Open Communication Centre →</button>
  </div></>;
}
