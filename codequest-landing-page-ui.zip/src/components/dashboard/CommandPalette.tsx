import { useEffect, useMemo, useState } from "react";
import { cn } from "../../utils/cn";
import {
  coursesData,
  practiceProblemsList,
  competitionsData,
  announcementsData,
} from "../../data/dashboardData";
import {
  BookOpenIcon,
  CodeIcon,
  TrophyIcon,
  MegaphoneIcon,
  SearchIcon,
  SparklesIcon,
  CloseIcon,
} from "../icons";

type SearchItem = {
  id: string;
  category: "PRACTICE" | "COURSE" | "COMPETITION" | "UPDATE" | "ACTION";
  title: string;
  sub: string;
  targetTab: string;
  meta?: string;
};

export default function CommandPalette({
  open,
  onClose,
  onNavigate,
}: {
  open: boolean;
  onClose: () => void;
  onNavigate: (tab: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);

  const allItems: SearchItem[] = useMemo(() => {
    const list: SearchItem[] = [
      {
        id: "action-daily",
        category: "ACTION",
        title: "Solve Daily Challenge: Two Sum II",
        sub: "+50 XP · Keep 7-day flame streak alive",
        targetTab: "daily-practice",
        meta: "Quick Action",
      },
      {
        id: "action-tutor",
        category: "ACTION",
        title: "Ask AI Tutor a question",
        sub: "Concept visualizer, call stack diagrams & debugging",
        targetTab: "ai-tutor",
        meta: "AI Workspace",
      },
      {
        id: "action-r1",
        category: "ACTION",
        title: "Season 01 Round 1 Qualifier Arena",
        sub: "Starts in 4 days · 4 problems · Verified students",
        targetTab: "competitions",
        meta: "Tournament",
      },
      ...practiceProblemsList.map((p) => ({
        id: p.id,
        category: "PRACTICE" as const,
        title: p.title,
        sub: `${p.category} · ${p.difficulty} · ${p.points} pts`,
        targetTab: "practice",
        meta: p.acceptanceRate,
      })),
      ...coursesData.map((c) => ({
        id: c.id,
        category: "COURSE" as const,
        title: c.title,
        sub: `${c.track} · ${c.progressPercent}% completed (${c.currentLessonTitle})`,
        targetTab: "courses",
        meta: c.difficulty,
      })),
      ...competitionsData.map((comp) => ({
        id: comp.id,
        category: "COMPETITION" as const,
        title: comp.name,
        sub: `${comp.status} · ${comp.duration} · ${comp.participantsCount} competitors`,
        targetTab: "competitions",
        meta: comp.category,
      })),
      ...announcementsData.map((a) => ({
        id: a.id,
        category: "UPDATE" as const,
        title: a.title,
        sub: `${a.date} · ${a.importance}`,
        targetTab: "announcements",
        meta: a.category,
      })),
    ];
    return list;
  }, []);

  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim();
    if (!q) return allItems.slice(0, 8);
    return allItems
      .filter(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          item.sub.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q)
      )
      .slice(0, 10);
  }, [query, allItems]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelectedIndex((idx) => (idx + 1) % Math.max(1, filtered.length));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelectedIndex((idx) => (idx - 1 + filtered.length) % Math.max(1, filtered.length));
      } else if (e.key === "Enter" && filtered[selectedIndex]) {
        e.preventDefault();
        onNavigate(filtered[selectedIndex].targetTab);
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, filtered, selectedIndex, onNavigate, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-start justify-center bg-black/60 p-4 pt-16 backdrop-blur-sm sm:p-6 sm:pt-24"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Global search command palette"
    >
      <div
        className="panel-in clip-oct w-full max-w-2xl border border-[var(--border-strong)] bg-[var(--surface-solid)] shadow-[0_24px_50px_rgba(0,0,0,0.45)]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search header */}
        <div className="flex items-center gap-3 border-b border-[var(--border)] px-4 py-3.5 sm:px-5">
          <SearchIcon className="h-5 w-5 text-[var(--blue)]" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search problems, courses, competitions, AI prompts, updates..."
            className="flex-1 bg-transparent text-sm text-[var(--text)] placeholder:text-[var(--text-3)] focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="text-[var(--text-3)] transition-colors hover:text-[var(--text)]"
            >
              <CloseIcon className="h-4 w-4" />
            </button>
          )}
          <span className="clip-oct-sm hidden border border-[var(--border-strong)] bg-[var(--surface-2)] px-2 py-0.5 font-mono text-[10px] text-[var(--text-3)] sm:inline-block">
            ESC
          </span>
        </div>

        {/* Results list */}
        <div className="max-h-[60vh] overflow-y-auto p-2 sm:p-3">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-sm text-[var(--text-3)]">
              No results matching "{query}". Try searching for <span className="text-[var(--blue)]">"recursion"</span>, <span className="text-[var(--blue)]">"two sum"</span>, or <span className="text-[var(--blue)]">"round 1"</span>.
            </div>
          ) : (
            <div className="space-y-1">
              {filtered.map((item, idx) => {
                const active = idx === selectedIndex;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.targetTab);
                      onClose();
                    }}
                    onMouseEnter={() => setSelectedIndex(idx)}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-none border px-3.5 py-2.5 text-left transition-colors duration-150",
                      active
                        ? "border-[var(--blue)] bg-[var(--blue-soft)]"
                        : "border-transparent hover:border-[var(--border)] hover:bg-[var(--surface-2)]"
                    )}
                  >
                    <span
                      className={cn(
                        "clip-oct-sm flex h-8 w-8 shrink-0 items-center justify-center border transition-colors",
                        active
                          ? "border-[var(--blue)] bg-[var(--blue)] text-white"
                          : "border-[var(--border-strong)] bg-[var(--surface-2)] text-[var(--text-2)]"
                      )}
                    >
                      {item.category === "ACTION" && <SparklesIcon className="h-4 w-4" />}
                      {item.category === "PRACTICE" && <CodeIcon className="h-4 w-4" />}
                      {item.category === "COURSE" && <BookOpenIcon className="h-4 w-4" />}
                      {item.category === "COMPETITION" && <TrophyIcon className="h-4 w-4" />}
                      {item.category === "UPDATE" && <MegaphoneIcon className="h-4 w-4" />}
                    </span>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate text-xs font-semibold text-[var(--text)] sm:text-sm">
                          {item.title}
                        </span>
                        {item.meta && (
                          <span className="hidden font-mono text-[10px] text-[var(--text-3)] sm:inline-block">
                            · {item.meta}
                          </span>
                        )}
                      </div>
                      <p className="truncate text-[11px] text-[var(--text-2)]">{item.sub}</p>
                    </div>

                    <span className="font-mono text-[10px] tracking-wider text-[var(--text-3)]">
                      {item.category}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="flex items-center justify-between border-t border-[var(--border)] px-4 py-2.5 font-mono text-[10.5px] text-[var(--text-3)]">
          <span className="flex items-center gap-3">
            <span>↑↓ to navigate</span>
            <span>↵ to select</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
            CodeQuest Command
          </span>
        </div>
      </div>
    </div>
  );
}
