import { useEffect, useState, type ReactNode } from "react";
import { cn } from "../../utils/cn";
import { Link, navigate } from "../../lib/router";
import { currentStudent } from "../../data/dashboardData";
import { questions } from "../../data/practiceData";
import { useCommunications } from "../../lib/communicationsStore";
import { ThemeToggle, Wordmark } from "../Navbar";
import {
  LayoutDashboardIcon,
  BookOpenIcon,
  CalendarCheckIcon,
  CodeIcon,
  SparklesIcon,
  TrophyIcon,
  UploadCloudIcon,
  UsersIcon,
  MegaphoneIcon,
  SettingsIcon,
  UserIcon,
  SearchIcon,
  BellIcon,
  SidebarCollapseIcon,
  CloseIcon,
  MenuIcon,
  LogoMark,
  GraduationCapIcon,
  MapRouteIcon,
  PlayIcon,
} from "../icons";
import CommandPalette from "./CommandPalette";
import NotificationPopover from "./NotificationPopover";

export type NavItem = {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  category: "OVERVIEW" | "LEARN" | "COMPETE" | "COMMUNITY" | "UPDATES" | "ACCOUNT";
};

export const navItems: NavItem[] = [
  { id: "overview", label: "Dashboard", icon: LayoutDashboardIcon, category: "OVERVIEW" },
  { id: "courses", label: "Academy", icon: GraduationCapIcon, badge: "Courses", category: "LEARN" },
  { id: "path", label: "My Learning Path", icon: MapRouteIcon, category: "LEARN" },
  { id: "continue", label: "Continue Learning", icon: PlayIcon, category: "LEARN" },
  { id: "daily-practice", label: "Daily Practice", icon: CalendarCheckIcon, badge: `${questions.length} live`, category: "LEARN" },
  { id: "practice", label: "Practice", icon: CodeIcon, category: "LEARN" },
  { id: "ai-tutor", label: "AI Tutor", icon: SparklesIcon, badge: "Studio", category: "LEARN" },
  { id: "competitions", label: "Competitions", icon: TrophyIcon, badge: "1 Live", category: "COMPETE" },
  { id: "submissions", label: "Submissions", icon: UploadCloudIcon, category: "COMPETE" },
  { id: "hub", label: "Student Hub", icon: UsersIcon, badge: "3 Unread", category: "COMMUNITY" },
  { id: "announcements", label: "Announcements", icon: MegaphoneIcon, category: "UPDATES" },
  { id: "settings", label: "Settings", icon: SettingsIcon, category: "ACCOUNT" },
  { id: "profile", label: "Profile", icon: UserIcon, category: "ACCOUNT" },
];

const categoryLabels: { key: NavItem["category"]; label: string }[] = [
  { key: "OVERVIEW", label: "OVERVIEW" },
  { key: "LEARN", label: "LEARN" },
  { key: "COMPETE", label: "COMPETE" },
  { key: "COMMUNITY", label: "COMMUNITY" },
  { key: "UPDATES", label: "UPDATES" },
];

export default function DashboardShell({
  activeTab,
  onTabChange,
  children,
}: {
  activeTab: string;
  onTabChange: (tabId: string) => void;
  children: ReactNode;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const { unread } = useCommunications();

  // Global Ctrl+K / Cmd+K shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const activeItem = navItems.find((n) => n.id === activeTab) || navItems[0];

  const handleSelectTab = (id: string) => {
    onTabChange(id);
    setMobileDrawerOpen(false);
  };

  return (
    <div className="flex min-h-screen bg-[var(--bg)] text-[var(--text)]">
      {/* ---------------- DESKTOP SIDEBAR ---------------- */}
      <aside
        className={cn(
          "sticky top-0 z-30 hidden h-screen flex-col border-r border-[var(--border)] bg-[var(--sidebar)] transition-all duration-300 md:flex",
          collapsed ? "w-[72px]" : "w-[256px]"
        )}
      >
        {/* Brand header */}
        <div className="flex h-14 items-center justify-between border-b border-[var(--border)] px-4">
          {!collapsed ? (
            <div className="flex items-center gap-2">
              <Wordmark />
              <span className="clip-oct-sm border border-[var(--blue)]/50 bg-[var(--blue-soft)] px-1.5 py-0.5 font-mono text-[9px] font-bold text-[var(--blue)]">
                STUDENT
              </span>
            </div>
          ) : (
            <div className="mx-auto">
              <LogoMark className="h-6 w-6 text-[var(--blue)]" />
            </div>
          )}
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-2.5 py-3">
          {categoryLabels.map(({ key, label }) => {
            const items = navItems.filter((item) => item.category === key);
            return (
              <div key={key} className="mb-4">
                {!collapsed && (
                  <p className="mono-label px-2.5 pb-1.5 text-[10px] font-semibold tracking-[0.2em] text-[var(--text-3)]">
                    {label}
                  </p>
                )}
                <div className="space-y-0.5">
                  {items.map((item) => {
                    const active = activeTab === item.id;
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleSelectTab(item.id)}
                        title={collapsed ? item.label : undefined}
                        className={cn(
                          "group relative flex w-full items-center gap-3 border px-2.5 py-2 font-display text-[13px] font-medium transition-all duration-150",
                          active
                            ? "border-[var(--blue)]/60 bg-[var(--blue-soft)] text-[var(--text)] shadow-[inset_0_1px_0_rgba(255,255,255,0.05)]"
                            : "border-transparent text-[var(--text-2)] hover:border-[var(--border)] hover:bg-[var(--surface-2)] hover:text-[var(--text)]",
                          collapsed && "justify-center px-0 py-2.5"
                        )}
                      >
                        {/* Active octagon marker */}
                        {active && (
                          <span
                            className={cn(
                              "absolute left-0 top-1/2 -translate-y-1/2 bg-[var(--blue)]",
                              collapsed ? "h-5 w-1" : "h-4 w-1"
                            )}
                          />
                        )}

                        <Icon
                          className={cn(
                            "h-4 w-4 shrink-0 transition-colors",
                            active ? "text-[var(--blue)]" : "text-[var(--text-3)] group-hover:text-[var(--text)]"
                          )}
                        />

                        {!collapsed && (
                          <span className="flex-1 text-left">{item.label}</span>
                        )}

                        {!collapsed && (item.badge || (item.id === "announcements" && unread > 0)) && (
                          <span
                            className={cn(
                              "clip-oct-sm px-1.5 py-0.2 font-mono text-[9.5px] tracking-wide",
                              active
                                ? "bg-[var(--blue)] text-white"
                                : "bg-[var(--surface-2)] text-[var(--text-3)] group-hover:text-[var(--text-2)]"
                            )}
                          >
                            {item.id === "announcements" ? `${unread} New` : item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom account items & Collapse toggle */}
        <div className="border-t border-[var(--border)] p-2">
          <div className="space-y-0.5">
            {navItems
              .filter((i) => i.category === "ACCOUNT")
              .map((item) => {
                const active = activeTab === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    title={collapsed ? item.label : undefined}
                    className={cn(
                      "group flex w-full items-center gap-3 border px-2.5 py-1.5 font-display text-[12.5px] transition-colors",
                      active
                        ? "border-[var(--blue)]/50 bg-[var(--blue-soft)] text-[var(--text)]"
                        : "border-transparent text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--text)]",
                      collapsed && "justify-center px-0"
                    )}
                  >
                    <Icon className="h-4 w-4 text-[var(--text-3)] group-hover:text-[var(--text)]" />
                    {!collapsed && <span>{item.label}</span>}
                  </button>
                );
              })}
          </div>

          <button
            onClick={() => setCollapsed((v) => !v)}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className={cn(
              "mt-2 flex w-full items-center gap-2 border border-transparent px-2.5 py-1.5 font-mono text-[11px] text-[var(--text-3)] transition-colors hover:border-[var(--border)] hover:bg-[var(--surface-2)] hover:text-[var(--text)]",
              collapsed && "justify-center px-0"
            )}
          >
            <SidebarCollapseIcon
              className={cn("h-4 w-4 transition-transform", collapsed && "rotate-180")}
            />
            {!collapsed && <span>Collapse rail</span>}
          </button>
        </div>
      </aside>

      {/* ---------------- MAIN WRAPPER ---------------- */}
      <div className="flex flex-1 flex-col overflow-hidden pb-16 md:pb-0">
        {/* TOP BAR */}
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-[var(--border)] bg-[var(--sidebar)]/95 px-4 backdrop-blur-md sm:px-6">
          {/* Left: Mobile hamburger + breadcrumb context */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileDrawerOpen(true)}
              aria-label="Open navigation drawer"
              className="clip-oct-sm flex h-9 w-9 items-center justify-center border border-[var(--border)] text-[var(--text)] md:hidden"
            >
              <MenuIcon className="h-4 w-4" />
            </button>

            <div className="flex items-center gap-2 font-mono text-[12px]">
              <span className="hidden text-[var(--text-3)] sm:inline">
                {activeItem.category} /
              </span>
              <span className="flex items-center gap-1.5 font-semibold text-[var(--text)]">
                <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
                {activeItem.label}
              </span>
            </div>
          </div>

          {/* Right: Search + Notifications + Theme + Profile */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Search command trigger */}
            <button
              onClick={() => setSearchOpen(true)}
              className="clip-oct-sm flex items-center gap-2.5 border border-[var(--border)] bg-[var(--surface-2)] px-2.5 py-1.5 text-xs text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--text)] sm:px-3"
            >
              <SearchIcon className="h-3.5 w-3.5 text-[var(--blue)]" />
              <span className="hidden sm:inline">Search arena...</span>
              <kbd className="hidden rounded bg-[var(--surface-solid)] px-1.5 py-0.5 font-mono text-[10px] text-[var(--text-3)] md:inline-block">
                ⌘K
              </kbd>
            </button>

            {/* Notification bell popover */}
            <div className="relative">
              <button
                onClick={() => setNotifOpen((v) => !v)}
                aria-label="Notifications"
                className="clip-oct-sm relative flex h-9 w-9 items-center justify-center border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--text)]"
              >
                <BellIcon className="h-4 w-4" />
                {unread > 0 && <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-[var(--blue)] font-mono text-[9px] font-bold text-white shadow-[0_0_8px_var(--glow)]">{unread}</span>}
              </button>
              <NotificationPopover
                open={notifOpen}
                onClose={() => setNotifOpen(false)}
                onNavigate={(t) => handleSelectTab(t)}
              />
            </div>

            <ThemeToggle />

            {/* Profile Avatar menu */}
            <div className="relative">
              <button
                onClick={() => setProfileMenuOpen((v) => !v)}
                aria-label="User profile menu"
                className="clip-oct-sm relative flex h-9 items-center gap-2 border border-[var(--border)] bg-[var(--surface-2)] px-2 transition-colors hover:border-[var(--blue)]"
              >
                <div className="clip-oct-sm flex h-6 w-6 items-center justify-center bg-[var(--blue)] font-display text-[11px] font-bold text-white">
                  {currentStudent.avatarText}
                </div>
                <span className="hidden font-display text-xs font-semibold sm:inline">
                  Farid B.
                </span>
                <span className="h-1.5 w-1.5 rounded-full bg-[#5DD39E]" title="Online" />
              </button>

              {profileMenuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40 bg-transparent"
                    onClick={() => setProfileMenuOpen(false)}
                  />
                  <div className="panel-in clip-oct absolute right-0 top-12 z-50 w-56 border border-[var(--border-strong)] bg-[var(--surface-solid)] p-2 shadow-[0_16px_36px_rgba(0,0,0,0.4)]">
                    <div className="border-b border-[var(--border)] p-2.5">
                      <p className="font-display text-sm font-bold">{currentStudent.name}</p>
                      <p className="font-mono text-[10.5px] text-[var(--text-3)]">
                        {currentStudent.school}
                      </p>
                      <p className="mt-1 font-mono text-[10px] text-[var(--blue)]">
                        Level {currentStudent.level} Explorer · {currentStudent.xp} XP
                      </p>
                    </div>

                    <div className="py-1">
                      <button
                        onClick={() => {
                          handleSelectTab("profile");
                          setProfileMenuOpen(false);
                        }}
                        className="flex w-full items-center gap-2.5 px-3 py-1.5 text-xs text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--text)]"
                      >
                        <UserIcon className="h-3.5 w-3.5" />
                        View Profile
                      </button>
                      <button
                        onClick={() => {
                          handleSelectTab("overview");
                          setProfileMenuOpen(false);
                        }}
                        className="flex w-full items-center gap-2.5 px-3 py-1.5 text-xs text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--text)]"
                      >
                        <TrophyIcon className="h-3.5 w-3.5" />
                        My Progress
                      </button>
                      <button
                        onClick={() => {
                          handleSelectTab("settings");
                          setProfileMenuOpen(false);
                        }}
                        className="flex w-full items-center gap-2.5 px-3 py-1.5 text-xs text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--text)]"
                      >
                        <SettingsIcon className="h-3.5 w-3.5" />
                        Settings
                      </button>
                    </div>

                    <div className="border-t border-[var(--border)] pt-1">
                      <button
                        onClick={() => {
                          setProfileMenuOpen(false);
                          navigate("/");
                        }}
                        className="flex w-full items-center gap-2.5 px-3 py-1.5 text-xs text-red-400 hover:bg-red-500/10"
                      >
                        Sign Out
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* MAIN PAGE CONTENT SLOT */}
        <main
          className={cn(
            "flex-1 min-h-0 flex flex-col",
            activeTab === "practice" ? "overflow-hidden p-0" : "overflow-y-auto p-4 sm:p-6 lg:p-8"
          )}
        >
          {children}
        </main>
      </div>

      {/* ---------------- MOBILE DRAWER ---------------- */}
      {mobileDrawerOpen && (
        <div
          className="fixed inset-0 z-50 flex bg-black/60 backdrop-blur-sm md:hidden"
          onClick={() => setMobileDrawerOpen(false)}
        >
          <div
            className="panel-in flex h-full w-[280px] flex-col border-r border-[var(--border)] bg-[var(--sidebar)] p-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
              <Wordmark />
              <button
                onClick={() => setMobileDrawerOpen(false)}
                className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] text-[var(--text-2)]"
              >
                <CloseIcon className="h-4 w-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-3">
              {categoryLabels.map(({ key, label }) => {
                const items = navItems.filter((i) => i.category === key);
                return (
                  <div key={key} className="mb-4">
                    <p className="mono-label px-2 pb-1 text-[10px] text-[var(--text-3)]">
                      {label}
                    </p>
                    <div className="space-y-1">
                      {items.map((item) => {
                        const active = activeTab === item.id;
                        const Icon = item.icon;
                        return (
                          <button
                            key={item.id}
                            onClick={() => handleSelectTab(item.id)}
                            className={cn(
                              "flex w-full items-center gap-3 border px-3 py-2 text-xs font-medium transition-colors",
                              active
                                ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]"
                                : "border-transparent text-[var(--text-2)] hover:bg-[var(--surface-2)]"
                            )}
                          >
                            <Icon className="h-4 w-4" />
                            <span className="flex-1 text-left">{item.label}</span>
                            {(item.badge || (item.id === "announcements" && unread > 0)) && (
                              <span className="clip-oct-sm bg-[var(--surface-2)] px-1.5 py-0.5 font-mono text-[9px]">
                                {item.id === "announcements" ? `${unread} New` : item.badge}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="border-t border-[var(--border)] pt-3">
              <Link
                to="/"
                className="mono-label block py-2 text-center text-xs text-[var(--text-3)] hover:text-[var(--blue)]"
              >
                ← Exit to Landing Page
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* ---------------- MOBILE BOTTOM NAVIGATION ---------------- */}
      <nav className="fixed inset-x-0 bottom-0 z-30 flex h-14 items-center justify-around border-t border-[var(--border)] bg-[var(--surface-solid)]/95 backdrop-blur-md md:hidden">
        {[
          { id: "overview", label: "Home", icon: LayoutDashboardIcon },
          { id: "courses", label: "Learn", icon: BookOpenIcon },
          { id: "competitions", label: "Compete", icon: TrophyIcon },
          { id: "ai-tutor", label: "Tutor", icon: SparklesIcon },
          { id: "hub", label: "Hub", icon: UsersIcon },
        ].map((item) => {
          const active = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => handleSelectTab(item.id)}
              className={cn(
                "flex flex-col items-center gap-0.5 py-1 text-[10px] font-medium transition-colors",
                active ? "text-[var(--blue)]" : "text-[var(--text-3)]"
              )}
            >
              <Icon className="h-4 w-4" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Global Command Palette */}
      <CommandPalette
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        onNavigate={(tab) => handleSelectTab(tab)}
      />
    </div>
  );
}
