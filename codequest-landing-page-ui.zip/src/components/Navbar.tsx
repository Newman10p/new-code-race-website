import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { Link, parseRoute, useRoute } from "../lib/router";
import { useTheme } from "../lib/theme";
import { navLinks } from "../data";
import { CloseIcon, LogoMark, MenuIcon, MoonIcon, SunIcon } from "./icons";
import { ButtonLink } from "./ui";

export function ThemeToggle({ className }: { className?: string }) {
  const { theme, toggle } = useTheme();
  return (
    <button
      onClick={toggle}
      aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
      className={cn(
        "clip-oct-sm relative flex h-9 w-9 items-center justify-center border border-[var(--border-strong)] bg-[var(--surface-2)] text-[var(--text-2)] transition-all duration-300 hover:border-[var(--blue)] hover:text-[var(--blue)]",
        className
      )}
    >
      <SunIcon
        className={cn(
          "absolute h-[17px] w-[17px] transition-all duration-500",
          theme === "dark" ? "scale-100 rotate-0 opacity-100" : "scale-50 -rotate-90 opacity-0"
        )}
      />
      <MoonIcon
        className={cn(
          "absolute h-[17px] w-[17px] transition-all duration-500",
          theme === "light" ? "scale-100 rotate-0 opacity-100" : "scale-50 rotate-90 opacity-0"
        )}
      />
    </button>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <Link to="/" className={cn("group flex items-center gap-2.5", className)}>
      <LogoMark className="h-6 w-6 text-[var(--text)] transition-transform duration-500 group-hover:rotate-45" />
      <span className="display text-[15px] font-bold tracking-[0.08em]">
        CODE<span className="text-[var(--blue)]">QUEST</span>
      </span>
    </Link>
  );
}

export default function Navbar() {
  const route = useRoute();
  const { path } = parseRoute(route);
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => setOpen(false), [path]);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-400",
          scrolled
            ? "border-b border-[var(--border)] bg-[var(--nav-bg)] backdrop-blur-md"
            : "border-b border-transparent bg-transparent"
        )}
      >
        <div
          className={cn(
            "mx-auto flex max-w-7xl items-center justify-between px-5 transition-all duration-300 sm:px-8",
            scrolled ? "h-14" : "h-[72px]"
          )}
        >
          <Wordmark />

          {/* Desktop nav */}
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Main">
            {navLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className={cn(
                  "nav-link text-[13.5px] font-semibold tracking-wide text-[var(--text-2)]",
                  path === l.to && "is-active"
                )}
              >
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2.5">
            <ThemeToggle />
            <ButtonLink to="/login" variant="ghost" size="sm" className="hidden sm:inline-flex">
              Sign In
            </ButtonLink>
            <ButtonLink to="/login?mode=join" size="sm" className="hidden sm:inline-flex">
              Join CodeQuest
            </ButtonLink>
            <button
              className="clip-oct-sm flex h-9 w-9 items-center justify-center border border-[var(--border-strong)] text-[var(--text)] lg:hidden"
              onClick={() => setOpen(true)}
              aria-label="Open menu"
            >
              <MenuIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        className={cn(
          "fixed inset-0 z-[60] flex flex-col bg-[var(--bg)]/97 backdrop-blur-lg transition-all duration-400 lg:hidden",
          open ? "visible opacity-100" : "invisible opacity-0"
        )}
        aria-hidden={!open}
      >
        <div className="flex h-[72px] items-center justify-between px-5 sm:px-8">
          <Wordmark />
          <button
            className="clip-oct-sm flex h-9 w-9 items-center justify-center border border-[var(--border-strong)] text-[var(--text)]"
            onClick={() => setOpen(false)}
            aria-label="Close menu"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex flex-1 flex-col justify-center gap-2 px-8" aria-label="Mobile">
          {navLinks.map((l, i) => (
            <Link
              key={l.to}
              to={l.to}
              onClick={() => setOpen(false)}
              style={{ transitionDelay: open ? `${120 + i * 70}ms` : "0ms" }}
              className={cn(
                "display border-b border-[var(--border)] py-4 text-3xl font-bold uppercase tracking-tight transition-all duration-500",
                open ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0",
                path === l.to ? "text-[var(--blue)]" : "text-[var(--text)]"
              )}
            >
              <span className="mono-label mr-3 inline-block align-middle">0{i + 1}</span>
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex flex-col gap-3 px-8 pb-10">
          <ButtonLink to="/login?mode=join" size="lg" className="w-full" onClick={() => setOpen(false)}>
            Join CodeQuest
          </ButtonLink>
          <ButtonLink to="/login" variant="ghost" size="lg" className="w-full" onClick={() => setOpen(false)}>
            Sign In
          </ButtonLink>
        </div>
      </div>
    </>
  );
}
