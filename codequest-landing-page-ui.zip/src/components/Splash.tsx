import { useEffect, useRef, useState } from "react";
import { prefersReducedMotion } from "../lib/grid";
import { cn } from "../utils/cn";

const OCTS = [
  { top: "12%", left: "14%", size: 18, delay: 0.15 },
  { top: "22%", left: "82%", size: 12, delay: 0.3 },
  { top: "74%", left: "10%", size: 12, delay: 0.42 },
  { top: "80%", left: "86%", size: 20, delay: 0.24 },
  { top: "38%", left: "6%", size: 10, delay: 0.55 },
  { top: "58%", left: "92%", size: 10, delay: 0.6 },
  { top: "14%", left: "55%", size: 9, delay: 0.5 },
  { top: "86%", left: "40%", size: 11, delay: 0.65 },
];

const WORD = "CODEQUEST".split("");

export default function Splash({ onDone }: { onDone: () => void }) {
  const [exiting, setExiting] = useState(false);
  const reduced = prefersReducedMotion();
  const total = reduced ? 650 : 2350;
  const doneRef = useRef(false);

  useEffect(() => {
    const t1 = window.setTimeout(() => {
      setExiting(true);
    }, total);
    const t2 = window.setTimeout(() => {
      if (!doneRef.current) {
        doneRef.current = true;
        onDone();
      }
    }, total + 480);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [total, onDone]);

  const skip = () => {
    setExiting(true);
    window.setTimeout(() => {
      if (!doneRef.current) {
        doneRef.current = true;
        onDone();
      }
    }, 260);
  };

  return (
    <div
      onClick={skip}
      className={cn(
        "fixed inset-0 z-[100] flex cursor-pointer flex-col items-center justify-center bg-[var(--bg)] transition-opacity duration-500",
        exiting && "pointer-events-none opacity-0"
      )}
      role="status"
      aria-label="CodeQuest loading"
    >
      {/* Ambient octagons */}
      {OCTS.map((o, i) => (
        <span
          key={i}
          aria-hidden="true"
          style={{
            top: o.top,
            left: o.left,
            width: o.size,
            height: o.size,
            animation: reduced ? "none" : `cq-splash-oct 0.7s ${o.delay}s cubic-bezier(0.22,1,0.36,1) both`,
          }}
          className="clip-oct-sm absolute border border-[var(--border-strong)] opacity-0"
        />
      ))}

      {/* Wordmark */}
      <div
        className="flex overflow-hidden"
        style={{ transform: reduced ? undefined : "translateY(0)" }}
      >
        {WORD.map((ch, i) => (
          <span
            key={i}
            style={{
              animation: reduced
                ? "none"
                : `cq-splash-letter 0.65s ${0.35 + i * 0.05}s cubic-bezier(0.22,1,0.36,1) both`,
            }}
            className={cn(
              "display text-4xl font-bold tracking-[-0.04em] sm:text-6xl",
              i < 4 ? "text-[var(--text)]" : "text-[var(--blue)]",
              reduced && "opacity-100"
            )}
          >
            {ch}
          </span>
        ))}
      </div>

      {/* Blue sweep line */}
      <div className="relative mt-5 h-px w-56 overflow-visible sm:w-80" aria-hidden="true">
        <div
          className="h-px w-full origin-left bg-[var(--blue)] shadow-[0_0_12px_var(--glow)]"
          style={{
            transform: reduced ? "scaleX(1)" : "scaleX(0)",
            animation: reduced ? "none" : "cq-sweep 0.7s 1.15s cubic-bezier(0.65,0,0.35,1) both",
          }}
        />
      </div>

      {/* Tagline */}
      <p
        className="mono-label mt-6"
        style={{
          opacity: reduced ? 1 : 0,
          animation: reduced ? "none" : "cq-rise 0.6s 1.55s ease both",
        }}
      >
        Think. Build. Compete.
      </p>

      {/* Corner meta */}
      <p
        className="mono-label absolute bottom-6 left-6 hidden opacity-70 sm:block"
        style={{ animation: reduced ? "none" : "cq-rise 0.6s 1.7s ease both" }}
      >
        Grid :: boot sequence
      </p>
      <p
        className="mono-label absolute bottom-6 right-6 hidden opacity-70 sm:block"
        style={{ animation: reduced ? "none" : "cq-rise 0.6s 1.7s ease both" }}
      >
        Season 01
      </p>

      {/* Skip hint */}
      {!reduced && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            skip();
          }}
          className="mono-label absolute bottom-6 left-1/2 -translate-x-1/2 cursor-pointer opacity-0 transition-colors hover:text-[var(--blue)]"
          style={{ animation: "cq-rise 0.5s 1.9s ease both" }}
        >
          Click to skip
        </button>
      )}
    </div>
  );
}
