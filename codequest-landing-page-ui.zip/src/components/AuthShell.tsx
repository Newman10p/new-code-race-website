import type { ReactNode } from "react";
import { Link } from "../lib/router";
import { Wordmark } from "./Navbar";
import { OctagonFrame } from "./icons";

export const fieldCls =
  "w-full border border-[var(--border-strong)] bg-[var(--surface-2)] px-4 py-3 text-sm text-[var(--text)] placeholder:text-[var(--text-3)] transition-colors duration-200 focus:border-[var(--blue)] focus:outline-none";

const stats = [
  { n: "500+", l: "Students" },
  { n: "20+", l: "Schools" },
  { n: "6", l: "Rounds" },
];

/**
 * Shared split layout for the CodeQuest gateway pages:
 * brand rail on the left, form on the right.
 */
export default function AuthShell({
  eyebrow,
  title,
  lede,
  footnote,
  children,
}: {
  eyebrow: string;
  title: ReactNode;
  lede: string;
  footnote: string;
  children: ReactNode;
}) {
  return (
    <div className="relative z-10 mx-auto flex min-h-[100svh] max-w-6xl flex-col justify-center px-5 py-28 sm:px-8 md:py-32">
      {/* Mobile chrome (desktop branding lives in the rail) */}
      <div className="mb-7 flex items-center justify-between md:hidden">
        <span className="mono-label flex items-center gap-2.5">
          <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />
          Secure gateway
        </span>
        <Link
          to="/"
          className="mono-label transition-colors hover:text-[var(--blue)]"
        >
          Exit →
        </Link>
      </div>

      <div className="panel clip-oct grid w-full overflow-hidden md:grid-cols-[1.04fr_1fr]">
        {/* Brand rail */}
        <aside className="relative hidden flex-col justify-between overflow-hidden border-r border-[var(--border)] bg-[var(--surface-2)] p-10 md:flex">
          {/* Decorative octagon outlines */}
          <OctagonFrame className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 text-[var(--border)]" />
          <OctagonFrame className="pointer-events-none absolute -right-6 top-40 h-28 w-28 text-[var(--border-strong)]" />
          <OctagonFrame className="pointer-events-none absolute -bottom-14 -left-12 h-44 w-44 text-[var(--border)]" />

          <div className="relative">
            <Wordmark />
          </div>

          <div className="relative my-8">
            <p className="mono-label mb-5 flex items-center gap-3 text-[var(--blue)]">
              <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
              {eyebrow}
            </p>
            <h1 className="display max-w-[15ch] text-[2.15rem] font-bold uppercase leading-[1.06] tracking-tight">
              {title}
            </h1>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-[var(--text-2)]">
              {lede}
            </p>
          </div>

          <div className="relative">
            <div className="grid grid-cols-3 gap-4 border-t border-[var(--border)] pt-6">
              {stats.map((s) => (
                <div key={s.l}>
                  <p className="display text-2xl font-bold tracking-tight text-[var(--text)]">
                    {s.n}
                  </p>
                  <p className="mono-label mt-1 text-[10px]">{s.l}</p>
                </div>
              ))}
            </div>
            <p className="mono-label mt-6 flex items-center gap-2.5 text-[10px]">
              <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />
              {footnote}
            </p>
          </div>
        </aside>

        {/* Form side */}
        <div className="p-6 sm:p-9 md:p-11">{children}</div>
      </div>

      <p className="mono-label mt-5 text-center text-[10px] opacity-60">
        CodeQuest secure gateway :: frontend preview
      </p>
    </div>
  );
}
