import { useEffect, useState } from "react";
import { cn } from "./utils/cn";
import { ThemeProvider, useTheme } from "./lib/theme";
import { parseRoute, useRoute } from "./lib/router";
import { prefersReducedMotion } from "./lib/grid";
import OctagonCanvas from "./components/OctagonCanvas";
import Splash from "./components/Splash";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Timeline from "./pages/Timeline";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Gallery from "./pages/Gallery";
import Privacy from "./pages/Privacy";
import ForgotPassword from "./pages/ForgotPassword";
import Login from "./pages/Login";
import DevDock from "./components/DevDock";
import UserDashboard from "./pages/dashboard/UserDashboard";
import OrganizerDashboard from "./pages/dashboard/OrganizerDashboard";
import AdminDashboard from "./pages/dashboard/AdminDashboard";
import { isDashboardPath } from "./lib/dashboards";

function Shell() {
  const { theme } = useTheme();
  const route = useRoute();
  const { path } = parseRoute(route);
  const [splashDone, setSplashDone] = useState(false);
  const isDash = isDashboardPath(path);
  /* The Hub is a dedicated environment — it renders without the dashboard
     shell so only one navigation sidebar is ever visible. */
  const isHub = path.startsWith("/dashboard/user/hub");

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [path]);

  let page;
  if (path === "/dashboard" || path.startsWith("/dashboard/user")) {
    page = <UserDashboard />;
  } else if (path.startsWith("/dashboard/organizer")) {
    page = <OrganizerDashboard />;
  } else if (path.startsWith("/dashboard/admin")) {
    page = <AdminDashboard />;
  } else {
    switch (path) {
      case "/timeline":
        page = <Timeline />;
        break;
      case "/about":
        page = <About />;
        break;
      case "/contact":
        page = <Contact />;
        break;
      case "/gallery":
        page = <Gallery />;
        break;
      case "/privacy":
        page = <Privacy />;
        break;
      case "/forgot-password":
      case "/forgot":
        page = <ForgotPassword />;
        break;
      case "/login":
      case "/sign-in":
        page = <Login />;
        break;
      default:
        page = <Home />;
    }
  }

  return (
    <div className="relative min-h-screen bg-[var(--bg)]">
      {/* The environmental grid dims further inside the dashboard so it
          never competes with information density. */}
      <div className={cn("contents", isDash && "[&>canvas]:opacity-[0.62]")}>
        <OctagonCanvas theme={theme} active={splashDone} />
      </div>
      {!splashDone && <Splash onDone={() => setSplashDone(true)} />}
      {!isDash && <Navbar />}
      {splashDone && (
        <main
          key={path}
          className={cn("relative z-10", !prefersReducedMotion() && !isHub && "page-in")}
        >
          {page}
        </main>
      )}
      {splashDone &&
        !isDash &&
        !["/login", "/sign-in", "/forgot-password", "/forgot"].includes(path) && <Footer />}
      {splashDone && <DevDock />}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <Shell />
    </ThemeProvider>
  );
}
