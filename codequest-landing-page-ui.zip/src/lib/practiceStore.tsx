import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  archiveStats,
  missionConfig,
  questionById,
  questions as seedQuestions,
  type Question,
  type QuestionStatus,
  type QuestionTest,
} from "../data/practiceData";
import { currentStudent } from "../data/dashboardData";

/** Single source of truth for the student's lifetime XP (shared with the main dashboard). */
const baseXp = currentStudent.xp;

/* ══════════════════ GRADING ENGINE ══════════════════ */

export type TestOutcome = {
  name: string;
  hidden: boolean;
  weight: number;
  status: "pass" | "fail" | "error";
  input: string;
  expected: string;
  actual: string;
  ms: number;
  error?: string;
};

export type GradeReport = {
  kind: "executed";
  outcomes: TestOutcome[];
  passed: number;
  total: number;
  fraction: number;
  accepted: boolean;
  awardedXp: number;
  potentialXp: number;
  durationMs: number;
  compileError?: string;
  mode: "run" | "submit";
};

export type OfflineReport = {
  kind: "offline";
  language: string;
  runnable: string[];
};

const fmt = (v: unknown) => {
  if (v === undefined) return "undefined";
  try {
    return JSON.stringify(v);
  } catch {
    return String(v);
  }
};

/**
 * Each test gets a fresh copy of its inputs. Questions are allowed to solve
 * in-place (that is often the point), so reusing the fixture array would let a
 * second run grade against corrupted data.
 */
function cloneArgs(args: unknown[]): unknown[] {
  return args.map((a) => {
    if (a === null || typeof a !== "object") return a;
    try {
      return typeof structuredClone === "function"
        ? structuredClone(a)
        : JSON.parse(JSON.stringify(a));
    } catch {
      return a;
    }
  });
}

const fmtArgs = (args: unknown[]) =>
  args
    .map((a) => {
      const s = fmt(a);
      return s === undefined ? "undefined" : s.length > 64 ? `${s.slice(0, 61)}…` : s;
    })
    .join(", ");

/**
 * Executes the student's JavaScript against the question's own test cases and
 * derives the score from the configured marking weights. Verdicts are real
 * evaluation output — never a placeholder — so partial credit is meaningful.
 */
function execute(code: string, tests: QuestionTest[]): GradeReport {
  const t0 = performance.now();
  let solve: ((...a: unknown[]) => unknown) | null = null;
  let compileError: string | undefined;

  try {
    // eslint-disable-next-line no-new-func
    const factory = new Function(`"use strict";\n${code}\n;return typeof solve === "function" ? solve : null;`);
    solve = factory() as never;
  } catch (e) {
    compileError = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
  }

  if (compileError || !solve) {
    return {
      kind: "executed",
      outcomes: [],
      passed: 0,
      total: tests.length,
      fraction: 0,
      accepted: false,
      awardedXp: 0,
      potentialXp: 0,
      durationMs: performance.now() - t0,
      compileError:
        compileError ?? "No callable `solve` found — define a top-level function named solve.",
      mode: "run",
    };
  }

  const outcomes: TestOutcome[] = tests.map((t) => {
    const start = performance.now();
    const args = cloneArgs(t.args);
    try {
      const actual = (solve as (...a: unknown[]) => unknown)(...args);
      const ms = performance.now() - start;
      const pass = fmt(actual) === fmt(t.expected);
      return {
        name: t.name,
        hidden: Boolean(t.hidden),
        weight: t.weight,
        status: pass ? "pass" : "fail",
        input: fmtArgs(args),
        expected: fmt(t.expected),
        actual: fmt(actual),
        ms,
      };
    } catch (e) {
      return {
        name: t.name,
        hidden: Boolean(t.hidden),
        weight: t.weight,
        status: "error",
        input: fmtArgs(t.args),
        expected: fmt(t.expected),
        actual: "—",
        ms: performance.now() - start,
        error: e instanceof Error ? `${e.name}: ${e.message}` : String(e),
      };
    }
  });

  const passed = outcomes.filter((o) => o.status === "pass").length;
  const earnedWeight = outcomes.reduce((s, o) => s + (o.status === "pass" ? o.weight : 0), 0);
  const totalWeight = outcomes.reduce((s, o) => s + o.weight, 0) || 1;
  const fraction = earnedWeight / totalWeight;
  const accepted = passed === outcomes.length && outcomes.length > 0;

  return {
    kind: "executed",
    outcomes,
    passed,
    total: outcomes.length,
    fraction,
    accepted,
    awardedXp: 0,
    potentialXp: 0,
    durationMs: performance.now() - t0,
    mode: "run",
  };
}

/* ══════════════════ STATE ══════════════════ */

export type RecentAttempt = {
  questionId: string;
  title: string;
  status: string;
  score: string;
  last: string;
  percent: number;
};

type PracticeCtx = {
  questions: Question[];
  statuses: Record<string, QuestionStatus>;
  attempts: Record<string, number>;
  best: Record<string, number>;
  stats: { solved: number; practiceXp: number; successRate: number; streakDays: number };
  totalXp: number;
  level: number;
  rank: { position: number; board: RankRow[]; gapToNext: number | null };
  mission: { label: string; target: number; progress: number; bonusXp: number; source: string; window: string };
  recent: RecentAttempt[];
  grade: (q: Question, code: string, language: string, mode: "run" | "submit") => GradeReport | OfflineReport;
  recordSubmission: (q: Question, report: GradeReport) => void;
  reset: () => void;
};

const Ctx = createContext<PracticeCtx | null>(null);

const seedStatuses = (): Record<string, QuestionStatus> =>
  Object.fromEntries(seedQuestions.map((q) => [q.id, q.status]));
const seedAttempts = (): Record<string, number> =>
  Object.fromEntries(seedQuestions.map((q) => [q.id, q.attempts]));
const seedBest = (): Record<string, number> =>
  Object.fromEntries(seedQuestions.filter((q) => q.bestPercent).map((q) => [q.id, q.bestPercent!]));

type RankRow = { name: string; xp: number; you?: boolean; rank?: number };

const RIVAL_ROWS = [
  { name: "Ayaan K.", xp: 3120 },
  { name: "Sarah K.", xp: 2985 },
  { name: "Meera D.", xp: 2892 },
  { name: "Imran K.", xp: 2760 },
];

const XP_PER_LEVEL = 250;

export function PracticeProvider({ children }: { children: ReactNode }) {
  const [statuses, setStatuses] = useState<Record<string, QuestionStatus>>(seedStatuses);
  const [attempts, setAttempts] = useState<Record<string, number>>(seedAttempts);
  const [best, setBest] = useState<Record<string, number>>(seedBest);
  const [solved, setSolved] = useState(archiveStats.solved);
  const [practiceXp, setPracticeXp] = useState(archiveStats.practiceXp);
  const [totalXp, setTotalXp] = useState<number>(baseXp);
  const [missionProgress, setMissionProgress] = useState(missionConfig.progress);
  const [recent, setRecent] = useState<RecentAttempt[]>([
    { questionId: "infinite-queue", title: "The Infinite Queue", status: "Completed", score: "40 XP", last: "Today", percent: 100 },
    { questionId: "disappearing-transactions", title: "The Disappearing Transactions", status: "Needs another pass", score: "11 XP", last: "Today", percent: 55 },
    { questionId: "decode-message", title: "Decode the Hidden Message", status: "In Progress", score: "—", last: "Yesterday", percent: 55 },
    { questionId: "last-file-standing", title: "The Last File Standing", status: "Needs another pass", score: "14 XP", last: "2 days ago", percent: 62 },
  ]);

  const grade = useCallback(
    (q: Question, code: string, language: string, mode: "run" | "submit"): GradeReport | OfflineReport => {
      if (!q.localRunner.includes(language)) {
        return { kind: "offline", language, runnable: q.localRunner };
      }
      const pool = mode === "run" ? q.tests.filter((t) => !t.hidden) : q.tests;
      const report = execute(code, pool);
      const potential = q.points;
      // Partial credit: weighted at 80%, and only from 50% coverage upward.
      const awarded =
        mode === "submit"
          ? report.accepted
            ? potential
            : report.fraction >= 0.5
            ? Math.round(potential * report.fraction * 0.8)
            : 0
          : 0;
      return { ...report, mode, awardedXp: awarded, potentialXp: potential };
    },
    []
  );

  const recordSubmission = useCallback(
    (q: Question, report: GradeReport) => {
      const nextStatus: QuestionStatus = report.accepted
        ? "COMPLETED"
        : report.fraction > 0
        ? "ATTEMPT AGAIN"
        : "IN PROGRESS";

      // Integrity: a question already banked cannot be farmed for repeat XP.
      const wasCompleted = statuses[q.id] === "COMPLETED";
      const counts = report.accepted && !wasCompleted;
      const xpDelta = wasCompleted && report.accepted ? 0 : report.awardedXp;

      setStatuses((prev) => ({ ...prev, [q.id]: nextStatus }));
      setAttempts((prev) => ({ ...prev, [q.id]: (prev[q.id] ?? 0) + 1 }));
      setBest((prev) => ({ ...prev, [q.id]: Math.max(prev[q.id] ?? 0, Math.round(report.fraction * 100)) }));

      if (xpDelta > 0) {
        setPracticeXp((v) => v + xpDelta);
        setTotalXp((v) => v + xpDelta);
      }
      if (counts) {
        setSolved((v) => v + 1);
        setMissionProgress((v) => Math.min(missionConfig.target, v + 1));
      }

      setRecent((prev) => [
        {
          questionId: q.id,
          title: q.title,
          status: report.accepted
            ? wasCompleted
              ? "Completed again"
              : "Completed"
            : report.fraction > 0
            ? "Partial credit"
            : "No points awarded",
          score: xpDelta > 0 ? `${xpDelta} XP` : "—",
          last: "Just now",
          percent: Math.round(report.fraction * 100),
        },
        ...prev.filter((r) => r.questionId !== q.id),
      ]);
    },
    [statuses]
  );

  const reset = useCallback(() => {
    setStatuses(seedStatuses());
    setAttempts(seedAttempts());
    setBest(seedBest());
    setSolved(archiveStats.solved);
    setPracticeXp(archiveStats.practiceXp);
    setTotalXp(baseXp);
    setMissionProgress(missionConfig.progress);
  }, []);

  const rank = useMemo(() => {
    const rows: RankRow[] = [
      ...RIVAL_ROWS.map((r) => ({ name: r.name, xp: r.xp })),
      { name: currentStudent.name, xp: totalXp, you: true },
    ];
    rows.sort((a, b) => b.xp - a.xp);
    const position = rows.findIndex((r) => r.you === true) + 1;
    const above = rows
      .filter((r) => !r.you && r.xp > totalXp)
      .sort((a, b) => a.xp - b.xp)[0];
    return {
      position,
      board: rows.map((r, i) => ({ ...r, rank: i + 1 })) as RankRow[],
      gapToNext: above ? above.xp - totalXp : null,
    };
  }, [totalXp]);

  const value = useMemo<PracticeCtx>(
    () => ({
      questions: seedQuestions,
      statuses,
      attempts,
      best,
      stats: {
        solved,
        practiceXp,
        successRate: archiveStats.successRate,
        streakDays: archiveStats.streakDays,
      },
      totalXp,
      level: Math.floor(totalXp / XP_PER_LEVEL) + 1,
      rank,
      mission: { ...missionConfig, progress: missionProgress },
      recent,
      grade,
      recordSubmission,
      reset,
    }),
    [statuses, attempts, best, solved, practiceXp, totalXp, rank, missionProgress, recent, grade, recordSubmission, reset]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function usePractice(): PracticeCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("usePractice must be used inside PracticeProvider");
  return ctx;
}

export const getQuestion = questionById;
