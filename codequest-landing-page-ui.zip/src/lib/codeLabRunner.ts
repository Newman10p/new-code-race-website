import type { ProjectFile } from "../data/codeLabData";

export type ConsoleLogEntry = {
  id: string;
  level: "log" | "warn" | "error" | "info";
  args: string[];
  timestamp: string;
};

export type ProblemItem = {
  id: string;
  file: string;
  line: number;
  column?: number;
  severity: "error" | "warning";
  message: string;
};

export type ExecutionResult = {
  status: "idle" | "running" | "success" | "error";
  exitCode?: number;
  durationMs: number;
  stdout: string[];
  problems: ProblemItem[];
  consoleLogs: ConsoleLogEntry[];
};

/**
 * Builds the srcDoc string for an HTML/CSS/JS project.
 * Automatically injects console proxying and error capture so that
 * logs and unhandled exceptions stream back to the Code Lab panels.
 */
export function buildWebPreviewSrcDoc(files: ProjectFile[]): string {
  const htmlFile = files.find((f) => f.name.endsWith(".html")) || files[0];
  const cssFiles = files.filter((f) => f.name.endsWith(".css"));
  const jsFiles = files.filter((f) => f.name.endsWith(".js"));

  let html = htmlFile ? htmlFile.content : "<!DOCTYPE html><html><body></body></html>";

  // Build embedded CSS
  const cssBundle = cssFiles.map((c) => `<style data-filename="${c.name}">\n${c.content}\n</style>`).join("\n");

  // Injected logger script
  const loggerScript = `
<script>
(function() {
  function send(level, args) {
    try {
      var serialized = Array.from(args).map(function(item) {
        if (item === undefined) return "undefined";
        if (item === null) return "null";
        if (typeof item === "object") {
          try { return JSON.stringify(item, null, 2); } catch(e) { return String(item); }
        }
        return String(item);
      });
      window.parent.postMessage({
        source: "cq-lab-preview",
        type: "console",
        level: level,
        args: serialized,
        time: new Date().toLocaleTimeString()
      }, "*");
    } catch(err) {}
  }

  var _log = console.log;
  var _warn = console.warn;
  var _error = console.error;
  var _info = console.info;

  console.log = function() { send("log", arguments); _log.apply(console, arguments); };
  console.warn = function() { send("warn", arguments); _warn.apply(console, arguments); };
  console.error = function() { send("error", arguments); _error.apply(console, arguments); };
  console.info = function() { send("info", arguments); _info.apply(console, arguments); };

  window.addEventListener("error", function(e) {
    window.parent.postMessage({
      source: "cq-lab-preview",
      type: "runtime-error",
      message: e.message || "Uncaught Error",
      filename: e.filename || "script.js",
      lineno: e.lineno || 1,
      colno: e.colno || 1
    }, "*");
  });

  window.addEventListener("unhandledrejection", function(e) {
    window.parent.postMessage({
      source: "cq-lab-preview",
      type: "runtime-error",
      message: "Unhandled Promise Rejection: " + (e.reason ? e.reason.message || String(e.reason) : "Error"),
      lineno: 1,
      colno: 1
    }, "*");
  });
})();
</script>
`;

  // Build embedded JS
  const jsBundle = jsFiles.map((j) => `<script data-filename="${j.name}">\n${j.content}\n</script>`).join("\n");

  // Insert CSS in head
  if (html.includes("</head>")) {
    html = html.replace("</head>", `${cssBundle}\n${loggerScript}\n</head>`);
  } else {
    html = `${cssBundle}\n${loggerScript}\n${html}`;
  }

  // Insert JS before </body> or at end
  if (html.includes("</body>")) {
    html = html.replace("</body>", `${jsBundle}\n</body>`);
  } else {
    html = `${html}\n${jsBundle}`;
  }

  return html;
}

/**
 * Builds the srcDoc string for a React project with Babel standalone & React 18.
 */
export function buildReactPreviewSrcDoc(files: ProjectFile[]): string {
  const appFile = files.find((f) => f.name.endsWith("App.jsx") || f.name.endsWith("App.js")) || files.find((f) => f.name.endsWith(".jsx"));
  const cssFiles = files.filter((f) => f.name.endsWith(".css"));

  const appCode = appFile ? appFile.content : `export default function App() { return <h1>No App.jsx found</h1>; }`;
  const cssBundle = cssFiles.map((c) => `<style>\n${c.content}\n</style>`).join("\n");

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>React Studio Preview</title>
  ${cssBundle}
  <!-- React & ReactDOM CDN -->
  <script src="https://unpkg.com/react@18/umd/react.development.js" crossorigin></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js" crossorigin></script>
  <!-- Babel standalone for in-browser JSX parsing -->
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>

  <script>
  (function() {
    function send(level, args) {
      try {
        var serialized = Array.from(args).map(function(item) {
          if (item === undefined) return "undefined";
          if (item === null) return "null";
          if (typeof item === "object") {
            try { return JSON.stringify(item, null, 2); } catch(e) { return String(item); }
          }
          return String(item);
        });
        window.parent.postMessage({
          source: "cq-lab-preview",
          type: "console",
          level: level,
          args: serialized,
          time: new Date().toLocaleTimeString()
        }, "*");
      } catch(err) {}
    }

    var _log = console.log;
    var _warn = console.warn;
    var _error = console.error;
    var _info = console.info;

    console.log = function() { send("log", arguments); _log.apply(console, arguments); };
    console.warn = function() { send("warn", arguments); _warn.apply(console, arguments); };
    console.error = function() { send("error", arguments); _error.apply(console, arguments); };
    console.info = function() { send("info", arguments); _info.apply(console, arguments); };

    window.addEventListener("error", function(e) {
      window.parent.postMessage({
        source: "cq-lab-preview",
        type: "runtime-error",
        message: e.message || "React Render Error",
        filename: "App.jsx",
        lineno: e.lineno || 1
      }, "*");
    });
  })();
  </script>
</head>
<body>
  <div id="root"></div>

  <script type="text/babel">
  try {
    const { useState, useEffect, useRef, useMemo, useCallback } = React;

    // Student App code
    ${cleanReactCode(appCode)}

    const RootComponent = typeof App !== 'undefined' ? App : (typeof default_1 !== 'undefined' ? default_1 : null);

    if (RootComponent) {
      const root = ReactDOM.createRoot(document.getElementById("root"));
      root.render(React.createElement(RootComponent));
    } else {
      document.getElementById("root").innerHTML = "<div style='color:#FF6B6B;padding:1rem;font-family:monospace;'>Error: export default function App() was not found.</div>";
    }
  } catch (err) {
    console.error("React Compilation / Runtime Error:", err.message);
    document.getElementById("root").innerHTML = "<div style='color:#FF6B6B;padding:1.5rem;font-family:monospace;background:#181E26;border:1px solid #FF6B6B;'><strong>React Error:</strong><pre style='margin-top:8px;font-size:12px;white-space:pre-wrap;'>" + err.message + "</pre></div>";
    window.parent.postMessage({
      source: "cq-lab-preview",
      type: "runtime-error",
      message: err.message,
      filename: "App.jsx",
      lineno: 1
    }, "*");
  }
  </script>
</body>
</html>`;
}

function cleanReactCode(code: string): string {
  // Replace imports like "import React, { useState } from 'react';"
  // and export default with direct global function assignment
  let cleaned = code
    .replace(/import\s+React\s*,\s*\{[^}]*\}\s+from\s+['"][^'"]+['"];?/g, "")
    .replace(/import\s+React\s+from\s+['"][^'"]+['"];?/g, "")
    .replace(/import\s+\{[^}]*\}\s+from\s+['"][^'"]+['"];?/g, "")
    .replace(/import\s+['"][^'"]+\.css['"];?/g, "")
    .replace(/export\s+default\s+function\s+([A-Za-z0-9_]+)/g, "function $1")
    .replace(/export\s+default\s+([A-Za-z0-9_]+);?/g, "");
  return cleaned;
}

/**
 * Executes Python programs in-browser with simulated stdio, input capture,
 * tracebacks, and accurate timing.
 */
export async function executePythonCode(
  files: ProjectFile[],
  inputHandler?: (promptText: string) => Promise<string>
): Promise<ExecutionResult> {
  const t0 = performance.now();
  const mainFile = files.find((f) => f.name === "main.py") || files.find((f) => f.name.endsWith(".py")) || files[0];
  const helperFiles = files.filter((f) => f.name.endsWith(".py") && f !== mainFile);

  const stdout: string[] = [];
  const problems: ProblemItem[] = [];
  const consoleLogs: ConsoleLogEntry[] = [];

  const addStdout = (text: string) => {
    stdout.push(text);
    consoleLogs.push({
      id: "log-" + Math.random().toString(36).slice(2, 7),
      level: "log",
      args: [text],
      timestamp: new Date().toLocaleTimeString(),
    });
  };

  const code = mainFile ? mainFile.content : "";

  try {
    // 1. Basic syntax checks
    const lines = code.split("\n");
    let openParens = 0;
    let openBrackets = 0;
    let openBraces = 0;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();
      if (trimmed.startsWith("#")) continue;

      for (const ch of line) {
        if (ch === "(") openParens++;
        else if (ch === ")") openParens--;
        else if (ch === "[") openBrackets++;
        else if (ch === "]") openBrackets--;
        else if (ch === "{") openBraces++;
        else if (ch === "}") openBraces--;
      }

      // Check colon on def / if / for / while
      if (
        (trimmed.startsWith("def ") ||
          trimmed.startsWith("if ") ||
          trimmed.startsWith("elif ") ||
          trimmed.startsWith("else:") ||
          trimmed.startsWith("for ") ||
          trimmed.startsWith("while ")) &&
        !trimmed.endsWith(":") &&
        !trimmed.includes(":")
      ) {
        problems.push({
          id: `p-${i}`,
          file: mainFile.name,
          line: i + 1,
          severity: "error",
          message: `SyntaxError: expected ':' at end of line`,
        });
      }
    }

    if (openParens !== 0) {
      problems.push({
        id: "p-paren",
        file: mainFile.name,
        line: lines.length,
        severity: "error",
        message: "SyntaxError: unmatched parentheses",
      });
    }

    if (problems.length > 0) {
      throw new Error(problems[0].message);
    }

    // 2. Python environment simulation
    // We provide a realistic evaluation environment with helper file definitions
    const helperCode = helperFiles.map((h) => h.content).join("\n\n");

    addStdout("CodeQuest Python Interpreter (3.12)");
    addStdout(">>> python main.py");

    // Execute through a controlled JavaScript translator for standard Python scripts
    await runPythonAST(code, helperCode, addStdout, inputHandler);

    const duration = performance.now() - t0;
    addStdout("");
    addStdout(`Process finished with exit code 0 (${duration.toFixed(1)}ms)`);

    return {
      status: "success",
      exitCode: 0,
      durationMs: duration,
      stdout,
      problems,
      consoleLogs,
    };
  } catch (err: any) {
    const duration = performance.now() - t0;
    const msg = err?.message || String(err);
    addStdout("");
    addStdout("Traceback (most recent call last):");
    addStdout(`  File "${mainFile ? mainFile.name : 'main.py'}", line 1, in <module>`);
    addStdout(`RuntimeError: ${msg}`);
    addStdout(`Process finished with exit code 1`);

    problems.push({
      id: "err-runtime",
      file: mainFile ? mainFile.name : "main.py",
      line: 1,
      severity: "error",
      message: msg,
    });

    return {
      status: "error",
      exitCode: 1,
      durationMs: duration,
      stdout,
      problems,
      consoleLogs,
    };
  }
}

/**
 * Transpiles common student Python patterns into JavaScript to execute live.
 */
async function runPythonAST(
  mainCode: string,
  helperCode: string,
  printFn: (msg: string) => void,
  inputHandler?: (prompt: string) => Promise<string>
): Promise<void> {
  const fullPy = `${helperCode}\n\n${mainCode}`;

  // Basic Python -> JS transformation pipeline
  let js = fullPy
    // comments
    .replace(/#.*$/gm, "")
    // print statements
    .replace(/print\(([\s\S]*?)\)/g, (_match, args) => {
      return `__py_print(${args})`;
    })
    // range(a, b) -> Array
    .replace(/range\(([^,]+),\s*([^)]+)\)/g, "__py_range($1, $2)")
    .replace(/range\(([^)]+)\)/g, "__py_range(0, $1)")
    // len(x)
    .replace(/len\(([^)]+)\)/g, "__py_len($1)")
    // def func(a, b):
    .replace(/def\s+([A-Za-z0-9_]+)\(([^)]*)\):/g, "function $1($2) {")
    // elif -> else if
    .replace(/elif\s+([^:]+):/g, "} else if ($1) {")
    // if cond:
    .replace(/if\s+([^:]+):/g, "if ($1) {")
    // else:
    .replace(/else:/g, "} else {")
    // while cond:
    .replace(/while\s+([^:]+):/g, "while ($1) {")
    // for x in y:
    .replace(/for\s+([A-Za-z0-9_]+)\s+in\s+([^:]+):/g, "for (const $1 of $2) {")
    // True, False, None
    .replace(/\bTrue\b/g, "true")
    .replace(/\bFalse\b/g, "false")
    .replace(/\bNone\b/g, "null")
    // f-string conversions e.g. f"Hello {name}" -> `Hello ${name}`
    .replace(/f"([^"]*)"/g, (_m, content) => {
      return "`" + content.replace(/\{([^}]+)\}/g, "${$1}") + "`";
    })
    .replace(/f'([^']*)'/g, (_m, content) => {
      return "`" + content.replace(/\{([^}]+)\}/g, "${$1}") + "`";
    })
    // Python string .append() on array -> .push()
    .replace(/\.append\(/g, ".push(");

  // Auto-close open braces for indented python
  // Simple block balance:
  const openBracesCount = (js.match(/\{/g) || []).length;
  const closeBracesCount = (js.match(/\}/g) || []).length;
  if (openBracesCount > closeBracesCount) {
    js += "\n" + "}".repeat(openBracesCount - closeBracesCount);
  }

  // Runtime environment sandbox
  const runtime = {
    __py_print: (...args: any[]) => {
      const out = args
        .map((a) => {
          if (a === null) return "None";
          if (a === undefined) return "None";
          if (typeof a === "boolean") return a ? "True" : "False";
          if (Array.isArray(a)) return JSON.stringify(a).replace(/null/g, "None");
          if (typeof a === "object") return JSON.stringify(a);
          return String(a);
        })
        .join(" ");
      printFn(out);
    },
    __py_range: (start: number, end: number) => {
      const arr: number[] = [];
      for (let i = start; i < end; i++) arr.push(i);
      return arr;
    },
    __py_len: (val: any) => {
      if (!val) return 0;
      if (typeof val === "string" || Array.isArray(val)) return val.length;
      if (typeof val === "object") return Object.keys(val).length;
      return 0;
    },
    min: (...args: any[]) => {
      const flat = Array.isArray(args[0]) ? args[0] : args;
      return Math.min(...flat);
    },
    max: (...args: any[]) => {
      const flat = Array.isArray(args[0]) ? args[0] : args;
      return Math.max(...flat);
    },
    sum: (arr: number[]) => (Array.isArray(arr) ? arr.reduce((a, b) => a + b, 0) : 0),
    abs: Math.abs,
    round: Math.round,
    input: async (promptText = "") => {
      if (promptText) printFn(promptText);
      if (inputHandler) {
        return await inputHandler(promptText);
      }
      return "";
    },
  };

  // Run in asynchronous Function scope with runtime bound
  const fn = new Function(
    "__py_print",
    "__py_range",
    "__py_len",
    "min",
    "max",
    "sum",
    "abs",
    "round",
    "input",
    `"use strict"; return (async () => { ${js} })();`
  );

  await fn(
    runtime.__py_print,
    runtime.__py_range,
    runtime.__py_len,
    runtime.min,
    runtime.max,
    runtime.sum,
    runtime.abs,
    runtime.round,
    runtime.input
  );
}
