import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  competitionById,
  makeReference,
  seedProjects,
  type CommunityComment,
  type FileMeta,
  type Project,
} from "../data/submissionsData";

/**
 * Every channel action returns a Result. A failed validation never mutates
 * state, so the UI cannot show a failed submission as successful.
 */
export type Result = { ok: true; reference?: string; at?: string } | { ok: false; error: string };

const KEY = "cq-submissions-v1";

function load(): Project[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as Project[];
  } catch {
    /* fall through to seed */
  }
  return seedProjects;
}

type Ctx = {
  projects: Project[];
  createProject: (competitionId: string) => string;
  updateDraft: (id: string, patch: Partial<Pick<Project, "title" | "summary" | "problem" | "solution" | "technologies" | "team" | "extra" | "links" | "videoUrl">>) => void;
  addFile: (id: string, file: FileMeta) => Result;
  removeFile: (id: string, fileId: string) => Result;
  submitToPatron: (id: string, message: string) => Result;
  submitToJudges: (id: string, changes: string) => Result;
  publishShowcase: (id: string, description: string) => Result;
  unpublishShowcase: (id: string) => Result;
  updateShowcase: (id: string, patch: { description?: string; commentsEnabled?: boolean }) => void;
  toggleReaction: (id: string) => void;
  addComment: (id: string, comment: Omit<CommunityComment, "id" | "at" | "helpful" | "replies">, parentId?: string) => void;
  markHelpful: (id: string, commentId: string) => void;
  reportComment: (id: string, commentId: string) => void;
  deleteDraft: (id: string) => void;
  resetDemo: () => void;
};

const SubmissionContext = createContext<Ctx | null>(null);

/** Is this project's official channel currently locked? */
export function judgingLock(p: Project): string | null {
  const c = competitionById(p.competitionId);
  if (!c?.config.judging.enabled) return "Official judging is not enabled for this competition.";
  if (Date.now() > new Date(c.config.judging.deadline).getTime()) return "The judging deadline has passed.";
  const submittedCount = p.versions.filter((v) => v.destination === "judges").length;
  if (submittedCount > 0 && !c.config.judging.resubmission) return "This competition does not allow resubmission.";
  if (submittedCount >= c.config.judging.maxVersions) return `The ${c.config.judging.maxVersions}-version submission limit has been reached.`;
  if (c.config.patron.required && !["REVIEW COMPLETED", "FEEDBACK AVAILABLE"].includes(p.patron.status)) {
    return "This competition requires a completed patron review before official submission.";
  }
  return null;
}

function mapComments(list: CommunityComment[], id: string, fn: (c: CommunityComment) => CommunityComment): CommunityComment[] {
  return list.map((c) => (c.id === id ? fn(c) : { ...c, replies: mapComments(c.replies, id, fn) }));
}

export function SubmissionProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>(load);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(projects));
    } catch {
      /* storage unavailable */
    }
  }, [projects]);

  const patch = useCallback((id: string, fn: (p: Project) => Project) => {
    setProjects((ps) => ps.map((p) => (p.id === id ? fn(p) : p)));
  }, []);

  const find = useCallback((id: string) => projects.find((p) => p.id === id), [projects]);

  const createProject = useCallback((competitionId: string) => {
    const id = `proj-${Date.now()}`;
    const now = new Date().toISOString();
    const fresh: Project = {
      id, competitionId, title: "Untitled project", summary: "", problem: "", solution: "",
      technologies: [], team: ["Farid Bulega"], extra: "", links: [], videoUrl: "", files: [], updatedAt: now,
      versions: [{ no: 1, createdAt: now, submittedAt: null, destination: "draft", reference: null, changes: "Project created", snapshot: { title: "Untitled project", summary: "", files: 0 } }],
      patron: { status: "NOT SUBMITTED", message: "", timeline: [] },
      judging: { status: "NOT SUBMITTED", reference: null, submittedAt: null, versionNo: null, timeline: [] },
      showcase: { published: false, publishedAt: null, description: "", commentsEnabled: true, reactions: 0, reacted: false, comments: [] },
    };
    setProjects((ps) => [fresh, ...ps]);
    return id;
  }, []);

  /** Edits always land in the current draft version; submitted versions are frozen. */
  const updateDraft: Ctx["updateDraft"] = useCallback((id, changes) => {
    patch(id, (p) => {
      const now = new Date().toISOString();
      const last = p.versions[p.versions.length - 1];
      const versions = last.destination === "draft"
        ? p.versions
        : [...p.versions, { no: last.no + 1, createdAt: now, submittedAt: null, destination: "draft" as const, reference: null, changes: "Working draft", snapshot: { title: p.title, summary: p.summary, files: p.files.length } }];
      return { ...p, ...changes, updatedAt: now, versions };
    });
  }, [patch]);

  const addFile = useCallback((id: string, file: FileMeta): Result => {
    const p = find(id);
    const c = p && competitionById(p.competitionId);
    if (!p || !c) return { ok: false, error: "Project not found." };
    if (!c.config.files.types.includes(file.ext)) return { ok: false, error: `.${file.ext} files are not permitted. Allowed: ${c.config.files.types.join(", ")}.` };
    if (file.size > c.config.files.maxMb * 1_000_000) return { ok: false, error: `${file.name} exceeds the ${c.config.files.maxMb} MB limit.` };
    if (p.files.length >= c.config.files.maxFiles) return { ok: false, error: `This competition allows at most ${c.config.files.maxFiles} files.` };
    if (p.files.some((f) => f.name === file.name)) return { ok: false, error: `${file.name} is already attached.` };
    updateDraft(id, {});
    patch(id, (pp) => ({ ...pp, files: [...pp.files, file] }));
    return { ok: true };
  }, [find, patch, updateDraft]);

  const removeFile = useCallback((id: string, fileId: string): Result => {
    updateDraft(id, {});
    patch(id, (p) => ({ ...p, files: p.files.filter((f) => f.id !== fileId) }));
    return { ok: true };
  }, [patch, updateDraft]);

  const freezeDraft = (p: Project, destination: "patron" | "judges", reference: string, at: string, changes: string) => {
    const last = p.versions[p.versions.length - 1];
    const frozen = { no: last.destination === "draft" ? last.no : last.no + 1, createdAt: last.destination === "draft" ? last.createdAt : at, submittedAt: at, destination, reference, changes: changes || last.changes, snapshot: { title: p.title, summary: p.summary, files: p.files.length } };
    return last.destination === "draft" ? [...p.versions.slice(0, -1), frozen] : [...p.versions, frozen];
  };

  const submitToPatron = useCallback((id: string, message: string): Result => {
    const p = find(id);
    const c = p && competitionById(p.competitionId);
    if (!p || !c) return { ok: false, error: "Project not found." };
    if (!c.config.patron.enabled) return { ok: false, error: "Patron review is not enabled for this competition." };
    if (["SUBMITTED", "UNDER REVIEW"].includes(p.patron.status)) return { ok: false, error: "A version is already with your patron. Wait for feedback before sending another." };
    if (!p.title.trim() || p.title === "Untitled project" || !p.summary.trim()) return { ok: false, error: "Add a project title and summary before requesting review." };
    if (p.files.length === 0 && p.links.length === 0) return { ok: false, error: "Attach at least one file or project link." };
    const at = new Date().toISOString();
    const reference = makeReference("PAT");
    patch(id, (pp) => ({
      ...pp,
      versions: freezeDraft(pp, "patron", reference, at, "Sent for patron review"),
      patron: { ...pp.patron, status: "SUBMITTED", message, timeline: [...pp.patron.timeline, { label: "Submitted to patron (recorded locally)", at }] },
    }));
    return { ok: true, reference, at };
  }, [find, patch]);

  const submitToJudges = useCallback((id: string, changes: string): Result => {
    const p = find(id);
    if (!p) return { ok: false, error: "Project not found." };
    const lock = judgingLock(p);
    if (lock) return { ok: false, error: lock };
    const missing = [
      !p.title.trim() || p.title === "Untitled project" ? "project name" : "",
      !p.summary.trim() ? "summary" : "",
      !p.problem.trim() ? "problem statement" : "",
      !p.solution.trim() ? "proposed solution" : "",
      p.technologies.length === 0 ? "technologies" : "",
      p.files.length === 0 ? "design documentation file" : "",
    ].filter(Boolean);
    if (missing.length) return { ok: false, error: `Complete the required fields first: ${missing.join(", ")}.` };
    const at = new Date().toISOString();
    const reference = makeReference("JDG");
    patch(id, (pp) => {
      const versions = freezeDraft(pp, "judges", reference, at, changes || "Official submission");
      return {
        ...pp,
        versions,
        judging: {
          status: "SUBMITTED",
          reference,
          submittedAt: at,
          versionNo: versions[versions.length - 1].no,
          timeline: [...pp.judging.timeline, { label: `Submitted v${versions[versions.length - 1].no} (local receipt — awaiting server confirmation)`, at }],
          result: undefined,
        },
      };
    });
    return { ok: true, reference, at };
  }, [find, patch]);

  const publishShowcase = useCallback((id: string, description: string): Result => {
    const p = find(id);
    const c = p && competitionById(p.competitionId);
    if (!p || !c) return { ok: false, error: "Project not found." };
    if (!c.config.showcase.enabled) return { ok: false, error: "Public sharing is not enabled for this competition." };
    if (description.trim().length < 40) return { ok: false, error: "Write a public description of at least 40 characters." };
    patch(id, (pp) => ({ ...pp, showcase: { ...pp.showcase, published: true, publishedAt: new Date().toISOString(), description: description.trim(), commentsEnabled: c.config.showcase.comments } }));
    return { ok: true };
  }, [find, patch]);

  const unpublishShowcase = useCallback((id: string): Result => {
    const p = find(id);
    const c = p && competitionById(p.competitionId);
    if (!c?.config.showcase.ownerCanUnpublish) return { ok: false, error: "This competition does not allow owners to unpublish." };
    patch(id, (pp) => ({ ...pp, showcase: { ...pp.showcase, published: false } }));
    return { ok: true };
  }, [find, patch]);

  const value: Ctx = useMemo(() => ({
    projects,
    createProject,
    updateDraft,
    addFile,
    removeFile,
    submitToPatron,
    submitToJudges,
    publishShowcase,
    unpublishShowcase,
    updateShowcase: (id, changes) => patch(id, (p) => ({ ...p, showcase: { ...p.showcase, ...changes } })),
    toggleReaction: (id) => patch(id, (p) => ({ ...p, showcase: { ...p.showcase, reacted: !p.showcase.reacted, reactions: p.showcase.reactions + (p.showcase.reacted ? -1 : 1) } })),
    addComment: (id, comment, parentId) => patch(id, (p) => {
      const created: CommunityComment = { ...comment, id: `c-${Date.now()}`, at: new Date().toISOString(), helpful: 0, replies: [] };
      const comments = parentId
        ? mapComments(p.showcase.comments, parentId, (c) => ({ ...c, replies: [...c.replies, created] }))
        : [...p.showcase.comments, created];
      return { ...p, showcase: { ...p.showcase, comments } };
    }),
    markHelpful: (id, commentId) => patch(id, (p) => ({
      ...p,
      showcase: { ...p.showcase, comments: mapComments(p.showcase.comments, commentId, (c) => ({ ...c, markedHelpful: !c.markedHelpful, helpful: c.helpful + (c.markedHelpful ? -1 : 1) })) },
    })),
    reportComment: (id, commentId) => patch(id, (p) => ({
      ...p,
      showcase: { ...p.showcase, comments: mapComments(p.showcase.comments, commentId, (c) => ({ ...c, reported: true })) },
    })),
    deleteDraft: (id) => setProjects((ps) => ps.filter((p) => p.id !== id || p.versions.some((v) => v.submittedAt))),
    resetDemo: () => setProjects(seedProjects),
  }), [projects, createProject, updateDraft, addFile, removeFile, submitToPatron, submitToJudges, publishShowcase, unpublishShowcase, patch]);

  return <SubmissionContext.Provider value={value}>{children}</SubmissionContext.Provider>;
}

export function useSubmissions() {
  const ctx = useContext(SubmissionContext);
  if (!ctx) throw new Error("SubmissionProvider is missing");
  return ctx;
}
