import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  deriveAutomaticReminders, seedAnnouncements, seedFeatures, seedNotifications,
  seedPersonalReminders, type AnnouncementRecord, type FeatureRecord,
  type NotificationRecord, type ReminderRecord,
} from "../data/communicationsData";

export type Preferences = {
  dnd: boolean; quietStart: string; quietEnd: string; frequency: "instant" | "daily";
  email: boolean; browser: boolean;
  categories: Record<string, boolean>;
  hub: "all" | "mentions" | "replies" | "followed" | "muted";
};

const defaultPreferences: Preferences = {
  dnd: false, quietStart: "22:00", quietEnd: "07:00", frequency: "instant",
  email: false, browser: false,
  categories: {
    "Platform news": true, "Maintenance": true, "New features": true,
    "School notices": true, "Competition updates": true, "Submission results": true,
    "Learning & practice": true, "Hub activity": true,
  }, hub: "all",
};

type State = {
  announcements: AnnouncementRecord[];
  notifications: NotificationRecord[];
  features: FeatureRecord[];
  reminders: ReminderRecord[];
  announcementRead: Record<string, boolean>;
  announcementSaved: Record<string, boolean>;
  preferences: Preferences;
};
const seedState = (): State => ({
  announcements: seedAnnouncements,
  notifications: seedNotifications,
  features: seedFeatures,
  reminders: seedPersonalReminders,
  announcementRead: {}, announcementSaved: {}, preferences: defaultPreferences,
});
const KEY = "cq-communications-v1";
function initialState(): State {
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || "null") as Partial<State> | null;
    if (saved) {
      const base = seedState();
      return {
        ...base, ...saved,
        announcements: base.announcements, // official records cannot be edited by students
        features: base.features.map((f) => ({ ...f, ...(saved.features?.find((s) => s.id === f.id) ?? {}) })),
        preferences: { ...defaultPreferences, ...saved.preferences, categories: { ...defaultPreferences.categories, ...saved.preferences?.categories } },
      };
    }
  } catch { /* malformed storage: use seed */ }
  return seedState();
}

type CommContext = {
  state: State;
  automatic: ReminderRecord[];
  unread: number;
  setNotifications: (updater: (items: NotificationRecord[]) => NotificationRecord[]) => void;
  updateNotification: (id: string, patch: Partial<NotificationRecord>) => void;
  updateAnnouncements: (ids: string[], read: boolean) => void;
  toggleAnnouncementSaved: (id: string) => void;
  updateFeature: (id: string, patch: Partial<FeatureRecord>) => void;
  saveReminder: (reminder: ReminderRecord) => void;
  removeReminder: (id: string) => void;
  setPreferences: (updater: (prefs: Preferences) => Preferences) => void;
  undo: () => void;
  canUndo: boolean;
};
const Context = createContext<CommContext | null>(null);

export function CommunicationsProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(initialState);
  const [history, setHistory] = useState<State | null>(null);
  const automatic = useMemo(deriveAutomaticReminders, []);
  const unread = state.notifications.filter((n) => !n.is_read && !n.is_archived && !n.deleted).length;

  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* storage unavailable */ }
  }, [state]);

  const setNotifications = (updater: (items: NotificationRecord[]) => NotificationRecord[]) => {
    setState((old) => {
      setHistory(old);
      return { ...old, notifications: updater(old.notifications) };
    });
  };
  const updateNotification = (id: string, patch: Partial<NotificationRecord>) =>
    setNotifications((items) => items.map((n) => n.id === id ? { ...n, ...patch } : n));
  const updateAnnouncements = (ids: string[], read: boolean) => {
    setState((old) => {
      setHistory(old);
      return { ...old, announcementRead: { ...old.announcementRead, ...Object.fromEntries(ids.map((id) => [id, read])) } };
    });
  };
  const toggleAnnouncementSaved = (id: string) => setState((old) => ({
    ...old, announcementSaved: { ...old.announcementSaved, [id]: !old.announcementSaved[id] },
  }));
  const updateFeature = (id: string, patch: Partial<FeatureRecord>) => setState((old) => ({
    ...old, features: old.features.map((f) => f.id === id ? { ...f, ...patch } : f),
  }));
  const saveReminder = (reminder: ReminderRecord) => setState((old) => ({
    ...old, reminders: old.reminders.some((r) => r.id === reminder.id)
      ? old.reminders.map((r) => r.id === reminder.id ? reminder : r)
      : [...old.reminders, reminder],
  }));
  const removeReminder = (id: string) => setState((old) => ({
    ...old, reminders: old.reminders.filter((r) => r.id !== id),
  }));
  const setPreferences = (updater: (prefs: Preferences) => Preferences) =>
    setState((old) => ({ ...old, preferences: updater(old.preferences) }));
  const undo = () => {
    if (history) { setState(history); setHistory(null); }
  };

  return <Context.Provider value={{ state, automatic, unread, setNotifications, updateNotification,
    updateAnnouncements, toggleAnnouncementSaved, updateFeature, saveReminder, removeReminder,
    setPreferences, undo, canUndo: history !== null }}>{children}</Context.Provider>;
}

export function useCommunications() {
  const value = useContext(Context);
  if (!value) throw new Error("CommunicationsProvider is missing");
  return value;
}