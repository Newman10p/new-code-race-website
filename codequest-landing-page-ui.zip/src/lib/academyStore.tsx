import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { ACHIEVEMENTS, academyCourses, type Course, type Lesson } from "../data/academyData";

/** Save states — reported honestly; nothing is claimed as server-confirmed. */
export type SaveState = "idle" | "saving" | "saved" | "offline" | "failed";

type Persisted = {
  completedLessons: Record<string, number>; // lessonId -> points, awarded once
  startedCourses: string[];
  notes: Record<string, string>;
  bookmarks: Record<string, boolean>;
  lessonPositions: Record<string, number>;
  completionDays: string[]; // ISO days with a completion
  dayStart: string;
};

const KEY = "cq-academy-v1";

function load(): Persisted {
  const fallback: Persisted = { completedLessons: {}, startedCourses: [], notes: {}, bookmarks: {}, lessonPositions: {}, completionDays: [], dayStart: new Date().toISOString().slice(0, 10) };
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...fallback, ...(JSON.parse(raw) as Persisted) };
  } catch { /* corrupted storage */ }
  return fallback;
}

type Ctx = {
  state: Persisted;
  saveState: SaveState;
  /* derivation — single source for library, journey, studio and path */
  isLessonComplete: (lessonId: string) => boolean;
  lessonPoints: (lessonId: string) => number;
  moduleProgress: (course: Course, moduleId: string) => { done: number; total: number; completed: boolean };
  moduleState: (course: Course, index: number) => "completed" | "current" | "locked";
  courseProgress: (course: Course) => { done: number; total: number; percent: number; status: "NOT STARTED" | "IN PROGRESS" | "COMPLETED" };
  currentLessonOf: (course: Course) => { module: Course["modules"][number]; moduleIndex: number; lesson: Lesson; lessonIndex: number } | null;
  firstLockedModuleIndex: (course: Course) => number;
  /* actions */
  completeLesson: (course: Course, moduleIndex: number, lesson: Lesson, accuracy: number) => { points: number; newlyUnlockedModule: boolean; courseCompleted: boolean };
  beginCourse: (courseId: string) => void;
  saveNote: (lessonId: string, text: string) => void;
  toggleBookmark: (lessonId: string) => void;
  savePosition: (lessonId: string, index: number) => void;
  /* stats */
  stats: { lessons: number; courses: number; completedCourses: number; inProgress: number; points: number; streakDays: number; days: number; codePracticals: number; fastCourses: number; minutes: number };
  achievements: { id: string; name: string; desc: string; earned: boolean }[];
  weeklyActivity: { day: string; count: number }[];
  subjectProgress: { subject: string; percent: number }[];
  reset: () => void;
};

const AcademyContext = createContext<Ctx | null>(null);

export function AcademyProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Persisted>(load);
  const [saveState, setSaveState] = useState<SaveState>("idle");

  const persist = useCallback((next: Persisted, delay = 450) => {
    setSaveState("saving");
    window.setTimeout(() => {
      try {
        localStorage.setItem(KEY, JSON.stringify(next));
        setSaveState("saved");
      } catch {
        setSaveState("failed");
      }
    }, delay);
  }, []);

  useEffect(() => { persist(state); }, [state, persist]);

  const isLessonComplete = useCallback((id: string) => state.completedLessons[id] !== undefined, [state.completedLessons]);
  const lessonPoints = useCallback((id: string) => state.completedLessons[id] ?? 0, [state.completedLessons]);

  const moduleProgress = useCallback((course: Course, moduleId: string) => {
    const mod = course.modules.find((m) => m.id === moduleId)!;
    const done = mod.lessons.filter((l) => isLessonComplete(l.id)).length;
    return { done, total: mod.lessons.length, completed: done === mod.lessons.length };
  }, [isLessonComplete]);

  /** Unlocking: module i is completed, or is the first uncompleted one with all earlier modules complete. */
  const firstLockedModuleIndex = useCallback((course: Course) => {
    for (let i = 0; i < course.modules.length; i++) {
      const p = moduleProgress(course, course.modules[i].id);
      if (!p.completed) return i;
    }
    return course.modules.length;
  }, [moduleProgress]);

  const moduleState = useCallback((course: Course, index: number): "completed" | "current" | "locked" => {
    const p = moduleProgress(course, course.modules[index].id);
    if (p.completed) return "completed";
    return index === firstLockedModuleIndex(course) ? "current" : "locked";
  }, [moduleProgress, firstLockedModuleIndex]);

  const courseProgress = useCallback((course: Course) => {
    const total = course.modules.reduce((s, m) => s + m.lessons.length, 0);
    const done = course.modules.reduce((s, m) => s + moduleProgress(course, m.id).done, 0);
    const percent = total ? Math.round((done / total) * 100) : 0;
    const status: "COMPLETED" | "IN PROGRESS" | "NOT STARTED" =
      done === total && total > 0 ? "COMPLETED" : done > 0 ? "IN PROGRESS" : "NOT STARTED";
    return { done, total, percent, status };
  }, [moduleProgress]);

  const currentLessonOf = useCallback((course: Course) => {
    const idx = firstLockedModuleIndex(course);
    if (idx >= course.modules.length) return null;
    const module = course.modules[idx];
    const lesson = module.lessons.find((l) => !isLessonComplete(l.id)) ?? module.lessons[module.lessons.length - 1];
    return { module, moduleIndex: idx, lesson, lessonIndex: module.lessons.indexOf(lesson) };
  }, [firstLockedModuleIndex, isLessonComplete]);

  const completeLesson = useCallback((course: Course, moduleIndex: number, lesson: Lesson, accuracy: number) => {
    const already = state.completedLessons[lesson.id] !== undefined;
    const prevFirst = firstLockedModuleIndex(course);
    const day = new Date().toISOString().slice(0, 10);

    if (already) {
      // no duplicate points, ever
      const after = moduleProgress(course, course.modules[moduleIndex].id);
      const courseDone = courseProgress(course).status === "COMPLETED";
      return { points: 0, newlyUnlockedModule: false, courseCompleted: courseDone && after.completed };
    }

    const bonus = Math.round(lesson.points * (accuracy >= 1 ? 0.2 : accuracy >= 0.6 ? 0.1 : 0));
    const awarded = lesson.points + bonus;

    setState((prev) => ({
      ...prev,
      completedLessons: { ...prev.completedLessons, [lesson.id]: awarded },
      startedCourses: prev.startedCourses.includes(course.id) ? prev.startedCourses : [...prev.startedCourses, course.id],
      completionDays: prev.completionDays.includes(day) ? prev.completionDays : [...prev.completionDays, day],
    }));

    const nextFirst = (() => {
      // simulate the same rule against the updated record
      for (let i = 0; i < course.modules.length; i++) {
        const m = course.modules[i];
        const done = m.lessons.filter((l) => l.id === lesson.id || state.completedLessons[l.id] !== undefined).length;
        if (done < m.lessons.length) return i;
      }
      return course.modules.length;
    })();

    const courseCompleted = nextFirst >= course.modules.length;
    return { points: awarded, newlyUnlockedModule: nextFirst > prevFirst, courseCompleted };
  }, [state.completedLessons, firstLockedModuleIndex, moduleProgress, courseProgress]);

  const beginCourse = useCallback((courseId: string) => {
    setState((prev) => prev.startedCourses.includes(courseId) ? prev : { ...prev, startedCourses: [...prev.startedCourses, courseId] });
  }, []);

  const saveNote = useCallback((lessonId: string, text: string) => {
    setState((prev) => ({ ...prev, notes: { ...prev.notes, [lessonId]: text } }));
  }, []);

  const toggleBookmark = useCallback((lessonId: string) => {
    setState((prev) => ({ ...prev, bookmarks: { ...prev.bookmarks, [lessonId]: !prev.bookmarks[lessonId] } }));
  }, []);

  const savePosition = useCallback((lessonId: string, index: number) => {
    setState((prev) => ({ ...prev, lessonPositions: { ...prev.lessonPositions, [lessonId]: index } }));
  }, []);

  const stats = useMemo(() => {
    const lessons = Object.keys(state.completedLessons).length;
    const points = Object.values(state.completedLessons).reduce((s, v) => s + v, 0);
    const published = academyCourses.filter((c) => c.published);
    const completedCourses = published.filter((c) => courseProgress(c).status === "COMPLETED").length;
    const inProgress = published.filter((c) => courseProgress(c).status === "IN PROGRESS").length;
    const days = state.completionDays.length;
    const minutes = published.reduce((s, c) => s + (courseProgress(c).percent / 100) * c.estimatedHours * 60, 0);
    const codePracticals = published.flatMap((c) => c.modules.flatMap((m) => m.lessons)).filter((l) => isLessonComplete(l.id)).length;
    return {
      lessons, points, courses: published.length, completedCourses, inProgress,
      streakDays: days, days, codePracticals, fastCourses: completedCourses, minutes: Math.round(minutes),
    };
  }, [state.completedLessons, state.completionDays, courseProgress, isLessonComplete]);

  const achievements = useMemo(() => ACHIEVEMENTS.map((a) => ({
    id: a.id, name: a.name, desc: a.desc, earned: a.check(stats as never),
  })), [stats]);

  const weeklyActivity = useMemo(() => {
    const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    return Array.from({ length: 7 }).map((_, i) => {
      const d = new Date(Date.now() - (6 - i) * 86400_000).toISOString().slice(0, 10);
      const idx = new Date(d + "T12:00:00").getDay();
      return { day: names[idx], count: state.completionDays.includes(d) ? 1 : 0 };
    });
  }, [state.completionDays]);

  const subjectProgress = useMemo(() => {
    const published = academyCourses.filter((c) => c.published);
    const subjects = Array.from(new Set(published.map((c) => c.subject)));
    return subjects.map((subject) => {
      const list = published.filter((c) => c.subject === subject);
      const total = list.reduce((s, c) => s + courseProgress(c).total, 0);
      const done = list.reduce((s, c) => s + courseProgress(c).done, 0);
      return { subject, percent: total ? Math.round((done / total) * 100) : 0 };
    });
  }, [courseProgress]);

  const reset = useCallback(() => {
    setState({ completedLessons: {}, startedCourses: [], notes: {}, bookmarks: {}, lessonPositions: {}, completionDays: [], dayStart: new Date().toISOString().slice(0, 10) });
  }, []);

  /* honest offline reporting when the tab loses storage access */
  useEffect(() => {
    const off = () => setSaveState("offline");
    window.addEventListener("offline", off);
    return () => window.removeEventListener("offline", off);
  }, []);

  const value = useMemo<Ctx>(() => ({
    state, saveState, isLessonComplete, lessonPoints, moduleProgress, moduleState, courseProgress,
    currentLessonOf, firstLockedModuleIndex, completeLesson, beginCourse, saveNote, toggleBookmark,
    savePosition, stats, achievements, weeklyActivity, subjectProgress, reset,
  }), [state, saveState, isLessonComplete, lessonPoints, moduleProgress, moduleState, courseProgress,
    currentLessonOf, firstLockedModuleIndex, completeLesson, beginCourse, saveNote, toggleBookmark,
    savePosition, stats, achievements, weeklyActivity, subjectProgress, reset]);

  return <AcademyContext.Provider value={value}>{children}</AcademyContext.Provider>;
}

export function useAcademy() {
  const ctx = useContext(AcademyContext);
  if (!ctx) throw new Error("AcademyProvider is missing");
  return ctx;
}

/** Every published course the student can see — drafts are never returned. */
export const visibleCourses = () => academyCourses.filter((c) => c.published);

export function lockReason(course: Course, moduleIndex: number, idx: number): string | null {
  if (moduleIndex < idx) return null;
  const prev = course.modules[idx - 1];
  return prev ? `Complete "${prev.title}" to unlock this stage.` : null;
}
