/** Shared runtime state for the octagon canvas (ambient energy boost per section). */
export const gridRuntime = {
  energy: 0.14,
  targetEnergy: 0.14,
};

export function setGridEnergy(v: number) {
  gridRuntime.targetEnergy = v;
}

let cached: boolean | null = null;

export function prefersReducedMotion(): boolean {
  if (cached !== null) return cached;
  if (typeof window === "undefined" || !window.matchMedia) return false;
  cached = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  window.matchMedia("(prefers-reduced-motion: reduce)").addEventListener?.(
    "change",
    (e) => {
      cached = e.matches;
    }
  );
  return cached;
}

/** Lerp helper for rgb triples. */
export function lerpColor(
  a: [number, number, number],
  b: [number, number, number],
  t: number
): string {
  const r = Math.round(a[0] + (b[0] - a[0]) * t);
  const g = Math.round(a[1] + (b[1] - a[1]) * t);
  const bl = Math.round(a[2] + (b[2] - a[2]) * t);
  return `rgb(${r},${g},${bl})`;
}

export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
  ];
}
