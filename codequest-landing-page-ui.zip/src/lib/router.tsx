import { useEffect, useState, type AnchorHTMLAttributes } from "react";

function currentRoute(): string {
  const h = window.location.hash;
  if (h.startsWith("#/")) return h.slice(1);
  return "/";
}

export function useRoute(): string {
  const [route, setRoute] = useState<string>(() => currentRoute());
  useEffect(() => {
    const onChange = () => setRoute(currentRoute());
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);
  return route;
}

/** Returns { path, query } from a route string like "/login?mode=join". */
export function parseRoute(route: string): { path: string; query: URLSearchParams } {
  const [path, qs] = route.split("?");
  return { path: path || "/", query: new URLSearchParams(qs || "") };
}

export function navigate(to: string) {
  window.location.hash = to;
}

type LinkProps = AnchorHTMLAttributes<HTMLAnchorElement> & { to: string };

export function Link({ to, ...props }: LinkProps) {
  return <a href={`#${to}`} {...props} />;
}
