import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  competitionsSeed,
  resolveSchedule,
  type ArenaQuestion,
  type Competition,
} from "../data/competitionsData";

/* ══════════════ TYPES ══════════════ */

export type SaveState = "idle" | "saving" | "saved" | "failed" | "offline";
export type ConnectionState = "connected" | "unstable" | "reconnecting" | "offline";

export type AnswerEntry = {
  questionId: string;
  kind: ArenaQuestion["kind"];
  value: string;
  language?: string;
  savedAt: number;
  /** Student pressed the explicit final-answer confirmation. */
  confirmed?: boolean;
  /** Local rehearsal run of visible tests — never the official verdict. */
  localResult?: { passed: number; total: number; ms: number };
  /** "local" = stored in this browser only; never claimed as server-confirmed. */
  confirmedBy: "local";
};

export type Attempt = {
  id: string;
  competitionId: string;
  startedAt: number;
  roundIndex: number;
  questionIndex: number;
  answers: Record<string, AnswerEntry>;
  visited: Record<string, boolean>;
  flags: Record<string, boolean>;
  submitted: boolean;
  completedAt: number | null;
  /** Official score — only ever set by the grading service. Null in this prototype. */
  score: number | null;
  /** Local rehearsal estimate, clearly labelled as unofficial wherever shown. */
  rehearsalScore: number | null;
  rehearsalLog: string[];
};

type Persisted = {
  schedule: Record<string, { starts_at: string; ends_at: string }>;
  registered: string[];
  attempts: Record<string, Attempt>;
  soundEnabled: boolean;
  /** Control overrides (delay / cancellation) stand in for competition management. */
  controls: Record<string, NonNullable<Competition["control"]>>;
};

const KEY = "cq-competition-arena-v1";

function load(): Persisted {
  const fallback: Persisted = {
    schedule: resolveSchedule(Date.now()),
    registered: [],
    attempts: {},
    soundEnabled: false,
    controls: {},
  };
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<Persisted>;
    return { ...fallback, ...parsed, schedule: parsed.schedule ?? fallback.schedule };
  } catch {
    return fallback;
  }
}

/* ══════════════ CONTEXT ══════════════ */

type CompetitionCtx = {
  competitions: Competition[];
  byId: (id: string) => Competition | undefined;
  attemptFor: (id: string) => Attempt | undefined;
  register: (competitionId: string) => void;
  reschedule: (competitionId: string, startsAt: string, control?: NonNullable<Competition["control"]>) => void;
  clearControl: (competitionId: string) => void;
  startAttempt: (competitionId: string) => Attempt;
  patchAttempt: (competitionId: string, patch: Partial<Attempt>) => void;
  saveAnswer: (competitionId: string, entry: AnswerEntry) => void;
  setVisited: (competitionId: string, questionId: string) => void;
  toggleFlag: (competitionId: string, questionId: string) => void;
  submitAttempt: (competitionId: string, rehearsalScore: number | null, log: string[]) => void;
  resetAttempt: (competitionId: string) => void;
  /* time */
  serverNow: () => number;
  now: number;
  clockOffsetMs: number;
  /* transport */
  connection: ConnectionState;
  simulateDisconnection: () => void;
  restoreConnection: () => void;
  saveState: SaveState;
  pendingSync: number;
  /* prefs */
  soundEnabled: boolean;
  setSoundEnabled: (v: boolean) => void;
};

const Ctx = createContext<CompetitionCtx | null>(null);

export function CompetitionProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Persisted>(load);
  const [now, setNow] = useState(() => Date.now());
  const [clockOffsetMs] = useState(() => Math.round(Math.random() * 40) - 20);
  const [connection, setConnection] = useState<ConnectionState>("connected");
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [pendingSync, setPendingSync] = useState(0);
  const saveTimer = useRef<number | null>(null);

  /* persist */
  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(data));
    } catch {
      /* storage unavailable — session only */
    }
  }, [data]);

  /* one-second tick drives every countdown */
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const serverNow = useCallback(() => Date.now() + clockOffsetMs, [clockOffsetMs]);

  const competitions = useMemo<Competition[]>(
    () =>
      competitionsSeed
        .filter((c) => c.publication_status === "published")
        .map((c) => {
          const s = data.schedule[c.id];
          const base = s ? { ...c, starts_at: s.starts_at, ends_at: s.ends_at } : (c as Competition);
          const control = data.controls[c.id];
          return control ? { ...base, control } : base;
        }),
    [data.schedule, data.controls]
  );

  const byId = useCallback((id: string) => competitions.find((c) => c.id === id), [competitions]);
  const attemptFor = useCallback((id: string) => data.attempts[id], [data.attempts]);

  const register = useCallback((competitionId: string) => {
    setData((d) => ({
      ...d,
      registered: d.registered.includes(competitionId) ? d.registered : [...d.registered, competitionId],
    }));
  }, []);

  /** Stands in for competition control moving or cancelling an event. */
  const reschedule = useCallback(
    (competitionId: string, startsAt: string, control?: NonNullable<Competition["control"]>) => {
      setData((d) => {
        const prev = d.schedule[competitionId];
        const durationMs = prev
          ? new Date(prev.ends_at).getTime() - new Date(prev.starts_at).getTime()
          : 45 * 60_000;
        return {
          ...d,
          schedule: {
            ...d.schedule,
            [competitionId]: {
              starts_at: startsAt,
              ends_at: new Date(new Date(startsAt).getTime() + durationMs).toISOString(),
            },
          },
          controls: control ? { ...d.controls, [competitionId]: control } : d.controls,
        };
      });
    },
    []
  );

  const clearControl = useCallback((competitionId: string) => {
    setData((d) => {
      const next = { ...d.controls };
      delete next[competitionId];
      return { ...d, controls: next };
    });
  }, []);

  const startAttempt = useCallback(
    (competitionId: string): Attempt => {
      const existing = data.attempts[competitionId];
      if (existing) return existing;
      const created: Attempt = {
        id: `att-${competitionId}-${Date.now()}`,
        competitionId,
        startedAt: Date.now(),
        roundIndex: 0,
        questionIndex: 0,
        answers: {},
        visited: {},
        flags: {},
        submitted: false,
        completedAt: null,
        score: null,
        rehearsalScore: null,
        rehearsalLog: [],
      };
      setData((d) => ({ ...d, attempts: { ...d.attempts, [competitionId]: created } }));
      return created;
    },
    [data.attempts]
  );

  const patchAttempt = useCallback((competitionId: string, patch: Partial<Attempt>) => {
    setData((d) => {
      const current = d.attempts[competitionId];
      if (!current) return d;
      return { ...d, attempts: { ...d.attempts, [competitionId]: { ...current, ...patch } } };
    });
  }, []);

  /**
   * Autosave. Honest behaviour: while the connection is down the write stays
   * local, is counted as pending sync, and the UI never claims server receipt.
   */
  const saveAnswer = useCallback(
    (competitionId: string, entry: AnswerEntry) => {
      if (saveTimer.current) window.clearTimeout(saveTimer.current);
      setSaveState(connection === "offline" ? "failed" : "saving");

      setData((d) => {
        const current = d.attempts[competitionId];
        if (!current) return d;
        return {
          ...d,
          attempts: {
            ...d.attempts,
            [competitionId]: { ...current, answers: { ...current.answers, [entry.questionId]: entry } },
          },
        };
      });

      if (connection === "offline") {
        setPendingSync((n) => n + 1);
        return;
      }

      saveTimer.current = window.setTimeout(() => {
        setSaveState("saved");
      }, 420);
    },
    [connection]
  );

  const setVisited = useCallback((competitionId: string, questionId: string) => {
    setData((d) => {
      const current = d.attempts[competitionId];
      if (!current || current.visited[questionId]) return d;
      return {
        ...d,
        attempts: {
          ...d.attempts,
          [competitionId]: { ...current, visited: { ...current.visited, [questionId]: true } },
        },
      };
    });
  }, []);

  const toggleFlag = useCallback((competitionId: string, questionId: string) => {
    setData((d) => {
      const current = d.attempts[competitionId];
      if (!current) return d;
      return {
        ...d,
        attempts: {
          ...d.attempts,
          [competitionId]: {
            ...current,
            flags: { ...current.flags, [questionId]: !current.flags[questionId] },
          },
        },
      };
    });
  }, []);

  const submitAttempt = useCallback(
    (competitionId: string, rehearsalScore: number | null, log: string[]) => {
      setData((d) => {
        const current = d.attempts[competitionId];
        if (!current) return d;
        return {
          ...d,
          attempts: {
            ...d.attempts,
            [competitionId]: {
              ...current,
              submitted: true,
              completedAt: Date.now(),
              score: null,
              rehearsalScore,
              rehearsalLog: [...current.rehearsalLog, ...log],
            },
          },
        };
      });
      setPendingSync(0);
      setSaveState("idle");
    },
    []
  );

  const resetAttempt = useCallback((competitionId: string) => {
    setData((d) => {
      const next = { ...d.attempts };
      delete next[competitionId];
      return { ...d, attempts: next };
    });
    setPendingSync(0);
  }, []);

  /* connection lifecycle: reconnecting -> unstable -> connected, flushing pending writes */
  const simulateDisconnection = useCallback(() => {
    setConnection("offline");
    setSaveState("failed");
  }, []);

  const restoreConnection = useCallback(() => {
    setConnection("reconnecting");
    window.setTimeout(() => {
      setConnection("unstable");
      window.setTimeout(() => {
        setConnection("connected");
        setSaveState((s) => (s === "failed" ? "saved" : s));
        setPendingSync(0);
      }, 1400);
    }, 1200);
  }, []);

  useEffect(() => {
    if (connection === "offline" && saveState !== "failed") setSaveState("failed");
  }, [connection, saveState]);

  const value = useMemo<CompetitionCtx>(
    () => ({
      competitions,
      byId,
      attemptFor,
      register,
      reschedule,
      clearControl,
      startAttempt,
      patchAttempt,
      saveAnswer,
      setVisited,
      toggleFlag,
      submitAttempt,
      resetAttempt,
      serverNow,
      now,
      clockOffsetMs,
      connection,
      simulateDisconnection,
      restoreConnection,
      saveState,
      pendingSync,
      soundEnabled: data.soundEnabled,
      setSoundEnabled: (v: boolean) => setData((d) => ({ ...d, soundEnabled: v })),
    }),
    [
      competitions, byId, attemptFor, register, reschedule, clearControl, startAttempt, patchAttempt, saveAnswer,
      setVisited, toggleFlag, submitAttempt, resetAttempt, serverNow, now, clockOffsetMs,
      connection, simulateDisconnection, restoreConnection, saveState, pendingSync, data.soundEnabled,
    ]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCompetitions() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("CompetitionProvider is missing");
  return ctx;
}

/** Student registration merges the seed flag with locally registered ids. */
export function isRegistered(c: Competition, localRegistered: string[]) {
  return c.studentRegistered || localRegistered.includes(c.id);
}
