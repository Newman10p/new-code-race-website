import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  ME, initialFollowing, seedBattles, seedCommunities, seedConversations,
  seedNotifications, seedPosts, seedRequests, studentById,
  type Attachment, type Battle, type Community, type Conversation, type DMRequest,
  type HubNotification, type Message, type Post,
} from "../data/hubData";
import { studentId as commStudentId } from "../data/communicationsData";
import { useCommunications } from "./communicationsStore";

export type Report = { id: string; kind: string; targetId: string; reason: string; at: string };
export type HubSettings = {
  whoCanRequest: "everyone" | "following" | "none";
  battleInvites: boolean;
  showPresence: boolean;
  allowCommunityInvites: boolean;
};

type State = {
  conversations: Conversation[];
  requests: DMRequest[];
  posts: Post[];
  communities: Community[];
  battles: Battle[];
  notifications: HubNotification[];
  following: string[];
  blocked: string[];
  mutedUsers: string[];
  hiddenPosts: string[];
  reports: Report[];
  settings: HubSettings;
};

const KEY = "cq-hub-v1";
const uid = (p: string) => `${p}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
const nowISO = () => new Date().toISOString();

const defaults = (): State => ({
  conversations: seedConversations, requests: seedRequests, posts: seedPosts,
  communities: seedCommunities, battles: seedBattles, notifications: seedNotifications,
  following: initialFollowing, blocked: [], mutedUsers: [], hiddenPosts: [], reports: [],
  settings: { whoCanRequest: "everyone", battleInvites: true, showPresence: true, allowCommunityInvites: true },
});

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...defaults(), ...(JSON.parse(raw) as Partial<State>) };
  } catch { /* ignore */ }
  return defaults();
}

/** Every mutating action returns a result, so no failed action can look successful. */
export type ActionResult = { ok: true } | { ok: false; error: string };
const OK: ActionResult = { ok: true };
const fail = (error: string): ActionResult => ({ ok: false, error });

type Ctx = {
  state: State;
  me: ReturnType<typeof studentById>;
  unreadChats: number;
  pendingIncomingRequests: DMRequest[];
  pendingOutgoingRequests: DMRequest[];
  unreadNotifications: number;
  /* conversations */
  sendMessage: (conversationId: string, text: string, attachment?: Attachment, replyTo?: string) => ActionResult;
  retryMessage: (conversationId: string, messageId: string) => void;
  editMessage: (conversationId: string, messageId: string, text: string) => void;
  deleteMessage: (conversationId: string, messageId: string) => void;
  reactToMessage: (conversationId: string, messageId: string, emoji: string) => void;
  togglePinMessage: (conversationId: string, messageId: string) => void;
  markConversationRead: (conversationId: string) => void;
  togglePinConversation: (conversationId: string) => void;
  toggleMuteConversation: (conversationId: string) => void;
  leaveGroup: (conversationId: string) => void;
  createGroup: (data: { name: string; description: string; memberIds: string[]; color: string }) => ActionResult;
  regenerateInvite: (conversationId: string) => void;
  revokeInvite: (conversationId: string) => void;
  simulateIncoming: (conversationId: string) => void;
  typingIn: string[];
  /* requests */
  sendRequest: (toId: string, message: string) => ActionResult;
  acceptRequest: (requestId: string) => ActionResult;
  declineRequest: (requestId: string) => void;
  blockFromRequest: (requestId: string) => void;
  cancelRequest: (requestId: string) => void;
  /* social */
  toggleFollow: (studentId: string) => void;
  toggleBlock: (studentId: string) => void;
  toggleMuteUser: (studentId: string) => void;
  /* posts */
  createPost: (input: Partial<Post> & { text: string }) => ActionResult;
  editPost: (postId: string, text: string) => void;
  deletePost: (postId: string) => void;
  toggleLike: (postId: string) => void;
  toggleRepost: (postId: string) => void;
  toggleBookmark: (postId: string) => void;
  addComment: (postId: string, text: string, parentId?: string) => ActionResult;
  likeComment: (postId: string, commentId: string) => void;
  reportComment: (postId: string, commentId: string) => void;
  hidePost: (postId: string) => void;
  votePoll: (postId: string, optionIndex: number) => void;
  /* communities */
  joinCommunity: (communityId: string) => ActionResult;
  leaveCommunity: (communityId: string) => void;
  createCommunity: (input: { name: string; description: string; category: string; visibility: Community["visibility"] }) => ActionResult;
  pinCommunityPost: (communityId: string, postId: string) => void;
  removeCommunityPost: (communityId: string, postId: string) => void;
  /* battles */
  createBattle: (input: Partial<Battle> & { title: string }) => ActionResult;
  joinBattle: (battleId: string) => ActionResult;
  leaveBattle: (battleId: string) => void;
  toggleReady: (battleId: string) => void;
  startBattle: (battleId: string) => ActionResult;
  /* moderation + notifications */
  submitReport: (kind: string, targetId: string, reason: string) => ActionResult;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  pushNotification: (n: Omit<HubNotification, "id" | "at" | "unread">) => void;
  setSettings: (patch: Partial<HubSettings>) => void;
  validateFile: (file: { name: string; size: number }) => ActionResult;
  reset: () => void;
};

const HubContext = createContext<Ctx | null>(null);

function mapMessage(list: Message[], id: string, fn: (m: Message) => Message): Message[] {
  return list.map((m) => (m.id === id ? fn(m) : m));
}

function mapComment(list: Post["comments"], id: string, fn: (c: Post["comments"][number]) => Post["comments"][number]): Post["comments"] {
  return list.map((c) => c.id === id ? fn(c) : { ...c, replies: mapComment(c.replies, id, fn) });
}

export function HubProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(load);
  const [typingIn, setTypingIn] = useState<string[]>([]);
  const { setNotifications } = useCommunications();

  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* storage unavailable */ }
  }, [state]);

  /* Route key Hub events into the main dashboard notification inbox too. */
  const globalNotice = useCallback((title: string, message: string) => {
    setNotifications((items) => [{
      id: uid("n-hub"), student_id: commStudentId, type: "hub", source_type: "hub", title, message,
      created_at: nowISO(), is_read: false, read_at: null, is_archived: false, is_pinned: false,
      action_url: "#/dashboard/user/hub", related_entity: { type: "hub", id: "hub", tab: "hub" }, priority: "normal",
    }, ...items]);
  }, [setNotifications]);

  const pushNotification: Ctx["pushNotification"] = useCallback((n) => {
    setState((s) => ({ ...s, notifications: [{ ...n, id: uid("hn"), at: nowISO(), unread: true }, ...s.notifications] }));
  }, []);

  const mutateConversation = useCallback((id: string, fn: (c: Conversation) => Conversation) =>
    setState((s) => ({ ...s, conversations: s.conversations.map((c) => c.id === id ? fn(c) : c) })), []);

  const mutatePost = useCallback((id: string, fn: (p: Post) => Post) =>
    setState((s) => ({ ...s, posts: s.posts.map((p) => p.id === id ? fn(p) : p) })), []);

  /* ─────────── conversations ─────────── */

  const sendMessage: Ctx["sendMessage"] = useCallback((conversationId, text, attachment, replyTo) => {
    const conv = state.conversations.find((c) => c.id === conversationId);
    if (!conv) return fail("Conversation not found.");
    if (!text.trim() && !attachment) return fail("Write a message or attach something first.");
    if (text.length > 2000) return fail("Message is over the 2000 character limit.");
    const other = conv.type === "direct" ? conv.participantIds?.find((p) => p !== ME) : undefined;
    if (other && state.blocked.includes(other)) return fail("This conversation is blocked.");
    const msg: Message = { id: uid("msg"), fromId: ME, text: text.trim(), at: nowISO(), reactions: [], replyTo, attachment, status: "sending" };
    mutateConversation(conversationId, (c) => ({ ...c, messages: [...c.messages, msg] }));
    // "Sending" resolves to "recorded locally" — never claims server delivery.
    window.setTimeout(() => mutateConversation(conversationId, (c) => ({
      ...c, messages: mapMessage(c.messages, msg.id, (m) => ({ ...m, status: "sent" })),
    })), 380);
    return OK;
  }, [state.conversations, state.blocked, mutateConversation]);

  const retryMessage: Ctx["retryMessage"] = useCallback((cid, mid) => {
    mutateConversation(cid, (c) => ({ ...c, messages: mapMessage(c.messages, mid, (m) => ({ ...m, status: "sending" })) }));
    window.setTimeout(() => mutateConversation(cid, (c) => ({ ...c, messages: mapMessage(c.messages, mid, (m) => ({ ...m, status: "sent" })) })), 500);
  }, [mutateConversation]);

  const editMessage: Ctx["editMessage"] = useCallback((cid, mid, text) =>
    mutateConversation(cid, (c) => ({ ...c, messages: mapMessage(c.messages, mid, (m) => ({ ...m, text, edited: true })) })), [mutateConversation]);

  const deleteMessage: Ctx["deleteMessage"] = useCallback((cid, mid) =>
    mutateConversation(cid, (c) => ({ ...c, messages: mapMessage(c.messages, mid, (m) => ({ ...m, deleted: true, text: "", attachment: undefined })) })), [mutateConversation]);

  const reactToMessage: Ctx["reactToMessage"] = useCallback((cid, mid, emoji) =>
    mutateConversation(cid, (c) => ({
      ...c,
      messages: mapMessage(c.messages, mid, (m) => {
        const found = m.reactions.find((r) => r.emoji === emoji);
        const reactions = found
          ? m.reactions.map((r) => r.emoji === emoji
            ? { ...r, by: r.by.includes(ME) ? r.by.filter((x) => x !== ME) : [...r.by, ME] } : r).filter((r) => r.by.length)
          : [...m.reactions, { emoji, by: [ME] }];
        return { ...m, reactions };
      }),
    })), [mutateConversation]);

  const togglePinMessage: Ctx["togglePinMessage"] = useCallback((cid, mid) =>
    mutateConversation(cid, (c) => ({ ...c, pinnedMessages: c.pinnedMessages.includes(mid) ? c.pinnedMessages.filter((x) => x !== mid) : [...c.pinnedMessages, mid] })), [mutateConversation]);

  const markConversationRead: Ctx["markConversationRead"] = useCallback((cid) =>
    mutateConversation(cid, (c) => ({ ...c, unread: 0 })), [mutateConversation]);

  const togglePinConversation: Ctx["togglePinConversation"] = useCallback((cid) =>
    mutateConversation(cid, (c) => ({ ...c, pinned: !c.pinned })), [mutateConversation]);

  const toggleMuteConversation: Ctx["toggleMuteConversation"] = useCallback((cid) =>
    mutateConversation(cid, (c) => ({ ...c, muted: !c.muted })), [mutateConversation]);

  const leaveGroup: Ctx["leaveGroup"] = useCallback((cid) => {
    setState((s) => ({ ...s, conversations: s.conversations.filter((c) => c.id !== cid) }));
    pushNotification({ type: "group", title: "You left a group", message: "You can rejoin through an invite link.", icon: "message", target: "chats" });
  }, [pushNotification]);

  const createGroup: Ctx["createGroup"] = useCallback((data) => {
    if (!data.name.trim()) return fail("Give the group a name.");
    if (data.memberIds.length < 1) return fail("Invite at least one student.");
    const id = uid("conv");
    const conv: Conversation = {
      id, type: "group", name: data.name.trim().startsWith("#") ? data.name.trim() : `#${data.name.trim()}`,
      description: data.description, color: data.color, initials: data.name.trim().slice(0, 2).toUpperCase(),
      memberIds: [ME, ...data.memberIds], ownerId: ME, adminIds: [], pinned: false, muted: false, unread: 0,
      messages: [{ id: uid("msg"), fromId: ME, text: `Group created. ${data.description || "Say hello!"}`, at: nowISO(), reactions: [] }],
      pinnedMessages: [], createdAt: nowISO(),
      invite: { code: `CQ-${Math.random().toString(36).slice(2, 6).toUpperCase()}`, expiresAt: new Date(Date.now() + 7 * 86400_000).toISOString(), revoked: false },
    };
    setState((s) => ({ ...s, conversations: [conv, ...s.conversations] }));
    pushNotification({ type: "group", title: "Group created", message: `${conv.name} is ready — you are the owner.`, icon: "message", target: "chats" });
    return OK;
  }, [pushNotification]);

  const regenerateInvite: Ctx["regenerateInvite"] = useCallback((cid) =>
    mutateConversation(cid, (c) => ({ ...c, invite: { code: `CQ-${Math.random().toString(36).slice(2, 6).toUpperCase()}`, expiresAt: new Date(Date.now() + 7 * 86400_000).toISOString(), revoked: false } })), [mutateConversation]);

  const revokeInvite: Ctx["revokeInvite"] = useCallback((cid) =>
    mutateConversation(cid, (c) => ({ ...c, invite: c.invite ? { ...c.invite, revoked: true } : undefined })), [mutateConversation]);

  const simulateIncoming: Ctx["simulateIncoming"] = useCallback((cid) => {
    const conv = state.conversations.find((c) => c.id === cid);
    if (!conv) return;
    setTypingIn((t) => [...new Set([...t, cid])]);
    window.setTimeout(() => {
      setTypingIn((t) => t.filter((x) => x !== cid));
      const sender = conv.memberIds.find((id) => id !== ME) ?? "stu-sarah";
      mutateConversation(cid, (c) => ({
        ...c,
        unread: c.unread + 1,
        messages: [...c.messages, { id: uid("msg"), fromId: sender, text: "Got it — I'll take a look and share notes shortly.", at: nowISO(), reactions: [] }],
      }));
      pushNotification({ type: "group", title: "New message", message: `${studentById(sender)?.name ?? "A student"} replied in ${conv.name}.`, icon: "message", target: "chats" });
    }, 2000);
  }, [state.conversations, mutateConversation, pushNotification]);

  /* ─────────── DM requests ─────────── */

  const sendRequest: Ctx["sendRequest"] = useCallback((toId, message) => {
    if (toId === ME) return fail("You cannot message yourself.");
    if (state.blocked.includes(toId)) return fail("This user is blocked. Unblock them first.");
    const target = studentById(toId);
    if (!target) return fail("Student not found.");
    if (state.settings.whoCanRequest === "none") return fail("Your privacy settings currently block outgoing requests.");
    if (!message.trim()) return fail("Include a short introduction with your request.");
    if (state.requests.some((r) => r.fromId === ME && r.toId === toId && r.status === "pending")) return fail("You already have a pending request with this student.");
    const outgoingPending = state.requests.filter((r) => r.fromId === ME && r.status === "pending").length;
    if (outgoingPending >= 5) return fail("Rate limit: maximum 5 pending outgoing requests.");
    const active = state.conversations.find((c) => c.type === "direct" && c.participantIds?.includes(toId));
    if (active) return fail("You already have an active conversation with this student.");
    setState((s) => ({ ...s, requests: [{ id: uid("req"), fromId: ME, toId, initialMessage: message.trim(), at: nowISO(), status: "pending" }, ...s.requests] }));
    pushNotification({ type: "request", title: "Request sent", message: `Waiting for ${target.name} to accept.`, icon: "request", target: "requests" });
    return OK;
  }, [state.blocked, state.requests, state.conversations, state.settings, pushNotification]);

  const acceptRequest: Ctx["acceptRequest"] = useCallback((requestId) => {
    const req = state.requests.find((r) => r.id === requestId);
    if (!req || req.toId !== ME || req.status !== "pending") return fail("This request is no longer pending.");
    const other = req.fromId;
    const conv: Conversation = {
      id: uid("conv-dm"), type: "direct", name: studentById(other)?.name ?? "Student",
      color: studentById(other)?.color ?? "#4D9CFF", initials: studentById(other)?.initials ?? "ST",
      memberIds: [ME, other], participantIds: [ME, other], pinned: false, muted: false, unread: 0,
      createdAt: nowISO(), pinnedMessages: [],
      messages: [{ id: uid("msg"), fromId: other, text: req.initialMessage, at: req.at, reactions: [] }],
    };
    setState((s) => ({
      ...s,
      requests: s.requests.map((r) => r.id === requestId ? { ...r, status: "accepted" } : r),
      conversations: [conv, ...s.conversations],
    }));
    pushNotification({ type: "request", title: "Request accepted", message: `You can now message ${conv.name} privately.`, icon: "request", target: "chats" });
    globalNotice("Message request accepted", `Your private conversation with ${conv.name} is now active.`);
    return OK;
  }, [state.requests, pushNotification, globalNotice]);

  const declineRequest: Ctx["declineRequest"] = useCallback((requestId) =>
    setState((s) => ({ ...s, requests: s.requests.map((r) => r.id === requestId ? { ...r, status: "declined" } : r) })), []);

  const blockFromRequest: Ctx["blockFromRequest"] = useCallback((requestId) => {
    const req = state.requests.find((r) => r.id === requestId);
    if (!req) return;
    setState((s) => ({
      ...s,
      requests: s.requests.map((r) => r.id === requestId ? { ...r, status: "blocked" } : r),
      blocked: s.blocked.includes(req.fromId) ? s.blocked : [...s.blocked, req.fromId],
    }));
  }, [state.requests]);

  const cancelRequest: Ctx["cancelRequest"] = useCallback((requestId) =>
    setState((s) => ({ ...s, requests: s.requests.filter((r) => r.id !== requestId) })), []);

  /* ─────────── social ─────────── */

  const toggleFollow: Ctx["toggleFollow"] = useCallback((id) =>
    setState((s) => ({ ...s, following: s.following.includes(id) ? s.following.filter((x) => x !== id) : [...s.following, id] })), []);

  const toggleBlock: Ctx["toggleBlock"] = useCallback((id) =>
    setState((s) => ({ ...s, blocked: s.blocked.includes(id) ? s.blocked.filter((x) => x !== id) : [...s.blocked, id] })), []);

  const toggleMuteUser: Ctx["toggleMuteUser"] = useCallback((id) =>
    setState((s) => ({ ...s, mutedUsers: s.mutedUsers.includes(id) ? s.mutedUsers.filter((x) => x !== id) : [...s.mutedUsers, id] })), []);

  /* ─────────── posts ─────────── */

  const createPost: Ctx["createPost"] = useCallback((input) => {
    if (!input.text.trim()) return fail("Write something before publishing.");
    if (input.text.length > 1200) return fail("Posts are limited to 1200 characters.");
    const post: Post = {
      id: uid("post"), authorId: ME, text: input.text.trim(), at: nowISO(),
      category: input.category ?? "General Discussion", audience: input.audience ?? "public",
      communityId: input.communityId, snippet: input.snippet, link: input.link, poll: input.poll, art: input.art,
      likes: [], reposts: [], bookmarks: [], comments: [],
    };
    setState((s) => ({ ...s, posts: [post, ...s.posts] }));
    pushNotification({ type: "post", title: post.audience === "draft" ? "Draft saved" : "Post published", message: post.text.slice(0, 80), icon: "post", target: "posts" });
    return OK;
  }, [pushNotification]);

  const editPost: Ctx["editPost"] = useCallback((postId, text) =>
    mutatePost(postId, (p) => ({ ...p, text, edited: true })), [mutatePost]);

  const deletePost: Ctx["deletePost"] = useCallback((postId) =>
    setState((s) => ({ ...s, posts: s.posts.filter((p) => p.id !== postId) })), []);

  const toggleLike: Ctx["toggleLike"] = useCallback((postId) =>
    mutatePost(postId, (p) => ({ ...p, likes: p.likes.includes(ME) ? p.likes.filter((x) => x !== ME) : [...p.likes, ME] })), [mutatePost]);

  const toggleRepost: Ctx["toggleRepost"] = useCallback((postId) =>
    mutatePost(postId, (p) => ({ ...p, reposts: p.reposts.includes(ME) ? p.reposts.filter((x) => x !== ME) : [...p.reposts, ME] })), [mutatePost]);

  const toggleBookmark: Ctx["toggleBookmark"] = useCallback((postId) =>
    mutatePost(postId, (p) => ({ ...p, bookmarks: p.bookmarks.includes(ME) ? p.bookmarks.filter((x) => x !== ME) : [...p.bookmarks, ME] })), [mutatePost]);

  const addComment: Ctx["addComment"] = useCallback((postId, text, parentId) => {
    if (!text.trim()) return fail("Write a comment first.");
    const comment = { id: uid("c"), authorId: ME, text: text.trim(), at: nowISO(), likes: [], replies: [] };
    mutatePost(postId, (p) => ({
      ...p,
      comments: parentId ? mapComment(p.comments, parentId, (c) => ({ ...c, replies: [...c.replies, comment] })) : [...p.comments, comment],
    }));
    return OK;
  }, [mutatePost]);

  const likeComment: Ctx["likeComment"] = useCallback((postId, commentId) =>
    mutatePost(postId, (p) => ({ ...p, comments: mapComment(p.comments, commentId, (c) => ({ ...c, likes: c.likes.includes(ME) ? c.likes.filter((x) => x !== ME) : [...c.likes, ME] })) })), [mutatePost]);

  const reportComment: Ctx["reportComment"] = useCallback((postId, commentId) =>
    mutatePost(postId, (p) => ({ ...p, comments: mapComment(p.comments, commentId, (c) => ({ ...c, reported: true })) })), [mutatePost]);

  const hidePost: Ctx["hidePost"] = useCallback((postId) =>
    setState((s) => ({ ...s, hiddenPosts: s.hiddenPosts.includes(postId) ? s.hiddenPosts.filter((x) => x !== postId) : [...s.hiddenPosts, postId] })), []);

  const votePoll: Ctx["votePoll"] = useCallback((postId, optionIndex) =>
    mutatePost(postId, (p) => p.poll ? ({
      ...p,
      poll: { ...p.poll, options: p.poll.options.map((o, i) => {
        const voted = o.votes.includes(ME);
        const votes = voted ? o.votes.filter((x) => x !== ME) : o.votes;
        return i === optionIndex && !voted ? { ...o, votes: [...votes, ME] } : { ...o, votes };
      }) },
    }) : p), [mutatePost]);

  /* ─────────── communities ─────────── */

  const joinCommunity: Ctx["joinCommunity"] = useCallback((communityId) => {
    const com = state.communities.find((c) => c.id === communityId);
    if (!com) return fail("Community not found.");
    if (com.membership === "banned") return fail("You are banned from this community.");
    if (com.membership === "joined") return fail("You are already a member.");
    if (com.visibility === "private") return fail("This community is invite-only.");
    if (com.visibility === "approval") {
      setState((s) => ({ ...s, communities: s.communities.map((c) => c.id === communityId ? { ...c, membership: "pending" } : c) }));
      pushNotification({ type: "community", title: "Join request sent", message: `Waiting for a moderator of ${com.name}.`, icon: "community", target: "communities" });
      return OK;
    }
    setState((s) => ({ ...s, communities: s.communities.map((c) => c.id === communityId ? { ...c, membership: "joined", members: [...c.members, ME] } : c) }));
    pushNotification({ type: "community", title: "Community joined", message: `You are now a member of ${com.name}.`, icon: "community", target: "communities" });
    return OK;
  }, [state.communities, pushNotification]);

  const leaveCommunity: Ctx["leaveCommunity"] = useCallback((communityId) =>
    setState((s) => ({ ...s, communities: s.communities.map((c) => c.id === communityId ? { ...c, membership: "none", members: c.members.filter((x) => x !== ME) } : c) })), []);

  const createCommunity: Ctx["createCommunity"] = useCallback((input) => {
    if (!input.name.trim()) return fail("Give the community a name.");
    const com: Community = {
      id: uid("com"), name: input.name.trim(), description: input.description, category: input.category,
      initials: input.name.trim().slice(0, 2).toUpperCase(), color: "#4D9CFF", members: [ME], moderators: [ME], ownerId: ME,
      visibility: input.visibility, membership: "joined", rules: ["Be constructive", "No live-round spoilers"],
      announcements: [], resources: [], activity: "New", pinnedPostIds: [],
    };
    setState((s) => ({ ...s, communities: [com, ...s.communities] }));
    return OK;
  }, []);

  const pinCommunityPost: Ctx["pinCommunityPost"] = useCallback((communityId, postId) =>
    setState((s) => ({ ...s, communities: s.communities.map((c) => c.id === communityId ? { ...c, pinnedPostIds: c.pinnedPostIds.includes(postId) ? c.pinnedPostIds.filter((x) => x !== postId) : [...c.pinnedPostIds, postId] } : c) })), []);

  const removeCommunityPost: Ctx["removeCommunityPost"] = useCallback((communityId, postId) => {
    setState((s) => ({ ...s, communities: s.communities.map((c) => c.id === communityId ? { ...c, pinnedPostIds: c.pinnedPostIds.filter((x) => x !== postId) } : c), posts: s.posts.filter((p) => p.id !== postId) }));
  }, []);

  /* ─────────── battles ─────────── */

  const createBattle: Ctx["createBattle"] = useCallback((input) => {
    if (!input.title?.trim()) return fail("Give the battle a name.");
    const b: Battle = {
      id: uid("battle"), title: input.title.trim(), description: input.description ?? "",
      creatorId: ME, language: input.language ?? "Python", difficulty: input.difficulty ?? "Medium",
      durationMinutes: input.durationMinutes ?? 30, maxPlayers: input.maxPlayers ?? 8, questionCount: input.questionCount ?? 3,
      startsAt: input.startsAt ?? new Date(Date.now() + 30 * 60_000).toISOString(), status: "open", access: input.access ?? "open",
      participants: [{ studentId: ME, ready: true }], scoring: input.scoring ?? ["Correctness", "Time as tie-breaker"],
    };
    setState((s) => ({ ...s, battles: [b, ...s.battles] }));
    pushNotification({ type: "battle", title: "Battle created", message: `${b.title} is open for challengers.`, icon: "battle", target: "battles" });
    return OK;
  }, [pushNotification]);

  const joinBattle: Ctx["joinBattle"] = useCallback((battleId) => {
    const b = state.battles.find((x) => x.id === battleId);
    if (!b) return fail("Battle not found.");
    if (b.status === "completed" || b.status === "cancelled" || b.status === "live") return fail("This battle is not open for joining.");
    if (b.participants.some((p) => p.studentId === ME)) return fail("You are already in this battle.");
    if (b.participants.length >= b.maxPlayers) return fail("This battle is full.");
    if (b.access === "invite") return fail("This battle is invite-only — ask the creator for an invitation.");
    setState((s) => ({ ...s, battles: s.battles.map((x) => x.id === battleId ? { ...x, participants: [...x.participants, { studentId: ME, ready: false }] } : x) }));
    return OK;
  }, [state.battles]);

  const leaveBattle: Ctx["leaveBattle"] = useCallback((battleId) =>
    setState((s) => ({ ...s, battles: s.battles.map((b) => b.id === battleId ? { ...b, participants: b.participants.filter((p) => p.studentId !== ME) } : b) })), []);

  const toggleReady: Ctx["toggleReady"] = useCallback((battleId) =>
    setState((s) => ({ ...s, battles: s.battles.map((b) => b.id === battleId ? { ...b, participants: b.participants.map((p) => p.studentId === ME ? { ...p, ready: !p.ready } : p) } : b) })), []);

  const startBattle: Ctx["startBattle"] = useCallback((battleId) => {
    const b = state.battles.find((x) => x.id === battleId);
    if (!b) return fail("Battle not found.");
    if (b.creatorId !== ME) return fail("Only the creator or an authorised host can start this battle.");
    setState((s) => ({ ...s, battles: s.battles.map((x) => x.id === battleId ? { ...x, status: "live" } : x) }));
    pushNotification({ type: "battle", title: "Battle is live", message: `${b.title} has started (local rehearsal).`, icon: "battle", target: "battles" });
    return OK;
  }, [state.battles, pushNotification]);

  /* ─────────── moderation / preferences ─────────── */

  const submitReport: Ctx["submitReport"] = useCallback((kind, targetId, reason) => {
    if (!reason.trim()) return fail("Add a short reason for the report.");
    setState((s) => ({ ...s, reports: [{ id: uid("rep"), kind, targetId, reason: reason.trim(), at: nowISO() }, ...s.reports] }));
    return OK;
  }, []);

  const markNotificationRead: Ctx["markNotificationRead"] = useCallback((id) =>
    setState((s) => ({ ...s, notifications: s.notifications.map((n) => n.id === id ? { ...n, unread: false } : n) })), []);

  const markAllNotificationsRead: Ctx["markAllNotificationsRead"] = useCallback(() =>
    setState((s) => ({ ...s, notifications: s.notifications.map((n) => ({ ...n, unread: false })) })), []);

  const setSettings: Ctx["setSettings"] = useCallback((patch) =>
    setState((s) => ({ ...s, settings: { ...s.settings, ...patch } })), []);

  const validateFile: Ctx["validateFile"] = useCallback((file) => {
    const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
    if (!["png", "jpg", "jpeg", "pdf", "zip", "py", "js", "ts", "jsx", "md"].includes(ext)) return fail(`.${ext || "?"} files are not permitted in the Hub.`);
    if (file.size > 20 * 1_000_000) return fail("Files are limited to 20 MB.");
    return OK;
  }, []);

  const reset = useCallback(() => { setState(defaults()); setTypingIn([]); }, []);

  const unreadChats = state.conversations.reduce((s, c) => s + c.unread, 0);
  const pendingIncomingRequests = state.requests.filter((r) => r.toId === ME && r.status === "pending");
  const pendingOutgoingRequests = state.requests.filter((r) => r.fromId === ME && r.status === "pending");
  const unreadNotifications = state.notifications.filter((n) => n.unread).length;

  const value = useMemo<Ctx>(() => ({
    state, me: studentById(ME), unreadChats, pendingIncomingRequests, pendingOutgoingRequests, unreadNotifications,
    sendMessage, retryMessage, editMessage, deleteMessage, reactToMessage, togglePinMessage,
    markConversationRead, togglePinConversation, toggleMuteConversation, leaveGroup, createGroup,
    regenerateInvite, revokeInvite, simulateIncoming, typingIn,
    sendRequest, acceptRequest, declineRequest, blockFromRequest, cancelRequest,
    toggleFollow, toggleBlock, toggleMuteUser,
    createPost, editPost, deletePost, toggleLike, toggleRepost, toggleBookmark, addComment, likeComment,
    reportComment, hidePost, votePoll,
    joinCommunity, leaveCommunity, createCommunity, pinCommunityPost, removeCommunityPost,
    createBattle, joinBattle, leaveBattle, toggleReady, startBattle,
    submitReport, markNotificationRead, markAllNotificationsRead, pushNotification, setSettings, validateFile, reset,
  }), [
    state, unreadChats, pendingIncomingRequests, pendingOutgoingRequests, unreadNotifications, sendMessage, retryMessage,
    editMessage, deleteMessage, reactToMessage, togglePinMessage, markConversationRead, togglePinConversation,
    toggleMuteConversation, leaveGroup, createGroup, regenerateInvite, revokeInvite, simulateIncoming, typingIn,
    sendRequest, acceptRequest, declineRequest, blockFromRequest, cancelRequest, toggleFollow, toggleBlock, toggleMuteUser,
    createPost, editPost, deletePost, toggleLike, toggleRepost, toggleBookmark, addComment, likeComment, reportComment,
    hidePost, votePoll, joinCommunity, leaveCommunity, createCommunity, pinCommunityPost, removeCommunityPost,
    createBattle, joinBattle, leaveBattle, toggleReady, startBattle, submitReport, markNotificationRead,
    markAllNotificationsRead, pushNotification, setSettings, validateFile, reset,
  ]);

  return <HubContext.Provider value={value}>{children}</HubContext.Provider>;
}

export function useHub() {
  const ctx = useContext(HubContext);
  if (!ctx) throw new Error("HubProvider is missing");
  return ctx;
}

/** Guard used everywhere a private conversation is opened. */
export function canDirectMessage(state: State, otherId: string) {
  if (state.blocked.includes(otherId)) return false;
  return state.conversations.some((c) => c.type === "direct" && c.participantIds?.includes(otherId));
}

export type { State as HubState };
