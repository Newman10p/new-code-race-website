/**
 * Dashboard registry.
 *
 * Single source of truth for the three "inside" experiences.
 * Labels / blurbs are placeholders — rename here and the dock,
 * placeholder pages and routes all follow.
 */
export type DashboardId = "user" | "organizer" | "admin";

export type DashboardMeta = {
  id: DashboardId;
  num: string;
  label: string;
  path: string;
  blurb: string;
};

export const dashboards: DashboardMeta[] = [
  { id: "user", num: "01", label: "User", path: "/dashboard/user", blurb: "Student competitor view" },
  { id: "organizer", num: "02", label: "Organizer", path: "/dashboard/organizer", blurb: "School / event coordinator" },
  { id: "admin", num: "03", label: "Admin", path: "/dashboard/admin", blurb: "Platform administration" },
];

/** TEMPORARY: flip to false (or delete DevDock) once real auth routing exists. */
export const SHOW_DEV_DOCK = true;

export function isDashboardPath(path: string): boolean {
  return path === "/dashboard" || path.startsWith("/dashboard/");
}

/** `/dashboard` is an alias for the user dashboard. */
export function normalizeDashboardPath(path: string): string {
  return path === "/dashboard" ? "/dashboard/user" : path;
}
