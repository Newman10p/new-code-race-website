import JSZip from "jszip";
import type { CodeLabProject } from "../data/codeLabData";

export async function exportProjectAsZip(project: CodeLabProject): Promise<void> {
  const zip = new JSZip();

  // Add files to zip archive
  for (const file of project.files) {
    zip.file(file.path, file.content);
  }

  // Generate binary zip
  const blob = await zip.generateAsync({ type: "blob" });

  // Trigger browser download
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${project.name.toLowerCase().replace(/[^a-z0-9_-]/g, "-") || "project"}.zip`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
