import { team, values } from "../data";
import { ButtonLink, Reveal, SectionHead, Stat } from "../components/ui";
import { ArrowRight, LogoMark } from "../components/icons";

export default function About() {
  return (
    <div className="relative z-10 mx-auto max-w-7xl px-5 pb-28 pt-32 sm:px-8 md:pt-40">
      <SectionHead
        index="A1"
        label="About CodeQuest"
        title={
          <>
            Built by students, <span className="text-[var(--blue)]">for students.</span>
          </>
        }
      />

      <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
        <Reveal>
          <div className="space-y-5 text-[15px] leading-relaxed text-[var(--text-2)]">
            <p>
              CodeQuest began as a shared document between four students at
              different schools — a simple list of the problems they wished a
              real competition would ask them. One semester later, that list
              became a platform.
            </p>
            <p>
              We believe school coding competitions should feel like the
              product they aspire to be: rigorous problems, honest scoring,
              fast results, and a community that keeps sharpening after the
              final whistle.
            </p>
            <p>
              Season 01 is our first open run across partner schools. Every
              round, problem, and rule is public. Every score is earned.
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-3 gap-4 self-start lg:pt-4">
          <Stat value={500} suffix="+" label="Students" />
          <Stat value={20} suffix="+" label="Schools" delay={120} />
          <Stat value={100} suffix="+" label="Challenges" delay={240} />
        </div>
      </div>

      {/* Values */}
      <div className="mt-20 grid gap-4 md:grid-cols-3">
        {values.map((v, i) => (
          <Reveal key={v.title} delay={i * 100}>
            <div className="panel card-hover clip-oct h-full p-6">
              <p className="mono-label mb-3 text-[var(--blue)]">V.0{i + 1}</p>
              <h3 className="display text-lg font-bold uppercase tracking-tight">{v.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-[var(--text-2)]">{v.copy}</p>
            </div>
          </Reveal>
        ))}
      </div>

      {/* Team */}
      <div className="mt-20">
        <Reveal>
          <p className="mono-label mb-8 flex items-center gap-3">
            <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
            The core team
          </p>
        </Reveal>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {team.map((m, i) => (
            <Reveal key={m.name} delay={i * 90}>
              <div className="panel card-hover clip-oct group p-6">
                <div
                  className="clip-oct flex h-16 w-16 items-center justify-center border border-[var(--border-strong)] bg-[var(--surface-2)] text-[var(--blue)] transition-all duration-300 group-hover:border-[var(--blue)] group-hover:[filter:drop-shadow(0_0_16px_var(--glow))]"
                >
                  <span className="display text-lg font-bold text-[var(--blue)]">{m.initials}</span>
                </div>
                <h3 className="display mt-5 text-base font-bold">{m.name}</h3>
                <p className="mt-1 font-mono text-[11px] tracking-wider text-[var(--text-3)]">{m.role}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      {/* CTA */}
      <Reveal delay={120}>
        <div className="mt-20 flex flex-col items-center gap-6 border-t border-[var(--border)] pt-12 text-center">
          <LogoMark className="h-10 w-10 text-[var(--text)]" />
          <h2 className="display max-w-xl text-3xl font-bold uppercase tracking-tight sm:text-4xl">
            Questions, schools, <span className="text-[var(--blue)]">collabs?</span>
          </h2>
          <ButtonLink to="/contact" size="lg" variant="ghost">
            Contact the team
            <ArrowRight className="h-4 w-4" />
          </ButtonLink>
        </div>
      </Reveal>
    </div>
  );
}
