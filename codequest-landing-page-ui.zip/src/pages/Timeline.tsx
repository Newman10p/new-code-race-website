import { fullTimeline } from "../data";
import { ButtonLink, OctagonNode, Reveal, SectionHead } from "../components/ui";
import { ArrowRight } from "../components/icons";

const scoring = [
  { label: "Base points", value: "100 per problem solved" },
  { label: "Time bonus", value: "Up to 50% of base, decays over the round" },
  { label: "Submissions", value: "Unlimited, no failed-run penalty" },
  { label: "Team rounds", value: "Best single submission per problem counts" },
];

export default function Timeline() {
  return (
    <div className="relative z-10 mx-auto max-w-7xl px-5 pb-28 pt-32 sm:px-8 md:pt-40">
      <SectionHead
        index="T1"
        label="Season 01 — 2026"
        title={
          <>
            The full <span className="text-[var(--blue)]">timeline.</span>
          </>
        }
      />

      <div className="grid gap-12 lg:grid-cols-[1fr_320px] lg:gap-16">
        {/* Vertical timeline */}
        <div className="relative">
          <div className="absolute bottom-4 left-[19px] top-4 w-px bg-[var(--border)]" aria-hidden="true" />
          <div className="flex flex-col gap-10">
            {fullTimeline.map((p, i) => (
              <Reveal key={p.id} delay={i * 80}>
                <div className="relative flex gap-6">
                  <div className="relative z-10 shrink-0 pt-1">
                    <OctagonNode active={p.status === "active"} size={40}>
                      {p.status === "active" ? (
                        <span className="pulse-dot h-2 w-2 rounded-full bg-white" />
                      ) : (
                        <span className="font-mono text-[10px] font-semibold">{String(i + 1).padStart(2, "0")}</span>
                      )}
                    </OctagonNode>
                  </div>
                  <div className="panel card-hover clip-oct flex-1 p-6">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="mono-label text-[var(--blue)]">{p.date}</p>
                      {p.status === "active" && (
                        <span className="flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-[var(--blue)]">
                          <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />
                          IN PROGRESS
                        </span>
                      )}
                    </div>
                    <h3 className="display mt-2 text-xl font-bold uppercase tracking-tight">{p.title}</h3>
                    <p className="mt-3 max-w-xl text-sm leading-relaxed text-[var(--text-2)]">{p.copy}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {p.chips.map((c) => (
                        <span
                          key={c}
                          className="clip-oct-sm border border-[var(--border-strong)] bg-[var(--surface-2)] px-3 py-1 font-mono text-[10.5px] tracking-wider text-[var(--text-2)]"
                        >
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6 lg:pt-2">
          <Reveal delay={150}>
            <div className="panel clip-oct p-6">
              <p className="mono-label mb-5 text-[var(--blue)]">Scoring</p>
              <ul className="space-y-4">
                {scoring.map((s) => (
                  <li key={s.label} className="flex items-start gap-3">
                    <span className="clip-oct-sm mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center border border-[var(--border-strong)]">
                      <span className="h-1 w-1 bg-[var(--blue)]" />
                    </span>
                    <div>
                      <p className="text-[13px] font-semibold">{s.label}</p>
                      <p className="mt-0.5 text-[12px] leading-relaxed text-[var(--text-2)]">{s.value}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          <Reveal delay={250}>
            <div className="panel clip-oct p-6 text-center">
              <p className="mono-label mb-3">Ready when you are</p>
              <p className="text-sm leading-relaxed text-[var(--text-2)]">
                Registration closes Feb 02, 2026. Seats are free for all
                partner schools.
              </p>
              <ButtonLink to="/login?mode=join" className="mt-5 w-full">
                Register Now
                <ArrowRight className="h-4 w-4" />
              </ButtonLink>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
