import { useState, type FormEvent } from "react";
import { cn } from "../utils/cn";
import { Reveal, SectionHead } from "../components/ui";
import { Button } from "../components/ui";
import { CheckIcon, GitHubIcon, LinkedInIcon, MailIcon, XIcon } from "../components/icons";

type Errors = Partial<Record<"name" | "email" | "message", string>>;

const inputCls =
  "w-full border border-[var(--border-strong)] bg-[var(--surface-2)] px-4 py-3 text-sm text-[var(--text)] placeholder:text-[var(--text-3)] transition-colors duration-200 focus:border-[var(--blue)] focus:outline-none";

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [school, setSchool] = useState("");
  const [topic, setTopic] = useState("General");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [sent, setSent] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const next: Errors = {};
    if (name.trim().length < 2) next.name = "Enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email address.";
    if (message.trim().length < 10) next.message = "Tell us a little more (10+ characters).";
    setErrors(next);
    if (Object.keys(next).length === 0) setSent(true);
  };

  const reset = () => {
    setSent(false);
    setName("");
    setEmail("");
    setSchool("");
    setTopic("General");
    setMessage("");
    setErrors({});
  };

  return (
    <div className="relative z-10 mx-auto max-w-7xl px-5 pb-28 pt-32 sm:px-8 md:pt-40">
      <SectionHead
        index="C1"
        label="Contact"
        title={
          <>
            Talk to <span className="text-[var(--blue)]">the grid.</span>
          </>
        }
      />

      <div className="grid gap-10 lg:grid-cols-[1fr_340px] lg:gap-14">
        <Reveal>
          {sent ? (
            <div className="panel clip-oct panel-in p-8 text-center sm:p-12">
              <span className="clip-oct mx-auto flex h-16 w-16 items-center justify-center border border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)] [filter:drop-shadow(0_0_16px_var(--glow))]">
                <CheckIcon className="h-7 w-7" />
              </span>
              <h3 className="display mt-6 text-2xl font-bold uppercase tracking-tight">Message received</h3>
              <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-[var(--text-2)]">
                Thanks, {name.split(" ")[0] || "contender"}. We reply to most
                messages within 48 hours.
              </p>
              <p className="mono-label mt-6 opacity-60">
                Frontend preview — no message was actually sent.
              </p>
              <Button variant="ghost" className="mt-7" onClick={reset}>
                Send another
              </Button>
            </div>
          ) : (
            <form onSubmit={submit} noValidate className="panel clip-oct p-7 sm:p-9">
              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label htmlFor="c-name" className="mono-label mb-2 block">
                    Name
                  </label>
                  <input
                    id="c-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your full name"
                    className={cn(inputCls, errors.name && "border-red-400/70")}
                  />
                  {errors.name && <p className="mt-1.5 text-xs text-red-400">{errors.name}</p>}
                </div>
                <div>
                  <label htmlFor="c-email" className="mono-label mb-2 block">
                    Email
                  </label>
                  <input
                    id="c-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@school.edu"
                    className={cn(inputCls, errors.email && "border-red-400/70")}
                  />
                  {errors.email && <p className="mt-1.5 text-xs text-red-400">{errors.email}</p>}
                </div>
                <div>
                  <label htmlFor="c-school" className="mono-label mb-2 block">
                    School <span className="opacity-50">(optional)</span>
                  </label>
                  <input
                    id="c-school"
                    value={school}
                    onChange={(e) => setSchool(e.target.value)}
                    placeholder="Your school"
                    className={inputCls}
                  />
                </div>
                <div>
                  <label htmlFor="c-topic" className="mono-label mb-2 block">
                    Topic
                  </label>
                  <select
                    id="c-topic"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    className={cn(inputCls, "cursor-pointer")}
                  >
                    {["General", "Registration", "School partnership", "Report an issue", "Press"].map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label htmlFor="c-msg" className="mono-label mb-2 block">
                    Message
                  </label>
                  <textarea
                    id="c-msg"
                    rows={5}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder={topic + "…"}
                    className={cn(inputCls, "resize-none", errors.message && "border-red-400/70")}
                  />
                  {errors.message && <p className="mt-1.5 text-xs text-red-400">{errors.message}</p>}
                </div>
              </div>
              <div className="mt-7 flex items-center justify-between gap-4">
                <p className="hidden font-mono text-[10.5px] tracking-wider text-[var(--text-3)] sm:block">
                  // avg response time: 48h
                </p>
                <Button type="submit" size="lg" className="ml-auto">
                  Send Message
                </Button>
              </div>
            </form>
          )}
        </Reveal>

        {/* Info column */}
        <div className="space-y-6">
          <Reveal delay={120}>
            <div className="panel clip-oct p-6">
              <p className="mono-label mb-5">Reach us directly</p>
              <a
                href="mailto:hello@codequest.dev"
                className="group flex items-center gap-3 text-sm font-semibold transition-colors hover:text-[var(--blue)]"
              >
                <span className="clip-oct-sm flex h-9 w-9 items-center justify-center border border-[var(--border-strong)] transition-colors group-hover:border-[var(--blue)]">
                  <MailIcon className="h-4 w-4 text-[var(--blue)]" />
                </span>
                hello@codequest.dev
              </a>
              <div className="mt-5 flex gap-2.5">
                {[
                  { label: "GitHub", icon: GitHubIcon, href: "https://github.com" },
                  { label: "X", icon: XIcon, href: "https://x.com" },
                  { label: "LinkedIn", icon: LinkedInIcon, href: "https://linkedin.com" },
                ].map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={s.label}
                    className="clip-oct-sm flex h-9 w-9 items-center justify-center border border-[var(--border-strong)] text-[var(--text-2)] transition-all duration-300 hover:-translate-y-0.5 hover:border-[var(--blue)] hover:text-[var(--blue)]"
                  >
                    <s.icon className="h-4 w-4" />
                  </a>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal delay={220}>
            <div className="panel clip-oct p-6">
              <p className="mono-label mb-4">For schools</p>
              <p className="text-sm leading-relaxed text-[var(--text-2)]">
                Running a school with 10+ interested students? We provide
                coordinator accounts, practice problem sets, and event-day
                support at no cost.
              </p>
              <a
                href="mailto:schools@codequest.dev"
                className="mt-4 inline-block font-mono text-[12px] tracking-wider text-[var(--blue)] transition-opacity hover:opacity-75"
              >
                schools@codequest.dev →
              </a>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
