import { useEffect, useState, type FormEvent } from "react";
import { cn } from "../utils/cn";
import { Link } from "../lib/router";
import { Button } from "../components/ui";
import AuthShell, { fieldCls } from "../components/AuthShell";
import { ArrowLeft, CheckIcon, EyeIcon, EyeOffIcon, MailIcon } from "../components/icons";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function mask(email: string) {
  const [user, domain] = email.split("@");
  const head = user.slice(0, Math.min(2, user.length));
  return `${head}${"•".repeat(Math.max(3, user.length - head.length))}@${domain}`;
}

const tips = [
  "Reset links expire 30 minutes after they're sent.",
  "Check your school spam folder — some districts quarantine mail.",
  "Still nothing? Your school coordinator can re-verify your address.",
];

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [sentTo, setSentTo] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(0);
  const [showPw, setShowPw] = useState(false);
  const [newPw, setNewPw] = useState("");
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (countdown <= 0) return;
    const t = window.setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => window.clearTimeout(t);
  }, [countdown]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!EMAIL_RE.test(email)) {
      setError("Enter a valid email address.");
      return;
    }
    setError(null);
    setSentTo(email);
    setCountdown(30);
  };

  const setNewPassword = (e: FormEvent) => {
    e.preventDefault();
    if (newPw.length < 8) {
      setError("New password must be at least 8 characters.");
      return;
    }
    setError(null);
    setDone(true);
  };

  return (
    <AuthShell
      eyebrow="Season 01 · Account recovery"
      title={
        <>
          Recover your <span className="text-[var(--blue)]">profile.</span>
        </>
      }
      lede="Password resets are single-use and tied to your registered school email. No account data is lost between rounds."
      footnote="Average recovery time — under 2 minutes"
    >
      <Link
        to="/login"
        className="mono-label mb-7 inline-flex items-center gap-2 transition-colors hover:text-[var(--blue)]"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        Back to sign in
      </Link>

      {done ? (
        <div className="panel-in">
          <span className="clip-oct flex h-16 w-16 items-center justify-center border border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)] [filter:drop-shadow(0_0_16px_var(--glow))]">
            <CheckIcon className="h-7 w-7" />
          </span>
          <h2 className="display mt-6 text-2xl font-bold tracking-tight">Password updated</h2>
          <p className="mt-2 max-w-sm text-[13.5px] leading-relaxed text-[var(--text-2)]">
            Your CodeQuest profile is secure again. Sign in with the new
            password to return to the arena.
          </p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <Link to="/login" className="btn-shell btn-primary-shell btn-shell-md flex-1">
              <span className="btn-core">Back to Sign In</span>
            </Link>
            <Link to="/" className="btn-shell btn-ghost-shell btn-shell-md flex-1">
              <span className="btn-core">Go Home</span>
            </Link>
          </div>
        </div>
      ) : sentTo ? (
        <div className="panel-in">
          <p className="mono-label mb-6 flex items-center gap-3 text-[var(--blue)]">
            <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
            Reset link sent
          </p>

          <div className="panel clip-oct p-5">
            <div className="flex items-center gap-3">
              <span className="clip-oct-sm flex h-9 w-9 shrink-0 items-center justify-center border border-[var(--border-strong)] bg-[var(--surface-2)] text-[var(--blue)]">
                <MailIcon className="h-4 w-4" />
              </span>
              <div className="min-w-0">
                <p className="text-[13px] font-semibold">Check your inbox</p>
                <p className="truncate font-mono text-[11.5px] tracking-wider text-[var(--text-2)]">
                  {mask(sentTo)}
                </p>
              </div>
            </div>
            <p className="mt-4 border-t border-[var(--border)] pt-4 text-[12.5px] leading-relaxed text-[var(--text-2)]">
              We sent a single-use link. It expires in 30 minutes — request a
              fresh one if it lapses.
            </p>
          </div>

          {/* Frontend preview: inline new-password step */}
          <form onSubmit={setNewPassword} className="mt-6">
            <label htmlFor="f-pw" className="mono-label mb-2 block">
              Choose a new password
            </label>
            <div className="relative">
              <input
                id="f-pw"
                type={showPw ? "text" : "password"}
                value={newPw}
                onChange={(e) => setNewPw(e.target.value)}
                placeholder="At least 8 characters"
                className={cn(fieldCls, "pr-12", error && "border-red-400/70")}
              />
              <button
                type="button"
                onClick={() => setShowPw((v) => !v)}
                aria-label={showPw ? "Hide password" : "Show password"}
                className="absolute right-1 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center text-[var(--text-3)] transition-colors hover:text-[var(--blue)]"
              >
                {showPw ? <EyeOffIcon className="h-4.5 w-4.5" /> : <EyeIcon className="h-4.5 w-4.5" />}
              </button>
            </div>
            {error && <p className="mt-1.5 text-xs text-red-400">{error}</p>}
            <Button type="submit" size="lg" className="mt-5 w-full">
              Set New Password
            </Button>
          </form>

          <div className="mt-6 flex items-center justify-between gap-4 border-t border-[var(--border)] pt-5">
            <span className="font-mono text-[11px] tracking-wider text-[var(--text-3)]">
              Didn't get it?
            </span>
            <button
              type="button"
              disabled={countdown > 0}
              onClick={() => setCountdown(30)}
              className={cn(
                "font-mono text-[11px] tracking-wider transition-colors",
                countdown > 0
                  ? "cursor-not-allowed text-[var(--text-3)]"
                  : "text-[var(--blue)] hover:opacity-75"
              )}
            >
              {countdown > 0 ? `Resend in ${countdown}s` : "Resend link"}
            </button>
          </div>
        </div>
      ) : (
        <div>
          <h2 className="display text-2xl font-bold tracking-tight">Reset your password</h2>
          <p className="mt-2 max-w-sm text-[13.5px] leading-relaxed text-[var(--text-2)]">
            Enter the email registered to your CodeQuest profile and we'll
            send a single-use reset link.
          </p>

          <form onSubmit={submit} noValidate className="mt-7">
            <label htmlFor="f-email" className="mono-label mb-2 block">
              Registered email
            </label>
            <input
              id="f-email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@school.edu"
              className={cn(fieldCls, error && "border-red-400/70")}
            />
            {error && <p className="mt-1.5 text-xs text-red-400">{error}</p>}
            <Button type="submit" size="lg" className="mt-5 w-full">
              Send Reset Link
            </Button>
          </form>

          <div className="mt-8 border-t border-[var(--border)] pt-6">
            <p className="mono-label mb-4">Recovery notes</p>
            <ul className="space-y-3">
              {tips.map((t) => (
                <li key={t} className="flex items-start gap-3 text-[12.5px] leading-relaxed text-[var(--text-2)]">
                  <span className="clip-oct-sm mt-1 flex h-4 w-4 shrink-0 items-center justify-center border border-[var(--border-strong)]">
                    <span className="h-1 w-1 bg-[var(--blue)]" />
                  </span>
                  {t}
                </li>
              ))}
            </ul>
            <p className="mt-5 text-[12.5px] text-[var(--text-3)]">
              Locked out entirely?{" "}
              <Link to="/contact" className="text-[var(--blue)] hover:opacity-75">
                Contact support
              </Link>
              .
            </p>
          </div>
        </div>
      )}
    </AuthShell>
  );
}
