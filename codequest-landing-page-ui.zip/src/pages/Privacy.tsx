import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { Link } from "../lib/router";
import { ButtonLink, Reveal, SectionHead } from "../components/ui";
import { ArrowRight } from "../components/icons";

type Doc = { id: string; n: string; title: string; paras: string[] };

const doc: Doc[] = [
  {
    id: "collect",
    n: "P.01",
    title: "Information we collect",
    paras: [
      "To run a competition, CodeQuest needs a small, defined set of data: your name, your school, your year group, an email address, and a display name you choose for leaderboards.",
      "During rounds we record your submissions, timestamps, scores, and results. These are competition records — they exist to keep scoring fair and verifiable, and they are never used to profile you outside CodeQuest.",
      "We collect minimal technical data — device type, browser, and approximate region — to keep the platform stable during live rounds.",
    ],
  },
  {
    id: "use",
    n: "P.02",
    title: "How we use your information",
    paras: [
      "Your data is used to operate the competition: to verify your school eligibility, score your submissions, publish rankings, and notify you about rounds you have registered for.",
      "We also use aggregate, de-identified statistics — such as how many schools participated or how a problem was solved across the field — to improve future problem sets.",
      "We do not use your data for advertising, and we do not sell or rent it to anyone. Ever.",
    ],
  },
  {
    id: "leaderboard",
    n: "P.03",
    title: "Leaderboard and display names",
    paras: [
      "Leaderboards show your chosen display name, your school, and your score. This is intentional: competition standing must be public to be meaningful.",
      "You control your display name. Real names and email addresses are never published on rankings, and we recommend choosing a display name you are comfortable seeing in public.",
      "Rank movement indicators (▲/▼) are calculated only from your own round results relative to other participants.",
    ],
  },
  {
    id: "storage",
    n: "P.04",
    title: "Cookies and local storage",
    paras: [
      "CodeQuest uses strictly necessary storage to keep you signed in and to remember preferences such as your theme choice (light or dark).",
      "We do not use third-party advertising cookies or cross-site tracking pixels. Analytics, where enabled, are aggregated and anonymised.",
    ],
  },
  {
    id: "sharing",
    n: "P.05",
    title: "Sharing and disclosure",
    paras: [
      "Your school coordinator can see the roster and results of students registered through that school — this is how inter-school competition is organised.",
      "We disclose data to service providers only where necessary to run the platform (for example, email delivery), and only under contracts that prohibit any other use.",
      "If required by law, or to protect the integrity of a live round, we may disclose limited information to schools or authorities — with a record of what was shared.",
    ],
  },
  {
    id: "retention",
    n: "P.06",
    title: "Data retention",
    paras: [
      "Competition records are kept for the season plus 12 months, so that results can be audited and historical standings remain accurate.",
      "Accounts deleted at season end are purged within 30 days, except where a record must be retained to resolve a scoring dispute already in progress.",
    ],
  },
  {
    id: "security",
    n: "P.07",
    title: "Security",
    paras: [
      "Passwords are hashed; sessions expire; round results are checked server-side. Access to participant data is limited to organizers who need it to run the competition.",
      "If we ever become aware of a breach affecting your personal data, we will notify you and your school coordinator promptly, with plain-language detail on what happened.",
    ],
  },
  {
    id: "students",
    n: "P.08",
    title: "Students and younger participants",
    paras: [
      "CodeQuest is built for school students. Where a participant is below the age of digital consent in their region, registration must be confirmed by a teacher, school coordinator, or guardian.",
      "We never require more personal information from a student than is necessary to verify eligibility and score the competition.",
    ],
  },
  {
    id: "rights",
    n: "P.09",
    title: "Your rights and choices",
    paras: [
      "You can request a copy of your data, correct it, or ask us to delete your account at any time. Deleting your account removes your profile; published round results are anonymised rather than erased where they affect other participants' standings.",
      "You can opt out of non-essential round reminders while keeping essential competition notices.",
      "Requests are answered through hello@codequest.dev, normally within 30 days.",
    ],
  },
  {
    id: "changes",
    n: "P.10",
    title: "Changes to this policy",
    paras: [
      "If the way we handle data changes materially, we will update this page and notify registered participants before the change takes effect — never silently mid-season.",
    ],
  },
  {
    id: "contact",
    n: "P.11",
    title: "Contact",
    paras: [
      "Questions about this policy go to our privacy contact at privacy@codequest.dev, or through the contact page. For general competition questions, use hello@codequest.dev.",
    ],
  },
];

export default function Privacy() {
  const [active, setActive] = useState(doc[0].id);

  useEffect(() => {
    const els = doc
      .map((s) => document.getElementById(s.id))
      .filter((el): el is HTMLElement => Boolean(el));
    if (!els.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setActive(visible[0].target.id);
      },
      { rootMargin: "-96px 0px -60% 0px", threshold: 0 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  const jump = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="relative z-10 mx-auto max-w-7xl px-5 pb-28 pt-32 sm:px-8 md:pt-40">
      <SectionHead
        index="P1"
        label="Legal — last updated Feb 12, 2026"
        title={
          <>
            Privacy <span className="text-[var(--blue)]">policy.</span>
          </>
        }
      />

      <Reveal>
        <div className="panel clip-oct mb-12 flex flex-col gap-5 p-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="max-w-2xl text-sm leading-relaxed text-[var(--text-2)]">
            CodeQuest handles student data. This page states, in plain
            language, exactly what we collect, why we collect it, and what you
            can ask us to do with it.
          </p>
          <div className="flex shrink-0 gap-3">
            <span className="clip-oct-sm border border-[var(--border-strong)] bg-[var(--surface-2)] px-3 py-1.5 font-mono text-[10.5px] tracking-wider text-[var(--text-2)]">
              DOC P.01 — v1.2
            </span>
            <span className="clip-oct-sm border border-[var(--blue)]/50 bg-[var(--blue-soft)] px-3 py-1.5 font-mono text-[10.5px] tracking-wider text-[var(--blue)]">
              IN EFFECT
            </span>
          </div>
        </div>
      </Reveal>

      <div className="grid gap-10 lg:grid-cols-[240px_minmax(0,1fr)] lg:gap-14">
        {/* Sticky contents rail */}
        <nav aria-label="Policy contents" className="lg:sticky lg:top-24 lg:self-start">
          <p className="mono-label mb-4">Contents</p>
          <ul className="-mx-1 flex gap-1.5 overflow-x-auto pb-3 lg:mx-0 lg:block lg:space-y-0.5 lg:overflow-visible lg:pb-0">
            {doc.map((s) => (
              <li key={s.id} className="shrink-0 lg:shrink">
                <button
                  onClick={() => jump(s.id)}
                  className={cn(
                    "flex w-full items-center gap-2.5 whitespace-nowrap border px-3 py-1.5 text-left font-mono text-[11px] tracking-wider transition-all duration-200",
                    active === s.id
                      ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]"
                      : "border-[var(--border)] text-[var(--text-3)] hover:border-[var(--border-strong)] hover:text-[var(--text-2)]"
                  )}
                >
                  <span
                    className={cn(
                      "inline-block h-1.5 w-1.5 rotate-45 transition-colors",
                      active === s.id ? "bg-[var(--blue)]" : "bg-[var(--border-strong)]"
                    )}
                  />
                  {s.n} {s.title}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Document */}
        <article className="min-w-0 space-y-12">
          {doc.map((s) => (
            <section key={s.id} id={s.id} className="scroll-mt-24">
              <Reveal>
                <div className="flex items-baseline gap-4 border-b border-[var(--border)] pb-3">
                  <span className="mono-label text-[var(--blue)]">{s.n}</span>
                  <h2 className="display text-xl font-bold uppercase tracking-tight sm:text-2xl">
                    {s.title}
                  </h2>
                </div>
                <div className="mt-5 space-y-4">
                  {s.paras.map((p) => (
                    <p key={p.slice(0, 24)} className="max-w-2xl text-[14.5px] leading-relaxed text-[var(--text-2)]">
                      {p}
                    </p>
                  ))}
                </div>
              </Reveal>
            </section>
          ))}

          <Reveal>
            <div className="panel clip-oct flex flex-col items-start gap-5 p-7 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h3 className="display text-lg font-bold uppercase tracking-tight">
                  Still have questions?
                </h3>
                <p className="mt-1.5 text-sm text-[var(--text-2)]">
                  Our privacy contact replies within 30 days.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <ButtonLink to="/contact" size="md">
                  Contact us
                  <ArrowRight className="h-4 w-4" />
                </ButtonLink>
                <a
                  href="mailto:privacy@codequest.dev"
                  className="btn-shell btn-ghost-shell btn-shell-md"
                >
                  <span className="btn-core">privacy@codequest.dev</span>
                </a>
              </div>
            </div>
            <p className="mt-6 text-[12.5px] text-[var(--text-3)]">
              Looking for participation terms?{" "}
              <Link to="/login" className="text-[var(--blue)] hover:opacity-75">
                Create a profile
              </Link>{" "}
              and accept the Season 01 rules there, or{" "}
              <Link to="/about" className="text-[var(--blue)] hover:opacity-75">
                read how CodeQuest works
              </Link>
              .
            </p>
          </Reveal>
        </article>
      </div>
    </div>
  );
}
