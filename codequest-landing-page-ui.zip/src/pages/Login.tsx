import { useMemo, useState, type FormEvent } from "react";
import { cn } from "../utils/cn";
import { Link, parseRoute, useRoute } from "../lib/router";
import { Button } from "../components/ui";
import AuthShell, { fieldCls } from "../components/AuthShell";
import { EyeIcon, EyeOffIcon, OctagonFrame } from "../components/icons";

type Errors = Partial<Record<"name" | "school" | "email" | "password" | "agree", string>>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function strengthOf(pw: string): { score: number; label: string } {
  let s = 0;
  if (pw.length >= 8) s++;
  if (pw.length >= 12) s++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
  if (/\d/.test(pw) && /[^A-Za-z0-9]/.test(pw)) s++;
  const labels = ["Too short", "Weak", "Fair", "Strong", "Elite"];
  return { score: s, label: labels[s] };
}

export default function Login() {
  const route = useRoute();
  const { query } = parseRoute(route);
  const mode: "signin" | "join" = query.get("mode") === "join" ? "join" : "signin";

  const [name, setName] = useState("");
  const [school, setSchool] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [agree, setAgree] = useState(false);
  const [errors, setErrors] = useState<Errors>({});
  const [notice, setNotice] = useState<string | null>(null);
  const [entered, setEntered] = useState(false);

  const pwStrength = useMemo(() => strengthOf(password), [password]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const next: Errors = {};
    if (mode === "join") {
      if (name.trim().length < 2) next.name = "Enter your full name.";
      if (school.trim().length < 2) next.school = "Which school are you competing for?";
      if (!agree) next.agree = "Accept the competition rules to continue.";
    }
    if (!EMAIL_RE.test(email)) next.email = "Enter a valid email address.";
    if (password.length < 8) next.password = "Password must be at least 8 characters.";
    setErrors(next);
    if (Object.keys(next).length > 0) {
      setNotice(null);
      setEntered(false);
      return;
    }
    setEntered(true);
    setNotice(
      mode === "join"
        ? "Profile created (preview). Your Season 01 seat is reserved — registration lands when auth goes live."
        : "Signed in (preview). The gateway unlocks for real once Season 01 registration opens."
    );
  };

  const err = (k: keyof Errors) =>
    errors[k] ? (
      <p className="mt-1.5 text-xs text-red-400">{errors[k]}</p>
    ) : null;

  const idp = [
    { label: "Continue with School SSO", sub: "Partner schools" },
    { label: "Continue with GitHub", sub: "Student devs" },
  ];

  return (
    <AuthShell
      eyebrow={mode === "join" ? "Season 01 · Register" : "Season 01 · Authenticate"}
      title={
        mode === "join" ? (
          <>
            Claim your <span className="text-[var(--blue)]">seat.</span>
          </>
        ) : (
          <>
            Every quest starts with <span className="text-[var(--blue)]">one line.</span>
          </>
        )
      }
      lede={
        mode === "join"
          ? "One profile for every round — your scores, your school, and your position on the CodeQuest leaderboard."
          : "Sign in to track your ranking, follow rounds live, and pick up where the last challenge left you."
      }
      footnote="Registration open — closes Feb 02, 2026"
    >
      {/* Tabs */}
      <div className="clip-oct-sm grid grid-cols-2 border border-[var(--border-strong)] p-1">
        {(
          [
            { id: "signin", label: "Sign In", to: "/login" },
            { id: "join", label: "Join CodeQuest", to: "/login?mode=join" },
          ] as const
        ).map((t) => (
          <Link
            key={t.id}
            to={t.to}
            className={cn(
              "clip-oct-sm py-2 text-center font-display text-[13px] font-semibold transition-all duration-300",
              mode === t.id
                ? "bg-[var(--blue-strong)] text-white [filter:drop-shadow(0_0_12px_var(--glow))]"
                : "text-[var(--text-2)] hover:text-[var(--text)]"
            )}
          >
            {t.label}
          </Link>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="display text-2xl font-bold tracking-tight">
          {mode === "join" ? "Create your profile" : "Welcome back"}
        </h2>
        <p className="mt-1.5 text-[13px] text-[var(--text-2)]">
          {mode === "join"
            ? "Free for all partner-school students."
            : "Sign in to your CodeQuest profile."}
        </p>
      </div>

      <form onSubmit={submit} noValidate className="mt-7 space-y-5">
        {mode === "join" && (
          <div>
            <label htmlFor="l-name" className="mono-label mb-2 block">
              Full name
            </label>
            <input
              id="l-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Alex Mercer"
              className={cn(fieldCls, errors.name && "border-red-400/70")}
            />
            {err("name")}
          </div>
        )}

        {mode === "join" && (
          <div>
            <label htmlFor="l-school" className="mono-label mb-2 block">
              School
            </label>
            <input
              id="l-school"
              value={school}
              onChange={(e) => setSchool(e.target.value)}
              placeholder="Northview Academy"
              className={cn(fieldCls, errors.school && "border-red-400/70")}
            />
            {err("school")}
          </div>
        )}

        <div>
          <label htmlFor="l-email" className="mono-label mb-2 block">
            Email
          </label>
          <input
            id="l-email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@school.edu"
            className={cn(fieldCls, errors.email && "border-red-400/70")}
          />
          {err("email")}
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between gap-3">
            <label htmlFor="l-pass" className="mono-label block">
              Password
            </label>
            {mode === "signin" && (
              <Link
                to="/forgot-password"
                className="font-mono text-[10.5px] tracking-wider text-[var(--text-3)] transition-colors hover:text-[var(--blue)]"
              >
                Forgot password?
              </Link>
            )}
          </div>
          <div className="relative">
            <input
              id="l-pass"
              type={showPw ? "text" : "password"}
              autoComplete={mode === "join" ? "new-password" : "current-password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className={cn(fieldCls, "pr-12", errors.password && "border-red-400/70")}
            />
            <button
              type="button"
              onClick={() => setShowPw((v) => !v)}
              aria-label={showPw ? "Hide password" : "Show password"}
              className="absolute right-1 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center text-[var(--text-3)] transition-colors hover:text-[var(--blue)]"
            >
              {showPw ? <EyeOffIcon className="h-4.5 w-4.5" /> : <EyeIcon className="h-4.5 w-4.5" />}
            </button>
          </div>
          {err("password")}

          {mode === "join" && password.length > 0 && (
            <div className="mt-3 flex items-center gap-3">
              <div className="flex gap-1.5" aria-hidden="true">
                {[0, 1, 2, 3].map((i) => (
                  <span
                    key={i}
                    className={cn(
                      "clip-oct-sm h-2.5 w-6 transition-all duration-300",
                      i < pwStrength.score
                        ? "bg-[var(--blue)] [filter:drop-shadow(0_0_6px_var(--glow))]"
                        : "bg-[var(--border-strong)]"
                    )}
                  />
                ))}
              </div>
              <span className="font-mono text-[10.5px] tracking-wider text-[var(--text-3)]">
                strength: <span className="text-[var(--blue)]">{pwStrength.label}</span>
              </span>
            </div>
          )}
        </div>

        {mode === "signin" ? (
          <label className="flex cursor-pointer items-center gap-2.5 text-[12.5px] text-[var(--text-2)]">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="h-3.5 w-3.5 accent-[var(--blue)]"
            />
            Keep me signed in
          </label>
        ) : (
          <div>
            <label className="flex cursor-pointer items-start gap-2.5 text-[12.5px] text-[var(--text-2)]">
              <input
                type="checkbox"
                checked={agree}
                onChange={(e) => setAgree(e.target.checked)}
                className="mt-0.5 h-3.5 w-3.5 accent-[var(--blue)]"
              />
              <span>
                I accept the competition rules and the{" "}
                <Link to="/privacy" className="text-[var(--blue)] hover:opacity-75">
                  Privacy Policy
                </Link>
                .
              </span>
            </label>
            {err("agree")}
          </div>
        )}

        <Button type="submit" size="lg" className="w-full">
          {mode === "join" ? "Create My Profile" : "Sign In"}
        </Button>

        {notice && (
          <div className="panel-in clip-oct-sm flex items-start gap-3 border border-[var(--blue)]/40 bg-[var(--blue-soft)] p-3.5">
            <span className="clip-oct-sm mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center bg-[var(--blue)] text-white">
              <OctagonFrame className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0">
              <p className="text-[12.5px] leading-relaxed text-[var(--text)]">{notice}</p>
              {entered && (
                <Link
                  to="/dashboard/user"
                  className="mt-2.5 inline-flex items-center gap-2 font-mono text-[11px] font-semibold tracking-wider text-[var(--blue)] transition-opacity hover:opacity-75"
                >
                  Enter dashboard (preview) →
                </Link>
              )}
            </div>
          </div>
        )}
      </form>

      {/* Identity providers */}
      <div className="mt-7">
        <div className="flex items-center gap-4" aria-hidden="true">
          <span className="h-px flex-1 bg-[var(--border)]" />
          <span className="mono-label text-[10px]">or</span>
          <span className="h-px flex-1 bg-[var(--border)]" />
        </div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          {idp.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => {
                setEntered(false);
                setNotice(`Identity provider hand-off is disabled in this frontend preview — ${p.sub}.`);
              }}
              className="clip-oct-sm group flex flex-col items-start gap-0.5 border border-[var(--border-strong)] bg-[var(--surface-2)] px-3.5 py-2.5 text-left transition-all duration-300 hover:border-[var(--blue)] hover:bg-[var(--blue-soft)]"
            >
              <span className="font-display text-[12.5px] font-semibold text-[var(--text)] transition-colors group-hover:text-[var(--blue)]">
                {p.label}
              </span>
              <span className="font-mono text-[10px] tracking-wider text-[var(--text-3)]">{p.sub}</span>
            </button>
          ))}
        </div>
      </div>

      <p className="mt-7 text-center font-mono text-[11px] tracking-wider text-[var(--text-3)]">
        {mode === "join" ? (
          <>
            Already registered?{" "}
            <Link to="/login" className="text-[var(--blue)] transition-opacity hover:opacity-75">
              Sign in
            </Link>
          </>
        ) : (
          <>
            New to CodeQuest?{" "}
            <Link to="/login?mode=join" className="text-[var(--blue)] transition-opacity hover:opacity-75">
              Join the competition
            </Link>
          </>
        )}
      </p>

      <p className="mt-4 text-center text-[11px] leading-relaxed text-[var(--text-3)]">
        By continuing you agree to our{" "}
        <Link to="/privacy" className="text-[var(--text-2)] underline-offset-2 hover:text-[var(--blue)] hover:underline">
          Privacy Policy
        </Link>{" "}
        and the Season 01 competition rules.
      </p>
    </AuthShell>
  );
}
