import { useEffect, useMemo, useState } from "react";
import { cn } from "../../../utils/cn";
import {
  CATEGORIES,
  DIFFICULTIES,
  achievements,
  difficultyXp,
  packs,
  questions as allQuestions,
  type Difficulty,
  type Question,
  type QuestionStatus,
} from "../../../data/practiceData";
import { usePractice } from "../../../lib/practiceStore";
import { OctagonNode, Reveal, useAnimatedNumber } from "../../../components/ui";
import {
  SearchIcon,
  ArrowRight,
  CheckIcon,
  TrophyIcon,
  SparklesIcon,
  CodeIcon,
  FlameIcon,
  MegaphoneIcon,
  UsersIcon,
} from "../../../components/icons";

const STATUS_STYLE: Record<QuestionStatus, { label: string; cls: string }> = {
  NEW: { label: "NEW", cls: "border-[var(--blue)] text-[var(--blue)] bg-[var(--blue-soft)]" },
  "NOT STARTED": { label: "NOT STARTED", cls: "border-[var(--border-strong)] text-[var(--text-3)]" },
  "IN PROGRESS": { label: "IN PROGRESS", cls: "border-[#F2C94C] text-[#F2C94C]" },
  COMPLETED: { label: "COMPLETED", cls: "border-[#5DD39E] text-[#5DD39E]" },
  "ATTEMPT AGAIN": { label: "ATTEMPT AGAIN", cls: "border-[#FF6B6B] text-[#FF6B6B]" },
};

const ACTION_BY_STATUS: Record<QuestionStatus, string> = {
  NEW: "Start Challenge",
  "NOT STARTED": "Start Challenge",
  "IN PROGRESS": "Continue Solving",
  COMPLETED: "View Solution",
  "ATTEMPT AGAIN": "Try Again",
};

const DIFF_TONE: Record<Difficulty, string> = {
  Beginner: "#5DD39E",
  Intermediate: "var(--blue)",
  Advanced: "#F2C94C",
  Expert: "#FF6B6B",
};

const SORTS = [
  { id: "recent", label: "Recently Added" },
  { id: "xp", label: "Highest Points" },
  { id: "time", label: "Shortest Time" },
  { id: "hard", label: "Most Challenging" },
] as const;

const diffRank: Record<Difficulty, number> = {
  Beginner: 0,
  Intermediate: 1,
  Advanced: 2,
  Expert: 3,
};



/* ══════════════════ QUESTION CARD ══════════════════ */

function QuestionCard({
  q,
  status,
  attempts,
  best,
  wide,
  onOpen,
}: {
  q: Question;
  status: QuestionStatus;
  attempts: number;
  best?: number;
  wide?: boolean;
  onOpen: () => void;
}) {
  const done = status === "COMPLETED";
  const meta = [q.languages[0].toUpperCase(), q.difficulty.toUpperCase(), `+${q.points} XP`, `${q.estMinutes} MIN`];

  return (
    <button
      onClick={onOpen}
      className={cn(
        "group relative block h-full w-full overflow-hidden border border-[var(--border)] bg-[var(--surface-2)] p-4 text-left transition-all duration-300 hover:-translate-y-[3px] hover:border-[var(--blue)] hover:bg-[var(--surface-hover)] focus-visible:border-[var(--blue)] sm:p-5",
        wide && "sm:col-span-2"
      )}
    >
      {/* corner brackets light up on hover */}
      <span aria-hidden="true" className="pointer-events-none absolute left-0 top-0 h-6 w-6 border-l-2 border-t-2 border-[var(--blue)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      <span aria-hidden="true" className="pointer-events-none absolute bottom-0 right-0 h-6 w-6 border-b-2 border-r-2 border-[var(--blue)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      <span aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-px scale-x-0 bg-[var(--blue)] transition-transform duration-500 group-hover:scale-x-100" />

      <div className="flex items-start justify-between gap-3">
        <span className="mono-label text-[10px] text-[var(--blue)]">
          {q.category}
        </span>
        <span
          className={cn(
            "clip-oct-sm shrink-0 border px-2 py-0.5 font-mono text-[9.5px] font-bold tracking-wider",
            STATUS_STYLE[status].cls
          )}
        >
          {done ? "⬡ " : ""}
          {STATUS_STYLE[status].label}
        </span>
      </div>

      <h3
        className={cn(
          "display mt-2.5 font-bold leading-tight tracking-tight transition-colors group-hover:text-[var(--blue)]",
          wide ? "text-xl sm:text-2xl" : "text-base sm:text-lg"
        )}
      >
        {q.title}
      </h3>

      <p className={cn("mt-2 text-[12.5px] leading-relaxed text-[var(--text-2)]", wide && "sm:text-[13.5px]")}>
        {q.blurb}
      </p>

      {/* metadata */}
      <div className="mt-3.5 flex flex-wrap items-center gap-x-2.5 gap-y-1.5 font-mono text-[10px] tracking-wide text-[var(--text-3)]">
        {meta.map((m, i) => (
          <span key={m} className="flex items-center gap-2.5">
            {i > 0 && <span className="text-[var(--border-strong)]">·</span>}
            <span style={i === 1 ? { color: DIFF_TONE[q.difficulty] } : undefined}>{m}</span>
          </span>
        ))}
      </div>

      {/* footer */}
      <div className="mt-4 flex items-center justify-between border-t border-[var(--border)] pt-3">
        <div className="flex items-center gap-3 font-mono text-[10px] text-[var(--text-3)]">
          {attempts > 0 && <span>{attempts} attempt{attempts > 1 ? "s" : ""}</span>}
          {typeof best === "number" && (
            <span className={best === 100 ? "text-[#5DD39E]" : "text-[#F2C94C]"}>best {best}%</span>
          )}
          {attempts === 0 && <span>unattempted</span>}
        </div>
        <span className="flex items-center gap-1.5 font-display text-[11.5px] font-semibold text-[var(--text-2)] transition-colors group-hover:text-[var(--blue)]">
          {ACTION_BY_STATUS[status]}
          <ArrowRight className="h-3 w-3 transition-transform duration-300 group-hover:translate-x-1" />
        </span>
      </div>
    </button>
  );
}

/* ══════════════════ PAGE ══════════════════ */

export default function DailyPracticeTab({
  onOpenQuestion,
  onNavigate,
}: {
  onOpenQuestion: (questionId: string) => void;
  onNavigate: (tab: string) => void;
}) {
  const { statuses, attempts, best, stats, totalXp, rank, mission, recent } = usePractice();

  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"ALL" | "NOT STARTED" | "IN PROGRESS" | "COMPLETED">("ALL");
  const [difficulty, setDifficulty] = useState<"All" | Difficulty>("All");
  const [category, setCategory] = useState<string>("All");
  const [sort, setSort] = useState<(typeof SORTS)[number]["id"]>("recent");
  const [pack, setPack] = useState<string | null>(null);

  useEffect(() => {
    const t = window.setTimeout(() => setLoading(false), 460);
    return () => window.clearTimeout(t);
  }, []);

  const solvedXp = useAnimatedNumber(stats.practiceXp, 900);
  const solvedCount = useAnimatedNumber(stats.solved, 900);

  const featured = packs[0];
  const withLang = allQuestions;

  /* pack metadata is derived, never typed by hand */
  const featuredPack = useMemo(() => {
    const qs = withLang.filter((q) => featured.questionIds.includes(q.id));
    const tally = qs.reduce<Record<string, number>>((acc, q) => {
      acc[q.difficulty] = (acc[q.difficulty] ?? 0) + 1;
      return acc;
    }, {});
    const topDifficulty =
      (Object.entries(tally).sort((a, b) => b[1] - a[1])[0]?.[0] as Difficulty) ?? "Mixed";
    return {
      questions: qs,
      totalXp: qs.reduce((s, q) => s + q.points, 0),
      totalMinutes: qs.reduce((s, q) => s + q.estMinutes, 0),
      topDifficulty,
    };
  }, [withLang, featured]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = withLang.filter((item) => {
      const st = statuses[item.id] ?? item.status;
      if (statusFilter === "NOT STARTED" && st !== "NOT STARTED" && st !== "NEW" && st !== "ATTEMPT AGAIN") return false;
      if (statusFilter === "IN PROGRESS" && st !== "IN PROGRESS") return false;
      if (statusFilter === "COMPLETED" && st !== "COMPLETED") return false;
      if (difficulty !== "All" && item.difficulty !== difficulty) return false;
      if (category !== "All" && item.category !== category) return false;
      if (pack && item.packId !== pack) return false;
      if (q) {
        const hay =
          `${item.title} ${item.blurb} ${item.category} ${item.difficulty} ${item.languages.join(" ")}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    list = [...list].sort((a, b) => {
      if (sort === "xp") return b.points - a.points;
      if (sort === "time") return a.estMinutes - b.estMinutes;
      if (sort === "hard") return diffRank[b.difficulty] - diffRank[a.difficulty] || b.points - a.points;
      return b.publishedAt.localeCompare(a.publishedAt);
    });
    return list;
  }, [withLang, statuses, statusFilter, difficulty, category, pack, query, sort]);

  const counts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const q of withLang) map[q.category] = (map[q.category] ?? 0) + 1;
    return map;
  }, [withLang]);

  const filtersActive =
    query !== "" || statusFilter !== "ALL" || difficulty !== "All" || category !== "All" || pack !== null;

  const clearAll = () => {
    setQuery("");
    setStatusFilter("ALL");
    setDifficulty("All");
    setCategory("All");
    setPack(null);
  };

  const missionPercent = Math.round((mission.progress / mission.target) * 100);

  return (
    <div className="space-y-8">
      {/* ════════════ INTRODUCTION ════════════ */}
      <Reveal>
        <div className="grid gap-6 border-b border-[var(--border)] pb-7 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
          <div className="min-w-0">
            <p className="mono-label flex flex-wrap items-center gap-2.5 text-[var(--blue)]">
              <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
              DAILY PRACTICE · THE CHALLENGE ARCHIVE
              <span className="font-mono text-[10px] tracking-[0.1em] text-[var(--text-3)]">
                {withLang.length} published
              </span>
            </p>
            <h1 className="display mt-2 text-[1.85rem] font-bold leading-[1.05] tracking-tight sm:text-[2.6rem]">
              Your next breakthrough
              <br className="hidden sm:block" /> starts with <span className="text-[var(--blue)]">a problem.</span>
            </h1>
            <p className="mt-3 max-w-xl text-[13.5px] leading-relaxed text-[var(--text-2)]">
              Explore carefully selected challenges, sharpen your thinking, and earn points with every
              solution. Every task here was written by a setter and published by a patron — these are
              not exercises, they are archives of things worth solving.
            </p>
          </div>

          {/* personal status */}
          <div className="grid grid-cols-3 gap-2.5 lg:gap-3">
            {[
              { v: stats.solved, label: "Solved", suffix: "", tone: "var(--text)", anim: solvedCount },
              { v: stats.practiceXp, label: "Practice XP", suffix: "", tone: "var(--blue)", anim: solvedXp },
              { v: stats.streakDays, label: "Day streak", suffix: "", tone: "#FF6B6B", anim: stats.streakDays },
            ].map((s) => (
              <div key={s.label} className="border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 text-center lg:text-left">
                <p className="display text-xl font-bold leading-none tracking-tight" style={{ color: s.tone }}>
                  {s.anim.toLocaleString()}
                </p>
                <p className="mono-label mt-1.5 text-[9px]">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      {/* ════════════ PERFORMANCE STRIP ════════════ */}
      <Reveal delay={80}>
        <div className="panel clip-oct flex flex-col gap-4 p-4 sm:p-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="grid flex-1 grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
            {[
              { label: "Questions solved", value: stats.solved.toLocaleString(), tone: "var(--text)" },
              { label: "Points earned", value: `${stats.practiceXp.toLocaleString()} XP`, tone: "var(--blue)", link: true },
              { label: "Success rate", value: `${stats.successRate}%`, tone: "#5DD39E" },
              { label: "Current streak", value: `${stats.streakDays} days`, tone: "#FF6B6B" },
            ].map((m, i) => (
              <div key={m.label} className={cn(i > 0 && "sm:border-l sm:border-[var(--border)] sm:pl-6")}>
                <p className="mono-label text-[9.5px]">{m.label}</p>
                <p className="display mt-1 text-lg font-bold leading-none tracking-tight" style={{ color: m.tone }}>
                  {m.value}
                </p>
                {m.link && (
                  <button
                    onClick={() => onNavigate("competitions")}
                    className="mt-1 flex items-center gap-1 font-mono text-[9.5px] text-[var(--text-3)] transition-colors hover:text-[var(--blue)]"
                  >
                    feeds school rank #{String(rank.position).padStart(2, "0")} <ArrowRight className="h-2.5 w-2.5" />
                  </button>
                )}
              </div>
            ))}
          </div>

          <button
            onClick={() => onNavigate("profile")}
            className="mono-label flex shrink-0 items-center gap-2 self-end border border-[var(--border)] px-3 py-2 transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)] lg:self-auto"
          >
            View my performance <ArrowRight className="h-3 w-3" />
          </button>
        </div>
      </Reveal>

      {/* ════════════ FEATURED PACK + PACKS RAIL ════════════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Reveal className="lg:col-span-8">
          <div
            className="clip-oct relative h-full overflow-hidden border p-5 sm:p-7"
            style={{ borderColor: "color-mix(in srgb, var(--blue) 45%, var(--border))" }}
          >
            <span
              aria-hidden="true"
              className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rotate-12 border border-[var(--border)] [clip-path:polygon(25%_0,75%_0,100%_25%,100%_75%,75%_100%,25%_100%,0_75%,0_25%)]"
            />
            <p className="mono-label flex items-center gap-2 text-[var(--blue)]">
              <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
              PICK UP WHERE CURIOSITY LEADS
            </p>
            <h2 className="display mt-3 text-2xl font-bold uppercase leading-none tracking-tight sm:text-3xl">
              {featured.title}
            </h2>
            <p className="display mt-1.5 text-sm font-semibold text-[var(--blue)]">{featured.tagline}</p>
            <p className="mt-3 max-w-2xl text-[13px] leading-relaxed text-[var(--text-2)]">
              {featured.description}
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-2">
              {[
                `${featuredPack.questions.length} questions`,
                `mostly ${featuredPack.topDifficulty}`,
                "Python / JavaScript",
                `up to ${featuredPack.totalXp} XP`,
                `≈ ${featuredPack.totalMinutes} minutes`,
              ].map((chip) => (
                <span
                  key={chip}
                  className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-2)] px-2.5 py-1 font-mono text-[10px] tracking-wide text-[var(--text-2)]"
                >
                  {chip}
                </span>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
              <button
                onClick={() => { setPack(featured.id); setSort("recent"); document.getElementById("archive-grid")?.scrollIntoView({ behavior: "smooth", block: "start" }); }}
                className="btn-shell btn-primary-shell btn-shell-md"
              >
                <span className="btn-core">
                  Explore Pack <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </button>
              <p className="font-mono text-[10px] leading-relaxed text-[var(--text-3)]">
                {featured.publishedBy}
                <br />
                {featured.curatedBy}
              </p>
            </div>
          </div>
        </Reveal>

        {/* available packs */}
        <Reveal delay={90} className="lg:col-span-4">
          <div className="panel clip-oct flex h-full flex-col p-4 sm:p-5">
            <div className="flex items-center justify-between">
              <span className="font-display text-xs font-bold uppercase tracking-wide">
                Available packs
              </span>
              <span className="mono-label text-[9.5px]">{packs.length} curated</span>
            </div>

            <div className="mt-3 divide-y divide-[var(--border)]">
              {packs.map((p) => {
                const active = pack === p.id;
                const solvedInPack = p.questionIds.filter((id) => statuses[id] === "COMPLETED").length;
                return (
                  <button
                    key={p.id}
                    onClick={() => setPack(active ? null : p.id)}
                    className={cn(
                      "group flex w-full items-center gap-3 py-2.5 text-left transition-colors",
                      active ? "text-[var(--text)]" : "hover:text-[var(--text)]"
                    )}
                  >
                    <span
                      className="h-7 w-1 shrink-0 transition-all duration-300 group-hover:h-8"
                      style={{ backgroundColor: active ? p.accent : "var(--border-strong)" }}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="display block truncate text-[12.5px] font-bold tracking-tight">
                        {p.title}
                      </span>
                      <span className="block truncate font-mono text-[10px] text-[var(--text-3)]">
                        {p.questionIds.length} questions · {solvedInPack} solved
                      </span>
                    </span>
                    {active && <span className="font-mono text-[9px] text-[var(--blue)]">FILTERED</span>}
                  </button>
                );
              })}
            </div>

            <p className="mt-auto border-t border-[var(--border)] pt-3 font-mono text-[9.5px] leading-relaxed text-[var(--text-3)]">
              Packs are published by the patron circle. Selecting one filters the archive below.
            </p>
          </div>
        </Reveal>
      </div>

      {/* ════════════ ARCHIVE GRID ════════════ */}
      <div id="archive-grid" className="scroll-mt-20">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="display text-xl font-bold uppercase tracking-tight sm:text-2xl">
                Explore practice questions
              </h2>
              <p className="mt-1 text-[13px] text-[var(--text-2)]">
                Choose a challenge. Find your approach. Make it work.
              </p>
            </div>
            <p className="mono-label">
              <span className="text-[var(--blue)]">{visible.length}</span> of {withLang.length} shown
            </p>
          </div>
        </Reveal>

        {/* toolbar */}
        <div className="panel clip-oct mt-4 space-y-3 p-3.5">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
            <label className="relative flex flex-1 items-center">
              <SearchIcon className="pointer-events-none absolute left-3 h-3.5 w-3.5 text-[var(--text-3)]" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Find a challenge…"
                className="w-full border border-[var(--border)] bg-[var(--surface-2)] py-2 pl-9 pr-3 text-[13px] text-[var(--text)] placeholder:text-[var(--text-3)] transition-colors focus:border-[var(--blue)] focus:outline-none"
              />
            </label>

            <div className="flex gap-1.5 overflow-x-auto">
              {(["ALL", "NOT STARTED", "IN PROGRESS", "COMPLETED"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={cn(
                    "clip-oct-sm shrink-0 border px-2.5 py-1.5 font-mono text-[10px] tracking-wider transition-colors",
                    statusFilter === s
                      ? "border-[var(--blue)] bg-[var(--blue)] text-white"
                      : "border-[var(--border)] text-[var(--text-3)] hover:border-[var(--blue)] hover:text-[var(--text)]"
                  )}
                >
                  {s === "ALL" ? "All questions" : s}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-x-5 gap-y-2.5 border-t border-[var(--border)] pt-3">
            <div className="flex items-center gap-1.5">
              <span className="mono-label text-[9px]">Difficulty</span>
              {(["All", ...DIFFICULTIES] as const).map((d) => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d as "All" | Difficulty)}
                  className={cn(
                    "clip-oct-sm border px-2 py-0.5 font-mono text-[10px] transition-colors",
                    difficulty === d
                      ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]"
                      : "border-[var(--border)] text-[var(--text-3)] hover:text-[var(--text)]"
                  )}
                >
                  {d}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5">
              <span className="mono-label text-[9px]">Category</span>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="clip-oct-sm cursor-pointer border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1 font-mono text-[10.5px] text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
              >
                <option value="All">All categories</option>
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div className="ml-auto flex items-center gap-1.5">
              <span className="mono-label text-[9px]">Sort</span>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as typeof sort)}
                className="clip-oct-sm cursor-pointer border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1 font-mono text-[10.5px] text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
              >
                {SORTS.map((s) => (
                  <option key={s.id} value={s.id}>{s.label}</option>
                ))}
              </select>
              {filtersActive && (
                <button
                  onClick={clearAll}
                  className="font-mono text-[10px] text-[var(--text-3)] underline underline-offset-4 transition-colors hover:text-[var(--blue)]"
                >
                  clear
                </button>
              )}
            </div>
          </div>
        </div>

        {/* grid */}
        {loading ? (
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-[210px] animate-pulse border border-[var(--border)] bg-[var(--surface-2)]" />
            ))}
          </div>
        ) : visible.length === 0 ? (
          <div className="panel clip-oct mt-5 p-10 text-center">
            <p className="display text-lg font-bold uppercase tracking-tight">No challenges match that</p>
            <p className="mx-auto mt-2 max-w-sm text-[13px] text-[var(--text-2)]">
              The archive holds {withLang.length} published questions. Loosen a filter, or search for
              “queue”, “recursion”, “debug” or “graph”.
            </p>
            <button onClick={clearAll} className="btn-shell btn-ghost-shell btn-shell-sm mt-5">
              <span className="btn-core">Reset filters</span>
            </button>
          </div>
        ) : (
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((q, i) => (
              <Reveal
                key={q.id}
                delay={Math.min(i, 5) * 60}
                className={cn(i === 0 && visible.length > 2 && "sm:col-span-2")}
              >
                <QuestionCard
                  q={q}
                  wide={i === 0 && visible.length > 2}
                  status={statuses[q.id] ?? q.status}
                  attempts={attempts[q.id] ?? 0}
                  best={best[q.id]}
                  onOpen={() => onOpenQuestion(q.id)}
                />
              </Reveal>
            ))}
          </div>
        )}
      </div>

      {/* ════════════ BROWSE BY CATEGORY ════════════ */}
      <Reveal>
        <div className="panel clip-oct p-5">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--border)] pb-3">
            <span className="font-display text-sm font-bold uppercase tracking-wide">Browse by category</span>
            <span className="font-mono text-[10px] text-[var(--text-3)]">
              XP bands: Beginner {difficultyXp.Beginner} · Expert {difficultyXp.Expert}
            </span>
          </div>
          <div className="mt-3.5 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
            {CATEGORIES.map((c) => {
              const active = category === c;
              const n = counts[c] ?? 0;
              const solvedHere = withLang.filter((q) => q.category === c && statuses[q.id] === "COMPLETED").length;
              return (
                <button
                  key={c}
                  onClick={() => setCategory(active ? "All" : c)}
                  className={cn(
                    "group flex items-center justify-between border px-3 py-2.5 text-left transition-all duration-300 hover:-translate-y-0.5",
                    active
                      ? "border-[var(--blue)] bg-[var(--blue-soft)]"
                      : "border-[var(--border)] bg-[var(--surface-2)] hover:border-[var(--blue)]"
                  )}
                >
                  <span className={cn("text-[11.5px] font-semibold leading-tight", active ? "text-[var(--blue)]" : "text-[var(--text-2)] group-hover:text-[var(--text)]")}>
                    {c}
                  </span>
                  <span className="font-mono text-[10px] text-[var(--text-3)]">
                    {solvedHere}/{n}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </Reveal>

      {/* ════════════ RECENT + MISSION + ACHIEVEMENTS ════════════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        <Reveal className="lg:col-span-7">
          <div className="panel clip-oct h-full overflow-hidden">
            <div className="flex items-center justify-between border-b border-[var(--border)] px-5 py-3.5">
              <span className="font-display text-sm font-bold uppercase tracking-wide">Your recent challenges</span>
              <span className="font-mono text-[10px] text-[var(--text-3)]">{recent.length} tracked</span>
            </div>
            <div className="divide-y divide-[var(--border)]">
              {recent.map((r) => {
                const q = questionOrUndefined(r.questionId);
                return (
                  <button
                    key={r.questionId}
                    onClick={() => onOpenQuestion(r.questionId)}
                    className="group grid w-full grid-cols-[minmax(0,1fr)_5.5rem_3.5rem_4.5rem] items-center gap-2 px-5 py-3 text-left transition-colors hover:bg-[var(--surface-2)]"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-[13px] font-medium text-[var(--text)] group-hover:text-[var(--blue)]">
                        {r.title}
                      </span>
                      <span className="block truncate font-mono text-[10px] text-[var(--text-3)]">
                        {q ? `${q.category} · ${q.difficulty}` : "archived"}
                      </span>
                    </span>
                    <span className="font-mono text-[10px]" style={{ color: r.percent === 100 ? "#5DD39E" : r.percent > 0 ? "#F2C94C" : "var(--text-3)" }}>
                      {r.status}
                    </span>
                    <span className="text-right font-mono text-[11px] text-[var(--text)]">{r.score}</span>
                    <span className="text-right font-mono text-[10px] text-[var(--text-3)]">{r.last}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </Reveal>

        <div className="space-y-5 lg:col-span-5">
          {/* weekly mission */}
          <Reveal delay={80}>
            <div className="panel clip-oct p-5">
              <div className="flex items-center justify-between">
                <span className="mono-label flex items-center gap-2 text-[var(--blue)]">
                  <FlameIcon className="h-3.5 w-3.5" />
                  Your weekly mission
                </span>
                <span className="clip-oct-sm border border-[#F2C94C]/50 px-2 py-0.5 font-mono text-[9.5px] text-[#F2C94C]">
                  +{mission.bonusXp} BONUS XP
                </span>
              </div>
              <p className="display mt-3 text-[15px] font-semibold leading-snug">{mission.label}</p>
              <div className="mt-3 flex items-center gap-3">
                <div className="h-2 flex-1 overflow-hidden bg-[var(--border)]">
                  <div
                    className="h-full bg-[var(--blue)] shadow-[0_0_10px_var(--glow)] transition-all duration-700"
                    style={{ width: `${missionPercent}%` }}
                  />
                </div>
                <span className="font-mono text-[11px] tabular-nums text-[var(--text-2)]">
                  {mission.progress} / {mission.target}
                </span>
              </div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[var(--border)] pt-2.5">
                <span className="font-mono text-[9.5px] text-[var(--text-3)]">{mission.source}</span>
                <span className="font-mono text-[9.5px] text-[var(--text-3)]">{mission.window}</span>
              </div>
            </div>
          </Reveal>

          {/* achievements */}
          <Reveal delay={140}>
            <div className="panel clip-oct p-5">
              <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
                <span className="mono-label flex items-center gap-2">
                  <TrophyIcon className="h-3.5 w-3.5 text-[var(--blue)]" />
                  Practice achievements
                </span>
                <button onClick={() => onNavigate("profile")} className="font-mono text-[10px] text-[var(--text-3)] transition-colors hover:text-[var(--blue)]">
                  collection →
                </button>
              </div>
              <div className="mt-3.5 grid grid-cols-2 gap-2.5">
                {achievements.map((a) => (
                  <div
                    key={a.id}
                    className={cn(
                      "flex items-center gap-2.5 border p-2.5 transition-colors",
                      a.state === "earned"
                        ? "border-[var(--blue)]/40 bg-[var(--blue-soft)]/40"
                        : a.state === "progress"
                        ? "border-[var(--border)] bg-[var(--surface-2)]"
                        : "border-dashed border-[var(--border)] opacity-55"
                    )}
                  >
                    <OctagonNode active={a.state === "earned"} size={30}>
                      {a.state === "earned" ? <CheckIcon className="h-3.5 w-3.5" /> : <SparklesIcon className="h-3 w-3" />}
                    </OctagonNode>
                    <div className="min-w-0">
                      <p className="display truncate text-[10.5px] font-bold tracking-tight">{a.name}</p>
                      <p className="truncate font-mono text-[9px] text-[var(--text-3)]">
                        {a.state === "progress" ? `${a.percent}% there` : a.state === "locked" ? "locked" : a.detail}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>

      {/* provenance footer */}
      <Reveal>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--border)] pt-4 font-mono text-[10px] text-[var(--text-3)]">
          <span className="flex items-center gap-2">
            <UsersIcon className="h-3 w-3" /> Setter authors → patron reviews → student sees published
          </span>
          <span className="flex items-center gap-2">
            <MegaphoneIcon className="h-3 w-3" /> Frontend prototype · only JavaScript runs in-browser
          </span>
          <span className="flex items-center gap-2">
            <CodeIcon className="h-3 w-3" /> lifetime XP {totalXp.toLocaleString()}
          </span>
        </div>
      </Reveal>
    </div>
  );
}

function questionOrUndefined(id: string) {
  return allQuestions.find((q) => q.id === id);
}
