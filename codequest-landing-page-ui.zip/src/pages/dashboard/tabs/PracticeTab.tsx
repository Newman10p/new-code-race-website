import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { html } from "@codemirror/lang-html";
import { css } from "@codemirror/lang-css";
import { javascript } from "@codemirror/lang-javascript";
import { python } from "@codemirror/lang-python";
import { oneDark } from "@codemirror/theme-one-dark";
import { EditorView } from "@codemirror/view";
import { cn } from "../../../utils/cn";
import {
  WEB_STARTER_FILES,
  REACT_STARTER_FILES,
  PYTHON_STARTER_FILES,
  type CodeLabProject,
  type EnvironmentType,
  type ProjectFile,
  type LabChallenge,
} from "../../../data/codeLabData";
import {
  buildWebPreviewSrcDoc,
  buildReactPreviewSrcDoc,
  executePythonCode,
  type ConsoleLogEntry,
  type ProblemItem,
} from "../../../lib/codeLabRunner";
import { exportProjectAsZip } from "../../../lib/codeLabExport";
import { useTheme } from "../../../lib/theme";
import {
  PlayIcon,
  StopIcon,
  RefreshCwIcon,
  FolderOpenIcon,
  FileIcon,
  FilePlusIcon,
  CloseIcon,
  DownloadIcon,
  LayoutIcon,
  MaximizeIcon,
  MinimizeIcon,
  TrashIcon,
  EditIcon,
  SparklesIcon,
  ChevronDown,
  SidebarCollapseIcon,
} from "../../../components/icons";
import CodeLabWelcomeModal from "./codelab/CodeLabWelcomeModal";
import CodeLabSnippetsModal from "./codelab/CodeLabSnippetsModal";
import CodeLabChallengesDrawer from "./codelab/CodeLabChallengesDrawer";
import CodeLabShortcutsModal from "./codelab/CodeLabShortcutsModal";

const STORAGE_KEY = "cq-codelab-project-v1";

function getStarterFiles(env: EnvironmentType): ProjectFile[] {
  if (env === "react") return JSON.parse(JSON.stringify(REACT_STARTER_FILES));
  if (env === "python") return JSON.parse(JSON.stringify(PYTHON_STARTER_FILES));
  return JSON.parse(JSON.stringify(WEB_STARTER_FILES));
}

function getDefaultProject(env: EnvironmentType = "web", name = "Untitled Project"): CodeLabProject {
  const files = getStarterFiles(env);
  return {
    id: "proj-" + Date.now(),
    name,
    environment: env,
    updatedAt: new Date().toISOString(),
    files,
    activeFileId: files[0].id,
    openTabs: files.slice(0, 3).map((f) => f.id),
  };
}

export default function PracticeTab({
  onNavigate,
}: {
  onNavigate?: (tab: string) => void;
}) {
  const { theme, toggle: toggleTheme } = useTheme();

  // Project state
  const [project, setProject] = useState<CodeLabProject>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return getDefaultProject("web", "My Web App");
  });

  const [projectName, setProjectName] = useState(project.name);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [saveStatus, setSaveStatus] = useState<"saved" | "saving" | "unsaved">("saved");

  // Active file & editor
  const activeFile = project.files.find((f) => f.id === project.activeFileId) || project.files[0];
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });
  const [fontSize, setFontSize] = useState<number>(13);
  const [wordWrap, setWordWrap] = useState<boolean>(true);

  // Layout & Panes
  const [layoutMode, setLayoutMode] = useState<"split-v" | "split-h" | "editor-only" | "preview-only">("split-v");
  const [explorerOpen, setExplorerOpen] = useState(true);
  const [bottomOpen, setBottomOpen] = useState(true);
  const [bottomTab, setBottomTab] = useState<"problems" | "output" | "console" | "terminal">("console");
  const [previewViewport, setPreviewViewport] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Resizable panel dimensions
  const [explorerWidth, setExplorerWidth] = useState(210);
  const [previewWidth, setPreviewWidth] = useState(480);
  const [bottomHeight, setBottomHeight] = useState(190);
  const dragTargetRef = useRef<null | "explorer" | "preview" | "bottom">(null);

  // Execution & Diagnostics
  const [isRunning, setIsRunning] = useState(false);
  const [executionMessage, setExecutionMessage] = useState<string>("Ready");
  const [previewSrcDoc, setPreviewSrcDoc] = useState<string>("");
  const [previewKey, setPreviewKey] = useState(1);
  const [pythonStdout, setPythonStdout] = useState<string[]>([
    "CodeQuest Python Terminal (3.12)",
    ">>> Press Run (Ctrl+Enter) to execute main.py",
  ]);
  const [consoleLogs, setConsoleLogs] = useState<ConsoleLogEntry[]>([
    {
      id: "init",
      level: "info",
      args: ["CodeQuest Code Lab initialized."],
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);
  const [problems, setProblems] = useState<ProblemItem[]>([]);

  // Modals & Drawers
  const [welcomeModalOpen, setWelcomeModalOpen] = useState(false);
  const [snippetsModalOpen, setSnippetsModalOpen] = useState(false);
  const [challengesDrawerOpen, setChallengesDrawerOpen] = useState(false);
  const [shortcutsModalOpen, setShortcutsModalOpen] = useState(false);
  const [settingsDropdownOpen, setSettingsDropdownOpen] = useState(false);

  // New File / Rename state
  const [newFileInputOpen, setNewFileInputOpen] = useState(false);
  const [newFileName, setNewFileName] = useState("");
  const [renamingFileId, setRenamingFileId] = useState<string | null>(null);
  const [renamingValue, setRenamingValue] = useState("");

  // Terminal input prompt
  const [terminalInputPending, setTerminalInputPending] = useState<((val: string) => void) | null>(null);
  const [terminalInputPrompt, setTerminalInputPrompt] = useState("");
  const [terminalInputValue, setTerminalInputValue] = useState("");

  const containerRef = useRef<HTMLDivElement>(null);

  // Autosave to localStorage
  useEffect(() => {
    setSaveStatus("saving");
    const t = setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(project));
        setSaveStatus("saved");
      } catch {
        setSaveStatus("unsaved");
      }
    }, 600);
    return () => clearTimeout(t);
  }, [project]);

  // Initial preview build
  useEffect(() => {
    if (project.environment === "web") {
      setPreviewSrcDoc(buildWebPreviewSrcDoc(project.files));
      setBottomTab("console");
    } else if (project.environment === "react") {
      setPreviewSrcDoc(buildReactPreviewSrcDoc(project.files));
      setBottomTab("console");
    } else {
      setBottomTab("terminal");
    }
  }, [project.environment, project.files]);

  // Listen to postMessage from sandboxed iframes
  useEffect(() => {
    const onMessage = (e: MessageEvent) => {
      if (e.data && e.data.source === "cq-lab-preview") {
        if (e.data.type === "console") {
          setConsoleLogs((prev) => [
            ...prev,
            {
              id: "log-" + Date.now() + Math.random(),
              level: e.data.level,
              args: e.data.args,
              timestamp: e.data.time || new Date().toLocaleTimeString(),
            },
          ]);
        } else if (e.data.type === "runtime-error") {
          setProblems((prev) => [
            {
              id: "err-" + Date.now(),
              file: e.data.filename || "index.html",
              line: e.data.lineno || 1,
              column: e.data.colno || 1,
              severity: "error",
              message: e.data.message || "Runtime Error",
            },
            ...prev,
          ]);
        }
      }
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  // Panel drag resize listeners
  useEffect(() => {
    const onPointerMove = (e: PointerEvent) => {
      if (!dragTargetRef.current) return;
      if (dragTargetRef.current === "explorer") {
        setExplorerWidth(Math.min(360, Math.max(160, e.clientX - 260)));
      } else if (dragTargetRef.current === "preview") {
        const offsetFromRight = window.innerWidth - e.clientX;
        setPreviewWidth(Math.min(window.innerWidth * 0.65, Math.max(280, offsetFromRight)));
      } else if (dragTargetRef.current === "bottom") {
        const fromBottom = window.innerHeight - e.clientY - 60;
        setBottomHeight(Math.min(420, Math.max(100, fromBottom)));
      }
    };

    const onPointerUp = () => {
      dragTargetRef.current = null;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };

    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
    return () => {
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
    };
  }, []);

  // ---------------- EXECUTION RUNNER ----------------
  const handleRun = useCallback(async () => {
    setIsRunning(true);
    setExecutionMessage("Running...");
    setProblems([]);

    if (project.environment === "web") {
      setPreviewSrcDoc(buildWebPreviewSrcDoc(project.files));
      setPreviewKey((k) => k + 1);
      setTimeout(() => {
        setIsRunning(false);
        setExecutionMessage("Web preview updated");
      }, 300);
    } else if (project.environment === "react") {
      setPreviewSrcDoc(buildReactPreviewSrcDoc(project.files));
      setPreviewKey((k) => k + 1);
      setTimeout(() => {
        setIsRunning(false);
        setExecutionMessage("React component rendered");
      }, 400);
    } else if (project.environment === "python") {
      setBottomTab("terminal");
      const res = await executePythonCode(project.files, (promptText) => {
        return new Promise<string>((resolve) => {
          setTerminalInputPrompt(promptText || "input(): ");
          setTerminalInputPending(() => resolve);
        });
      });

      setPythonStdout(res.stdout);
      setProblems(res.problems);
      setIsRunning(false);
      setExecutionMessage(res.status === "success" ? `Success (${res.durationMs.toFixed(0)}ms)` : "Runtime Error");
    }
  }, [project.environment, project.files]);

  // Terminal input submit
  const handleTerminalInputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (terminalInputPending) {
      const val = terminalInputValue;
      setPythonStdout((prev) => [...prev, `${terminalInputPrompt}${val}`]);
      terminalInputPending(val);
      setTerminalInputPending(null);
      setTerminalInputValue("");
      setTerminalInputPrompt("");
    }
  };

  // Keyboard Shortcuts listener
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
        e.preventDefault();
        handleRun();
      } else if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        setSaveStatus("saving");
        setTimeout(() => setSaveStatus("saved"), 300);
      } else if (e.shiftKey && e.altKey && e.key.toLowerCase() === "m") {
        e.preventDefault();
        setLayoutMode((m) => (m === "editor-only" ? "split-v" : "editor-only"));
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "b") {
        e.preventDefault();
        setExplorerOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [handleRun]);

  // ---------------- FILE OPERATIONS ----------------
  const handleFileChange = (newContent: string) => {
    setProject((prev) => ({
      ...prev,
      files: prev.files.map((f) => (f.id === prev.activeFileId ? { ...f, content: newContent } : f)),
    }));
  };

  const handleSelectFile = (fileId: string) => {
    setProject((prev) => ({
      ...prev,
      activeFileId: fileId,
      openTabs: prev.openTabs.includes(fileId) ? prev.openTabs : [...prev.openTabs, fileId],
    }));
  };

  const handleCloseTab = (fileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setProject((prev) => {
      const nextTabs = prev.openTabs.filter((id) => id !== fileId);
      const nextActive = prev.activeFileId === fileId ? nextTabs[0] || prev.files[0]?.id : prev.activeFileId;
      return {
        ...prev,
        openTabs: nextTabs.length ? nextTabs : [nextActive],
        activeFileId: nextActive,
      };
    });
  };

  const handleCreateFile = () => {
    if (!newFileName.trim()) return;
    const name = newFileName.trim();
    let ext: ProjectFile["language"] = "javascript";
    if (name.endsWith(".html")) ext = "html";
    else if (name.endsWith(".css")) ext = "css";
    else if (name.endsWith(".jsx")) ext = "jsx";
    else if (name.endsWith(".py")) ext = "python";
    else if (name.endsWith(".md")) ext = "markdown";
    else if (name.endsWith(".json")) ext = "json";

    const newF: ProjectFile = {
      id: "f-" + Date.now(),
      name,
      path: name,
      language: ext,
      content: `// ${name}\n`,
    };

    setProject((prev) => ({
      ...prev,
      files: [...prev.files, newF],
      activeFileId: newF.id,
      openTabs: [...prev.openTabs, newF.id],
    }));

    setNewFileName("");
    setNewFileInputOpen(false);
  };

  const handleDeleteFile = (fileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (project.files.length <= 1) return;
    if (!window.confirm("Are you sure you want to delete this file?")) return;

    setProject((prev) => {
      const remaining = prev.files.filter((f) => f.id !== fileId);
      const remainingTabs = prev.openTabs.filter((id) => id !== fileId);
      return {
        ...prev,
        files: remaining,
        openTabs: remainingTabs.length ? remainingTabs : [remaining[0].id],
        activeFileId: prev.activeFileId === fileId ? remaining[0].id : prev.activeFileId,
      };
    });
  };

  const handleStartRename = (file: ProjectFile, e: React.MouseEvent) => {
    e.stopPropagation();
    setRenamingFileId(file.id);
    setRenamingValue(file.name);
  };

  const handleFinishRename = () => {
    if (renamingFileId && renamingValue.trim()) {
      setProject((prev) => ({
        ...prev,
        files: prev.files.map((f) => (f.id === renamingFileId ? { ...f, name: renamingValue.trim() } : f)),
      }));
    }
    setRenamingFileId(null);
  };

  // ---------------- PROJECT ACTIONS ----------------
  const handleEnvironmentSwitch = (newEnv: EnvironmentType) => {
    if (newEnv === project.environment) return;
    if (window.confirm(`Switch to ${newEnv.toUpperCase()}? This will load the ${newEnv} starter template.`)) {
      const next = getDefaultProject(newEnv, `${newEnv.toUpperCase()} Project`);
      setProject(next);
      setProjectName(next.name);
      setProblems([]);
    }
  };

  const handleResetProject = () => {
    if (window.confirm("Reset all project files back to original starter templates?")) {
      const next = getDefaultProject(project.environment, project.name);
      setProject(next);
      setProblems([]);
    }
  };

  const handleExportZip = async () => {
    await exportProjectAsZip(project);
  };

  const handleLoadChallenge = (challenge: LabChallenge) => {
    const next = getDefaultProject(challenge.env, challenge.title);
    setProject(next);
    setProjectName(next.name);
    setProblems([]);
  };

  const handleInsertSnippet = (snippetCode: string) => {
    handleFileChange(activeFile.content + "\n\n" + snippetCode);
  };

  // Format code (Shift+Alt+F)
  const handleFormatCode = () => {
    try {
      const clean = activeFile.content
        .replace(/\t/g, "  ")
        .split("\n")
        .map((l) => l.replace(/\s+$/, ""))
        .join("\n");
      handleFileChange(clean);
      setExecutionMessage("Formatted document");
    } catch {
      // ignore
    }
  };

  // Language extension selector for CodeMirror
  const editorExtensions = useMemo(() => {
    const exts = [
      EditorView.lineWrapping,
      EditorView.updateListener.of((update) => {
        if (update.selectionSet) {
          const pos = update.state.selection.main.head;
          const line = update.state.doc.lineAt(pos);
          setCursorPos({ line: line.number, col: pos - line.from + 1 });
        }
      }),
      EditorView.theme({
        "&": {
          fontSize: `${fontSize}px`,
          height: "100%",
          backgroundColor: "var(--surface-solid)",
        },
        ".cm-scroller": {
          fontFamily: "var(--font-mono)",
          lineHeight: "1.6",
        },
        ".cm-gutters": {
          backgroundColor: "var(--surface-solid)",
          borderRight: "1px solid var(--border)",
          color: "var(--text-3)",
        },
        ".cm-activeLine": {
          backgroundColor: "rgba(77,156,255,0.06)",
        },
        ".cm-activeLineGutter": {
          backgroundColor: "rgba(77,156,255,0.08)",
          color: "var(--blue)",
        },
      }),
    ];

    if (activeFile.name.endsWith(".html")) exts.push(html());
    else if (activeFile.name.endsWith(".css")) exts.push(css());
    else if (activeFile.name.endsWith(".py")) exts.push(python());
    else exts.push(javascript({ jsx: true }));

    return exts;
  }, [activeFile.name, fontSize]);

  const isDark = theme === "dark";

  return (
    <div
      ref={containerRef}
      className={cn(
        "flex flex-1 flex-col h-full bg-[var(--bg)] text-[var(--text)] select-none",
        isFullscreen && "fixed inset-0 z-50 bg-[var(--bg)]"
      )}
    >
      {/* ══════════════════ 1. TOP WORKSPACE TOOLBAR ══════════════════ */}
      <header className="flex h-12 shrink-0 items-center justify-between border-b border-[var(--border)] bg-[var(--sidebar)] px-3 sm:px-4">
        {/* Left: Logo & Breadcrumbs & Editable Title */}
        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-2 sm:flex">
            <button
              onClick={() => onNavigate?.("overview")}
              className="font-mono text-xs text-[var(--text-3)] hover:text-[var(--blue)]"
            >
              Dashboard /
            </button>
            <span className="font-display text-xs font-bold uppercase tracking-wider text-[var(--blue)]">
              Code Lab
            </span>
          </div>

          <span className="hidden h-4 w-px bg-[var(--border)] sm:block" />

          {/* Project Title inline editor */}
          <div className="flex items-center gap-1.5">
            {isEditingTitle ? (
              <input
                type="text"
                value={projectName}
                autoFocus
                onBlur={() => {
                  setIsEditingTitle(false);
                  setProject((p) => ({ ...p, name: projectName.trim() || "Untitled Project" }));
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    setIsEditingTitle(false);
                    setProject((p) => ({ ...p, name: projectName.trim() || "Untitled Project" }));
                  }
                }}
                onChange={(e) => setProjectName(e.target.value)}
                className="border border-[var(--blue)] bg-[var(--surface-2)] px-2 py-0.5 font-display text-xs font-bold text-[var(--text)] focus:outline-none"
              />
            ) : (
              <button
                onClick={() => setIsEditingTitle(true)}
                className="group flex items-center gap-1.5 font-display text-xs font-bold text-[var(--text)] hover:text-[var(--blue)]"
                title="Click to rename project"
              >
                <span>{project.name}</span>
                <EditIcon className="h-3 w-3 opacity-0 group-hover:opacity-100 text-[var(--text-3)]" />
              </button>
            )}

            {/* Save indicator badge */}
            <span
              className={cn(
                "hidden font-mono text-[10px] tracking-wider sm:inline",
                saveStatus === "saved" && "text-[#5DD39E]",
                saveStatus === "saving" && "text-[#F2C94C]",
                saveStatus === "unsaved" && "text-[var(--text-3)]"
              )}
            >
              {saveStatus === "saved" ? "✓ Saved" : saveStatus === "saving" ? "Saving..." : "Unsaved"}
            </span>
          </div>
        </div>

        {/* Center: Environment Selector */}
        <div className="flex items-center gap-1 rounded border border-[var(--border)] bg-[var(--surface-2)] p-0.5">
          <button
            onClick={() => handleEnvironmentSwitch("web")}
            className={cn(
              "flex items-center gap-1.5 px-2.5 py-1 font-mono text-[11px] transition-colors",
              project.environment === "web"
                ? "bg-[var(--blue)] text-white shadow-[0_0_8px_var(--glow)] font-bold"
                : "text-[var(--text-3)] hover:text-[var(--text)]"
            )}
            title="HTML / CSS / JavaScript Playground"
          >
            <span>&lt;&gt;</span>
            <span className="hidden md:inline">Web</span>
          </button>

          <button
            onClick={() => handleEnvironmentSwitch("react")}
            className={cn(
              "flex items-center gap-1.5 px-2.5 py-1 font-mono text-[11px] transition-colors",
              project.environment === "react"
                ? "bg-[var(--blue)] text-white shadow-[0_0_8px_var(--glow)] font-bold"
                : "text-[var(--text-3)] hover:text-[var(--text)]"
            )}
            title="React JSX Studio"
          >
            <span>⚛</span>
            <span className="hidden md:inline">React</span>
          </button>

          <button
            onClick={() => handleEnvironmentSwitch("python")}
            className={cn(
              "flex items-center gap-1.5 px-2.5 py-1 font-mono text-[11px] transition-colors",
              project.environment === "python"
                ? "bg-[var(--blue)] text-white shadow-[0_0_8px_var(--glow)] font-bold"
                : "text-[var(--text-3)] hover:text-[var(--text)]"
            )}
            title="Python 3.12 Lab"
          >
            <span>py</span>
            <span className="hidden md:inline">Python</span>
          </button>
        </div>

        {/* Right: Run, Format, Export, Snippets, Layout, Settings */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Prominent Run Button */}
          <button
            onClick={handleRun}
            disabled={isRunning}
            title="Execute Code (Ctrl + Enter / ⌘ + Enter)"
            className="btn-shell btn-primary-shell btn-shell-sm"
          >
            <span className="btn-core font-bold text-xs">
              <PlayIcon className="h-3 w-3" />
              <span>{isRunning ? "Running..." : "Run"}</span>
            </span>
          </button>

          {isRunning && (
            <button
              onClick={() => setIsRunning(false)}
              className="clip-oct-sm border border-red-500 bg-red-500/20 px-2 py-1 text-red-400 hover:bg-red-500 hover:text-white"
              title="Stop execution"
            >
              <StopIcon className="h-3 w-3" />
            </button>
          )}

          {/* Quick Snippets trigger */}
          <button
            onClick={() => setSnippetsModalOpen(true)}
            className="clip-oct-sm hidden border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1 font-mono text-[11px] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)] md:inline-flex items-center gap-1"
            title="Insert Code Snippet"
          >
            <SparklesIcon className="h-3 w-3 text-[var(--blue)]" />
            <span>Snippets</span>
          </button>

          {/* Challenges Ideas trigger */}
          <button
            onClick={() => setChallengesDrawerOpen(true)}
            className="clip-oct-sm hidden border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1 font-mono text-[11px] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)] lg:inline-flex items-center gap-1"
            title="Explore Playground Experiments"
          >
            <span>Ideas</span>
          </button>

          {/* Export Zip */}
          <button
            onClick={handleExportZip}
            className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
            title="Export project as .ZIP"
          >
            <DownloadIcon className="h-3.5 w-3.5" />
          </button>

          {/* Format Document */}
          <button
            onClick={handleFormatCode}
            className="clip-oct-sm hidden h-8 w-8 items-center justify-center border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)] sm:flex"
            title="Format Code (Shift + Alt + F)"
          >
            <span className="font-mono text-[10px] font-bold">FMT</span>
          </button>

          {/* Reset Project */}
          <button
            onClick={handleResetProject}
            className="clip-oct-sm hidden h-8 w-8 items-center justify-center border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)] hover:border-red-400 hover:text-red-400 sm:flex"
            title="Reset to starter files"
          >
            <RefreshCwIcon className="h-3.5 w-3.5" />
          </button>

          {/* Layout switcher button */}
          <div className="relative">
            <button
              onClick={() => {
                const modes: typeof layoutMode[] = ["split-v", "split-h", "editor-only", "preview-only"];
                const nextIdx = (modes.indexOf(layoutMode) + 1) % modes.length;
                setLayoutMode(modes[nextIdx]);
              }}
              className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
              title={`Layout: ${layoutMode} (Click to toggle)`}
            >
              <LayoutIcon className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Settings / Shortcuts dropdown */}
          <div className="relative">
            <button
              onClick={() => setSettingsDropdownOpen((v) => !v)}
              className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
              title="Editor Settings"
            >
              <ChevronDown className="h-3 w-3" />
            </button>

            {settingsDropdownOpen && (
              <>
                <div className="fixed inset-0 z-40 bg-transparent" onClick={() => setSettingsDropdownOpen(false)} />
                <div className="panel-in clip-oct absolute right-0 top-10 z-50 w-52 border border-[var(--border-strong)] bg-[var(--surface-solid)] p-2 shadow-2xl">
                  <div className="border-b border-[var(--border)] p-2 font-mono text-[10px] uppercase text-[var(--text-3)]">
                    Workspace Preferences
                  </div>

                  <div className="space-y-1 py-1 text-xs">
                    <button
                      onClick={() => {
                        setWelcomeModalOpen(true);
                        setSettingsDropdownOpen(false);
                      }}
                      className="flex w-full items-center justify-between px-2 py-1.5 text-[var(--text)] hover:bg-[var(--surface-2)]"
                    >
                      <span>New Project...</span>
                      <span className="font-mono text-[9px] text-[var(--blue)]">Switch</span>
                    </button>

                    <button
                      onClick={() => {
                        setShortcutsModalOpen(true);
                        setSettingsDropdownOpen(false);
                      }}
                      className="flex w-full items-center justify-between px-2 py-1.5 text-[var(--text)] hover:bg-[var(--surface-2)]"
                    >
                      <span>Keyboard Shortcuts</span>
                      <kbd className="font-mono text-[9px] text-[var(--text-3)]">?</kbd>
                    </button>

                    <button
                      onClick={() => setWordWrap(!wordWrap)}
                      className="flex w-full items-center justify-between px-2 py-1.5 text-[var(--text)] hover:bg-[var(--surface-2)]"
                    >
                      <span>Word Wrap</span>
                      <span className="font-mono text-[10px] text-[var(--blue)]">{wordWrap ? "ON" : "OFF"}</span>
                    </button>

                    <div className="flex items-center justify-between px-2 py-1.5 text-[var(--text)]">
                      <span>Font Size</span>
                      <div className="flex gap-1 font-mono text-[10px]">
                        {[12, 13, 14, 16].map((sz) => (
                          <button
                            key={sz}
                            onClick={() => setFontSize(sz)}
                            className={cn(
                              "px-1 rounded",
                              fontSize === sz ? "bg-[var(--blue)] text-white font-bold" : "text-[var(--text-3)]"
                            )}
                          >
                            {sz}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        toggleTheme();
                        setSettingsDropdownOpen(false);
                      }}
                      className="flex w-full items-center justify-between px-2 py-1.5 text-[var(--text)] hover:bg-[var(--surface-2)]"
                    >
                      <span>Theme</span>
                      <span className="font-mono text-[10px] text-[var(--blue)] uppercase">{theme}</span>
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Fullscreen workspace toggle */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
            title="Toggle Fullscreen Workspace"
          >
            {isFullscreen ? <MinimizeIcon className="h-3.5 w-3.5" /> : <MaximizeIcon className="h-3.5 w-3.5" />}
          </button>
        </div>
      </header>

      {/* ══════════════════ 2. THREE-PANE MAIN WORKSPACE AREA ══════════════════ */}
      <div className="flex flex-1 min-h-0 overflow-hidden relative">
        {/* ──────── LEFT: FILE EXPLORER ──────── */}
        {explorerOpen && layoutMode !== "editor-only" && layoutMode !== "preview-only" && (
          <aside
            style={{ width: `${explorerWidth}px` }}
            className="flex shrink-0 flex-col border-r border-[var(--border)] bg-[var(--sidebar)] select-none"
          >
            {/* Explorer Toolbar */}
            <div className="flex h-9 items-center justify-between border-b border-[var(--border)] px-3 text-xs">
              <span className="font-mono text-[11px] font-semibold tracking-wider text-[var(--text-3)] uppercase">
                Explorer
              </span>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setNewFileInputOpen(true)}
                  className="p-1 text-[var(--text-3)] hover:text-[var(--blue)]"
                  title="New File"
                >
                  <FilePlusIcon className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={handleResetProject}
                  className="p-1 text-[var(--text-3)] hover:text-[var(--text)]"
                  title="Refresh Files"
                >
                  <RefreshCwIcon className="h-3 w-3" />
                </button>
                <button
                  onClick={() => setExplorerOpen(false)}
                  className="p-1 text-[var(--text-3)] hover:text-[var(--text)]"
                  title="Collapse Explorer (Ctrl + B)"
                >
                  <SidebarCollapseIcon className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Project Root Folder */}
            <div className="flex-1 overflow-y-auto p-2">
              <div className="mb-1 flex items-center gap-1.5 px-1 py-1 font-mono text-[11px] font-bold text-[var(--text)]">
                <FolderOpenIcon className="h-3.5 w-3.5 text-[var(--blue)]" />
                <span className="truncate">{project.name}</span>
              </div>

              {/* Inline New File Input */}
              {newFileInputOpen && (
                <div className="my-1.5 flex items-center gap-1 px-2">
                  <FileIcon className="h-3 w-3 text-[var(--blue)]" />
                  <input
                    type="text"
                    value={newFileName}
                    autoFocus
                    placeholder="name.js / style.css"
                    onChange={(e) => setNewFileName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleCreateFile();
                      if (e.key === "Escape") setNewFileInputOpen(false);
                    }}
                    onBlur={() => {
                      if (!newFileName.trim()) setNewFileInputOpen(false);
                    }}
                    className="w-full border border-[var(--blue)] bg-[var(--surface-solid)] px-1.5 py-0.5 font-mono text-[11px] text-[var(--text)] focus:outline-none"
                  />
                </div>
              )}

              {/* File list */}
              <div className="space-y-0.5">
                {project.files.map((file) => {
                  const isActive = file.id === project.activeFileId;
                  const isRenaming = file.id === renamingFileId;

                  return (
                    <div
                      key={file.id}
                      onClick={() => handleSelectFile(file.id)}
                      className={cn(
                        "group flex cursor-pointer items-center justify-between px-2 py-1 text-xs font-mono transition-colors",
                        isActive
                          ? "bg-[var(--blue-soft)] text-[var(--blue)] font-semibold border-l-2 border-[var(--blue)]"
                          : "text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--text)]"
                      )}
                    >
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <FileIcon
                          className={cn(
                            "h-3.5 w-3.5 shrink-0",
                            file.name.endsWith(".html") && "text-[#FF6B6B]",
                            file.name.endsWith(".css") && "text-[var(--blue)]",
                            file.name.endsWith(".js") && "text-[#F2C94C]",
                            file.name.endsWith(".jsx") && "text-[#4D9CFF]",
                            file.name.endsWith(".py") && "text-[#5DD39E]",
                            file.name.endsWith(".md") && "text-[var(--text-3)]"
                          )}
                        />

                        {isRenaming ? (
                          <input
                            type="text"
                            value={renamingValue}
                            autoFocus
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => setRenamingValue(e.target.value)}
                            onBlur={handleFinishRename}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") handleFinishRename();
                              if (e.key === "Escape") setRenamingFileId(null);
                            }}
                            className="w-full border border-[var(--blue)] bg-[var(--surface-solid)] px-1 font-mono text-xs text-[var(--text)]"
                          />
                        ) : (
                          <span className="truncate">{file.name}</span>
                        )}
                      </div>

                      {/* File Hover Actions: Rename / Delete */}
                      <div className="hidden items-center gap-1 group-hover:flex">
                        <button
                          onClick={(e) => handleStartRename(file, e)}
                          className="p-0.5 text-[var(--text-3)] hover:text-[var(--blue)]"
                          title="Rename file"
                        >
                          <EditIcon className="h-3 w-3" />
                        </button>
                        {project.files.length > 1 && (
                          <button
                            onClick={(e) => handleDeleteFile(file.id, e)}
                            className="p-0.5 text-[var(--text-3)] hover:text-red-400"
                            title="Delete file"
                          >
                            <TrashIcon className="h-3 w-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bottom Explorer tip */}
            <div className="border-t border-[var(--border)] p-2.5 font-mono text-[10px] text-[var(--text-3)]">
              <span>{project.files.length} project files</span>
            </div>
          </aside>
        )}

        {/* Explorer Splitter Handle */}
        {explorerOpen && layoutMode !== "editor-only" && layoutMode !== "preview-only" && (
          <div
            role="separator"
            aria-orientation="vertical"
            onPointerDown={() => {
              dragTargetRef.current = "explorer";
              document.body.style.cursor = "col-resize";
              document.body.style.userSelect = "none";
            }}
            className="w-[3px] shrink-0 cursor-col-resize bg-[var(--border)] hover:bg-[var(--blue)] transition-colors"
          />
        )}

        {/* ──────── CENTER & RIGHT: EDITOR + PREVIEW + BOTTOM ──────── */}
        <div className="flex flex-1 min-w-0 flex-col overflow-hidden">
          {/* Main workspace split (Editor vs Preview) */}
          <div
            className={cn(
              "flex flex-1 min-h-0 overflow-hidden",
              layoutMode === "split-h" ? "flex-col" : "flex-row"
            )}
          >
            {/* ──────── CENTER: CODE EDITOR ──────── */}
            {layoutMode !== "preview-only" && (
              <section className="flex flex-1 min-w-0 flex-col bg-[var(--surface-solid)] overflow-hidden">
                {/* Editor Tabs Bar */}
                <div className="flex h-9 shrink-0 items-center justify-between border-b border-[var(--border)] bg-[var(--sidebar)] px-1 select-none">
                  {/* Open Tabs */}
                  <div className="flex items-center gap-1 overflow-x-auto">
                    {!explorerOpen && (
                      <button
                        onClick={() => setExplorerOpen(true)}
                        className="p-1.5 text-[var(--text-3)] hover:text-[var(--text)]"
                        title="Show Explorer (Ctrl + B)"
                      >
                        <SidebarCollapseIcon className="h-3.5 w-3.5 rotate-180" />
                      </button>
                    )}

                    {project.openTabs.map((tabId) => {
                      const file = project.files.find((f) => f.id === tabId);
                      if (!file) return null;
                      const isActive = file.id === project.activeFileId;

                      return (
                        <div
                          key={file.id}
                          onClick={() => handleSelectFile(file.id)}
                          className={cn(
                            "group flex cursor-pointer items-center gap-2 border-r border-[var(--border)] px-3 py-1.5 font-mono text-[11px] transition-colors",
                            isActive
                              ? "bg-[var(--surface-solid)] text-[var(--text)] border-t-2 border-t-[var(--blue)] font-semibold"
                              : "bg-[var(--sidebar)] text-[var(--text-3)] hover:bg-[var(--surface-2)] hover:text-[var(--text-2)]"
                          )}
                        >
                          <span
                            className={cn(
                              file.name.endsWith(".html") && "text-[#FF6B6B]",
                              file.name.endsWith(".css") && "text-[var(--blue)]",
                              file.name.endsWith(".js") && "text-[#F2C94C]",
                              file.name.endsWith(".jsx") && "text-[#4D9CFF]",
                              file.name.endsWith(".py") && "text-[#5DD39E]"
                            )}
                          >
                            {file.name}
                          </span>

                          <button
                            onClick={(e) => handleCloseTab(file.id, e)}
                            className="p-0.5 rounded text-[var(--text-3)] hover:text-[var(--text)] hover:bg-[var(--border)]"
                          >
                            <CloseIcon className="h-2.5 w-2.5" />
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  {/* Right Tab Bar Actions */}
                  <div className="flex items-center gap-1 pr-1 font-mono text-[10px] text-[var(--text-3)]">
                    <span className="hidden lg:inline">{activeFile.language.toUpperCase()}</span>
                    <button
                      onClick={() => setLayoutMode(layoutMode === "editor-only" ? "split-v" : "editor-only")}
                      className="p-1 hover:text-[var(--blue)]"
                      title="Focus Editor (Shift + Alt + M)"
                    >
                      {layoutMode === "editor-only" ? (
                        <MinimizeIcon className="h-3 w-3" />
                      ) : (
                        <MaximizeIcon className="h-3 w-3" />
                      )}
                    </button>
                  </div>
                </div>

                {/* CodeMirror Workspace */}
                <div className="flex-1 min-h-0 overflow-hidden relative">
                  <CodeMirror
                    value={activeFile.content}
                    onChange={handleFileChange}
                    extensions={editorExtensions}
                    theme={isDark ? oneDark : "light"}
                    height="100%"
                    basicSetup={{
                      lineNumbers: true,
                      foldGutter: true,
                      highlightActiveLine: true,
                      bracketMatching: true,
                      closeBrackets: true,
                      autocompletion: true,
                      indentOnInput: true,
                      tabSize: 2,
                    }}
                    style={{ height: "100%" }}
                  />
                </div>
              </section>
            )}

            {/* Splitter between Editor and Preview */}
            {layoutMode !== "editor-only" && layoutMode !== "preview-only" && (
              <div
                role="separator"
                aria-orientation={layoutMode === "split-h" ? "horizontal" : "vertical"}
                onPointerDown={() => {
                  dragTargetRef.current = "preview";
                  document.body.style.cursor = layoutMode === "split-h" ? "row-resize" : "col-resize";
                  document.body.style.userSelect = "none";
                }}
                className={cn(
                  "shrink-0 bg-[var(--border)] hover:bg-[var(--blue)] transition-colors",
                  layoutMode === "split-h" ? "h-[3px] cursor-row-resize" : "w-[3px] cursor-col-resize"
                )}
              />
            )}

            {/* ──────── RIGHT: LIVE PREVIEW & OUTPUT ──────── */}
            {layoutMode !== "editor-only" && (
              <section
                style={
                  layoutMode === "split-v"
                    ? { width: `${previewWidth}px` }
                    : undefined
                }
                className="flex flex-1 min-w-0 flex-col bg-[var(--surface-solid)] overflow-hidden"
              >
                {/* Preview Toolbar */}
                <div className="flex h-9 shrink-0 items-center justify-between border-b border-[var(--border)] bg-[var(--sidebar)] px-3 text-xs select-none">
                  {/* Left: Indicator */}
                  <div className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#5DD39E]" />
                    <span className="font-mono text-[11px] font-bold tracking-wider text-[var(--text)] uppercase">
                      {project.environment === "python" ? "Python Terminal" : "Live Preview"}
                    </span>
                  </div>

                  {/* Center: Device Viewport Toggle (for Web / React) */}
                  {project.environment !== "python" && (
                    <div className="hidden sm:flex items-center gap-1 border border-[var(--border)] bg-[var(--surface-2)] p-0.5 rounded">
                      <button
                        onClick={() => setPreviewViewport("desktop")}
                        className={cn(
                          "px-2 py-0.5 font-mono text-[10px] rounded",
                          previewViewport === "desktop" ? "bg-[var(--blue)] text-white font-bold" : "text-[var(--text-3)]"
                        )}
                        title="Desktop view (100%)"
                      >
                        Desktop
                      </button>
                      <button
                        onClick={() => setPreviewViewport("tablet")}
                        className={cn(
                          "px-2 py-0.5 font-mono text-[10px] rounded",
                          previewViewport === "tablet" ? "bg-[var(--blue)] text-white font-bold" : "text-[var(--text-3)]"
                        )}
                        title="Tablet view (768px)"
                      >
                        Tablet
                      </button>
                      <button
                        onClick={() => setPreviewViewport("mobile")}
                        className={cn(
                          "px-2 py-0.5 font-mono text-[10px] rounded",
                          previewViewport === "mobile" ? "bg-[var(--blue)] text-white font-bold" : "text-[var(--text-3)]"
                        )}
                        title="Mobile view (375px)"
                      >
                        Mobile
                      </button>
                    </div>
                  )}

                  {/* Right: Refresh & Actions */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={handleRun}
                      className="p-1 text-[var(--text-3)] hover:text-[var(--blue)]"
                      title="Reload Preview"
                    >
                      <RefreshCwIcon className="h-3 w-3" />
                    </button>
                    <button
                      onClick={() => setLayoutMode(layoutMode === "preview-only" ? "split-v" : "preview-only")}
                      className="p-1 text-[var(--text-3)] hover:text-[var(--blue)]"
                      title="Fullscreen Preview"
                    >
                      {layoutMode === "preview-only" ? (
                        <MinimizeIcon className="h-3 w-3" />
                      ) : (
                        <MaximizeIcon className="h-3 w-3" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Preview Content Area */}
                <div className="flex-1 min-h-0 overflow-auto bg-[var(--bg)] flex items-center justify-center p-2 relative">
                  {project.environment === "python" ? (
                    /* Python Terminal Window */
                    <div className="h-full w-full bg-[#080A0D] border border-[var(--border)] p-4 font-mono text-xs overflow-y-auto flex flex-col justify-between">
                      <div className="space-y-1">
                        {pythonStdout.map((line, idx) => (
                          <div
                            key={idx}
                            className={cn(
                              line.startsWith("RuntimeError") || line.startsWith("SyntaxError")
                                ? "text-[#FF6B6B]"
                                : line.startsWith(">>>")
                                ? "text-[var(--blue)] font-bold"
                                : line.startsWith("Process finished")
                                ? "text-[#5DD39E]"
                                : "text-[var(--text)]"
                            )}
                          >
                            {line}
                          </div>
                        ))}

                        {/* Interactive input field if python is waiting on input() */}
                        {terminalInputPending && (
                          <form onSubmit={handleTerminalInputSubmit} className="mt-2 flex items-center gap-2">
                            <span className="text-[var(--blue)] font-bold">{terminalInputPrompt}</span>
                            <input
                              type="text"
                              autoFocus
                              value={terminalInputValue}
                              onChange={(e) => setTerminalInputValue(e.target.value)}
                              className="flex-1 border-b border-[var(--blue)] bg-transparent text-xs text-[var(--text)] focus:outline-none"
                            />
                            <button
                              type="submit"
                              className="clip-oct-sm bg-[var(--blue)] px-2 py-0.5 text-[10px] text-white"
                            >
                              Enter ↵
                            </button>
                          </form>
                        )}
                      </div>

                      <div className="pt-4 border-t border-[var(--border)] flex items-center justify-between text-[10px] text-[var(--text-3)]">
                        <span>Python 3.12 (Sandboxed Runtime)</span>
                        <button
                          onClick={() => setPythonStdout([">>> Terminal cleared."])}
                          className="hover:text-[var(--text)]"
                        >
                          Clear
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* Web / React Sandboxed iframe Preview */
                    <div
                      className={cn(
                        "h-full transition-all duration-300 overflow-hidden bg-white shadow-xl relative",
                        previewViewport === "desktop" && "w-full",
                        previewViewport === "tablet" && "w-[768px] border-x border-[var(--border)]",
                        previewViewport === "mobile" && "w-[375px] border-x border-[var(--border)]"
                      )}
                    >
                      <iframe
                        key={previewKey}
                        title="CodeQuest Preview"
                        srcDoc={previewSrcDoc}
                        sandbox="allow-scripts allow-modals allow-forms allow-same-origin"
                        className="h-full w-full border-none"
                      />
                    </div>
                  )}
                </div>
              </section>
            )}
          </div>

          {/* Bottom Splitter Handle */}
          {bottomOpen && layoutMode !== "preview-only" && (
            <div
              role="separator"
              aria-orientation="horizontal"
              onPointerDown={() => {
                dragTargetRef.current = "bottom";
                document.body.style.cursor = "row-resize";
                document.body.style.userSelect = "none";
              }}
              className="h-[3px] shrink-0 cursor-row-resize bg-[var(--border)] hover:bg-[var(--blue)] transition-colors"
            />
          )}

          {/* ──────── 3. BOTTOM PANEL: PROBLEMS, OUTPUT, CONSOLE, TERMINAL ──────── */}
          {bottomOpen && layoutMode !== "preview-only" && (
            <section
              style={{ height: `${bottomHeight}px` }}
              className="flex shrink-0 flex-col border-t border-[var(--border)] bg-[var(--sidebar)] select-none overflow-hidden"
            >
              {/* Bottom Panel Tabs */}
              <div className="flex h-8 shrink-0 items-center justify-between border-b border-[var(--border)] px-3 text-xs">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setBottomTab("problems")}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1 font-mono text-[11px] transition-colors",
                      bottomTab === "problems"
                        ? "text-[var(--blue)] font-bold border-b border-[var(--blue)]"
                        : "text-[var(--text-3)] hover:text-[var(--text)]"
                    )}
                  >
                    <span>Problems</span>
                    {problems.length > 0 && (
                      <span className="clip-oct-sm bg-red-500 px-1 text-[9px] text-white">
                        {problems.length}
                      </span>
                    )}
                  </button>

                  <button
                    onClick={() => setBottomTab("output")}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1 font-mono text-[11px] transition-colors",
                      bottomTab === "output"
                        ? "text-[var(--blue)] font-bold border-b border-[var(--blue)]"
                        : "text-[var(--text-3)] hover:text-[var(--text)]"
                    )}
                  >
                    Output
                  </button>

                  <button
                    onClick={() => setBottomTab("console")}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1 font-mono text-[11px] transition-colors",
                      bottomTab === "console"
                        ? "text-[var(--blue)] font-bold border-b border-[var(--blue)]"
                        : "text-[var(--text-3)] hover:text-[var(--text)]"
                    )}
                  >
                    <span>Console</span>
                    {consoleLogs.length > 0 && (
                      <span className="text-[10px] opacity-60">({consoleLogs.length})</span>
                    )}
                  </button>

                  <button
                    onClick={() => setBottomTab("terminal")}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-1 font-mono text-[11px] transition-colors",
                      bottomTab === "terminal"
                        ? "text-[var(--blue)] font-bold border-b border-[var(--blue)]"
                        : "text-[var(--text-3)] hover:text-[var(--text)]"
                    )}
                  >
                    Terminal
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  {bottomTab === "console" && (
                    <button
                      onClick={() => setConsoleLogs([])}
                      className="font-mono text-[10px] text-[var(--text-3)] hover:text-[var(--text)]"
                    >
                      Clear
                    </button>
                  )}
                  <button
                    onClick={() => setBottomOpen(false)}
                    className="p-1 text-[var(--text-3)] hover:text-[var(--text)]"
                    title="Minimize Panel"
                  >
                    <CloseIcon className="h-3 w-3" />
                  </button>
                </div>
              </div>

              {/* Bottom Panel Content Body */}
              <div className="flex-1 overflow-y-auto p-3 font-mono text-xs select-text">
                {bottomTab === "problems" && (
                  <div>
                    {problems.length === 0 ? (
                      <p className="py-4 text-center text-[var(--text-3)]">No problems detected in workspace.</p>
                    ) : (
                      <div className="space-y-1.5">
                        {problems.map((prob) => (
                          <div
                            key={prob.id}
                            className="flex items-center justify-between border border-red-500/30 bg-red-500/10 p-2 text-red-400"
                          >
                            <span className="font-semibold">{prob.message}</span>
                            <span className="text-[11px] text-[var(--text-3)]">
                              {prob.file} [Ln {prob.line}, Col {prob.column || 1}]
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {bottomTab === "output" && (
                  <div className="space-y-1.5 text-[var(--text-2)]">
                    <p className="text-[var(--blue)] font-bold">Execution Status: {executionMessage}</p>
                    <p>Environment: {project.environment.toUpperCase()} Sandbox Runtime</p>
                    <p>Total Files: {project.files.length}</p>
                    <p className="text-[var(--text-3)]">Ready for code updates.</p>
                  </div>
                )}

                {bottomTab === "console" && (
                  <div className="space-y-1">
                    {consoleLogs.length === 0 ? (
                      <p className="py-4 text-center text-[var(--text-3)]">Console is empty.</p>
                    ) : (
                      consoleLogs.map((log) => (
                        <div
                          key={log.id}
                          className={cn(
                            "flex items-start gap-2 py-0.5",
                            log.level === "error" && "text-[#FF6B6B]",
                            log.level === "warn" && "text-[#F2C94C]",
                            log.level === "info" && "text-[var(--blue)]",
                            log.level === "log" && "text-[var(--text)]"
                          )}
                        >
                          <span className="text-[10px] text-[var(--text-3)] shrink-0">{log.timestamp}</span>
                          <span className="text-[10px] uppercase font-bold text-[var(--text-3)] shrink-0">
                            [{log.level}]
                          </span>
                          <span className="break-words">{log.args.join(" ")}</span>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {bottomTab === "terminal" && (
                  <div className="text-[var(--text)] space-y-1">
                    <p className="text-[var(--blue)] font-bold">CodeQuest Interactive Terminal v2.4</p>
                    <p className="text-[var(--text-3)]">Type and run code with Ctrl+Enter.</p>
                    <div className="mt-2 text-xs">
                      {project.environment === "python" ? (
                        <p className="text-[#5DD39E]">Python runtime online.</p>
                      ) : (
                        <p className="text-[var(--text-3)]">Web container ready.</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </section>
          )}

          {/* ══════════════════ 4. BOTTOM STATUS BAR ══════════════════ */}
          <footer className="flex h-6 shrink-0 items-center justify-between border-t border-[var(--border)] bg-[var(--sidebar)] px-3 font-mono text-[10px] text-[var(--text-3)] select-none">
            {/* Left status items */}
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-[#5DD39E]" />
                <span className="text-[var(--text-2)]">{executionMessage}</span>
              </span>

              <span>Ln {cursorPos.line}, Col {cursorPos.col}</span>
              <span className="hidden sm:inline">Spaces: 2</span>
              <span className="hidden sm:inline">UTF-8</span>
            </div>

            {/* Right status items */}
            <div className="flex items-center gap-3">
              {!bottomOpen && (
                <button
                  onClick={() => setBottomOpen(true)}
                  className="hover:text-[var(--text)]"
                  title="Expand Bottom Panel"
                >
                  Show Panel ▲
                </button>
              )}
              <span className="text-[var(--blue)] font-semibold">{project.environment.toUpperCase()}</span>
              <span className="hidden md:inline">CodeQuest Lab v2.4</span>
            </div>
          </footer>
        </div>
      </div>

      {/* ══════════════════ AUXILIARY MODALS & DRAWERS ══════════════════ */}
      <CodeLabWelcomeModal
        open={welcomeModalOpen}
        onClose={() => setWelcomeModalOpen(false)}
        onSelectEnvironment={(env, name) => {
          const next = getDefaultProject(env, name || `${env.toUpperCase()} Project`);
          setProject(next);
          setProjectName(next.name);
          setWelcomeModalOpen(false);
          setProblems([]);
        }}
      />

      <CodeLabSnippetsModal
        open={snippetsModalOpen}
        onClose={() => setSnippetsModalOpen(false)}
        onInsertSnippet={handleInsertSnippet}
      />

      <CodeLabChallengesDrawer
        open={challengesDrawerOpen}
        onClose={() => setChallengesDrawerOpen(false)}
        onLoadChallenge={handleLoadChallenge}
      />

      <CodeLabShortcutsModal
        open={shortcutsModalOpen}
        onClose={() => setShortcutsModalOpen(false)}
      />
    </div>
  );
}
