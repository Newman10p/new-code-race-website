import { useEffect, useMemo, useState } from "react";
import { cn } from "../../../utils/cn";
import {
  accentVar,
  competitionsSeed,
  countdownParts,
  dateLong,
  phaseFor,
  type Competition,
} from "../../../data/competitionsData";
import { useCompetitions, isRegistered } from "../../../lib/competitionStore";
import { prefersReducedMotion } from "../../../lib/grid";
import { ArrowLeft, ArrowRight, CheckIcon, ClockIcon, SearchIcon, TrophyIcon, UsersIcon } from "../../../components/icons";
import WaitingRoom from "./competitions/WaitingRoom";
import LiveArena from "./competitions/LiveArena";
import ResultsArena from "./competitions/ResultsArena";

const pad = (n: number) => String(n).padStart(2, "0");
type LobbyTab = "all" | "upcoming" | "live" | "completed" | "mine";
const SORTS = [
  { id: "soon", label: "Starting soon" },
  { id: "published", label: "Recently published" },
  { id: "participants", label: "Most participants" },
  { id: "recent", label: "Recently completed" },
] as const;

/* ══════════════ COMPETITION CARD ══════════════ */

function CompetitionCard({ c, phase, registered, onOpen }: {
  c: Competition; phase: string; registered: boolean; onOpen: () => void;
}) {
  const { now, serverNow } = useCompetitions();
  const accent = accentVar[c.accent];
  const remaining = new Date(c.starts_at).getTime() - serverNow();
  const parts = countdownParts(remaining);
  void now;

  const badge =
    phase === "live" ? { text: "LIVE NOW", cls: "bg-[#FF6B6B] text-black" }
    : phase === "results" ? { text: "RESULTS OUT", cls: "border border-[#5DD39E] text-[#5DD39E]" }
    : phase === "completed" ? { text: "COMPLETED", cls: "border border-[var(--border-strong)] text-[var(--text-3)]" }
    : registered ? { text: "REGISTERED", cls: "border border-[var(--blue)] text-[var(--blue)]" }
    : { text: "UPCOMING", cls: "border border-[var(--border-strong)] text-[var(--text-2)]" };

  return (
    <button onClick={onOpen} className="group relative block w-full overflow-hidden border border-[var(--border)] bg-[var(--surface-solid)] p-5 text-left transition-all duration-300 hover:-translate-y-[3px] hover:border-[var(--blue)]">
      <span aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-[2px] origin-left scale-x-0 transition-transform duration-500 group-hover:scale-x-100" style={{ background: accent }} />
      <span aria-hidden="true" className="pointer-events-none absolute -right-14 -top-14 h-40 w-40 rotate-12 opacity-[0.07] transition-opacity duration-500 group-hover:opacity-[0.16]"
        style={{ background: accent, clipPath: "polygon(25% 0,75% 0,100% 25%,100% 75%,75% 100%,25% 100%,0 75%,0 25%)" }} />

      <div className="relative flex flex-wrap items-center gap-2">
        <span className="mono-label text-[9px]" style={{ color: accent }}>{c.category} · {c.difficulty}</span>
        <span className={cn("clip-oct-sm ml-auto px-2 py-0.5 font-mono text-[9px] font-bold tracking-wider", badge.cls)}>
          {phase === "live" && <span className="live-dot mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-black" />}
          {badge.text}
        </span>
      </div>

      <h3 className="display relative mt-2.5 text-lg font-bold leading-tight tracking-tight group-hover:text-[var(--blue)]">{c.title}</h3>
      <p className="relative mt-1.5 line-clamp-2 text-[12.5px] leading-relaxed text-[var(--text-2)]">{c.shortDescription}</p>

      <dl className="relative mt-4 grid grid-cols-2 gap-x-4 gap-y-2 border-t border-[var(--border)] pt-3 font-mono text-[10px] sm:grid-cols-4">
        {[
          ["Starts", phase === "live" ? "in progress" : dateLong(c.starts_at).replace(/,\s\d{4}/, "")],
          ["Duration", `${c.durationMinutes} min`],
          ["Rounds", String(c.rounds.length)],
          ["Points", String(c.totalPoints)],
        ].map(([k, v]) => (
          <div key={k}><dt className="text-[var(--text-3)]">{k}</dt><dd className="mt-0.5 text-[var(--text)]">{v}</dd></div>
        ))}
      </dl>

      <div className="relative mt-3 flex flex-wrap items-center justify-between gap-2">
        <span className="flex items-center gap-3 font-mono text-[10px] text-[var(--text-3)]">
          <span className="flex items-center gap-1"><UsersIcon className="h-3 w-3" />{c.registeredCount}</span>
          <span>{c.schoolCount} schools</span>
          <span className="flex items-center gap-1 text-[#5DD39E]"><CheckIcon className="h-3 w-3" />verified</span>
        </span>

        {phase === "live" ? (
          <span className="font-display text-[11.5px] font-semibold text-[#FF6B6B]">Joined in progress →</span>
        ) : phase === "results" ? (
          <span className="font-display text-[11.5px] font-semibold text-[var(--blue)]">View results →</span>
        ) : phase === "completed" ? (
          <span className="font-display text-[11.5px] font-semibold text-[var(--text-3)]">View my performance →</span>
        ) : remaining > 0 && remaining < 3600_000 ? (
          <span className="countdown-digit font-mono text-[12px] font-bold" style={{ color: accent }}>
            T−{pad(parts.minutes)}:{pad(parts.seconds)}
          </span>
        ) : (
          <span className="font-display text-[11.5px] font-semibold text-[var(--text-2)] group-hover:text-[var(--blue)]">
            {registered ? "Enter waiting room →" : c.studentEligible ? "View details →" : "Registration required →"}
          </span>
        )}
      </div>
    </button>
  );
}

/* ══════════════ COMPLETION SCREEN ══════════════ */

function CompletionScreen({ c, onExit, onNavigate }: { c: Competition; onExit: () => void; onNavigate: (t: string) => void }) {
  const { attemptFor } = useCompetitions();
  const attempt = attemptFor(c.id);
  const answered = Object.values(attempt?.answers ?? {}).filter((a) => a.value.trim()).length;
  const total = c.rounds.reduce((s, r) => s + r.questions.length, 0);

  return (
    <div className={cn("arena-shell flex min-h-full items-center justify-center px-4 py-12", `accent-${c.accent}`)}>
      <div className="arena-texture w-full max-w-xl border bg-[var(--surface-solid)] p-7 sm:p-9" style={{ borderColor: `${accentVar[c.accent]}55` }}>
        <div className="flex gap-1.5" aria-hidden="true">
          {Array.from({ length: 9 }).map((_, i) => (
            <span key={i} className="clip-oct-sm h-2.5 flex-1" style={{ background: accentVar[c.accent], animation: prefersReducedMotion() ? "none" : `cq-ignite 700ms ${i * 70}ms ease-out both` }} />
          ))}
        </div>

        <p className="mono-label mt-6" style={{ color: accentVar[c.accent] }}>ATTEMPT FINALISED</p>
        <h1 className="display mt-2 text-3xl font-bold uppercase leading-none tracking-tight sm:text-4xl">Competition completed</h1>
        <p className="mt-3 text-sm leading-relaxed text-[var(--text-2)]">Your submission has been received and locked. Grading happens server-side.</p>

        <dl className="mt-6 grid grid-cols-2 gap-x-4 gap-y-3 border-y border-[var(--border)] py-4 font-mono text-[11px]">
          {[
            ["Competition", c.title],
            ["Completed", attempt?.completedAt ? new Date(attempt.completedAt).toLocaleString() : "—"],
            ["Answered", `${answered} of ${total}`],
            ["Submission", attempt?.submitted ? "locked" : "open"],
            ["Evaluation", "pending server grading"],
            ["Reference", attempt?.id ?? "—"],
          ].map(([k, v]) => (
            <div key={k}><dt className="text-[var(--text-3)]">{k}</dt><dd className="mt-0.5 break-words text-[var(--text)]">{v}</dd></div>
          ))}
        </dl>

        {attempt?.rehearsalScore !== null && attempt?.rehearsalScore !== undefined && (
          <p className="mt-4 border border-dashed border-[#F2C94C]/50 bg-[#F2C94C]/[0.07] p-3 font-mono text-[10.5px] leading-relaxed text-[#F2C94C]">
            Rehearsal estimate {attempt.rehearsalScore} points — local only (MCQ keys + visible code tests). This is not an
            official score, and standings stay hidden until results are published.
          </p>
        )}

        {attempt && attempt.rehearsalLog.length > 0 && (
          <div className="mt-4">
            <p className="mono-label mb-2 text-[9px]">Attempt log</p>
            <ul className="space-y-0.5 font-mono text-[10px] text-[var(--text-3)]">
              {attempt.rehearsalLog.slice(-6).map((l) => <li key={l}>· {l}</li>)}
            </ul>
          </div>
        )}

        <div className="mt-6 flex flex-wrap gap-2.5">
          <button onClick={onExit} className="btn-shell btn-primary-shell btn-shell-md"><span className="btn-core">Back to the arena</span></button>
          <button onClick={() => onNavigate("daily-practice")} className="btn-shell btn-ghost-shell btn-shell-md"><span className="btn-core">Practice while you wait</span></button>
          <button disabled className="btn-shell btn-ghost-shell btn-shell-md opacity-45"><span className="btn-core">Results sealed until published</span></button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ DETAILS ══════════════ */

function Details({ c, onBack, onWaiting, onLive, onResults }: {
  c: Competition; onBack: () => void; onWaiting: () => void; onLive: () => void; onResults: () => void;
}) {
  const { serverNow, register, attemptFor } = useCompetitions();
  const [registeredLocally, setRegisteredLocally] = useState<string[]>([]);
  const registered = isRegistered(c, registeredLocally);
  const phase = phaseFor(c, serverNow(), Boolean(attemptFor(c.id)?.submitted));
  const accent = accentVar[c.accent];
  const startMs = new Date(c.control?.revisedStart ?? c.starts_at).getTime();
  const remaining = startMs - serverNow();

  const timeline = [
    { label: "Registration opens", at: c.registration_opens },
    { label: "Registration closes", at: c.registration_closes },
    { label: "Waiting room opens", at: c.waiting_room_opens },
    { label: "Competition begins", at: c.control?.revisedStart ?? c.starts_at },
    { label: "Competition ends", at: c.ends_at },
    ...(c.results_at ? [{ label: "Results published", at: c.results_at }] : []),
  ];

  const canEnterWaiting = registered && c.studentEligible && phase === "waiting";
  const blockedReason = !c.studentEligible
    ? `This event is limited to ${c.difficulty.toLowerCase()} participants, and your account is outside that division.`
    : !registered
    ? "Registration is required before the waiting room opens. New entries are validated server-side."
    : phase === "lobby" && remaining > 0
    ? `The waiting room opens ${dateLong(c.waiting_room_opens)}.`
    : null;

  return (
    <div className={cn("arena-shell min-h-full pb-12", `accent-${c.accent}`)}>
      <div className="mx-auto max-w-[1080px] px-4 pt-6 sm:px-6">
        <button onClick={onBack} className="mono-label inline-flex items-center gap-2 transition-colors hover:text-[var(--blue)]">
          <ArrowLeft className="h-3 w-3" /> Competition lobby
        </button>

        <header className="mt-4 border-b border-[var(--border)] pb-6">
          <div className="flex flex-wrap items-center gap-2">
            <span className="mono-label text-[9px]" style={{ color: accent }}>{c.category} · {c.difficulty}</span>
            <span className="clip-oct-sm flex items-center gap-1.5 border border-[#5DD39E]/50 px-2 py-0.5 font-mono text-[9px] text-[#5DD39E]">
              <CheckIcon className="h-2.5 w-2.5" /> OFFICIAL CODEQUEST COMPETITION
            </span>
            <span className="clip-oct-sm ml-auto border px-2 py-0.5 font-mono text-[9px] uppercase" style={{ borderColor: accent, color: accent }}>
              {phase}
            </span>
          </div>
          <h1 className="display mt-3 text-3xl font-bold uppercase leading-[1.03] tracking-tight sm:text-[2.7rem]">{c.title}</h1>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-[var(--text-2)]">{c.shortDescription}</p>
          <dl className="mt-5 grid grid-cols-2 gap-4 font-mono text-[10.5px] sm:grid-cols-4">
            {[["Starts", dateLong(c.starts_at)], ["Duration", `${c.durationMinutes} minutes`], ["Rounds", String(c.rounds.length)], ["Registered", `${c.registeredCount} students`]].map(([k, v]) => (
              <div key={k} className="border-l pl-3" style={{ borderColor: accent }}><dt className="text-[var(--text-3)]">{k}</dt><dd className="mt-1 text-[var(--text)]">{v}</dd></div>
            ))}
          </dl>
        </header>

        {/* primary action */}
        <div className="mt-6 border bg-[var(--surface-solid)] p-5" style={{ borderColor: `${accent}44` }}>
          {phase === "results" ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div><p className="display text-base font-bold">Results are published.</p><p className="mt-1 text-xs text-[var(--text-2)]">Standings, breakdown and question review are available.</p></div>
              <button onClick={onResults} className="btn-shell btn-primary-shell btn-shell-md"><span className="btn-core">View results <ArrowRight className="h-3.5 w-3.5" /></span></button>
            </div>
          ) : phase === "live" ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div><p className="display flex items-center gap-2 text-base font-bold"><span className="live-dot h-2 w-2 rounded-full bg-[#FF6B6B]" />This competition is live.</p>
                <p className="mt-1 text-xs text-[var(--text-2)]">{registered ? "Your attempt is in progress — the timer continues while you are away." : "Entry closed once the round started."}</p></div>
              <button onClick={onLive} disabled={!registered} className="btn-shell btn-primary-shell btn-shell-md disabled:opacity-40"><span className="btn-core">Join Competition <ArrowRight className="h-3.5 w-3.5" /></span></button>
            </div>
          ) : phase === "waiting" ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="display text-base font-bold">Waiting room is open.</p>
                <p className="mt-1 font-mono text-[11px] text-[var(--text-2)]">
                  Starts in {pad(countdownParts(remaining).hours)}:{pad(countdownParts(remaining).minutes)}:{pad(countdownParts(remaining).seconds)} · your local time
                </p>
              </div>
              <button onClick={onWaiting} disabled={!canEnterWaiting} className="btn-shell btn-primary-shell btn-shell-md disabled:opacity-40">
                <span className="btn-core">Enter Waiting Room <ArrowRight className="h-3.5 w-3.5" /></span>
              </button>
            </div>
          ) : phase === "completed" ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div><p className="display text-base font-bold">This event has finished.</p><p className="mt-1 text-xs text-[var(--text-2)]">Results are pending jury sign-off; review opens once they are published.</p></div>
              <button onClick={onBack} className="btn-shell btn-ghost-shell btn-shell-md"><span className="btn-core">Back to lobby</span></button>
            </div>
          ) : (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div><p className="display text-base font-bold">{registered ? "You hold a confirmed seat." : "Registration is open."}</p>
                <p className="mt-1 text-xs text-[var(--text-2)]">{dateLong(c.starts_at)} · {c.languages.join(", ")}</p></div>
              {registered ? (
                <button disabled className="btn-shell btn-ghost-shell btn-shell-md opacity-50"><span className="btn-core">Registered ✓</span></button>
              ) : (
                <button disabled={!c.studentEligible} onClick={() => { register(c.id); setRegisteredLocally((r) => [...r, c.id]); }} className="btn-shell btn-primary-shell btn-shell-md disabled:opacity-40">
                  <span className="btn-core">Register for Competition</span>
                </button>
              )}
            </div>
          )}
          {blockedReason && <p className="mt-3 border-t border-[var(--border)] pt-3 font-mono text-[10.5px] leading-relaxed text-[#F2C94C]">{blockedReason}</p>}
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
          <div className="space-y-7">
            <section><h2 className="mono-label mb-3" style={{ color: accent }}>About this competition</h2>
              <div className="space-y-3">{c.description.map((p) => <p key={p} className="text-[13.5px] leading-relaxed text-[var(--text-2)]">{p}</p>)}</div></section>

            <section><h2 className="mono-label mb-3" style={{ color: accent }}>Competition structure</h2>
              <div className="space-y-2.5">{c.rounds.map((r, i) => (
                <div key={r.id} className="flex flex-wrap items-center justify-between gap-3 border border-[var(--border)] bg-[var(--surface-solid)] p-3.5">
                  <div className="flex items-center gap-3"><span className="clip-oct-sm flex h-7 w-7 items-center justify-center font-mono text-[10px] font-bold" style={{ background: accent, color: "#08111e" }}>{i + 1}</span>
                    <div><p className="display text-[13px] font-bold">{r.name}</p><p className="mt-0.5 text-[11.5px] text-[var(--text-2)]">{r.blurb}</p></div></div>
                  <p className="font-mono text-[10px] text-[var(--text-3)]">{r.questions.length} questions · {r.durationMinutes} min{r.unlocksAtMinute > 0 && ` · unlocks +${r.unlocksAtMinute}m`}</p>
                </div>))}</div>
              <ul className="mt-3 space-y-1">{c.scoring.map((s) => <li key={s} className="flex gap-2 text-[12px] leading-relaxed text-[var(--text-2)]"><span className="mt-1.5 h-1 w-1 shrink-0 rotate-45" style={{ background: accent }} />{s}</li>)}</ul></section>

            <section><h2 className="mono-label mb-3" style={{ color: accent }}>Rules and guidelines</h2>
              <dl className="grid gap-2 sm:grid-cols-2">{([
                ["Permitted languages", c.languages.join(", ") || "—"],
                ["External resources", c.rules.externalResources ? "Allowed" : "Not allowed"],
                ["Revisit questions", c.rules.revisitQuestions ? "Allowed" : "Locked — forward only"],
                ["Change answers", c.rules.changeAnswers ? "Allowed until submit" : "Locked after selection"],
                ["Submission attempts", "Unlimited runs; final submit locks the attempt"],
                ["Grace period", `${c.rules.graceMinutes} minutes`],
                ["Late submissions", c.rules.acceptLate ? "Accepted" : "Rejected"],
                ["Hidden test feedback", c.rules.showHiddenTests ? "Revealed with results" : "Withheld during the round"],
              ] as [string, string][]).map(([k, v]) => (
                <div key={k} className="border border-[var(--border)] bg-[var(--surface-solid)] px-3 py-2"><dt className="mono-label text-[9px]">{k}</dt><dd className="mt-1 text-[12px] text-[var(--text)]">{v}</dd></div>))}</dl>
              <div className="mt-3 border border-[#F2C94C]/35 bg-[#F2C94C]/[0.06] p-3.5">
                <p className="mono-label text-[#F2C94C]">Integrity & monitoring</p>
                <ul className="mt-2 space-y-1">{c.rules.monitoring.map((m) => <li key={m} className="text-[11.5px] leading-relaxed text-[var(--text-2)]">· {m}</li>)}</ul>
                <p className="mt-2 text-[11px] text-[var(--text-3)]">Camera and microphone monitoring is not used. Plagiarism or collaboration where prohibited results in disqualification.</p>
              </div>
            </section>

            <section><h2 className="mono-label mb-3" style={{ color: accent }}>Eligibility</h2>
              <ul className="space-y-1.5">{c.eligibility.map((e) => <li key={e} className="flex gap-2 text-[12.5px] text-[var(--text-2)]"><span className="mt-1.5 h-1 w-1 shrink-0 rotate-45" style={{ background: accent }} />{e}</li>)}</ul>
              <p className={cn("mt-3 font-mono text-[11px]", c.studentEligible ? "text-[#5DD39E]" : "text-[#F2C94C]")}>
                Your account: {c.studentEligible ? "eligible" : "outside the configured division"}
              </p></section>
          </div>

          {/* timeline rail */}
          <aside className="space-y-4">
            <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
              <h2 className="mono-label text-[var(--text)]">Competition timeline</h2>
              <div className="mt-4 border-l pl-4" style={{ borderColor: `${accent}55` }}>
                {timeline.map((t) => {
                  const past = new Date(t.at).getTime() < serverNow();
                  return (
                    <div key={t.label} className="relative pb-4 last:pb-0">
                      <span className={cn("absolute -left-[21px] top-1 h-2 w-2 rotate-45", past ? "" : "opacity-40")} style={{ background: accent }} />
                      <p className={cn("text-[12px] font-medium", past ? "text-[var(--text-3)] line-through" : "text-[var(--text)]")}>{t.label}</p>
                      <p className="mt-0.5 font-mono text-[10px] text-[var(--text-3)]">{dateLong(t.at)}</p>
                    </div>
                  );
                })}
              </div>
            </div>
            {c.rules.deviceRequirement && (
              <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
                <h2 className="mono-label text-[var(--text)]">Device requirement</h2>
                <p className="mt-2 text-[11.5px] leading-relaxed text-[#F2C94C]">{c.rules.deviceRequirement}</p>
              </div>
            )}
            <div className="border border-dashed border-[var(--border-strong)] p-3.5 font-mono text-[9.5px] leading-relaxed text-[var(--text-3)]">
              Published by authorised CodeQuest developers. Start, end and eligibility are validated server-side; a client cannot extend the window or alter a score.
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ PAGE ══════════════ */

export default function CompetitionsTab({ onNavigate }: { onNavigate: (tab: string) => void }) {
  const { competitions, serverNow, now, attemptFor } = useCompetitions();
  const [tab, setTab] = useState<LobbyTab>("all");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [difficulty, setDifficulty] = useState("all");
  const [window_, setWindow] = useState("all");
  const [participation, setParticipation] = useState("all");
  const [sort, setSort] = useState<(typeof SORTS)[number]["id"]>("soon");
  const [focus, setFocus] = useState<string | null>(null);
  const [mode, setMode] = useState<"details" | "waiting" | "live">("details");

  const focused = focus ? competitions.find((c) => c.id === focus) : undefined;
  const focusedPhase = focused ? phaseFor(focused, serverNow(), Boolean(attemptFor(focused.id)?.submitted)) : null;

  const phaseOf = (c: Competition) => phaseFor(c, serverNow(), Boolean(attemptFor(c.id)?.submitted));
  const registeredOf = (c: Competition) => isRegistered(c, []);

  const counts = useMemo(() => ({
    available: competitions.filter((c) => ["waiting", "live"].includes(phaseOf(c))).length,
    upcoming: competitions.filter((c) => new Date(c.starts_at).getTime() > serverNow()).length,
    live: competitions.filter((c) => phaseOf(c) === "live").length,
    completed: competitions.filter((c) => ["completed", "results"].includes(phaseOf(c))).length,
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [competitions, now]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return competitions
      .filter((c) => {
        const phase = phaseOf(c);
        if (tab === "upcoming" && new Date(c.starts_at).getTime() <= serverNow()) return false;
        if (tab === "live" && phase !== "live") return false;
        if (tab === "completed" && !["completed", "results"].includes(phase)) return false;
        if (tab === "mine" && !registeredOf(c)) return false;
        if (category !== "all" && c.category !== category) return false;
        if (difficulty !== "all" && c.difficulty !== difficulty) return false;
        if (participation === "registered" && !registeredOf(c)) return false;
        if (participation === "open" && !(new Date(c.registration_closes).getTime() > serverNow())) return false;
        if (participation === "closed" && new Date(c.registration_closes).getTime() > serverNow()) return false;
        if (participation === "eligible" && !c.studentEligible) return false;
        if (window_ === "week" && new Date(c.starts_at).getTime() > serverNow() + 7 * 86400_000) return false;
        if (window_ === "month" && new Date(c.starts_at).getTime() > serverNow() + 30 * 86400_000) return false;
        if (q && !`${c.title} ${c.shortDescription} ${c.category}`.toLowerCase().includes(q)) return false;
        return true;
      })
      .sort((a, b) => {
        if (sort === "participants") return b.registeredCount - a.registeredCount;
        if (sort === "published") return new Date(b.registration_opens).getTime() - new Date(a.registration_opens).getTime();
        if (sort === "recent") return new Date(a.ends_at).getTime() - new Date(b.ends_at).getTime();
        return new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime();
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [competitions, tab, query, category, difficulty, window_, participation, sort, now]);

  const hiddenDrafts = competitionsSeed.filter((c) => c.publication_status !== "published").length;
  const categories = Array.from(new Set(competitions.map((c) => c.category)));
  const difficulties = Array.from(new Set(competitions.map((c) => c.difficulty)));

  /* keep the focused view honest when the phase changes underneath us */
  useEffect(() => {
    if (focused && mode === "live" && focusedPhase === "results") setMode("details");
  }, [focused, mode, focusedPhase]);

  if (focused && mode === "live") {
    return attemptFor(focused.id)?.submitted
      ? <CompletionScreen c={focused} onExit={() => setMode("details")} onNavigate={onNavigate} />
      : <LiveArena competition={focused} onExit={() => setMode("details")} />;
  }
  if (focused && mode === "waiting") {
    return <WaitingRoom competition={focused} onEnter={() => setMode("live")} onLeave={() => setMode("details")} />;
  }
  /* published results take precedence over the pre-event detail page */
  if (focused && focusedPhase === "results") {
    return <ResultsArena competition={focused} onBack={() => setFocus(null)} onNavigate={onNavigate} />;
  }
  if (focused && mode === "details") {
    return <Details c={focused} onBack={() => setFocus(null)} onWaiting={() => setMode("waiting")} onLive={() => setMode("live")} onResults={() => setMode("details")} />;
  }

  return (
    <div className="arena-shell accent-blue mx-auto max-w-[1380px] space-y-6 pb-10">
      {/* header */}
      <div className="flex flex-col gap-5 border-b border-[var(--border)] pb-6 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="mono-label flex items-center gap-2 text-[var(--blue)]">
            <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />
            COMPETE / THE COMPETITION ARENA
          </p>
          <h1 className="display mt-2 text-3xl font-bold uppercase leading-[1.02] tracking-tight sm:text-[2.8rem]">
            Enter the arena. <span className="text-[var(--blue)]">Prove your skills.</span>
          </h1>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-[var(--text-2)]">
            Every challenge is an opportunity to prove what you can do. Only competitions published by authorised
            CodeQuest developers appear here.
          </p>
        </div>
        <dl className="grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-4 lg:gap-x-5">
          {[["Available", counts.available], ["Upcoming", counts.upcoming], ["Live", counts.live], ["Completed", counts.completed]].map(([k, v]) => (
            <div key={String(k)} className="border-l border-[var(--border-strong)] pl-3">
              <dt className="mono-label text-[9px]">{k}</dt>
              <dd className={cn("display mt-1 text-2xl font-bold leading-none", k === "Live" && Number(v) > 0 ? "text-[#FF6B6B]" : "text-[var(--text)]")}>{v}</dd>
            </div>
          ))}
        </dl>
      </div>

      {/* tabs */}
      <div role="tablist" aria-label="Competitions" className="flex flex-wrap gap-x-4 gap-y-2 border-b border-[var(--border)]">
        {([["all", "All Competitions"], ["upcoming", "Upcoming"], ["live", "Live Now"], ["completed", "Completed"], ["mine", "My Competitions"]] as [LobbyTab, string][]).map(([id, label]) => (
          <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
            className={cn("relative pb-3 font-display text-[12.5px] font-semibold transition-colors", tab === id ? "text-[var(--text)]" : "text-[var(--text-3)] hover:text-[var(--text)]")}>
            {label}
            {id === "live" && counts.live > 0 && <span className="live-dot ml-2 inline-block h-1.5 w-1.5 rounded-full bg-[#FF6B6B]" />}
            {tab === id && <span className="absolute inset-x-0 bottom-0 h-[2px] bg-[var(--blue)]" />}
          </button>
        ))}
      </div>

      {/* filters */}
      <div className="flex flex-wrap items-center gap-2">
        <label className="relative min-w-[180px] flex-1">
          <SearchIcon className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[var(--text-3)]" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search competitions…" aria-label="Search competitions"
            className="comm-input pl-8" />
        </label>
        {[
          { v: category, set: setCategory, opts: ["all", ...categories], label: "Type" },
          { v: difficulty, set: setDifficulty, opts: ["all", ...difficulties], label: "Difficulty" },
          { v: window_, set: setWindow, opts: ["all", "week", "month"], label: "Date" },
          { v: participation, set: setParticipation, opts: ["all", "registered", "open", "closed", "eligible"], label: "Status" },
        ].map((f) => (
          <label key={f.label} className="flex items-center gap-1.5">
            <span className="mono-label text-[9px]">{f.label}</span>
            <select value={f.v} onChange={(e) => f.set(e.target.value)} className="comm-input w-auto" aria-label={f.label}>
              {f.opts.map((o) => <option key={o} value={o}>{o === "all" ? `All` : o}</option>)}
            </select>
          </label>
        ))}
        <label className="ml-auto flex items-center gap-1.5">
          <span className="mono-label text-[9px]">Sort</span>
          <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} className="comm-input w-auto" aria-label="Sort competitions">
            {SORTS.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
          </select>
        </label>
      </div>

      {/* grid */}
      {visible.length ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {visible.map((c) => (
            <CompetitionCard key={c.id} c={c} phase={phaseOf(c)} registered={registeredOf(c)}
              onOpen={() => { setFocus(c.id); setMode(phaseOf(c) === "results" ? "details" : "details"); }} />
          ))}
        </div>
      ) : (
        <div className="flex min-h-52 flex-col items-center justify-center border border-dashed border-[var(--border-strong)] p-10 text-center">
          <TrophyIcon className="h-7 w-7 text-[var(--text-3)]" />
          <h2 className="display mt-3 text-base font-bold uppercase">No competitions match</h2>
          <p className="mt-1.5 max-w-sm text-xs text-[var(--text-2)]">
            {tab === "mine" ? "You have not registered for a competition in this view yet." : "Adjust a filter, or check back after the next publication window."}
          </p>
          <button className="comm-button mt-4" onClick={() => { setQuery(""); setCategory("all"); setDifficulty("all"); setWindow("all"); setParticipation("all"); setTab("all"); }}>Reset filters</button>
        </div>
      )}

      <p className="flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-[var(--border)] pt-4 font-mono text-[10px] text-[var(--text-3)]">
        <span className="flex items-center gap-1.5"><ClockIcon className="h-3 w-3" />{visible.length} published shown</span>
        <span>{hiddenDrafts} draft record{hiddenDrafts === 1 ? "" : "s"} hidden by publication status</span>
        <span className="ml-auto">Frontend rehearsal — registration and entry are validated server-side in production</span>
      </p>
    </div>
  );
}
