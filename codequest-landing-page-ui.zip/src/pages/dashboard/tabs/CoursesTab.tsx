import { useEffect, useMemo, useState } from "react";
import { cn } from "../../../utils/cn";
import { certificateFor, type Course } from "../../../data/academyData";
import { useAcademy, visibleCourses } from "../../../lib/academyStore";
import { prefersReducedMotion } from "../../../lib/grid";
import LessonStudio from "./courses/LessonStudio";
import {
  ArrowLeft, ArrowRight, CheckIcon, CloseIcon, ClockIcon, GraduationCapIcon,
  LockIcon, PlayIcon, SearchIcon, SparklesIcon, TrophyIcon,
} from "../../../components/icons";

type Chip = "all" | "recommended" | "in-progress" | "not-started" | "completed" | "saved";
type View = { kind: "library" } | { kind: "journey"; courseId: string } | { kind: "lesson"; courseId: string; m: number; l: number };

/* ═══════ subject visual identities (original UI compositions) ═══════ */

function SubjectPattern({ kind }: { kind: Course["pattern"] }) {
  const stroke = "currentColor";
  if (kind === "code") return (
    <svg viewBox="0 0 240 96" className="h-full w-full" aria-hidden="true" opacity="0.5">
      {Array.from({ length: 7 }).map((_, i) => (
        <g key={i} stroke={stroke} strokeWidth="1" fill="none">
          <path d={`M${14 + i * 34} 26 l-12 22 l12 22`} opacity={0.35 + (i % 3) * 0.2} />
          <path d={`M${30 + i * 34} 26 l12 22 l-12 22`} opacity={0.35 + (i % 2) * 0.25} />
        </g>
      ))}
      <line x1="0" y1="78" x2="240" y2="78" stroke={stroke} strokeWidth="1" opacity="0.25" strokeDasharray="3 7" />
    </svg>
  );
  if (kind === "circuit") return (
    <svg viewBox="0 0 240 96" className="h-full w-full" aria-hidden="true" opacity="0.55">
      <g stroke={stroke} strokeWidth="1" fill="none">
        <path d="M20 48 H70 L90 28 H150 L170 48 H220" opacity="0.6" />
        <path d="M20 70 H110 L130 70 M150 70 H220" opacity="0.35" />
        <path d="M50 48 V20 M190 48 V20 M120 28 V10" opacity="0.4" />
        {[[70, 48], [150, 48], [110, 70], [50, 48], [190, 48], [120, 28]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="4" fill={stroke} opacity="0.5" />)}
        <rect x="96" y="34" width="48" height="28" rx="3" opacity="0.55" />
      </g>
    </svg>
  );
  if (kind === "neural") return (
    <svg viewBox="0 0 240 96" className="h-full w-full" aria-hidden="true" opacity="0.55">
      <g stroke={stroke} strokeWidth="1" fill="none" opacity="0.5">
        {[0, 1, 2].flatMap((col) => [0, 1, 2, 3].flatMap((row) => [0, 1].map((next) => {
          const x1 = 50 + col * 70, y1 = 22 + row * 18, x2 = 120 + next * 70, y2 = 40 + next * 18;
          return <path key={`e${col}-${row}-${next}`} d={`M${x1} ${y1} L${x2} ${y2}`} opacity={0.3} />;
        })))}
        {[0, 1, 2].flatMap((col) => [0, 1, 2, 3].map((row) => <circle key={`n${col}-${row}`} cx={50 + col * 70} cy={22 + row * 18} r="5" fill={stroke} opacity={col === 1 ? 0.75 : 0.45} />))}
      </g>
    </svg>
  );
  if (kind === "layout") return (
    <svg viewBox="0 0 240 96" className="h-full w-full" aria-hidden="true" opacity="0.5">
      <g stroke={stroke} strokeWidth="1" fill="none" opacity="0.55">
        <rect x="24" y="16" width="192" height="64" rx="4" />
        <path d="M24 32 H216" />
        <rect x="36" y="42" width="60" height="28" rx="2" opacity="0.7" />
        <rect x="106" y="42" width="44" height="28" rx="2" opacity="0.5" />
        <rect x="160" y="42" width="44" height="28" rx="2" opacity="0.35" />
        <circle cx="34" cy="24" r="2.5" fill={stroke} />
        <circle cx="44" cy="24" r="2.5" fill={stroke} opacity="0.6" />
      </g>
    </svg>
  );
  return (
    <svg viewBox="0 0 240 96" className="h-full w-full" aria-hidden="true" opacity="0.55">
      {[0, 1, 2].map((r) => [0, 1, 2, 3].map((c) => (
        <rect key={`${r}-${c}`} x={40 + c * 44 - r * 10} y={16 + r * 26} width="40" height="18"
          fill="none" stroke={stroke} strokeWidth="1" opacity={0.55 - r * 0.15} />
      )))}
    </svg>
  );
}

const STATUS_STYLE: Record<string, string> = {
  NEW: "border-[var(--blue)] text-[var(--blue)] bg-[var(--blue-soft)]",
  "NOT STARTED": "border-[var(--border-strong)] text-[var(--text-3)]",
  "IN PROGRESS": "border-[var(--blue)] text-[var(--blue)]",
  COMPLETED: "border-[#5DD39E] text-[#5DD39E]",
  UPDATED: "border-[#F2C94C] text-[#F2C94C]",
};

/* ═══════════════════ ACADEMY ═══════════════════ */

export default function CoursesTab({ param, onNavigate }: { param?: string | null; onNavigate?: (tab: string) => void }) {
  const academy = useAcademy();
  const courses = visibleCourses();
  const [view, setView] = useState<View>({ kind: "library" });
  const [chip, setChip] = useState<Chip>("all");
  const [subject, setSubject] = useState("All");
  const [difficulty, setDifficulty] = useState("All");
  const [duration, setDuration] = useState("All");
  const [query, setQuery] = useState("");
  const [saved, setSaved] = useState<string[]>([]);
  const [certCourse, setCertCourse] = useState<Course | null>(null);

  /* deep link: /dashboard/user/courses/<courseId> opens its journey */
  useEffect(() => {
    if (!param || param === "continue") return;
    if (courses.some((c) => c.id === param)) setView({ kind: "journey", courseId: param });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [param]);

  /* "Continue Learning" nav entry jumps straight into the current lesson */
  useEffect(() => {
    if (param !== "continue") return;
    const inProgress = courses.find((c) => academy.courseProgress(c).status === "IN PROGRESS");
    const target = inProgress ?? courses.find((c) => academy.courseProgress(c).status !== "COMPLETED") ?? courses[0];
    const cur = academy.currentLessonOf(target);
    if (cur) setView({ kind: "lesson", courseId: target.id, m: cur.moduleIndex, l: cur.lessonIndex });
    else setView({ kind: "library" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [param]);

  const st = academy.stats;
  const overall = Math.round(courses.reduce((s, c) => s + academy.courseProgress(c).percent, 0) / courses.length);

  const featured = useMemo(() => {
    const inProgress = courses.find((c) => academy.courseProgress(c).status === "IN PROGRESS");
    if (inProgress) return inProgress;
    return courses.find((c) => c.recommended) ?? courses[0];
  }, [courses, academy]);

  const visible = useMemo(() => courses.filter((c) => {
    const p = academy.courseProgress(c);
    if (chip === "recommended" && !c.recommended && c.updated) return false;
    if (chip === "recommended" && !c.recommended) return false;
    if (chip === "in-progress" && p.status !== "IN PROGRESS") return false;
    if (chip === "not-started" && p.status !== "NOT STARTED") return false;
    if (chip === "completed" && p.status !== "COMPLETED") return false;
    if (chip === "saved" && !saved.includes(c.id)) return false;
    if (subject !== "All" && c.subject !== subject) return false;
    if (difficulty !== "All" && c.difficulty !== difficulty) return false;
    if (duration === "short" && c.estimatedHours > 10) return false;
    if (duration === "long" && c.estimatedHours <= 10) return false;
    if (query && !`${c.title} ${c.description} ${c.subject}`.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  }), [courses, chip, subject, difficulty, duration, query, saved, academy]);

  /* ── lesson view ── */
  if (view.kind === "lesson") {
    const course = courses.find((c) => c.id === view.courseId)!;
    const mod = course.modules[view.m];
    const lesson = mod?.lessons[view.l];
    if (course && mod && lesson) {
      return (
        <LessonStudio
          course={course} lesson={lesson} moduleTitle={mod.title}
          moduleIndex={view.m} lessonIndex={view.l}
          onExit={() => setView({ kind: "journey", courseId: course.id })}
          onGoLesson={(m, l) => setView({ kind: "lesson", courseId: course.id, m, l })}
        />
      );
    }
  }

  /* ── journey view ── */
  if (view.kind === "journey") {
    const course = courses.find((c) => c.id === view.courseId)!;
    const p = academy.courseProgress(course);
    const current = academy.currentLessonOf(course);
    const completed = p.status === "COMPLETED";

    return (
      <div className="mx-auto max-w-[1180px] pb-14">
        <button onClick={() => setView({ kind: "library" })} className="mono-label inline-flex items-center gap-2 transition-colors hover:text-[var(--blue)]">
          <ArrowLeft className="h-3 w-3" /> The Academy
        </button>

        {/* intro */}
        <header className="mt-4 grid gap-6 border-b border-[var(--border)] pb-7 lg:grid-cols-[minmax(0,1fr)_320px]">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="mono-label text-[var(--blue)]">{course.subject} · {course.difficulty}</span>
              <span className={cn("clip-oct-sm border px-2 py-0.5 font-mono text-[9.5px] font-bold", STATUS_STYLE[completed ? "COMPLETED" : p.status])}>
                {completed ? "COMPLETED" : p.status}
              </span>
            </div>
            <h1 className="display mt-2 text-3xl font-bold uppercase leading-[1.03] tracking-tight sm:text-[2.5rem]">{course.title}</h1>
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-[var(--text-2)]">{course.description}</p>

            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div><p className="mono-label mb-2 text-[9px]">Learning objectives</p>
                <ul className="space-y-1.5">{course.objectives.map((o) => <li key={o} className="flex gap-2 text-[12.5px] text-[var(--text-2)]"><CheckIcon className="mt-0.5 h-3 w-3 shrink-0 text-[var(--blue)]" />{o}</li>)}</ul></div>
              <div><p className="mono-label mb-2 text-[9px]">Skills you will acquire</p>
                <div className="flex flex-wrap gap-1.5">{course.skills.map((s) => <span key={s} className="clip-oct-sm border border-[var(--border-strong)] bg-[var(--surface-2)] px-2.5 py-1 font-mono text-[10.5px] text-[var(--text-2)]">{s}</span>)}</div></div>
            </div>
          </div>

          <aside className="space-y-4">
            <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
              <dl className="grid grid-cols-2 gap-3 font-mono text-[10.5px]">
                {[["Patron", course.patron.split(" ·")[0]], ["Level", course.level],
                  ["Duration", `${course.estimatedHours} hours`], ["Sub-courses", `${course.modules.length}`],
                  ["Lessons", `${p.total}`], ["Points", `${course.points} XP`]].map(([k, v]) => (
                  <div key={k}><dt className="text-[var(--text-3)]">{k}</dt><dd className="mt-0.5 text-[var(--text)]">{v}</dd></div>
                ))}
              </dl>
              <div className="mt-4">
                <div className="flex justify-between font-mono text-[11px]"><span className="text-[var(--text-2)]">Overall progress</span><span className="text-[var(--blue)]">{p.percent}%</span></div>
                <div className="mt-1.5 h-1.5 overflow-hidden bg-[var(--border)]"><div className="h-full bg-[var(--blue)] shadow-[0_0_8px_var(--glow)] transition-all duration-700" style={{ width: `${p.percent}%` }} /></div>
                <p className="mt-1.5 font-mono text-[10px] text-[var(--text-3)]">{p.done} of {p.total} lessons complete</p>
              </div>

              <button
                onClick={() => { if (current) { academy.beginCourse(course.id); setView({ kind: "lesson", courseId: course.id, m: current.moduleIndex, l: current.lessonIndex }); } }}
                disabled={!current}
                className="btn-shell btn-primary-shell btn-shell-md mt-4 w-full disabled:opacity-40"
              >
                <span className="btn-core">
                  {completed ? "Review course" : p.status === "NOT STARTED" ? "Begin course" : "Continue learning"} <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </button>

              {completed && (
                <button onClick={() => setCertCourse(course)} className="comm-button mt-2 w-full justify-center">
                  <GraduationCapIcon className="h-3.5 w-3.5" />View certificate
                </button>
              )}
            </div>
            <p className="font-mono text-[10px] leading-relaxed text-[var(--text-3)]">
              Patrons assemble this course from CodeQuest course materials. Published content only — drafts never reach this page.
            </p>
          </aside>
        </header>

        {/* ── learning map ── */}
        <section className="mt-8">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="mono-label text-[var(--blue)]">Sub-course progression</p>
              <h2 className="display mt-1 text-xl font-bold uppercase tracking-tight">Your learning pathway</h2>
            </div>
            <p className="font-mono text-[10.5px] text-[var(--text-3)]">Complete each stage to unlock the next · revisiting completed stages is always allowed</p>
          </div>

          <div className="relative mt-6 pl-4 sm:pl-8">
            <div className="absolute bottom-6 left-[27px] top-6 w-px bg-[var(--border)] sm:left-[35px]" aria-hidden="true" />
            <div className="space-y-5">
              {course.modules.map((mod, mi) => {
                const state = academy.moduleState(course, mi);
                const prog = academy.moduleProgress(course, mod.id);
                const prev = course.modules[mi - 1];
                return (
                  <div key={mod.id} className="relative">
                    <div className="flex gap-4 sm:gap-6">
                      {/* node */}
                      <div className="relative z-10 shrink-0">
                        <div className={cn(
                          "clip-oct-sm p-px transition-all duration-300",
                          state === "completed" ? "bg-[var(--blue)] [filter:drop-shadow(0_0_10px_var(--glow))]"
                            : state === "current" ? "bg-[var(--blue)]/70" : "bg-[var(--border-strong)]"
                        )}>
                          <div className={cn(
                            "clip-oct-sm flex h-11 w-11 items-center justify-center font-mono text-[12px] font-bold",
                            state === "completed" ? "bg-[var(--blue)] text-white"
                              : state === "current" ? "bg-[var(--surface-2)] text-[var(--blue)]" : "bg-[var(--surface-solid)] text-[var(--text-3)]"
                          )}>
                            {state === "completed" ? <CheckIcon className="h-5 w-5" /> : state === "locked" ? <LockIcon className="h-4 w-4" /> : String(mi + 1).padStart(2, "0")}
                          </div>
                        </div>
                        {state === "current" && (
                          <span aria-hidden="true" className="pulse-ring absolute inset-0 border border-[var(--blue)] [clip-path:polygon(7px_0,calc(100%-7px)_0,100%_7px,100%_calc(100%-7px),calc(100%-7px)_100%,7px_100%,0_calc(100%-7px),0_7px)]" />
                        )}
                      </div>

                      {/* card */}
                      <div className={cn(
                        "min-w-0 flex-1 border bg-[var(--surface-solid)] p-4 transition-all duration-300 sm:p-5",
                        state === "current" ? "border-[var(--blue)] shadow-[0_0_24px_rgba(77,156,255,0.14)]"
                          : state === "locked" ? "border-dashed border-[var(--border)] opacity-70"
                          : "border-[var(--border)]"
                      )}>
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="mono-label text-[9px]">Stage {String(mi + 1).padStart(2, "0")}</span>
                            {state === "current" && <span className="clip-oct-sm bg-[var(--blue)] px-1.5 py-0.5 font-mono text-[9px] font-bold text-white">CONTINUE HERE</span>}
                            {state === "completed" && <span className="clip-oct-sm border border-[#5DD39E] px-1.5 py-0.5 font-mono text-[9px] text-[#5DD39E]">COMPLETE</span>}
                          </div>
                          <span className="font-mono text-[10px] text-[var(--text-3)]">{prog.done}/{prog.total} lessons</span>
                        </div>

                        <h3 className="display mt-2 text-base font-bold tracking-tight">{mod.title}</h3>
                        <p className="mt-1 text-[12.5px] leading-relaxed text-[var(--text-2)]">{mod.summary}</p>

                        <ul className="mt-3 space-y-1.5">
                          {mod.lessons.map((l, li) => {
                            const done = academy.isLessonComplete(l.id);
                            const stageLocked = state === "locked";
                            return (
                              <li key={l.id}>
                                <button
                                  disabled={stageLocked}
                                  onClick={() => { academy.beginCourse(course.id); setView({ kind: "lesson", courseId: course.id, m: mi, l: li }); }}
                                  className={cn("flex w-full items-center gap-2.5 border px-2.5 py-2 text-left text-[12.5px] transition-colors",
                                    stageLocked ? "cursor-not-allowed border-[var(--border)] opacity-60" : "border-[var(--border)] hover:border-[var(--blue)] hover:bg-[var(--surface-hover)]")}
                                >
                                  <span className={cn("clip-oct-sm flex h-4.5 w-4.5 items-center justify-center font-mono text-[9px]",
                                    done ? "bg-[#5DD39E] text-black" : stageLocked ? "border border-[var(--border-strong)] text-[var(--text-3)]" : "bg-[var(--blue-soft)] text-[var(--blue)]")}>
                                    {done ? "✓" : li + 1}
                                  </span>
                                  <span className={cn("min-w-0 flex-1 truncate", done && "text-[var(--text-3)] line-through")}>{l.title}</span>
                                  <span className="font-mono text-[9.5px] text-[var(--text-3)]">{l.minutes}m</span>
                                </button>
                              </li>
                            );
                          })}
                        </ul>

                        {state === "locked" && (
                          <p className="mt-3 flex items-center gap-2 font-mono text-[10.5px] text-[#F2C94C]">
                            <LockIcon className="h-3 w-3" />
                            {prev ? `Complete "${prev.title}" to unlock this stage.` : "This stage is not available yet."}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </div>
    );
  }

  /* ═══════════ LIBRARY ═══════════ */
  return (
    <div className="mx-auto max-w-[1380px] space-y-7 pb-12">
      {/* header */}
      <header className="flex flex-col gap-5 border-b border-[var(--border)] pb-6 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="mono-label flex items-center gap-2 text-[var(--blue)]">
            <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />LEARN / THE ACADEMY
          </p>
          <h1 className="display mt-2 text-3xl font-bold uppercase leading-[1.03] tracking-tight sm:text-[2.6rem]">Your next skill starts with <span className="text-[var(--blue)]">your next lesson.</span></h1>
          <p className="mt-2 text-sm text-[var(--text-2)]">Learn the fundamentals. Master the craft. Build your future.</p>
        </div>
        <dl className="grid grid-cols-3 gap-x-5 gap-y-3 lg:grid-cols-3">
          {[["Overall progress", `${overall}%`], ["Streak", `${st.streakDays}d`], ["Points", st.points.toLocaleString()],
            ["Completed", `${st.completedCourses}/${st.courses}`], ["In progress", String(st.inProgress)], ["Lessons", String(st.lessons)]].map(([k, v]) => (
            <div key={k} className="border-l border-[var(--border-strong)] pl-3">
              <dt className="mono-label text-[9px]">{k}</dt>
              <dd className="display mt-1 text-lg font-bold">{v}</dd>
            </div>
          ))}
        </dl>
      </header>

      {/* featured */}
      {(() => {
        const p = academy.courseProgress(featured);
        return (
          <RevealBand>
            <button onClick={() => setView({ kind: "journey", courseId: featured.id })}
              className="group relative block w-full overflow-hidden border border-[var(--blue)]/45 bg-[var(--surface-solid)] p-5 text-left transition-all duration-300 hover:-translate-y-0.5 sm:p-6">
              <span className="pointer-events-none absolute inset-y-0 right-0 w-1/2 text-[var(--blue)] opacity-[0.14] transition-opacity duration-500 group-hover:opacity-[0.22]">
                <SubjectPattern kind={featured.pattern} />
              </span>
              <div className="relative max-w-2xl">
                <p className="mono-label flex items-center gap-2 text-[var(--blue)]">
                  <SparklesIcon className="h-3 w-3" />
                  {featured.recommended ? "RECOMMENDED BY YOUR PATRON" : "FEATURED · PICK UP WHERE YOU LEFT OFF"}
                </p>
                <h2 className="display mt-2 text-xl font-bold tracking-tight sm:text-2xl">{featured.title}</h2>
                <p className="mt-1.5 text-[13px] leading-relaxed text-[var(--text-2)]">{featured.description}</p>
                <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 font-mono text-[10.5px] text-[var(--text-3)]">
                  <span>{p.percent}% complete</span><span>{featured.modules.length} stages</span><span>{featured.estimatedHours}h</span><span className="text-[var(--blue)]">{featured.points} XP</span>
                </div>
                <div className="mt-3 h-1 w-full max-w-md overflow-hidden bg-[var(--border)]"><div className="h-full bg-[var(--blue)] shadow-[0_0_8px_var(--glow)]" style={{ width: `${p.percent}%` }} /></div>
                <span className="mt-4 inline-flex items-center gap-1.5 font-display text-[12.5px] font-semibold text-[var(--blue)]">
                  {p.status === "NOT STARTED" ? "Begin course" : p.status === "COMPLETED" ? "Review course" : "Continue learning"} <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </button>
          </RevealBand>
        );
      })()}

      {/* toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-1 flex-wrap gap-1.5">
          {([["all", "All courses"], ["recommended", "Recommended"], ["in-progress", "In progress"], ["not-started", "Not started"], ["completed", "Completed"], ["saved", "Saved"]] as [Chip, string][]).map(([id, label]) => (
            <button key={id} onClick={() => setChip(id)} aria-pressed={chip === id}
              className={cn("comm-small", chip === id && "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]")}>{label}</button>
          ))}
        </div>
        <label className="relative"><SearchIcon className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[var(--text-3)]" />
          <input className="comm-input w-48 pl-8" placeholder="Search courses…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search courses" /></label>
      </div>
      <div className="flex flex-wrap items-center gap-3 border-t border-[var(--border)] pt-3">
        {[{ label: "Subject", v: subject, set: setSubject, opts: ["All", ...Array.from(new Set(courses.map((c) => c.subject)))] },
          { label: "Difficulty", v: difficulty, set: setDifficulty, opts: ["All", "Beginner", "Intermediate", "Advanced"] },
          { label: "Duration", v: duration, set: setDuration, opts: ["All", "short", "long"] }].map((f) => (
          <label key={f.label} className="flex items-center gap-1.5">
            <span className="mono-label text-[9px]">{f.label}</span>
            <select className="comm-input w-auto" value={f.v} onChange={(e) => f.set(e.target.value)}>
              {f.opts.map((o) => <option key={o} value={o}>{o === "short" ? "≤ 10 hours" : o === "long" ? "> 10 hours" : o}</option>)}
            </select>
          </label>
        ))}
        <span className="ml-auto font-mono text-[10px] text-[var(--text-3)]">{visible.length} published course{visible.length === 1 ? "" : "s"} · drafts never shown</span>
      </div>

      {/* cards */}
      {visible.length === 0 ? (
        <div className="flex min-h-52 flex-col items-center justify-center border border-dashed border-[var(--border-strong)] p-10 text-center">
          <GraduationCapIcon className="h-7 w-7 text-[var(--text-3)]" />
          <h2 className="display mt-3 text-base font-bold uppercase">No courses match</h2>
          <p className="mt-1.5 max-w-xs text-[12.5px] text-[var(--text-2)]">Clear a filter to see everything your patrons have published.</p>
          <button className="comm-button mt-4" onClick={() => { setChip("all"); setSubject("All"); setDifficulty("All"); setDuration("All"); setQuery(""); setSaved([]); }}>Reset filters</button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {visible.map((c) => {
            const p = academy.courseProgress(c);
            const status = c.updated && p.status !== "COMPLETED" ? "UPDATED" : p.status;
            return (
              <div key={c.id} className="group relative flex flex-col overflow-hidden border border-[var(--border)] bg-[var(--surface-solid)] transition-all duration-300 hover:-translate-y-1 hover:border-[var(--blue)]"
                style={p.status === "COMPLETED" ? { borderColor: "rgba(77,156,255,0.55)" } : undefined}>
                {/* pattern header */}
                <div className="relative h-24 overflow-hidden border-b border-[var(--border)] bg-[var(--surface-2)]">
                  <span className={cn("absolute inset-0 text-[var(--blue)] transition-all duration-500 group-hover:opacity-100", p.status === "COMPLETED" ? "opacity-45" : "opacity-30")}>
                    <SubjectPattern kind={c.pattern} />
                  </span>
                  <div className="absolute inset-x-0 top-0 flex items-start justify-between p-3">
                    <span className="mono-label text-[9px] text-[var(--text-2)]">{c.subject}</span>
                    <span className={cn("clip-oct-sm border px-2 py-0.5 font-mono text-[9px] font-bold", STATUS_STYLE[status])}>{status}</span>
                  </div>
                  {p.status === "COMPLETED" && (
                    <span className="absolute bottom-2 right-3 flex items-center gap-1.5 font-mono text-[9.5px] text-[var(--blue)]">
                      <CheckIcon className="h-3 w-3" />COURSE MASTER
                    </span>
                  )}
                </div>

                <div className="flex flex-1 flex-col p-4">
                  <h3 className="display text-base font-bold leading-tight tracking-tight">{c.title}</h3>
                  <p className="mt-1.5 line-clamp-2 text-[12.5px] leading-relaxed text-[var(--text-2)]">{c.description}</p>

                  <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5 font-mono text-[10px] text-[var(--text-3)]">
                    <div className="truncate"><dt className="inline">Patron: </dt><dd className="inline text-[var(--text-2)]">{c.patron.split(" ·")[0]}</dd></div>
                    <div><dt className="inline">Level: </dt><dd className="inline text-[var(--text-2)]">{c.level}</dd></div>
                    <div><dt className="inline">Stages: </dt><dd className="inline text-[var(--text-2)]">{c.modules.length}</dd></div>
                    <div><dt className="inline">Time: </dt><dd className="inline text-[var(--text-2)]">{c.estimatedHours}h</dd></div>
                  </dl>

                  <div className="mt-auto pt-4">
                    <div className="flex items-center justify-between font-mono text-[10.5px]">
                      <span className="text-[var(--text-3)]">{p.done}/{p.total} lessons</span>
                      <span className="text-[var(--blue)]">{p.percent}% · {c.points} XP</span>
                    </div>
                    {/* illuminated progress line */}
                    <div className="mt-1.5 h-1 w-full overflow-hidden bg-[var(--border)]">
                      <div className="h-full bg-[var(--blue)] shadow-[0_0_8px_var(--glow)] transition-all duration-700" style={{ width: `${p.percent}%` }} />
                    </div>

                    <div className="mt-3 flex gap-2">
                      <button onClick={() => { setView({ kind: "journey", courseId: c.id }); }}
                        className="btn-shell btn-primary-shell btn-shell-sm flex-1">
                        <span className="btn-core">
                          {p.status === "NOT STARTED" ? "Begin" : p.status === "COMPLETED" ? "Review" : "Continue"} <ArrowRight className="h-3 w-3" />
                        </span>
                      </button>
                      <button onClick={() => setSaved((s) => s.includes(c.id) ? s.filter((x) => x !== c.id) : [...s, c.id])}
                        aria-pressed={saved.includes(c.id)} title="Save course"
                        className={cn("comm-small", saved.includes(c.id) && "border-[var(--blue)] text-[var(--blue)]")}>
                        {saved.includes(c.id) ? "Saved" : "Save"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* certificate modal */}
      {certCourse && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/75 p-4" role="dialog" aria-modal="true" aria-label="Certificate" onMouseDown={() => setCertCourse(null)}>
          <div className="panel-in w-full max-w-lg" onMouseDown={(e) => e.stopPropagation()} style={{ animation: prefersReducedMotion() ? "none" : "cq-rise .4s both" }}>
            <div className="clip-oct bg-[var(--blue)] p-px">
              <div className="clip-oct bg-[var(--surface-solid)] px-7 py-8 text-center">
                <div className="mx-auto flex w-fit gap-1.5" aria-hidden="true">
                  {Array.from({ length: 7 }).map((_, i) => (
                    <span key={i} className="clip-oct-sm h-4 w-4 bg-[var(--blue)]" style={{ animation: prefersReducedMotion() ? "none" : `cq-ignite 700ms ${i * 70}ms ease-out both` }} />
                  ))}
                </div>
                <p className="mono-label mt-6 text-[var(--blue)]">CODEQUEST ACADEMY · CERTIFICATE OF COMPLETION</p>
                <p className="mt-5 text-[13px] text-[var(--text-2)]">This certifies that</p>
                <p className="display mt-1.5 text-2xl font-bold">{currentStudentName}</p>
                <p className="mt-3 text-[13px] text-[var(--text-2)]">has completed</p>
                <p className="display mt-1 text-lg font-bold text-[var(--blue)]">{certCourse.title}</p>
                <dl className="mt-6 grid grid-cols-3 gap-3 border-y border-[var(--border)] py-4 font-mono text-[10.5px]">
                  <div><dt className="text-[var(--text-3)]">Issued</dt><dd className="mt-0.5">{certificateFor(currentStudentName, certCourse).issued}</dd></div>
                  <div><dt className="text-[var(--text-3)]">Issuer</dt><dd className="mt-0.5">{certCourse.patron.split(" ·")[0]}</dd></div>
                  <div><dt className="text-[var(--text-3)]">Reference</dt><dd className="mt-0.5 text-[var(--blue)]">{certificateFor(currentStudentName, certCourse).reference}</dd></div>
                </dl>
                <div className="mt-6 flex justify-center gap-2.5">
                  <button className="comm-button" onClick={() => window.print()}>Download PDF</button>
                  <button className="comm-button comm-button-blue" onClick={() => setCertCourse(null)}>Done</button>
                </div>
                <p className="mt-4 font-mono text-[9.5px] text-[var(--text-3)]">Download uses your browser's print-to-PDF — no server generator in this prototype.</p>
              </div>
            </div>
          </div>
        </div>
      )}
      {onNavigate && null}
    </div>
  );
}

function RevealBand({ children }: { children: React.ReactNode }) {
  return <div className="page-in">{children}</div>;
}

const currentStudentName = "Farid Bulega";

/* keep icons referenced for future lesson types */
void ClockIcon; void PlayIcon; void TrophyIcon; void CloseIcon; void SearchIcon;
