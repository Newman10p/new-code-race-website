import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { oneDark } from "@codemirror/theme-one-dark";
import { EditorView } from "@codemirror/view";
import { cn } from "../../../../utils/cn";
import type { Course, Lesson, PracSpec, Quiz } from "../../../../data/academyData";
import { useAcademy } from "../../../../lib/academyStore";
import { useTheme } from "../../../../lib/theme";
import { prefersReducedMotion } from "../../../../lib/grid";
import {
  ArrowLeft, ArrowRight, BookmarkIcon, CheckIcon, ChevronRight, CloseIcon, CodeIcon,
  PlayIcon, RefreshCwIcon, SparklesIcon, TerminalIcon,
} from "../../../../components/icons";

type Stage = "learn" | "explore" | "practise" | "test" | "complete";
const STAGES: { id: Stage; label: string }[] = [
  { id: "learn", label: "Learn" }, { id: "explore", label: "Explore" },
  { id: "practise", label: "Practise" }, { id: "test", label: "Test" }, { id: "complete", label: "Complete" },
];

const show = (v: unknown) => (v === undefined ? "undefined" : JSON.stringify(v));
const clone = <T,>(v: T): T => (v !== null && typeof v === "object" ? JSON.parse(JSON.stringify(v)) : v);

function runCode(code: string, fnName: string, args: unknown[], expected: unknown) {
  try {
    const fn = new Function(`"use strict";\n${code}\n;return typeof ${fnName} === "function" ? ${fnName} : null;`)();
    if (!fn) return { pass: false, error: `No function \`${fnName}\` found.` };
    const got = fn(...(args.map(clone) as unknown[]));
    return { pass: show(got) === show(expected), error: undefined, got };
  } catch (e) {
    return { pass: false, error: e instanceof Error ? e.message : String(e) };
  }
}

/* ═══════════ EXPLORE WIDGETS ═══════════ */

function StepsExplore({ steps, result }: { steps: { title: string; detail: string }[]; result: string }) {
  const [i, setI] = useState(0);
  return (
    <div className="border border-[var(--border)] bg-[var(--surface-2)] p-4">
      <div className="flex items-center gap-1.5" aria-hidden="true">
        {steps.map((_, k) => <span key={k} className={cn("h-1.5 flex-1 transition-colors duration-300", k <= i ? "bg-[var(--blue)]" : "bg-[var(--border)]")} />)}
      </div>
      <p className="display mt-3 text-sm font-bold">{steps[i].title}</p>
      <p className="mt-1.5 text-[13px] leading-relaxed text-[var(--text-2)]">{steps[i].detail}</p>
      {i === steps.length - 1 && (
        <p className="mt-3 border border-[#5DD39E]/40 bg-[#5DD39E]/10 p-2.5 font-mono text-[12px] text-[#5DD39E]">{result}</p>
      )}
      <div className="mt-3 flex justify-between">
        <button className="comm-small disabled:opacity-40" disabled={i === 0} onClick={() => setI((v) => v - 1)}>← Previous</button>
        <button className="comm-small disabled:opacity-40" disabled={i === steps.length - 1} onClick={() => setI((v) => v + 1)}>Next step →</button>
      </div>
    </div>
  );
}

function LabelsExplore({ map, parts, onTouched }: { map: "hardware" | "network" | "layers"; parts: { id: string; name: string; role: string }[]; onTouched: () => void }) {
  const [sel, setSel] = useState(0);
  const shapes: [string, number, number, number, number][] = map === "hardware"
    ? [["CPU", 40, 40, 90, 54], ["RAM", 150, 40, 90, 54], ["Storage", 40, 120, 90, 54], ["Bus", 150, 120, 90, 54]]
    : map === "network"
    ? [["Client", 24, 60, 84, 46], ["Router", 128, 60, 84, 46], ["DNS", 76, 130, 84, 46], ["Server", 232, 60, 84, 46]]
    : [["App", 30, 26, 100, 44], ["OS", 30, 84, 100, 44], ["Driver", 30, 142, 100, 44], ["HW", 160, 84, 100, 44]];

  return (
    <div className="border border-[var(--border)] bg-[var(--surface-2)] p-4">
      <svg viewBox="0 0 340 210" className="w-full" role="img" aria-label="Interactive diagram">
        <g stroke="var(--border-strong)" strokeWidth="1" fill="none">
          <path d={`M${shapes[0][1]} ${shapes[0][2] + 22} L${shapes[0][1]} ${shapes[1][2] + 22} L${shapes[1][1]} ${shapes[1][2] + 22}`} />
          <path d={`M${shapes[0][1] + 45} ${shapes[0][2] + 54} L${shapes[0][1] + 45} ${shapes[2][2]}`} />
        </g>
        {shapes.map((sh, k) => {
          const part = parts[k];
          const active = k === sel;
          return (
            <g key={part.id} transform={`translate(${sh[1]},${sh[2]})`} onClick={() => { setSel(k); onTouched(); }} className="cursor-pointer" tabIndex={0} onKeyDown={(e) => { if (e.key === "Enter") { setSel(k); onTouched(); } }}>
              <rect x={0} y={0} width={Number(sh[3])} height={Number(sh[4])} className={cn("transition-all duration-200", active ? "fill-[rgba(77,156,255,0.16)]" : "fill-[var(--surface-solid)]")} stroke={active ? "#4D9CFF" : "var(--border-strong)"} strokeWidth={active ? 1.6 : 1} />
              <text x={Number(sh[3]) / 2} y={Number(sh[4]) / 2 + 4} textAnchor="middle" fontSize="12" fontFamily="var(--font-mono)" fill={active ? "#4D9CFF" : "var(--text-2)"}>{part.name}</text>
            </g>
          );
        })}
      </svg>
      <div className="mt-3 border-l-2 border-[var(--blue)] pl-3">
        <p className="text-[13px] font-semibold">{parts[sel].name}</p>
        <p className="mt-0.5 text-[12.5px] leading-relaxed text-[var(--text-2)]">{parts[sel].role}</p>
      </div>
      <p className="mt-2 font-mono text-[10px] text-[var(--text-3)]">Select every component once to finish exploring.</p>
    </div>
  );
}

function SnippetExplore({ code, sample, runJs }: { code: string; sample: number; runJs: string }) {
  const [input, setInput] = useState(sample);
  const [out, setOut] = useState<string | null>(null);
  const run = () => {
    try {
      const fn = new Function(`"use strict";\n${runJs}\n;return main;`)();
      setOut(JSON.stringify(fn(input)));
    } catch (e) {
      setOut(`Error: ${e instanceof Error ? e.message : String(e)}`);
    }
  };
  return (
    <div className="border border-[var(--border)] bg-[var(--surface-2)] p-4">
      <p className="mono-label text-[9px]">{code.split("\n")[0].slice(0, 60)}</p>
      <pre className="mt-2 max-h-40 overflow-x-auto bg-[var(--surface-solid)] p-3 font-mono text-[12px] leading-relaxed text-[var(--text-2)]"><code>{code}</code></pre>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-2 font-mono text-[12px] text-[var(--text-2)]">n =
          <input type="number" value={input} onChange={(e) => setInput(Number(e.target.value))} className="comm-input w-20" />
        </label>
        <button className="comm-button" onClick={run}><PlayIcon className="h-3 w-3" />Run</button>
        {out !== null && <span className="font-mono text-[12.5px] text-[#5DD39E]">→ {out}</span>}
      </div>
      <p className="mt-2 font-mono text-[10px] text-[var(--text-3)]">Executed in your browser — this is real output, not a simulation.</p>
    </div>
  );
}

function CompareExplore({ before, after, note, onTouched }: { before: string; after: string; note: string; onTouched: () => void }) {
  const [side, setSide] = useState<"before" | "after">("before");
  useEffect(() => onTouched(), [onTouched]);
  return (
    <div className="border border-[var(--border)] bg-[var(--surface-2)] p-4">
      <div className="flex gap-1.5">
        {(["before", "after"] as const).map((s) => (
          <button key={s} onClick={() => setSide(s)} className={cn("comm-small", side === s && "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]")}>
            {s === "before" ? "Weak prompt" : "Strong prompt"}
          </button>
        ))}
      </div>
      <p className="mt-3 whitespace-pre-wrap border-l-2 pl-3 font-mono text-[12.5px] leading-relaxed" style={{ borderColor: side === "before" ? "#F2C94C" : "var(--blue)", color: "var(--text)" }}>{side === "before" ? before : after}</p>
      <p className="mt-3 border-t border-[var(--border)] pt-2.5 text-[12.5px] leading-relaxed text-[var(--text-2)]">{note}</p>
    </div>
  );
}

/* ═══════════ PRACTISE WIDGETS ═══════════ */

function CodePractise({ spec, lessonId, onPass }: { spec: Extract<PracSpec, { kind: "code" }>; lessonId: string; onPass: (accuracy: number) => void }) {
  const { theme } = useTheme();
  const [code, setCode] = useState(spec.starter);
  const [rows, setRows] = useState<{ name: string; pass: boolean; error?: string }[]>([]);
  const [ran, setRan] = useState(false);
  const { state, saveNote } = useAcademy(); // reuse store presence for autosave hook simplicity

  const run = () => {
    const results = spec.tests.map((t) => {
      const r = runCode(code, "main", t.args, t.expected);
      return { name: t.name, pass: r.pass, error: r.error };
    });
    setRows(results);
    setRan(true);
    const acc = results.filter((r) => r.pass).length / results.length;
    if (acc === 1) onPass(1);
    void state; void saveNote; void lessonId;
  };

  const extensions = useMemo(() => [
    javascript(),
    EditorView.lineWrapping,
    EditorView.theme({ "&": { fontSize: "12.5px", height: "100%" }, ".cm-scroller": { fontFamily: "var(--font-mono)", lineHeight: "1.6" } }),
  ], []);

  return (
    <div className="border border-[var(--border)] bg-[var(--surface-2)] p-4">
      <p className="mono-label text-[9px]">Write your solution in main()</p>
      <div className="mt-2 h-56 overflow-hidden border border-[var(--border)] bg-[var(--surface-solid)]">
        <CodeMirror value={code} onChange={setCode} extensions={extensions} theme={theme === "dark" ? oneDark : "light"} height="100%"
          basicSetup={{ lineNumbers: true, foldGutter: true, highlightActiveLine: true, bracketMatching: true, closeBrackets: true, indentOnInput: true, tabSize: 2 }} />
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <button className="comm-button" onClick={run}><PlayIcon className="h-3 w-3" />Run tests</button>
        <button className="comm-small" onClick={() => { setCode(spec.starter); setRows([]); setRan(false); }}><RefreshCwIcon className="h-3 w-3" />Reset</button>
        <details className="ml-auto"><summary className="cursor-pointer font-mono text-[11px] text-[var(--text-3)] hover:text-[var(--blue)]">Hint</summary>
          <p className="mt-1 max-w-md border-l-2 border-[var(--blue)] pl-2 text-[12px] text-[var(--text-2)]">{spec.hint}</p></details>
      </div>
      {ran && (
        <div className="mt-3 space-y-1">
          {rows.map((r) => (
            <div key={r.name} className={cn("flex items-center gap-2 border p-2 font-mono text-[11.5px]", r.pass ? "border-[#5DD39E]/40 text-[#5DD39E]" : "border-[#FF6B6B]/40 text-[#FF6B6B]")}>
              <span>{r.pass ? "✓" : "✕"}</span><span>{r.name}</span>{r.error && <span className="truncate">· {r.error}</span>}
            </div>
          ))}
        </div>
      )}
      <p className="mt-2 font-mono text-[10px] text-[var(--text-3)]">Executed locally in your browser against {spec.tests.length} test cases.</p>
    </div>
  );
}

function OrderPractise({ spec, onPass }: { spec: Extract<PracSpec, { kind: "order" }>; onPass: (a: number) => void }) {
  const shuffled = useMemo(() => [...spec.items].sort(() => Math.random() - 0.5), [spec]);
  const [picked, setPicked] = useState<string[]>([]);
  const [result, setResult] = useState<null | boolean>(null);
  const done = picked.length === spec.items.length;

  const pick = (item: string) => { if (result !== null || picked.includes(item)) return; const next = [...picked, item]; setPicked(next); if (next.length === spec.items.length) { const ok = next.every((v, i) => v === spec.correct[i]); setResult(ok); if (ok) onPass(1); } };

  return (
    <div className="border border-[var(--border)] bg-[var(--surface-2)] p-4">
      <p className="mono-label text-[9px]">{spec.label}</p>
      <div className="mt-3 space-y-1.5">
        {shuffled.map((item) => {
          const order = picked.indexOf(item);
          return (
            <button key={item} onClick={() => pick(item)} disabled={order >= 0 || result === true}
              className={cn("flex w-full items-center gap-3 border px-3 py-2.5 text-left text-[12.5px] transition-colors",
                order >= 0 ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--text)]" : "border-[var(--border)] bg-[var(--surface-solid)] hover:border-[var(--blue)]",
                result === false && "opacity-70")}>
              <span className={cn("clip-oct-sm flex h-5 w-5 items-center justify-center font-mono text-[10px]", order >= 0 ? "bg-[var(--blue)] text-white" : "border border-[var(--border-strong)] text-[var(--text-3)]")}>
                {order >= 0 ? order + 1 : "·"}
              </span>
              {item}
            </button>
          );
        })}
      </div>
      {result !== null && (
        <p className={cn("mt-3 border p-2.5 text-[12.5px]", result ? "border-[#5DD39E]/40 bg-[#5DD39E]/10 text-[#5DD39E]" : "border-[#FF6B6B]/40 bg-[#FF6B6B]/10 text-[#FF6B6B]")}>
          {result ? spec.success : "Not quite — the sequence is wrong. Reset and try again."}
        </p>
      )}
      {result !== null && <button className="comm-small mt-2" onClick={() => { setPicked([]); setResult(null); }}>Reset</button>}
      {result === false && <p className="mt-1 font-mono text-[10px] text-[var(--text-3)]">Each attempt is recorded; points are only awarded for a correct sequence.</p>}
      {!done && result === null && <p className="mt-2 font-mono text-[10px] text-[var(--text-3)]">Select every item in order ({picked.length}/{spec.items.length}).</p>}
    </div>
  );
}

function PromptPractise({ spec, onPass }: { spec: Extract<PracSpec, { kind: "prompt" }>; onPass: (a: number) => void }) {
  const [text, setText] = useState("");
  const [checks, setChecks] = useState<null | { label: string; pass: boolean }[]>(null);

  const evaluate = () => {
    const t = text.toLowerCase();
    const results = [
      { label: "States the audience or role", pass: spec.requires.some((k) => t.includes(k)) || /\baudience|you are|for a|to a\b/.test(t) },
      { label: "Sets a measurable limit (number or length)", pass: /\d/.test(text) },
      { label: "Specifies an output format", pass: t.includes(":") || t.includes("\n") || /list|table|bullet|paragraph|step/.test(t) },
      { label: "Substantial enough to be specific (40+ words)", pass: text.trim().split(/\s+/).length >= 40 },
    ];
    setChecks(results);
    if (results.filter((r) => r.pass).length >= 3) onPass(results.filter((r) => r.pass).length / results.length);
  };

  return (
    <div className="border border-[var(--border)] bg-[var(--surface-2)] p-4">
      <p className="mono-label text-[9px]">{spec.label}</p>
      <p className="mt-2 text-[12.5px] leading-relaxed text-[var(--text-2)]">{spec.brief}</p>
      <textarea rows={7} value={text} onChange={(e) => { setText(e.target.value); setChecks(null); }}
        placeholder="Write your prompt here…"
        className="comm-input mt-3 resize-none font-mono text-[12.5px] leading-relaxed" />
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
        <span className="font-mono text-[10.5px] text-[var(--text-3)]">{text.trim().split(/\s+/).filter(Boolean).length} words</span>
        <button className="comm-button" onClick={evaluate}><SparklesIcon className="h-3.5 w-3.5" />Evaluate prompt</button>
      </div>
      {checks && (
        <div className="mt-3 space-y-1">
          {checks.map((c) => (
            <p key={c.label} className={cn("flex items-center gap-2 font-mono text-[11.5px]", c.pass ? "text-[#5DD39E]" : "text-[#F2C94C]")}>
              <span>{c.pass ? "✓" : "○"}</span>{c.label}
            </p>
          ))}
          <p className="mt-2 border-t border-[var(--border)] pt-2 font-mono text-[10px] text-[var(--text-3)]">
            Rule-based checks, run locally. No AI model is connected to this preview, so this evaluates structure — not generated quality.
          </p>
        </div>
      )}
      <details className="mt-3"><summary className="cursor-pointer font-mono text-[11px] text-[var(--text-3)] hover:text-[var(--blue)]">See a strong example</summary>
        <p className="mt-1.5 whitespace-pre-wrap border-l-2 border-[var(--blue)] pl-3 font-mono text-[12px] leading-relaxed text-[var(--text-2)]">{spec.strong}</p></details>
    </div>
  );
}

function ChoicePractise({ spec, onPass }: { spec: Extract<PracSpec, { kind: "choice" }>; onPass: (a: number) => void }) {
  const [picked, setPicked] = useState<number | null>(null);
  const correct = picked === spec.correct;
  return (
    <div className="border border-[var(--border)] bg-[var(--surface-2)] p-4">
      <p className="mono-label text-[9px]">{spec.label}</p>
      <p className="mt-2 text-[13px] font-medium">{spec.q}</p>
      <div className="mt-3 space-y-1.5">
        {spec.options.map((o, i) => (
          <button key={o} disabled={picked !== null && correct} onClick={() => { setPicked(i); if (i === spec.correct) onPass(1); }}
            className={cn("flex w-full items-center gap-3 border px-3 py-2.5 text-left text-[12.5px] transition-colors",
              picked === i ? (i === spec.correct ? "border-[#5DD39E] bg-[#5DD39E]/10 text-[#5DD39E]" : "border-[#FF6B6B] bg-[#FF6B6B]/10 text-[#FF6B6B]") : "border-[var(--border)] bg-[var(--surface-solid)] hover:border-[var(--blue)]")}>
            <span className="font-mono text-[10px]">{String.fromCharCode(65 + i)}</span>{o}
          </button>
        ))}
      </div>
      {picked !== null && !correct && <button className="comm-small mt-3" onClick={() => setPicked(null)}>Try again</button>}
      {correct && <p className="mt-3 border border-[#5DD39E]/40 bg-[#5DD39E]/10 p-2.5 text-[12.5px] text-[#5DD39E]">{spec.success}</p>}
    </div>
  );
}

/* ═══════════ TEST ═══════════ */

function QuizStage({ quiz, onPass, completed }: { quiz: Quiz[]; onPass: (accuracy: number) => void; completed: boolean }) {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});
  const allAnswered = quiz.every((_, i) => answers[i] !== undefined);
  const allCorrect = quiz.every((q, i) => answers[i] === q.correct);

  const submit = () => {
    const acc = quiz.filter((q, i) => answers[i] === q.correct).length / quiz.length;
    setRevealed(Object.fromEntries(quiz.map((_, i) => [i, true])));
    if (acc === 1) onPass(acc);
  };

  return (
    <div className="space-y-4">
      {quiz.map((q, qi) => (
        <div key={q.q} className="border border-[var(--border)] bg-[var(--surface-2)] p-4">
          <p className="mono-label text-[9px]">Question {qi + 1} of {quiz.length}</p>
          <p className="mt-1.5 text-[13.5px] font-medium">{q.q}</p>
          <div className="mt-3 space-y-1.5">
            {q.options.map((opt, oi) => {
              const chosen = answers[qi] === oi;
              const showRight = revealed[qi] && oi === q.correct;
              const showWrong = revealed[qi] && chosen && oi !== q.correct;
              return (
                <button key={opt} onClick={() => { setAnswers((a) => ({ ...a, [qi]: oi })); setRevealed((r) => ({ ...r, [qi]: false })); }}
                  className={cn("flex w-full items-center gap-3 border px-3 py-2.5 text-left text-[12.5px] transition-colors",
                    showRight ? "border-[#5DD39E] bg-[#5DD39E]/10 text-[#5DD39E]" : showWrong ? "border-[#FF6B6B] bg-[#FF6B6B]/10 text-[#FF6B6B]" : chosen ? "border-[var(--blue)] bg-[var(--blue-soft)]" : "border-[var(--border)] bg-[var(--surface-solid)] hover:border-[var(--blue)]")}>
                  <span className="font-mono text-[10px]">{String.fromCharCode(65 + oi)}</span>{opt}
                </button>
              );
            })}
          </div>
          {revealed[qi] && <p className="mt-2 text-[12px] text-[var(--text-2)]">{q.explain}</p>}
        </div>
      ))}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <span className="font-mono text-[11px] text-[var(--text-3)]">
          {Object.keys(answers).length}/{quiz.length} answered{allCorrect && " · all correct"}
        </span>
        <button disabled={!allAnswered} onClick={submit} className="comm-button comm-button-blue disabled:opacity-40">
          {allCorrect && !completed ? "Complete lesson" : "Check answers"}
        </button>
      </div>
      {!allCorrect && allAnswered && <p className="font-mono text-[11px] text-[#F2C94C]">Some answers need another look — feedback is shown above. A perfect score unlocks completion.</p>}
    </div>
  );
}

/* ═══════════ MAIN STUDIO ═══════════ */

export default function LessonStudio({
  course, lesson, moduleTitle, moduleIndex, lessonIndex, onExit, onGoLesson,
}: {
  course: Course;
  lesson: Lesson;
  moduleTitle: string;
  moduleIndex: number;
  lessonIndex: number;
  onExit: () => void;
  onGoLesson: (moduleIndex: number, lessonIndex: number) => void;
}) {
  const academy = useAcademy();
  const alreadyDone = academy.isLessonComplete(lesson.id);
  const savedIndex = academy.state.lessonPositions[lesson.id] ?? 0;

  const [stage, setStage] = useState<Stage>(() => alreadyDone ? "complete" : (["learn", "explore", "practise", "test", "complete"] as Stage[])[Math.min(savedIndex, 3)]);
  const [unlocked, setUnlocked] = useState<Set<Stage>>(() => new Set(alreadyDone ? ["learn", "explore", "practise", "test", "complete"] : ["learn"]));
  const [practiseAccuracy, setPractiseAccuracy] = useState(0);
  const [result, setResult] = useState<null | { points: number; newlyUnlockedModule: boolean; courseCompleted: boolean; accuracy: number }>(null);
  const [leftPanel, setLeftPanel] = useState(true);
  const [rightPanel, setRightPanel] = useState(true);
  const [focus, setFocus] = useState(false);
  const [drawer, setDrawer] = useState<"nav" | "companion" | null>(null);
  const [notes, setNotes] = useState(academy.state.notes[lesson.id] ?? "");
  const [expandDef, setExpandDef] = useState(false);
  const openedAt = useRef(Date.now());

  useEffect(() => { openedAt.current = Date.now(); }, [lesson.id]);
  useEffect(() => { academy.savePosition(lesson.id, Math.max(0, (["learn", "explore", "practise", "test", "complete"] as Stage[]).indexOf(stage))); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [stage, lesson.id]);
  useEffect(() => { const t = window.setTimeout(() => academy.saveNote(lesson.id, notes), 700); return () => window.clearTimeout(t); }, [notes, lesson.id, academy]);

  const advance = (to: Stage) => { setUnlocked((s) => new Set(s).add(to)); setStage(to); };

  const onPractisePass = (acc: number) => {
    setPractiseAccuracy(acc);
    setUnlocked((s) => new Set(s).add("test"));
    window.setTimeout(() => setStage("test"), 400);
  };

  const onTestPass = (acc: number) => {
    const accuracy = (Math.min(practiseAccuracy || 1, 1) + acc) / 2;
    const r = academy.completeLesson(course, moduleIndex, lesson, accuracy);
    setUnlocked((s) => new Set(s).add("complete"));
    setResult({ ...r, accuracy: Math.round(accuracy * 100) });
    setStage("complete");
  };

  const elapsed = () => Math.max(1, Math.round((Date.now() - openedAt.current) / 60000));

  const nextLesson = useCallback((): { mi: number; li: number } | "next-module" | null => {
    const mod = course.modules[moduleIndex];
    if (lessonIndex + 1 < mod.lessons.length) return { mi: moduleIndex, li: lessonIndex + 1 };
    if (moduleIndex + 1 < course.modules.length) return "next-module";
    return null;
  }, [course, moduleIndex, lessonIndex]);

  const goNext = () => {
    const n = nextLesson();
    if (n === null) onExit();
    else if (n === "next-module") onExit();
    else onGoLesson(n.mi, n.li);
  };

  const bookmarks = Object.entries(academy.state.bookmarks).filter(([, v]) => v);

  const stageIdx = STAGES.findIndex((s) => s.id === stage);
  const studioKind = lesson.type === "code" ? "Programming Studio" : lesson.type === "prompt" ? "AI Prompting Studio" : lesson.type === "design" ? "System Design Studio" : "Theory Studio";

  const Navigator = (
    <div className="flex h-full flex-col bg-[var(--sidebar)]">
      <div className="flex items-start justify-between border-b border-[var(--border)] p-3">
        <div className="min-w-0">
          <p className="mono-label text-[9px]">{studioKind}</p>
          <p className="display mt-0.5 truncate text-[13px] font-bold">{course.title}</p>
          <p className="mt-0.5 truncate font-mono text-[10.5px] text-[var(--text-3)]">{moduleTitle}</p>
        </div>
        <button onClick={() => setLeftPanel(false)} aria-label="Collapse navigator" className="hidden text-[var(--text-3)] hover:text-[var(--text)] lg:block"><ChevronRight className="h-4 w-4" /></button>
      </div>

      <div className="flex-1 overflow-y-auto p-3">
        <p className="mono-label mb-2 text-[9px]">Stages</p>
        <ol className="mb-4 space-y-1">
          {STAGES.map((s, i) => (
            <li key={s.id}>
              <button onClick={() => unlocked.has(s.id) && setStage(s.id)} disabled={!unlocked.has(s.id)}
                className={cn("flex w-full items-center gap-2 border px-2.5 py-1.5 text-left font-mono text-[11px] transition-colors",
                  stage === s.id ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]" : unlocked.has(s.id) ? "border-transparent text-[var(--text-2)] hover:border-[var(--border)]" : "border-transparent text-[var(--text-3)] opacity-55")}>
                <span className={cn("clip-oct-sm flex h-4 w-4 items-center justify-center text-[8px]",
                  (s.id === "complete" ? alreadyDone : unlocked.has(s.id)) && i < stageIdx ? "bg-[#5DD39E] text-black" : stage === s.id ? "bg-[var(--blue)] text-white" : "border border-[var(--border-strong)]")}>
                  {i < stageIdx || (s.id === "complete" && alreadyDone) ? "✓" : i + 1}
                </span>
                {s.label}
              </button>
            </li>
          ))}
        </ol>

        <p className="mono-label mb-2 text-[9px]">Lessons in this module</p>
        <ul className="space-y-1">
          {course.modules[moduleIndex].lessons.map((l, i) => {
            const done = academy.isLessonComplete(l.id);
            return (
              <li key={l.id}>
                <button onClick={() => onGoLesson(moduleIndex, i)} className={cn("flex w-full items-center gap-2 border px-2.5 py-2 text-left text-[12px] transition-colors",
                  i === lessonIndex ? "border-[var(--blue)] bg-[var(--blue-soft)]" : "border-transparent hover:bg-[var(--surface-2)]")}>
                  <span className={cn("clip-oct-sm flex h-4 w-4 shrink-0 items-center justify-center text-[8px]", done ? "bg-[#5DD39E] text-black" : "border border-[var(--border-strong)] text-[var(--text-3)]")}>{done ? "✓" : i + 1}</span>
                  <span className={cn("truncate", done && "text-[var(--text-3)]")}>{l.title}</span>
                </button>
              </li>
            );
          })}
        </ul>

        <p className="mono-label mb-2 mt-4 text-[9px]">Modules</p>
        <ul className="space-y-1">
          {course.modules.map((m, i) => {
            const st = academy.moduleState(course, i);
            const p = academy.moduleProgress(course, m.id);
            return (
              <li key={m.id}>
                <button onClick={() => { if (st !== "locked") onGoLesson(i, 0); }} className={cn("flex w-full items-center gap-2 border px-2.5 py-2 text-left text-[11.5px] transition-colors",
                  st === "locked" ? "border-dashed border-[var(--border)] text-[var(--text-3)] opacity-70" : i === moduleIndex ? "border-[var(--blue)] text-[var(--blue)]" : "border-transparent text-[var(--text-2)] hover:bg-[var(--surface-2)]")}>
                <span>{st === "locked" ? "🔒" : st === "completed" ? "✓" : "●"}</span>
                <span className="truncate">{m.title}</span>
                <span className="ml-auto font-mono text-[9.5px]">{p.done}/{p.total}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      <div className="flex gap-2 border-t border-[var(--border)] p-2.5">
        <button disabled={lessonIndex === 0 && moduleIndex === 0} onClick={() => lessonIndex > 0 ? onGoLesson(moduleIndex, lessonIndex - 1) : onGoLesson(moduleIndex - 1, course.modules[moduleIndex - 1].lessons.length - 1)}
          className="comm-small flex-1 disabled:opacity-40">← Previous</button>
        <button onClick={goNext} className="comm-small flex-1">Next →</button>
      </div>
    </div>
  );

  const Companion = (
    <div className="flex h-full flex-col overflow-y-auto bg-[var(--sidebar)] p-3.5">
      <div className="flex items-center justify-between">
        <p className="mono-label text-[9px]">Lesson progress</p>
        <span className="font-mono text-[10px] text-[var(--text-3)]">{Math.round(((stageIdx + 1) / 5) * 100)}%</span>
      </div>
      <div className="mt-2 h-1 overflow-hidden bg-[var(--border)]"><div className="h-full bg-[var(--blue)] transition-all duration-500" style={{ width: `${((stageIdx + 1) / 5) * 100}%` }} /></div>

      <p className="mono-label mb-2 mt-5 text-[9px]">Objectives</p>
      <ul className="space-y-1.5">{lesson.objectives.map((o) => <li key={o} className="flex gap-2 text-[12px] leading-relaxed text-[var(--text-2)]"><span className="mt-1.5 h-1 w-1 shrink-0 rotate-45 bg-[var(--blue)]" />{o}</li>)}</ul>

      {lesson.definition && (
        <div className="mt-5 border border-[var(--border)] bg-[var(--surface-2)] p-3">
          <p className="mono-label text-[9px]">Key concept</p>
          <button onClick={() => setExpandDef(!expandDef)} className="mt-1.5 flex w-full items-center justify-between text-left">
            <span className="text-[12.5px] font-semibold text-[var(--blue)]">{lesson.definition.term}</span>
            <ChevronRight className={cn("h-3.5 w-3.5 transition-transform", expandDef && "rotate-90")} />
          </button>
          {expandDef && <p className="mt-1.5 text-[12px] leading-relaxed text-[var(--text-2)]">{lesson.definition.text}</p>}
        </div>
      )}

      <div className="mt-5">
        <p className="mono-label mb-1.5 text-[9px]">Your notes</p>
        <textarea rows={5} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Notes save automatically…"
          className="comm-input resize-none text-[12px]" />
        <p className="mt-1 font-mono text-[9.5px] text-[var(--text-3)]">Autosaved in this browser.</p>
      </div>

      <div className="mt-5">
        <button onClick={() => academy.toggleBookmark(lesson.id)} className={cn("comm-small w-full", academy.state.bookmarks[lesson.id] && "border-[var(--blue)] text-[var(--blue)]")}>
          <BookmarkIcon className="h-3 w-3" />{academy.state.bookmarks[lesson.id] ? "Bookmarked" : "Bookmark this lesson"}
        </button>
        {bookmarks.length > 1 && (
          <div className="mt-3"><p className="mono-label text-[9px]">Bookmarks across courses</p>
            <ul className="mt-1.5 space-y-1">{bookmarks.map(([id]) => { const l = findLesson(id); return l ? <li key={id} className="font-mono text-[10.5px] text-[var(--text-2)]">· {l.title}</li> : null; })}</ul></div>
        )}
      </div>

      <div className="mt-5 border-t border-[var(--border)] pt-4">
        <p className="mono-label mb-1.5 text-[9px]">Resources</p>
        <ul className="space-y-1 font-mono text-[10.5px] text-[var(--text-2)]">
          <li>· CodeQuest Practice Arena</li>
          <li>· {course.subject} reference sheet</li>
          <li>· Ask your patron: {course.patron.split(" ·")[0]}</li>
        </ul>
      </div>
    </div>
  );

  function findLesson(id: string) {
    for (const c of academy.state.startedCourses.length ? [course] : [course]) for (const m of c.modules) { const l = m.lessons.find((x) => x.id === id); if (l) return l; }
    return null;
  }

  return (
    <div className="fixed inset-0 z-[72] flex flex-col bg-[var(--bg)] text-[var(--text)]">
      {/* top bar */}
      <header className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-2 border-b border-[var(--border)] bg-[var(--sidebar)] px-3 py-2 sm:px-4">
        <button onClick={onExit} className="clip-oct-sm flex items-center gap-1.5 border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1.5 font-mono text-[11px] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--blue)]">
          <ArrowLeft className="h-3 w-3" /><span className="hidden sm:inline">Course</span>
        </button>
        <div className="min-w-0 flex-1">
          <p className="mono-label text-[9px]">{studioKind} · {moduleTitle}</p>
          <h1 className="display truncate text-[13.5px] font-bold">{lesson.title}</h1>
        </div>
        <span className={cn("font-mono text-[10.5px]", academy.saveState === "saving" ? "text-[#F2C94C]" : academy.saveState === "failed" || academy.saveState === "offline" ? "text-[#FF6B6B]" : "text-[#5DD39E]")}>
          {academy.saveState === "saving" ? "Saving…" : academy.saveState === "failed" ? "Save failed — retry" : academy.saveState === "offline" ? "Offline — pending" : "Saved"}
        </span>
        <button onClick={() => setFocus(!focus)} className="comm-small" title="Focus mode">{focus ? "Exit focus" : "Focus"}</button>
        <button onClick={() => setDrawer("companion")} className="comm-small lg:hidden">Companion</button>
      </header>

      {/* stage rail */}
      <div className="flex shrink-0 items-center gap-1 overflow-x-auto border-b border-[var(--border)] bg-[var(--surface-solid)] px-3 py-1.5">
        {STAGES.map((s, i) => (
          <button key={s.id} onClick={() => unlocked.has(s.id) && setStage(s.id)} disabled={!unlocked.has(s.id)}
            className={cn("flex shrink-0 items-center gap-1.5 border px-2.5 py-1 font-mono text-[10px] uppercase transition-colors",
              stage === s.id ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]" : unlocked.has(s.id) ? "border-transparent text-[var(--text-3)] hover:text-[var(--text)]" : "border-dashed border-[var(--border)] text-[var(--text-3)] opacity-50")}>
            <span className={cn("h-1.5 w-1.5 rotate-45", i < stageIdx ? "bg-[#5DD39E]" : stage === s.id ? "bg-[var(--blue)]" : "bg-[var(--border-strong)]")} />
            {s.label}
          </button>
        ))}
        <button onClick={() => { setLeftPanel((v) => !v); setRightPanel((v) => !v); }} className="comm-small ml-auto hidden lg:block">
          {leftPanel && rightPanel ? "Collapse panels" : "Show panels"}
        </button>
      </div>

      {/* body */}
      <div className="flex min-h-0 flex-1">
        {leftPanel && !focus && <aside className="hidden w-[260px] shrink-0 border-r border-[var(--border)] lg:block">{Navigator}</aside>}
        <button onClick={() => setDrawer("nav")} aria-label="Open navigator" className="hidden w-8 items-center justify-center border-r border-[var(--border)] bg-[var(--sidebar)] text-[var(--text-3)] hover:text-[var(--blue)] lg:hidden lg:flex">
          {leftPanel && !focus ? null : <ChevronRight className="h-3.5 w-3.5 rotate-180" />}
        </button>

        {/* canvas */}
        <main className="min-w-0 flex-1 overflow-y-auto">
          <div key={stage} className="question-in mx-auto w-full max-w-3xl px-4 py-6 sm:px-6">
            {stage === "learn" && (
              <div className="space-y-5">
                <div>
                  <p className="mono-label text-[var(--blue)]">Learn · {lesson.minutes} min · {lesson.points} points</p>
                  <h2 className="display mt-2 text-2xl font-bold tracking-tight">{lesson.title}</h2>
                </div>
                <p className="text-[14.5px] leading-7 text-[var(--text)]">{lesson.intro}</p>
                {lesson.callout && (
                  <div className="border-l-2 border-[var(--blue)] bg-[var(--blue-soft)] p-4">
                    <p className="mono-label text-[9px] text-[var(--blue)]">Remember</p>
                    <p className="mt-1 text-[13px] leading-relaxed text-[var(--text)]">{lesson.callout}</p>
                  </div>
                )}
                <div className="flex flex-wrap gap-2">
                  <button onClick={() => advance("explore")} className="btn-shell btn-primary-shell btn-shell-md"><span className="btn-core">Continue to explore <ArrowRight className="h-3.5 w-3.5" /></span></button>
                </div>
              </div>
            )}

            {stage === "explore" && (
              <div className="space-y-4">
                <div>
                  <p className="mono-label text-[var(--blue)]">Explore</p>
                  <h2 className="display mt-2 text-xl font-bold">See it in motion</h2>
                </div>
                {lesson.explore.kind === "steps" && <StepsExplore steps={lesson.explore.steps} result={lesson.explore.result} />}
                {lesson.explore.kind === "labels" && <LabelsExplore map={lesson.explore.map} parts={lesson.explore.parts} onTouched={() => {}} />}
                {lesson.explore.kind === "snippet" && <SnippetExplore code={lesson.explore.code} sample={lesson.explore.sample} runJs={lesson.explore.runJs} />}
                {lesson.explore.kind === "compare" && <CompareExplore before={lesson.explore.before} after={lesson.explore.after} note={lesson.explore.note} onTouched={() => {}} />}
                <button onClick={() => advance("practise")} className="btn-shell btn-primary-shell btn-shell-md"><span className="btn-core">Continue to practise <ArrowRight className="h-3.5 w-3.5" /></span></button>
                <p className="font-mono text-[10px] text-[var(--text-3)]">Moving forward keeps your place — you can always step back.</p>
              </div>
            )}

            {stage === "practise" && (
              <div className="space-y-4">
                <div>
                  <p className="mono-label text-[var(--blue)]">Practise</p>
                  <h2 className="display mt-2 text-xl font-bold">Your turn</h2>
                </div>
                {lesson.practise.kind === "code" && <CodePractise key={lesson.id} spec={lesson.practise} lessonId={lesson.id} onPass={onPractisePass} />}
                {lesson.practise.kind === "order" && <OrderPractise spec={lesson.practise} onPass={onPractisePass} />}
                {lesson.practise.kind === "prompt" && <PromptPractise spec={lesson.practise} onPass={onPractisePass} />}
                {lesson.practise.kind === "choice" && <ChoicePractise spec={lesson.practise} onPass={onPractisePass} />}
                <button onClick={() => setStage("learn")} className="comm-small">← Back to learn</button>
              </div>
            )}

            {stage === "test" && (
              <div className="space-y-4">
                <div>
                  <p className="mono-label text-[var(--blue)]">Test</p>
                  <h2 className="display mt-2 text-xl font-bold">Knowledge check</h2>
                  <p className="mt-1 text-[13px] text-[var(--text-2)]">Answer every question correctly to complete this lesson. Feedback appears after you check.</p>
                </div>
                <QuizStage key={lesson.id} quiz={lesson.quiz} completed={alreadyDone} onPass={onTestPass} />
                <button onClick={() => setStage("practise")} className="comm-small">← Back to practise</button>
              </div>
            )}

            {stage === "complete" && (
              <div className="space-y-5">
                {(result || alreadyDone) ? (
                  <>
                    <div className="flex gap-1.5" aria-hidden="true">
                      {Array.from({ length: 7 }).map((_, i) => (
                        <span key={i} className="clip-oct-sm h-7 w-7 bg-[var(--blue)]" style={{ animation: prefersReducedMotion() ? "none" : `cq-ignite 700ms ${i * 80}ms ease-out both` }} />
                      ))}
                    </div>
                    <p className="mono-label text-[#5DD39E]">LESSON COMPLETE</p>
                    <h2 className="display text-3xl font-bold uppercase tracking-tight">{lesson.title}</h2>
                    <dl className="grid grid-cols-2 gap-4 border-y border-[var(--border)] py-4 sm:grid-cols-4">
                      {[["Points", `+${result?.points ?? lessonPointsSafe(academy, lesson.id)}`], ["Accuracy", `${result?.accuracy ?? 100}%`], ["Time", `${elapsed()} min`], ["Status", "Recorded"]].map(([k, v]) => (
                        <div key={k}><dt className="mono-label text-[9px]">{k}</dt><dd className="display mt-1 text-lg font-bold text-[var(--text)]">{v}</dd></div>
                      ))}
                    </dl>
                    {result?.newlyUnlockedModule && (
                      <p className="border border-[#5DD39E]/40 bg-[#5DD39E]/10 p-3 text-[13px] text-[#5DD39E]">
                        New module unlocked: <strong>{course.modules[moduleIndex + 1]?.title}</strong>
                      </p>
                    )}
                    {result?.courseCompleted && (
                      <p className="border border-[var(--blue)]/50 bg-[var(--blue-soft)] p-3 text-[13px] text-[var(--blue)]">
                        Course completed — your certificate is available in the Academy.
                      </p>
                    )}
                    <div className="flex flex-wrap gap-2.5">
                      <button onClick={goNext} className="btn-shell btn-primary-shell btn-shell-md"><span className="btn-core">Continue to next lesson <ArrowRight className="h-3.5 w-3.5" /></span></button>
                      <button onClick={onExit} className="btn-shell btn-ghost-shell btn-shell-md"><span className="btn-core">Back to course journey</span></button>
                    </div>
                    <p className="font-mono text-[10px] text-[var(--text-3)]">Progress updated across your course, learning path and statistics.</p>
                  </>
                ) : (
                  <>
                    <p className="mono-label text-[var(--text-3)]">REVIEW MODE</p>
                    <h2 className="display text-2xl font-bold">Completed earlier</h2>
                    <p className="text-[13px] text-[var(--text-2)]">You already earned points for this lesson — reviewing does not award them again. Re-run the activities to refresh your understanding.</p>
                    <button onClick={() => { setStage("learn"); setUnlocked(new Set(["learn", "explore", "practise", "test", "complete"])); }} className="btn-shell btn-ghost-shell btn-shell-md"><span className="btn-core">Review from the start</span></button>
                  </>
                )}
              </div>
            )}
          </div>
        </main>

        {rightPanel && !focus && <aside className="hidden w-[270px] shrink-0 border-l border-[var(--border)] lg:block">{Companion}</aside>}
      </div>

      {/* mobile drawers */}
      {drawer && (
        <div className="fixed inset-0 z-[80] flex justify-end bg-black/60 lg:hidden" onClick={() => setDrawer(null)}>
          <div className="h-full w-[300px] max-w-[88vw] border-l border-[var(--border)]" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-end border-b border-[var(--border)] p-2"><button onClick={() => setDrawer(null)} aria-label="Close"><CloseIcon className="h-4 w-4" /></button></div>
            <div className="h-[calc(100%-40px)]">{drawer === "nav" ? Navigator : Companion}</div>
          </div>
        </div>
      )}
      <button onClick={() => setDrawer("nav")} aria-label="Open lesson navigator" className="fixed bottom-4 left-4 z-[76] clip-oct-sm border border-[var(--blue)] bg-[var(--surface-solid)] px-3 py-2 font-mono text-[11px] text-[var(--blue)] shadow-lg lg:hidden">
        Lessons
      </button>
    </div>
  );
}

function lessonPointsSafe(academy: ReturnType<typeof useAcademy>, id: string) {
  return academy.lessonPoints(id);
}

/* silence unused import warnings for icons used in sub-components */
void TerminalIcon; void CodeIcon; void CheckIcon;
