import { useMemo, useState } from "react";
import { cn } from "../../../utils/cn";
import { competitionById, projectCompetitions, when, type Project } from "../../../data/submissionsData";
import { judgingLock, useSubmissions } from "../../../lib/submissionStore";
import { ArrowRight, AwardIcon, GlobeIcon, LockIcon, SearchIcon, UploadCloudIcon } from "../../../components/icons";
import ProjectDetail, { MINT, VIOLET, StatusChip, judgingChip, patronChip } from "./submissions/ProjectDetail";

type Filter = "all" | "drafts" | "submitted" | "review" | "feedback" | "results" | "public";
type DetailTab = "overview" | "patron" | "judging" | "community" | "versions";

const isDraft = (p: Project) => !p.versions.some((v) => v.submittedAt);

export default function SubmissionsTab() {
  const { projects, createProject } = useSubmissions();
  const [competitionId, setCompetitionId] = useState(projectCompetitions[0].id);
  const [open, setOpen] = useState<{ id: string; tab: DetailTab } | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<"updated" | "title">("updated");

  const comp = competitionById(competitionId)!;
  const current = projects.find((p) => p.competitionId === competitionId);
  const opened = open && projects.find((p) => p.id === open.id);

  const stats = {
    submitted: projects.filter((p) => p.judging.status !== "NOT SUBMITTED").length,
    awaiting: projects.filter((p) => ["SUBMITTED", "UNDER REVIEW"].includes(p.patron.status) || ["SUBMITTED", "RECEIVED", "QUEUED FOR JUDGING", "UNDER EVALUATION", "JUDGING COMPLETED"].includes(p.judging.status)).length,
    feedback: projects.filter((p) => p.patron.feedback || p.judging.result).length,
    public: projects.filter((p) => p.showcase.published).length,
  };

  const steps = current ? [
    !isDraft(current) || current.files.length > 0,
    !comp.config.patron.enabled || !comp.config.patron.required || current.patron.status === "REVIEW COMPLETED",
    current.judging.status !== "NOT SUBMITTED",
  ] : [false, false, false];

  const visible = useMemo(() => projects
    .filter((p) => {
      if (filter === "drafts" && !isDraft(p)) return false;
      if (filter === "submitted" && p.judging.status === "NOT SUBMITTED") return false;
      if (filter === "review" && !["SUBMITTED", "UNDER REVIEW"].includes(p.patron.status) && !["SUBMITTED", "QUEUED FOR JUDGING", "UNDER EVALUATION"].includes(p.judging.status)) return false;
      if (filter === "feedback" && !p.patron.feedback) return false;
      if (filter === "results" && p.judging.status !== "RESULTS PUBLISHED") return false;
      if (filter === "public" && !p.showcase.published) return false;
      if (query && !`${p.title} ${competitionById(p.competitionId)?.name}`.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    })
    .sort((a, b) => (sort === "title" ? a.title.localeCompare(b.title) : new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())),
  [projects, filter, query, sort]);

  if (opened) return <ProjectDetail key={opened.id} project={opened} initialTab={open!.tab} onBack={() => setOpen(null)} />;

  const startNew = () => setOpen({ id: createProject(competitionId), tab: "overview" });
  const deadlineLeft = new Date(comp.config.judging.deadline).getTime() - Date.now();

  return (
    <div className="mx-auto max-w-[1380px] space-y-7 pb-10">
      {/* header */}
      <header className="flex flex-col gap-5 border-b border-[var(--border)] pb-6 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="mono-label flex items-center gap-2 text-[var(--blue)]"><span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />COMPETE / PROJECT REVIEW & SHOWCASE CENTRE</p>
          <h1 className="display mt-2 text-3xl font-bold uppercase leading-[1.03] tracking-tight sm:text-[2.6rem]">Project submissions</h1>
          <p className="mt-2 max-w-xl text-sm text-[var(--text-2)]">Every submission is a step from an idea to something real. Build something remarkable. Submit it. Get recognised.</p>
        </div>
        <div className="flex flex-col gap-2.5 sm:items-end">
          <label className="flex items-center gap-2"><span className="mono-label text-[9px]">Competition</span>
            <select value={competitionId} onChange={(e) => setCompetitionId(e.target.value)} className="comm-input w-auto max-w-[300px]" aria-label="Select competition">
              {projectCompetitions.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select></label>
          <p className={cn("font-mono text-[10.5px]", deadlineLeft > 0 && deadlineLeft < 3 * 86400_000 ? "text-[#F2C94C]" : "text-[var(--text-3)]")}>
            Judging deadline {when(comp.config.judging.deadline)} · {deadlineLeft > 0 ? `${Math.floor(deadlineLeft / 86400_000)}d ${Math.floor((deadlineLeft % 86400_000) / 3600_000)}h left` : "closed"}
          </p>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1" aria-label={`Submission progress ${steps.filter(Boolean).length} of 3`}>
              {["Draft", "Review", "Judging"].map((s, i) => <span key={s} title={s} className={cn("clip-oct-sm h-2 w-8 transition-colors duration-500", steps[i] ? "bg-[var(--blue)]" : "bg-[var(--border-strong)]")} />)}
            </div>
            <button onClick={startNew} className="btn-shell btn-primary-shell btn-shell-sm"><span className="btn-core"><UploadCloudIcon className="h-3.5 w-3.5" />New submission</span></button>
          </div>
        </div>
      </header>

      {/* stats */}
      <dl className="grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-4">
        {[["Projects submitted", stats.submitted], ["Awaiting review", stats.awaiting], ["Feedback received", stats.feedback], ["Public projects", stats.public]].map(([k, v]) => (
          <div key={k as string} className="border-l border-[var(--border-strong)] pl-3"><dt className="mono-label text-[9px]">{k}</dt><dd className="display mt-1 text-2xl font-bold">{v}</dd></div>
        ))}
      </dl>

      {/* three channels */}
      {!current ? (
        <div className="flex flex-col items-center border border-dashed border-[var(--border-strong)] p-10 text-center">
          <h2 className="display text-lg font-bold">No project for {comp.name} yet</h2>
          <p className="mt-1.5 text-[12.5px] text-[var(--text-2)]">Start a project to unlock its review, judging and showcase channels.</p>
          <button onClick={startNew} className="comm-button comm-button-blue mt-4">Start a project</button>
        </div>
      ) : (
        <section>
          <p className="mono-label mb-3">Channels for <span className="text-[var(--text)]">{current.title}</span></p>
          <div className="grid gap-4 lg:grid-cols-[1fr_1.35fr_1fr]">
            {/* patron */}
            <div className={cn("flex flex-col border-t-[3px] border-x border-b border-[var(--border)] bg-[var(--surface-solid)] p-5", !comp.config.patron.enabled && "opacity-60")} style={{ borderTopColor: MINT }}>
              <div className="flex items-center gap-2"><LockIcon className="h-4 w-4" /><p className="mono-label" style={{ color: MINT }}>PATRON REVIEW · PRIVATE</p></div>
              <p className="mt-2 text-[12px] text-[var(--text-2)]">Help me improve my work.</p>
              {comp.config.patron.enabled ? <>
                <div className="mt-4 flex items-center gap-2.5"><span className="clip-oct-sm flex h-8 w-8 items-center justify-center font-mono text-[11px] font-bold" style={{ background: `${MINT}22`, color: MINT }}>{comp.config.patron.patronInitials}</span>
                  <div><p className="text-[12.5px] font-semibold">{comp.config.patron.patronName}</p><p className="font-mono text-[10px] text-[var(--text-3)]">{comp.config.patron.required ? "Required" : "Optional"}</p></div></div>
                <div className="mt-3">{patronChip(current.patron.status)}</div>
                <button onClick={() => setOpen({ id: current.id, tab: "patron" })} className="comm-button mt-auto self-start" style={{ borderColor: MINT, color: MINT, marginTop: 20 }}>
                  {current.patron.feedback ? "Read feedback" : "Submit for review"} <ArrowRight className="h-3 w-3" /></button>
              </> : <p className="mt-4 text-[12px] text-[var(--text-3)]">Patron review is not offered for this competition.</p>}
            </div>

            {/* judging — most prominent */}
            <div className="arena-texture flex flex-col border border-[var(--blue)]/50 bg-[var(--surface-solid)] p-6">
              <div className="flex items-center gap-2"><AwardIcon className="h-5 w-5 text-[var(--blue)]" /><p className="mono-label text-[var(--blue)]">OFFICIAL JUDGING</p><span className="ml-auto">{judgingChip(current.judging.status)}</span></div>
              <p className="mt-2 text-[12.5px] text-[var(--text-2)]">Evaluate my work and determine my competition result.</p>
              <dl className="mt-4 grid grid-cols-3 gap-3 font-mono text-[10.5px]">
                <div><dt className="text-[var(--text-3)]">Version</dt><dd className="mt-1">{current.judging.versionNo ? `v${current.judging.versionNo}` : "—"}</dd></div>
                <div><dt className="text-[var(--text-3)]">Submitted</dt><dd className="mt-1">{current.judging.submittedAt ? when(current.judging.submittedAt) : "—"}</dd></div>
                <div><dt className="text-[var(--text-3)]">Reference</dt><dd className="mt-1">{current.judging.reference ?? "—"}</dd></div>
              </dl>
              <div className="mt-4 flex gap-1">{["SUBMITTED", "RECEIVED", "QUEUED FOR JUDGING", "UNDER EVALUATION", "JUDGING COMPLETED", "RESULTS PUBLISHED"].map((s, i, all) => {
                const reached = all.indexOf(current.judging.status) >= i;
                return <span key={s} title={s} className={cn("h-1 flex-1 transition-colors duration-700", reached ? "bg-[var(--blue)]" : "bg-[var(--border)]")} />;
              })}</div>
              {current.judging.result
                ? <p className="mt-3 text-[12.5px]">Published: <span className="font-bold text-[#5DD39E]">{current.judging.result.score}/{current.judging.result.maxScore}</span> · rank #{current.judging.result.rank}</p>
                : current.judging.status !== "NOT SUBMITTED" && <p className="mt-3 text-[11.5px] text-[var(--text-3)]">Results and judges' feedback appear here once officially published.</p>}
              <button onClick={() => setOpen({ id: current.id, tab: "judging" })} className="btn-shell btn-primary-shell btn-shell-md mt-auto self-start" style={{ marginTop: 20 }}>
                <span className="btn-core">{current.judging.status === "NOT SUBMITTED" ? "Submit to judges" : "View judging"} <ArrowRight className="h-3.5 w-3.5" /></span></button>
              {current.judging.status === "NOT SUBMITTED" && judgingLock(current) && <p className="mt-2 font-mono text-[10px] text-[#F2C94C]">{judgingLock(current)}</p>}
            </div>

            {/* showcase */}
            <div className={cn("flex flex-col border-t-[3px] border-x border-b border-[var(--border)] bg-[var(--surface-solid)] p-5", !comp.config.showcase.enabled && "opacity-60")} style={{ borderTopColor: VIOLET }}>
              <div className="flex items-center gap-2"><GlobeIcon className="h-4 w-4" /><p className="mono-label" style={{ color: VIOLET }}>COMMUNITY SHOWCASE</p></div>
              <p className="mt-2 text-[12px] text-[var(--text-2)]">Let other students experience and discuss my work.</p>
              {comp.config.showcase.enabled ? <>
                <div className="mt-4">{current.showcase.published ? <StatusChip label="PUBLISHED" tone={VIOLET} /> : <StatusChip label="NOT PUBLISHED" tone="var(--text-3)" />}</div>
                {current.showcase.published && <p className="mt-2 font-mono text-[10.5px] text-[var(--text-3)]">{current.showcase.reactions} appreciations · {current.showcase.comments.length} threads</p>}
                <button onClick={() => setOpen({ id: current.id, tab: "community" })} className="comm-button mt-auto self-start" style={{ borderColor: VIOLET, color: VIOLET, marginTop: 20 }}>
                  {current.showcase.published ? "Open showcase" : "Publish project"} <ArrowRight className="h-3 w-3" /></button>
              </> : <p className="mt-4 text-[12px] text-[var(--text-3)]">Public sharing is not enabled for this competition by the setter.</p>}
            </div>
          </div>
        </section>
      )}

      {/* my projects */}
      <section>
        <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--border)] pb-3">
          <h2 className="display text-xl font-bold uppercase tracking-tight">My projects</h2>
          <div className="flex flex-wrap items-center gap-2">
            <label className="relative"><SearchIcon className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[var(--text-3)]" />
              <input className="comm-input w-52 pl-8" placeholder="Search projects…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search projects" /></label>
            <select className="comm-input w-auto" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} aria-label="Sort projects"><option value="updated">Last updated</option><option value="title">Title A–Z</option></select>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {([["all", "All projects"], ["drafts", "Drafts"], ["submitted", "Submitted"], ["review", "Under review"], ["feedback", "Feedback received"], ["results", "Results published"], ["public", "Publicly shared"]] as [Filter, string][]).map(([id, label]) => (
            <button key={id} onClick={() => setFilter(id)} className={cn("comm-small", filter === id && "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]")}>{label}</button>
          ))}
        </div>

        <div className="mt-3 divide-y divide-[var(--border)] border border-[var(--border)] bg-[var(--surface-solid)]">
          {visible.map((p) => {
            const c = competitionById(p.competitionId)!;
            return (
              <button key={p.id} onClick={() => setOpen({ id: p.id, tab: "overview" })} className="grid w-full gap-3 p-4 text-left transition-colors hover:bg-[var(--surface-hover)] lg:grid-cols-[minmax(0,1.6fr)_auto_auto_auto_auto] lg:items-center">
                <div className="min-w-0">
                  <p className="truncate font-display text-[14px] font-semibold">{p.title}{isDraft(p) && <span className="ml-2 font-mono text-[9.5px] text-[var(--text-3)]">DRAFT</span>}</p>
                  <p className="truncate font-mono text-[10.5px] text-[var(--text-3)]">{c.name} · v{p.versions[p.versions.length - 1].no} · updated {when(p.updatedAt)}</p>
                </div>
                <div>{c.config.patron.enabled ? patronChip(p.patron.status) : <StatusChip label="NO PATRON" tone="var(--text-3)" />}</div>
                <div>{judgingChip(p.judging.status)}</div>
                <div>{p.showcase.published ? <StatusChip label="PUBLIC" tone={VIOLET} /> : <StatusChip label={c.config.showcase.enabled ? "PRIVATE" : "SHARING OFF"} tone="var(--text-3)" />}</div>
                <span className="font-mono text-[10.5px] text-[var(--blue)]">Open →</span>
              </button>
            );
          })}
          {visible.length === 0 && <p className="p-8 text-center text-[12.5px] text-[var(--text-3)]">No projects match this view.</p>}
        </div>
        <p className="mt-3 font-mono text-[10px] text-[var(--text-3)]">Frontend prototype — records are stored in this browser. Deadlines, file rules and reviewer permissions are enforced again server-side in production.</p>
      </section>
    </div>
  );
}
