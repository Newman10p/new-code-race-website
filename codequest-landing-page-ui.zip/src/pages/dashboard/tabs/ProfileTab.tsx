import { cn } from "../../../utils/cn";
import { currentStudent } from "../../../data/dashboardData";

export default function ProfileTab() {
  const badges = [
    { name: "First Blood", desc: "Solved a competitive problem in under 10 minutes", icon: "⚡", earned: true },
    { name: "7-Day Flame", desc: "Maintained daily practice consistency for 7 days", icon: "🔥", earned: true },
    { name: "Graph Wizard", desc: "Completed topological sort and Dijkstra challenges", icon: "◈", earned: true },
    { name: "Top 50 Qualifier", desc: "Ranked in the top 50 in pre-season baseline round", icon: "⬡", earned: true },
    { name: "Clean Code", desc: "100% test case pass on first test execution", icon: "✓", earned: true },
    { name: "Grand Finalist", desc: "Qualify for Season 01 Regional Finals heat", icon: "👑", earned: false },
  ];

  const skills = [
    { name: "Algorithms & Search", percent: 84 },
    { name: "Data Structures", percent: 76 },
    { name: "Python 3 Mastery", percent: 92 },
    { name: "System Architecture", percent: 68 },
    { name: "C++ Speed Execution", percent: 64 },
  ];

  return (
    <div className="space-y-6">
      {/* Profile Card Header */}
      <div className="panel clip-oct p-6">
        <div className="flex flex-col items-start gap-5 sm:flex-row sm:items-center">
          <div className="clip-oct flex h-20 w-20 shrink-0 items-center justify-center bg-[var(--blue)] font-display text-2xl font-bold text-white shadow-[0_0_24px_var(--glow)]">
            {currentStudent.avatarText}
          </div>

          <div className="min-w-0 flex-1 space-y-1">
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="display text-2xl font-bold">{currentStudent.name}</h1>
              <span className="clip-oct-sm bg-[var(--blue-soft)] px-2.5 py-0.5 font-mono text-xs font-semibold text-[var(--blue)]">
                {currentStudent.role}
              </span>
              <span className="clip-oct-sm border border-[var(--border)] px-2.5 py-0.5 font-mono text-xs text-[var(--text-3)]">
                ID: {currentStudent.studentId}
              </span>
            </div>

            <p className="text-sm text-[var(--text-2)]">
              {currentStudent.school} · {currentStudent.grade}
            </p>

            <p className="font-mono text-xs text-[var(--text-3)]">
              Season 01 Verified Competitor · Active since January 2026
            </p>
          </div>
        </div>

        {/* Level XP Bar */}
        <div className="mt-6 border-t border-[var(--border)] pt-4">
          <div className="flex items-center justify-between font-mono text-xs">
            <span className="font-semibold text-[var(--blue)]">
              Level {currentStudent.level} Explorer
            </span>
            <span className="text-[var(--text-3)]">
              {currentStudent.xp} / {currentStudent.nextLevelXp} XP (660 XP to Level 7)
            </span>
          </div>
          <div className="mt-2 h-2 w-full overflow-hidden bg-[var(--surface-2)]">
            <div
              className="h-full bg-[var(--blue)] shadow-[0_0_8px_var(--glow)]"
              style={{ width: `${(currentStudent.xp / currentStudent.nextLevelXp) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Two Columns: Badges & Skill Mastery */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Badges Collection */}
        <div className="panel clip-oct p-5">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
            <span className="font-display text-sm font-bold uppercase tracking-wide">
              Octagon Achievement Badges
            </span>
            <span className="font-mono text-xs text-[#5DD39E]">
              5 / 6 Unlocked
            </span>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {badges.map((b, idx) => (
              <div
                key={idx}
                className={cn(
                  "border p-3 text-center transition-all",
                  b.earned
                    ? "border-[var(--blue)] bg-[var(--blue-soft)]/50"
                    : "border-dashed border-[var(--border)] bg-[var(--surface-2)] opacity-50"
                )}
              >
                <div className="my-1 flex justify-center">
                  <span className="clip-oct-sm flex h-9 w-9 items-center justify-center bg-[var(--surface-solid)] text-base font-bold text-[var(--blue)]">
                    {b.icon}
                  </span>
                </div>
                <h4 className="display mt-1 text-xs font-bold leading-tight">
                  {b.name}
                </h4>
                <p className="mt-1 line-clamp-2 text-[10px] text-[var(--text-3)]">
                  {b.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Skill Mastery breakdown */}
        <div className="panel clip-oct p-5">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
            <span className="font-display text-sm font-bold uppercase tracking-wide">
              Skill Proficiency Radar
            </span>
            <span className="font-mono text-xs text-[var(--text-3)]">
              Based on solved challenges
            </span>
          </div>

          <div className="mt-4 space-y-4">
            {skills.map((s) => (
              <div key={s.name} className="space-y-1.5">
                <div className="flex justify-between font-mono text-xs">
                  <span className="text-[var(--text)]">{s.name}</span>
                  <span className="font-semibold text-[var(--blue)]">{s.percent}%</span>
                </div>
                <div className="h-1.5 w-full overflow-hidden bg-[var(--surface-2)]">
                  <div
                    className="h-full bg-[var(--blue)]"
                    style={{ width: `${s.percent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
