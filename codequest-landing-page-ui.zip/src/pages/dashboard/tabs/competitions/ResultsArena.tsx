import { useState } from "react";
import { cn } from "../../../../utils/cn";
import { accentVar, dateLong, type Competition } from "../../../../data/competitionsData";
import { currentStudent } from "../../../../data/dashboardData";
import { ArrowRight, CheckIcon, TrophyIcon } from "../../../../components/icons";

/**
 * Results Arena — only reachable once the competition record says results are
 * published. Nothing here invents a standing: it renders the published record.
 */
export default function ResultsArena({
  competition,
  onBack,
  onNavigate,
}: {
  competition: Competition;
  onBack: () => void;
  onNavigate: (tab: string) => void;
}) {
  const [reviewOpen, setReviewOpen] = useState(false);
  const accent = accentVar[competition.accent];
  const result = competition.studentResult;
  const board = competition.leaderboard ?? [];
  const reviewAllowed = competition.rules.showHiddenTests && competition.resultsPublished;

  return (
    <div className={cn("arena-shell min-h-full pb-10", `accent-${competition.accent}`)}>
      <div className="mx-auto max-w-[1180px] px-4 pt-6 sm:px-6">
        {/* header */}
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[var(--border)] pb-5">
          <div className="min-w-0">
            <button onClick={onBack} className="mono-label mb-3 inline-flex items-center gap-2 transition-colors hover:text-[var(--blue)]">
              ← Back to the arena
            </button>
            <p className="mono-label flex items-center gap-2" style={{ color: accent }}>
              <span className="h-1.5 w-1.5 rotate-45" style={{ background: accent }} />
              RESULTS PUBLISHED · {competition.category.toUpperCase()}
            </p>
            <h1 className="display mt-2 text-3xl font-bold uppercase leading-[1.03] tracking-tight sm:text-[2.6rem]">
              The results are in.
            </h1>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-[var(--text-2)]">
              Every challenge leaves you with something to build on. Published {competition.results_at ? dateLong(competition.results_at) : "—"}.
            </p>
          </div>
          <span className="clip-oct-sm border px-3 py-1.5 font-mono text-[10px]" style={{ borderColor: accent, color: accent }}>
            {competition.title}
          </span>
        </div>

        {!result ? (
          <div className="mt-8 border border-dashed border-[var(--border-strong)] p-10 text-center">
            <h2 className="display text-lg font-bold uppercase">No attempt on record</h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-[var(--text-2)]">
              Results are published for this competition, but there is no submission from your account. Only the grading
              service can attach a score — nothing is estimated here.
            </p>
            <button onClick={() => onNavigate("submissions")} className="comm-button comm-button-blue mt-5">
              Check submissions <ArrowRight className="h-3 w-3" />
            </button>
          </div>
        ) : (
          <>
            {/* headline score */}
            <div className="mt-6 grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
              <div className="arena-texture border bg-[var(--surface-solid)] p-6" style={{ borderColor: `${accent}55` }}>
                <p className="mono-label text-[9px]">Final score</p>
                <div className="mt-2 flex items-end gap-3">
                  <span className="countdown-digit display text-6xl font-bold leading-none" style={{ color: accent }}>
                    {result.score}
                  </span>
                  <span className="pb-2 font-mono text-sm text-[var(--text-3)]">/ {competition.totalPoints}</span>
                </div>
                <div className="mt-4 h-1.5 w-full overflow-hidden bg-[var(--border)]">
                  <div className="h-full transition-all duration-1000" style={{ width: `${(result.score / competition.totalPoints) * 100}%`, background: accent }} />
                </div>
                <dl className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4">
                  {[
                    ["Rank", `#${result.rank}`],
                    ["Field", `${result.totalParticipants}`],
                    ["Accuracy", `${result.accuracy}%`],
                    ["Time", `${result.completionMinutes}m`],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <dt className="mono-label text-[9px]">{k}</dt>
                      <dd className="display mt-1 text-lg font-bold">{v}</dd>
                    </div>
                  ))}
                </dl>
                {result.personalBest && (
                  <p className="mt-4 flex items-center gap-2 border-t border-[var(--border)] pt-3 font-mono text-[11px] text-[#5DD39E]">
                    <TrophyIcon className="h-3.5 w-3.5" /> New personal best — previous {result.previousScore} points
                  </p>
                )}
              </div>

              {/* breakdown */}
              <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-5">
                <h2 className="mono-label text-[var(--text)]">Performance breakdown</h2>
                <div className="mt-4 space-y-3.5">
                  {[
                    { label: "Multiple choice", got: result.mcq.correct, total: result.mcq.total, unit: "correct" },
                    { label: "Written response", got: result.written.awarded, total: result.written.total, unit: "points" },
                    { label: "Programming", got: result.coding.awarded, total: result.coding.total, unit: "points" },
                  ].map((row) => (
                    <div key={row.label}>
                      <div className="flex items-baseline justify-between text-[12px]">
                        <span className="text-[var(--text-2)]">{row.label}</span>
                        <span className="font-mono text-[var(--text)]">
                          {row.got} / {row.total} <span className="text-[var(--text-3)]">{row.unit}</span>
                        </span>
                      </div>
                      <div className="mt-1.5 h-1 w-full overflow-hidden bg-[var(--border)]">
                        <div className="h-full transition-all duration-700" style={{ width: `${(row.got / row.total) * 100}%`, background: accent }} />
                      </div>
                    </div>
                  ))}
                </div>

                <h3 className="mono-label mt-6 text-[var(--text)]">Round by round</h3>
                <div className="mt-2.5 space-y-2">
                  {result.perRound.map((r) => (
                    <div key={r.round} className="flex items-center justify-between border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2">
                      <span className="text-[12px] text-[var(--text-2)]">{r.round}</span>
                      <span className="font-mono text-[11px] text-[var(--text)]">{r.score} / {r.total}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* leaderboard */}
            <section className="mt-8">
              <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--border)] pb-3">
                <h2 className="display text-lg font-bold uppercase tracking-tight">Final standings</h2>
                <p className="font-mono text-[10px] text-[var(--text-3)]">
                  {competition.rules.leaderboard === "public" ? "public leaderboard" : "private evaluation — shown to participants only"} · ties broken by completion time
                </p>
              </div>

              <div className="mt-3 overflow-x-auto border border-[var(--border)] bg-[var(--surface-solid)]">
                <table className="w-full min-w-[560px] text-left">
                  <thead>
                    <tr className="border-b border-[var(--border)] font-mono text-[9.5px] uppercase tracking-wider text-[var(--text-3)]">
                      <th className="px-3 py-2.5 font-normal">Rank</th>
                      <th className="px-3 py-2.5 font-normal">Student</th>
                      <th className="px-3 py-2.5 font-normal">School</th>
                      <th className="px-3 py-2.5 text-right font-normal">Score</th>
                      <th className="px-3 py-2.5 text-right font-normal">Time</th>
                      <th className="px-3 py-2.5 text-right font-normal">Move</th>
                    </tr>
                  </thead>
                  <tbody>
                    {board.map((row, i) => {
                      const you = row.name === currentStudent.name;
                      return (
                        <tr key={row.name} className={cn("border-b border-[var(--border)] text-[12.5px] last:border-b-0", you && "bg-[var(--blue-soft)]")}>
                          <td className={cn("px-3 py-2.5 font-mono", i < 3 ? "font-bold" : "text-[var(--text-3)]")} style={i < 3 ? { color: accent } : undefined}>
                            {pad(i + 1)}
                          </td>
                          <td className="px-3 py-2.5">
                            <span className={cn("font-display font-semibold", you && "text-[var(--blue)]")}>{row.name}</span>
                            {you && <span className="ml-2 font-mono text-[9px] text-[var(--blue)]">YOU</span>}
                          </td>
                          <td className="px-3 py-2.5 font-mono text-[11px] text-[var(--text-3)]">{row.school}</td>
                          <td className="px-3 py-2.5 text-right font-mono tabular-nums">{row.score}</td>
                          <td className="px-3 py-2.5 text-right font-mono text-[11px] text-[var(--text-3)]">{row.tieBreak}</td>
                          <td className={cn("px-3 py-2.5 text-right font-mono text-[11px]", row.delta > 0 ? "text-[var(--blue)]" : row.delta < 0 ? "text-[var(--text-3)]" : "text-[var(--text-3)]")}>
                            {row.delta > 0 ? `▲ ${row.delta}` : row.delta < 0 ? `▼ ${Math.abs(row.delta)}` : "—"}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </section>

            {/* question review */}
            <section className="mt-8">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] pb-3">
                <h2 className="display text-lg font-bold uppercase tracking-tight">Question review</h2>
                <button onClick={() => setReviewOpen(!reviewOpen)} className="comm-small" disabled={!reviewAllowed}>
                  {reviewAllowed ? (reviewOpen ? "Hide review" : "Open review") : "Sealed by competition rules"}
                </button>
              </div>

              {!reviewAllowed ? (
                <p className="mt-3 border border-dashed border-[var(--border-strong)] p-5 text-[12.5px] leading-relaxed text-[var(--text-2)]">
                  Review is closed for this competition. The setter keeps questions and reference solutions confidential
                  until authorised, so answers, code and hidden test outcomes stay hidden.
                </p>
              ) : reviewOpen ? (
                <div className="mt-3 space-y-3">
                  {competition.rounds.flatMap((r) => r.questions).map((item, i) => (
                    <div key={item.id} className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="display text-[13px] font-bold">
                          {pad(i + 1)} · {item.title}
                        </p>
                        <span className="clip-oct-sm border px-2 py-0.5 font-mono text-[9.5px]" style={{ borderColor: accent, color: accent }}>
                          {item.points} pts · {item.kind}
                        </span>
                      </div>
                      {item.kind === "mcq" && (
                        <p className="mt-2 flex items-center gap-2 text-[12px] text-[var(--text-2)]">
                          <CheckIcon className="h-3.5 w-3.5 text-[#5DD39E]" />
                          Correct answer: <span className="font-semibold text-[var(--text)]">{item.options[item.correctIndex]}</span>
                        </p>
                      )}
                      {item.kind === "mcq" && item.explanation && (
                        <p className="mt-1.5 border-l-2 pl-3 text-[11.5px] leading-relaxed text-[var(--text-3)]" style={{ borderColor: accent }}>
                          {item.explanation}
                        </p>
                      )}
                      {item.kind === "text" && (
                        <ul className="mt-2 space-y-1">{item.rubric.map((r) => <li key={r} className="font-mono text-[10.5px] text-[var(--text-3)]">· {r}</li>)}</ul>
                      )}
                      {item.kind === "code" && (
                        <div className="mt-2">
                          <p className="mono-label text-[9px]">Reference solution</p>
                          <p className="mt-1 font-mono text-[10.5px] leading-relaxed text-[var(--text-3)]">
                            {item.hiddenTestCount} hidden tests graded server-side · visible samples {item.visibleTests.length}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="mt-3 font-mono text-[10.5px] text-[var(--text-3)]">Review is available for this competition — open it to see correct answers and rubrics.</p>
              )}
            </section>

            {/* next steps */}
            <section className="mt-8 flex flex-wrap gap-2.5 border-t border-[var(--border)] pt-6">
              <button onClick={onBack} className="btn-shell btn-primary-shell btn-shell-md">
                <span className="btn-core">Return to Competitions</span>
              </button>
              <button onClick={() => onNavigate("daily-practice")} className="btn-shell btn-ghost-shell btn-shell-md">
                <span className="btn-core">Explore practice questions <ArrowRight className="h-3.5 w-3.5" /></span>
              </button>
              <button onClick={() => onNavigate("profile")} className="btn-shell btn-ghost-shell btn-shell-md">
                <span className="btn-core">Review my performance</span>
              </button>
            </section>
          </>
        )}
      </div>
    </div>
  );
}

const pad = (n: number) => String(n).padStart(2, "0");
