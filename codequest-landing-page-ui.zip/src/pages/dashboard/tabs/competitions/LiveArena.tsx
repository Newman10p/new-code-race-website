import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { python } from "@codemirror/lang-python";
import { oneDark } from "@codemirror/theme-one-dark";
import { EditorView } from "@codemirror/view";
import { cn } from "../../../../utils/cn";
import {
  accentVar,
  type ArenaQuestion,
  type CodeQuestion,
  type Competition,
  type McqQuestion,
  type TextQuestion,
} from "../../../../data/competitionsData";
import { useCompetitions } from "../../../../lib/competitionStore";
import { useTheme } from "../../../../lib/theme";
import { prefersReducedMotion } from "../../../../lib/grid";
import {
  ArrowLeft,
  ArrowRight,
  CheckIcon,
  ChevronRight,
  CloseIcon,
  MenuIcon,
  PlayIcon,
  TerminalIcon,
} from "../../../../components/icons";

/* ══════════════ LOCAL REHEARSAL RUNNER ══════════════ */

type Row = { name: string; status: "pass" | "fail" | "error"; ms: number; got: string; want: string; error?: string };

const show = (v: unknown) => (v === undefined ? "undefined" : JSON.stringify(v));
const clone = (a: unknown) => (a !== null && typeof a === "object" ? structuredClone(a) : a);

/** Runs the student's code against the visible samples only. Hidden tests stay server-side. */
function runVisible(code: string, q: CodeQuestion) {
  const t0 = performance.now();
  let solve: ((...a: unknown[]) => unknown) | null = null;
  let compileError: string | undefined;
  try {
    solve = new Function(`"use strict";\n${code}\n;return typeof solve === "function" ? solve : null;`)() as never;
  } catch (e) {
    compileError = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
  }
  if (!solve) {
    return {
      rows: [] as Row[], passed: 0, total: q.visibleTests.length, ms: performance.now() - t0,
      compileError: compileError ?? "No callable `solve` found — define a top-level function named solve.",
    };
  }
  const rows = q.visibleTests.map<Row>((t) => {
    const s = performance.now();
    try {
      const got = (solve as (...a: unknown[]) => unknown)(...t.args.map(clone));
      return { name: t.name, status: show(got) === show(t.expected) ? "pass" : "fail", ms: performance.now() - s, got: show(got), want: show(t.expected) };
    } catch (e) {
      return { name: t.name, status: "error", ms: performance.now() - s, got: "—", want: show(t.expected), error: e instanceof Error ? e.message : String(e) };
    }
  });
  return { rows, passed: rows.filter((r) => r.status === "pass").length, total: rows.length, ms: performance.now() - t0, compileError };
}

/** Deterministic order when a competition randomises its questions. */
function orderedQuestions(qs: ArenaQuestion[], fixed: boolean, seed: string) {
  if (fixed) return qs;
  let h = 0;
  for (const c of seed) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  const out = [...qs];
  for (let i = out.length - 1; i > 0; i--) {
    h = (h * 1103515245 + 12345) >>> 0;
    const j = h % (i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

const pad = (n: number) => String(n).padStart(2, "0");

/* ══════════════ NAV PANEL ══════════════ */

function NavPanel({
  round, questions, activeIndex, onSelect, statuses, onClose, progress,
}: {
  round: string;
  questions: ArenaQuestion[];
  activeIndex: number;
  onSelect: (i: number) => void;
  statuses: (q: ArenaQuestion, i: number) => { glyph: string; label: string; tone: string };
  onClose?: () => void;
  progress: { answered: number; remaining: number; flagged: number; total: number };
}) {
  return (
    <div className="flex h-full flex-col bg-[var(--sidebar)]">
      <div className="flex items-center justify-between border-b border-[var(--border)] px-3 py-2.5">
        <div>
          <p className="mono-label text-[9px]">Question navigator</p>
          <p className="display mt-0.5 text-xs font-bold">{round}</p>
        </div>
        {onClose && (
          <button onClick={onClose} aria-label="Close navigator" className="text-[var(--text-3)] hover:text-[var(--text)] lg:hidden">
            <CloseIcon className="h-4 w-4" />
          </button>
        )}
      </div>

      <div className="border-b border-[var(--border)] px-3 py-2.5">
        <p className="font-mono text-[11px] text-[var(--text)]">
          {progress.answered} / {progress.total} Questions Answered
        </p>
        <div className="mt-1.5 h-1 w-full overflow-hidden bg-[var(--border)]">
          <div className="h-full bg-[var(--blue)] transition-all duration-500" style={{ width: `${(progress.answered / progress.total) * 100}%` }} />
        </div>
        <p className="mt-1.5 font-mono text-[9.5px] text-[var(--text-3)]">
          {progress.remaining} remaining · {progress.flagged} flagged
        </p>
      </div>

      <div className="grid flex-1 grid-cols-5 gap-1.5 overflow-y-auto p-3 lg:grid-cols-4">
        {questions.map((q, i) => {
          const s = statuses(q, i);
          return (
            <button
              key={q.id}
              onClick={() => onSelect(i)}
              aria-current={i === activeIndex}
              title={`${q.title} — ${s.label}`}
              className={cn(
                "relative flex aspect-square flex-col items-center justify-center border font-mono text-[11px] transition-all duration-200",
                i === activeIndex ? "border-[var(--blue)] bg-[var(--blue)] font-bold text-white" : "hover:border-[var(--blue)]",
                i !== activeIndex && s.tone === "answered" && "border-[#5DD39E]/60 bg-[#5DD39E]/10 text-[#5DD39E]",
                i !== activeIndex && s.tone === "visited" && "border-[var(--border-strong)] bg-[var(--surface-2)] text-[var(--text-2)]",
                i !== activeIndex && s.tone === "none" && "border-[var(--border)] text-[var(--text-3)]"
              )}
            >
              <span>{pad(i + 1)}</span>
              <span className="text-[9px] leading-none">{s.glyph}</span>
              {s.tone === "flagged" && <span className="absolute right-0.5 top-0.5 text-[9px] text-[#F2C94C]">⚑</span>}
            </button>
          );
        })}
      </div>

      <div className="border-t border-[var(--border)] p-3 font-mono text-[9px] leading-relaxed text-[var(--text-3)]">
        <p>— not visited · ◦ visited · ✓ answered</p>
        <p>⚑ flagged for review · ⏳ awaiting evaluation</p>
      </div>
    </div>
  );
}

/* ══════════════ MAIN ARENA ══════════════ */

export default function LiveArena({ competition, onExit }: { competition: Competition; onExit: () => void }) {
  const store = useCompetitions();
  const { theme } = useTheme();
  const existing = store.attemptFor(competition.id);

  useEffect(() => {
    if (!existing) store.startAttempt(competition.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [existing, competition.id]);

  const [roundIndex, setRoundIndex] = useState(existing?.roundIndex ?? 0);
  const [questionIndex, setQuestionIndex] = useState(existing?.questionIndex ?? 0);
  const [navOpen, setNavOpen] = useState(true);
  const [drawer, setDrawer] = useState(false);
  const [problemWidth, setProblemWidth] = useState(360);
  const [testsHeight, setTestsHeight] = useState(200);
  const [editorFont, setEditorFont] = useState(13);
  const [showConfirm, setShowConfirm] = useState(false);
  const [transition, setTransition] = useState<null | { to: number }>(null);
  const [running, setRunning] = useState(false);
  const [runRows, setRunRows] = useState<Record<string, Row[]>>({});
  const [customInput, setCustomInput] = useState("");
  const [customOut, setCustomOut] = useState<string | null>(null);
  const [mobilePane, setMobilePane] = useState<"problem" | "code" | "tests">("code");
  const [problemCollapsed, setProblemCollapsed] = useState(false);
  const drag = useRef<null | "x" | "y">(null);

  const attempt = existing;
  const accent = accentVar[competition.accent];
  const startMs = new Date(competition.control?.revisedStart ?? competition.starts_at).getTime();
  const endMs = new Date(competition.ends_at).getTime();
  const graceMs = competition.rules.graceMinutes * 60_000;
  const remaining = endMs - store.serverNow();
  const inGrace = remaining <= 0 && store.serverNow() <= endMs + graceMs;
  const locked = remaining <= -graceMs || Boolean(attempt?.submitted);
  const reduced = prefersReducedMotion();

  /* ── rounds ── */
  const openedRounds = useRef<number[]>([0]);
  const roundAvailable = useCallback(
    (i: number) => {
      if (i === 0) return true;
      const r = competition.rounds[i];
      if (!r) return false;
      const scheduled = store.serverNow() >= startMs + r.unlocksAtMinute * 60_000;
      return scheduled && (competition.rules.autoUnlockRounds || openedRounds.current.includes(i));
    },
    [competition, startMs, store]
  );
  const round = competition.rounds[roundIndex];
  const questions = useMemo(
    () => orderedQuestions(round?.questions ?? [], competition.rules.fixedOrder, `${competition.id}:${attempt?.id ?? ""}`),
    [round, competition.rules.fixedOrder, competition.id, attempt?.id]
  );
  const q = questions[questionIndex];

  /* ── persistence of navigation ── */
  useEffect(() => {
    if (attempt && (attempt.roundIndex !== roundIndex || attempt.questionIndex !== questionIndex)) {
      store.patchAttempt(competition.id, { roundIndex, questionIndex });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roundIndex, questionIndex]);

  useEffect(() => {
    if (attempt && q) store.setVisited(competition.id, q.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q?.id]);

  /* ── panel dragging ── */
  useEffect(() => {
    const move = (e: PointerEvent) => {
      if (!drag.current) return;
      if (drag.current === "x") setProblemWidth(Math.min(620, Math.max(260, e.clientX - (navOpen ? 250 : 0))));
      else setTestsHeight(Math.min(440, Math.max(120, window.innerHeight - e.clientY)));
    };
    const up = () => { drag.current = null; document.body.style.cursor = ""; document.body.style.userSelect = ""; };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    return () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); };
  }, [navOpen]);

  /* ── answers ── */
  const answerOf = (id: string) => attempt?.answers[id];
  const starterFor = (cq: CodeQuestion, lang: string) => cq.starter[lang] ?? cq.starter.javascript ?? "";

  const write = useCallback(
    (entry: Omit<import("../../../../lib/competitionStore").AnswerEntry, "savedAt" | "confirmedBy">) => {
      store.saveAnswer(competition.id, { ...entry, savedAt: Date.now(), confirmedBy: "local" });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [competition.id, store.saveState]
  );

  const isAnswered = (item: ArenaQuestion) => {
    const a = answerOf(item.id);
    if (!a || !a.value.trim()) return false;
    if (item.kind === "code") return a.value.trim() !== starterFor(item, a.language ?? item.runnable[0] ?? item.languages[0]).trim();
    return true;
  };

  const statuses = (item: ArenaQuestion, i: number) => {
    const a = answerOf(item.id);
    const flagged = Boolean(attempt?.flags[item.id]);
    if (attempt?.submitted) return { glyph: "⏳", label: "Awaiting evaluation", tone: flagged ? "flagged" : "answered" };
    if (flagged) return { glyph: "⚑", label: "Flagged for review", tone: "flagged" };
    if (isAnswered(item)) return { glyph: "✓", label: a?.confirmed ? "Answered · confirmed" : "Answered", tone: "answered" };
    if (attempt?.visited[item.id] || i === questionIndex) return { glyph: "◦", label: "Visited", tone: "visited" };
    return { glyph: "—", label: "Not visited", tone: "none" };
  };

  const progress = {
    total: questions.length,
    answered: questions.filter(isAnswered).length,
    flagged: questions.filter((item) => attempt?.flags[item.id]).length,
    remaining: questions.filter((item) => !isAnswered(item)).length,
  };

  /* ── rehearsal estimate: MCQ keys + visible tests only ── */
  const rehearsalEstimate = useMemo(() => {
    if (!attempt) return { earned: 0, basis: "" };
    let earned = 0;
    for (const r of competition.rounds) {
      for (const item of r.questions) {
        const a = attempt.answers[item.id];
        if (!a) continue;
        if (item.kind === "mcq") {
          const picked = Number(a.value);
          if (picked === item.correctIndex) earned += item.points;
        } else if (item.kind === "code" && a.localResult) {
          const denom = a.localResult.total + item.hiddenTestCount;
          earned += Math.round((item.points * a.localResult.passed) / denom);
        }
      }
    }
    return { earned, basis: "MCQ keys + visible code tests only — written answers are jury graded and excluded." };
  }, [attempt, competition.rounds]);

  /* ── finalisation ── */
  const finalize = useCallback(
    (reason: "manual" | "auto" | "grace") => {
      if (!attempt || attempt.submitted) return;
      const answered = Object.values(attempt.answers).filter((a) => a.value.trim()).length;
      store.submitAttempt(competition.id, rehearsalEstimate.earned, [
        `finalised: ${reason}`,
        `answers recorded locally: ${answered}`,
        `connection at submit: ${store.connection}`,
        `pending unsynced writes: ${store.pendingSync}`,
        `rehearsal estimate: ${rehearsalEstimate.earned} (local, unofficial)`,
      ]);
      setShowConfirm(false);
    },
    [attempt, competition.id, rehearsalEstimate.earned, store]
  );

  /* auto-close when the official window and grace period have both elapsed */
  useEffect(() => {
    if (locked && attempt && !attempt.submitted) finalize("auto");
  }, [locked, attempt, finalize]);

  /* ── movement ── */
  const goTo = (r: number, i: number) => {
    if (!competition.rules.revisitQuestions && (r < roundIndex || (r === roundIndex && i < questionIndex))) return;
    setRoundIndex(r);
    setQuestionIndex(i);
    setDrawer(false);
    setTransition(null);
  };
  const next = () => {
    if (questionIndex < questions.length - 1) return goTo(roundIndex, questionIndex + 1);
    const nextRound = roundIndex + 1;
    if (competition.rounds[nextRound]) beginRound(nextRound);
  };
  const beginRound = (i: number) => {
    if (!roundAvailable(i)) return;
    openedRounds.current = Array.from(new Set([...openedRounds.current, i]));
    if (!reduced) {
      setTransition({ to: i });
      window.setTimeout(() => { setRoundIndex(i); setQuestionIndex(0); setTransition(null); }, 1400);
    } else {
      setRoundIndex(i);
      setQuestionIndex(0);
    }
  };

  /* ── MCQ keyboard selection ── */
  useEffect(() => {
    if (!q || q.kind !== "mcq" || locked) return;
    const onKey = (e: KeyboardEvent) => {
      const idx = ["a", "b", "c", "d", "e"].indexOf(e.key.toLowerCase());
      const num = Number(e.key) - 1;
      const pick = idx >= 0 ? idx : num >= 0 && num < q.options.length ? num : -1;
      if (pick >= 0 && pick < q.options.length) {
        write({ questionId: q.id, kind: "mcq", value: String(pick) });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [q, locked, write]);

  if (!attempt || !round || !q) return null;

  const timerTone =
    remaining > 600_000 ? "text-[var(--text)]" : remaining > 300_000 ? "text-[#F2C94C]" : remaining > 60_000 ? "text-[#F2C94C]" : "text-[#FF6B6B]";
  const timerLabel = remaining <= 0 ? (inGrace ? "GRACE PERIOD" : "TIME CLOSED") : remaining <= 60_000 ? "FINAL MINUTE" : remaining <= 300_000 ? "5 MINUTE WARNING" : remaining <= 600_000 ? "10 MINUTE WARNING" : "TIME REMAINING";
  const t = { h: Math.floor(Math.max(0, remaining) / 3600_000), m: Math.floor((Math.max(0, remaining) % 3600_000) / 60_000), s: Math.floor((Math.max(0, remaining) % 60_000) / 1000) };

  const saveLabel =
    store.connection === "offline" ? "Save failed · kept locally"
      : store.saveState === "saving" ? "Saving…"
      : store.pendingSync > 0 ? `${store.pendingSync} pending sync`
      : store.saveState === "saved" ? "Saved locally" : "Autosave ready";

  return (
    <div className={cn("arena-shell fixed inset-0 z-[70] flex flex-col bg-[var(--bg)]", `accent-${competition.accent}`)}>
      {/* ═══ TOOLBAR ═══ */}
      <header className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-2 border-b border-[var(--border)] bg-[var(--sidebar)] px-3 py-2 sm:px-4">
        <div className="flex min-w-0 items-center gap-2.5">
          <button onClick={onExit} disabled={!competition.rules.submitEarly} title={competition.rules.submitEarly ? "Leave arena" : "Early exit is disabled for this competition"}
            className="clip-oct-sm flex items-center gap-1.5 border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1.5 font-mono text-[10px] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)] disabled:opacity-40">
            <ArrowLeft className="h-3 w-3" /><span className="hidden sm:inline">Exit</span>
          </button>
          <button onClick={() => setDrawer(true)} aria-label="Open question navigator" className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] text-[var(--text-2)] lg:hidden">
            <MenuIcon className="h-4 w-4" />
          </button>
          <div className="min-w-0">
            <p className="mono-label truncate text-[9px]" style={{ color: accent }}>
              {round.name} · Question {pad(questionIndex + 1)} of {pad(questions.length)}
            </p>
            <h1 className="display truncate text-[13px] font-bold tracking-tight">{competition.title}</h1>
          </div>
        </div>

        {/* timer — always visible */}
        <div className="ml-auto flex items-center gap-3">
          <div className="text-right">
            <p className={cn("mono-label text-[8.5px]", remaining <= 60_000 && "text-[#FF6B6B]")}>{timerLabel}</p>
            <p className={cn("countdown-digit display text-lg font-bold leading-none sm:text-xl", timerTone)}>
              {pad(t.h)}:{pad(t.m)}:{pad(t.s)}
            </p>
          </div>

          <div className="hidden flex-col gap-1 font-mono text-[9.5px] md:flex">
            <span className={cn("flex items-center gap-1.5", store.connection === "connected" ? "text-[#5DD39E]" : store.connection === "unstable" ? "text-[#F2C94C]" : "text-[#FF6B6B]")}>
              <span className={cn("h-1.5 w-1.5 rounded-full", store.connection === "connected" ? "bg-[#5DD39E]" : store.connection === "unstable" ? "bg-[#F2C94C]" : "bg-[#FF6B6B] live-dot")} />
              {store.connection}
            </span>
            <span className={cn(store.saveState === "failed" ? "text-[#FF6B6B]" : "text-[var(--text-3)]")}>{saveLabel}</span>
          </div>

          <button onClick={() => setShowConfirm(true)} disabled={locked} className="btn-shell btn-primary-shell btn-shell-sm disabled:opacity-40">
            <span className="btn-core">Submit Competition</span>
          </button>
        </div>
      </header>

      {/* round rail */}
      <div className="flex shrink-0 items-center gap-2 overflow-x-auto border-b border-[var(--border)] bg-[var(--surface-solid)] px-3 py-1.5">
        {competition.rounds.map((r, i) => {
          const available = roundAvailable(i);
          const done = i < roundIndex;
          const active = i === roundIndex;
          return (
            <button key={r.id} onClick={() => available && goTo(i, 0)} disabled={!available}
              className={cn("flex shrink-0 items-center gap-2 border px-2.5 py-1 font-mono text-[10px] transition-colors",
                active ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]" : available ? "border-[var(--border)] text-[var(--text-2)] hover:border-[var(--blue)]" : "border-dashed border-[var(--border)] text-[var(--text-3)] opacity-60")}>
              <span className={cn("clip-oct-sm flex h-4 w-4 items-center justify-center text-[9px]", done ? "bg-[#5DD39E] text-black" : active ? "bg-[var(--blue)] text-white" : "bg-[var(--surface-2)]")}>
                {done ? <CheckIcon className="h-2.5 w-2.5" /> : i + 1}
              </span>
              {r.name.replace(/^Round \d+ — /, "")}
              {!available && <span className="text-[9px]">locked</span>}
            </button>
          );
        })}
        <span className="ml-auto hidden shrink-0 font-mono text-[9.5px] text-[var(--text-3)] lg:inline">
          server offset {store.clockOffsetMs >= 0 ? "+" : ""}{store.clockOffsetMs}ms · autosave every change
        </span>
      </div>

      {/* ═══ BODY ═══ */}
      <div className="flex min-h-0 flex-1">
        {/* nav rail (desktop, collapsible) */}
        {navOpen ? (
          <aside className="relative hidden w-[210px] shrink-0 border-r border-[var(--border)] lg:block">
            <NavPanel round={round.name} questions={questions} activeIndex={questionIndex} onSelect={(i) => goTo(roundIndex, i)} statuses={statuses} progress={progress} />
            <button
              onClick={() => setNavOpen(false)}
              aria-label="Collapse question navigator"
              title="Collapse navigator"
              className="absolute -right-3 top-3 z-10 flex h-6 w-6 items-center justify-center border border-[var(--border-strong)] bg-[var(--surface-solid)] text-[var(--text-3)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
            >
              <ArrowLeft className="h-3 w-3" />
            </button>
          </aside>
        ) : (
          <button
            onClick={() => setNavOpen(true)}
            aria-label="Expand question navigator"
            title="Expand navigator"
            className="hidden w-8 shrink-0 items-center justify-center border-r border-[var(--border)] bg-[var(--sidebar)] text-[var(--text-3)] transition-colors hover:text-[var(--blue)] lg:flex"
          >
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        )}

        {/* question workspace */}
        <main className="flex min-w-0 flex-1 flex-col overflow-hidden">
          <div key={q.id} className={cn("question-in flex min-h-0 flex-1 flex-col overflow-hidden", q.kind === "code" ? "lg:flex-row" : "")}>
            {/* ── CODE: three panes ── */}
            {q.kind === "code" ? (
              <CodePane
                q={q} competition={competition} locked={locked} accent={accent}
                saved={answerOf(q.id)} write={write} running={running} setRunning={setRunning}
                rows={runRows[q.id] ?? []} setRows={(r) => setRunRows((m) => ({ ...m, [q.id]: r }))}
                customInput={customInput} setCustomInput={setCustomInput} customOut={customOut} setCustomOut={setCustomOut}
                problemWidth={problemWidth} setProblemWidth={setProblemWidth} problemCollapsed={problemCollapsed} setProblemCollapsed={setProblemCollapsed}
                testsHeight={testsHeight} drag={drag} editorFont={editorFont} setEditorFont={setEditorFont}
                dark={theme === "dark"} mobilePane={mobilePane} setMobilePane={setMobilePane} reduced={reduced}
                nextLabel={questionIndex < questions.length - 1 ? "Next question" : "Finish round"} onNext={next}
                flagged={Boolean(attempt.flags[q.id])} onFlag={() => store.toggleFlag(competition.id, q.id)}
                canRevisit={competition.rules.revisitQuestions} canChange={competition.rules.changeAnswers}
                connection={store.connection} simulate={store.simulateDisconnection} restore={store.restoreConnection}
              />
            ) : (
              <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
                <div className="mx-auto w-full max-w-3xl px-4 py-5 sm:px-6">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] pb-3">
                    <div>
                      <p className="mono-label text-[9px]" style={{ color: accent }}>
                        {q.kind === "mcq" ? "MULTIPLE CHOICE" : "WRITTEN RESPONSE"} · QUESTION {pad(questionIndex + 1)}
                      </p>
                      <h2 className="display mt-1 text-lg font-bold tracking-tight sm:text-xl">{q.title}</h2>
                    </div>
                    <span className="clip-oct-sm border px-2.5 py-1 font-mono text-[10px]" style={{ borderColor: accent, color: accent }}>
                      {q.points} POINTS
                    </span>
                  </div>

                  {q.kind === "mcq" ? (
                    <McqBody q={q} locked={locked} accent={accent} selected={answerOf(q.id)?.value} canChange={competition.rules.changeAnswers}
                      onPick={(i) => write({ questionId: q.id, kind: "mcq", value: String(i) })} />
                  ) : (
                    <TextBody q={q} locked={locked} accent={accent} entry={answerOf(q.id)} onSave={(v) => write({ questionId: q.id, kind: "text", value: v })}
                      onConfirm={(v) => write({ questionId: q.id, kind: "text", value: v, confirmed: true })} />
                  )}

                  <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-[var(--border)] pt-4">
                    <button onClick={() => store.toggleFlag(competition.id, q.id)}
                      className={cn("comm-small", attempt.flags[q.id] && "border-[#F2C94C] text-[#F2C94C]")}>
                      {attempt.flags[q.id] ? "⚑ Flagged" : "⚑ Flag for review"}
                    </button>
                    {!competition.rules.revisitQuestions && <span className="font-mono text-[10px] text-[var(--text-3)]">Revisiting previous questions is disabled for this competition.</span>}
                    <button onClick={next} className="btn-shell btn-primary-shell btn-shell-sm ml-auto">
                      <span className="btn-core">{questionIndex < questions.length - 1 ? "Next Question" : "Finish Round"} <ArrowRight className="h-3 w-3" /></span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* ═══ MOBILE DRAWER ═══ */}
      {drawer && (
        <div className="fixed inset-0 z-[80] flex bg-black/60 lg:hidden" onClick={() => setDrawer(false)}>
          <div className="w-[280px] max-w-[85vw] border-r border-[var(--border)]" onClick={(e) => e.stopPropagation()}>
            <NavPanel round={round.name} questions={questions} activeIndex={questionIndex} onSelect={(i) => goTo(roundIndex, i)} statuses={statuses} onClose={() => setDrawer(false)} progress={progress} />
          </div>
        </div>
      )}

      {/* ═══ ROUND TRANSITION ═══ */}
      {transition && (
        <div className="fixed inset-0 z-[85] flex flex-col items-center justify-center bg-[var(--bg)] px-6 text-center">
          <div className="flex gap-2" aria-hidden="true">
            {Array.from({ length: 9 }).map((_, i) => (
              <span key={i} className="clip-oct-sm h-7 w-7" style={{ background: accent, animation: reduced ? "none" : `cq-ignite 700ms ${i * 80}ms ease-out both` }} />
            ))}
          </div>
          <p className="mono-label mt-7" style={{ color: accent }}>ROUND {roundIndex + 1} COMPLETE</p>
          <h2 className="display mt-2 text-3xl font-bold uppercase tracking-tight">You've completed the stage.</h2>
          <p className="mt-3 max-w-md text-sm text-[var(--text-2)]">
            {progress.answered} of {progress.total} questions answered · rehearsal estimate {rehearsalEstimate.earned} points (local, unofficial).
          </p>
          <p className="mt-2 font-mono text-[11px] text-[var(--text-3)]">Entering {competition.rounds[transition.to]?.name}…</p>
        </div>
      )}

      {/* ═══ SUBMIT CONFIRMATION ═══ */}
      {showConfirm && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/75 p-4" role="dialog" aria-modal="true" aria-label="Submit competition">
          <div className="panel-in w-full max-w-md border border-[var(--border-strong)] bg-[var(--surface-solid)] p-6">
            <p className="mono-label" style={{ color: accent }}>FINAL SUBMISSION</p>
            <h2 className="display mt-1.5 text-2xl font-bold tracking-tight">Ready to submit?</h2>
            <p className="mt-2 text-[13px] leading-relaxed text-[var(--text-2)]">
              You have answered {progress.answered} of {progress.total} questions in this round.
              {progress.remaining > 0 && <> {progress.remaining} question{progress.remaining === 1 ? "" : "s"} still unanswered.</>}
            </p>
            <dl className="mt-4 space-y-1.5 border-y border-[var(--border)] py-3 font-mono text-[11px]">
              {[["Answered", progress.answered], ["Unanswered", progress.remaining], ["Flagged", progress.flagged],
                ["Code submissions", Object.values(attempt.answers).filter((a) => a.kind === "code").length],
                ["Unsynced writes", store.pendingSync]].map(([k, v]) => (
                <div key={String(k)} className="flex justify-between"><dt className="text-[var(--text-3)]">{k}</dt><dd className="text-[var(--text)]">{v}</dd></div>
              ))}
            </dl>
            <p className="mt-3 text-[11px] leading-relaxed text-[#F2C94C]">
              Submitting locks the attempt. Official scoring happens server-side; this prototype records a local rehearsal only.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button className="comm-button" onClick={() => setShowConfirm(false)}>Return to Competition</button>
              <button className="comm-button comm-button-blue" onClick={() => finalize(inGrace ? "grace" : "manual")}>Submit Competition</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══ LOCK OVERLAY ═══ */}
      {locked && !attempt.submitted && (
        <div className="fixed inset-0 z-[95] flex items-center justify-center bg-black/80 p-6 text-center">
          <div>
            <p className="mono-label text-[#FF6B6B]">TIME CLOSED</p>
            <h2 className="display mt-2 text-3xl font-bold">Editing is locked.</h2>
            <p className="mt-2 max-w-sm text-sm text-[var(--text-2)]">The official window and grace period have elapsed. Your last saved answers are being finalised.</p>
          </div>
        </div>
      )}
    </div>
  );
}

/* ══════════════ MCQ ══════════════ */

function McqBody({ q, locked, accent, selected, canChange, onPick }: {
  q: McqQuestion; locked: boolean; accent: string; selected?: string; canChange: boolean; onPick: (i: number) => void;
}) {
  return (
    <div className="mt-5">
      <div role="radiogroup" aria-label={q.title} className="space-y-2">
        {q.options.map((opt, i) => {
          const active = selected === String(i);
          return (
            <button key={opt} role="radio" aria-checked={active} disabled={locked || (Boolean(selected) && !canChange)} onClick={() => onPick(i)}
              className={cn("flex w-full items-center gap-3 border px-3.5 py-3 text-left transition-all duration-200",
                active ? "border-[var(--blue)] bg-[var(--blue-soft)]" : "border-[var(--border)] bg-[var(--surface-solid)] hover:border-[var(--blue)] hover:bg-[var(--surface-hover)]",
                (locked || (Boolean(selected) && !canChange)) && "cursor-not-allowed opacity-70")}>
              <span className={cn("clip-oct-sm flex h-7 w-7 shrink-0 items-center justify-center border font-mono text-[11px] font-bold",
                active ? "border-[var(--blue)] bg-[var(--blue)] text-white" : "border-[var(--border-strong)] text-[var(--text-3)]")}>
                {String.fromCharCode(65 + i)}
              </span>
              <span className={cn("text-[13.5px] leading-snug", active ? "font-semibold text-[var(--text)]" : "text-[var(--text-2)]")}>{opt}</span>
              {active && (
                <span className="ml-auto shrink-0" style={{ color: accent }}>
                  <CheckIcon className="h-4 w-4" />
                </span>
              )}
            </button>
          );
        })}
      </div>
      <p className="mt-4 font-mono text-[10px] leading-relaxed text-[var(--text-3)]">
        Press A–D or 1–4 to select · your choice autosaves locally after each click
        {!canChange && " · answers cannot be changed once selected in this competition"}
      </p>
    </div>
  );
}

/* ══════════════ WRITTEN RESPONSE ══════════════ */

function TextBody({ q, locked, accent, entry, onSave, onConfirm }: {
  q: TextQuestion; locked: boolean; accent: string; entry?: { value: string; confirmed?: boolean };
  onSave: (v: string) => void; onConfirm: (v: string) => void;
}) {
  const [draft, setDraft] = useState(entry?.value ?? "");
  const words = draft.trim() ? draft.trim().split(/\s+/).length : 0;
  const over = words > q.wordLimit;
  useEffect(() => {
    const t = window.setTimeout(() => { if (draft !== (entry?.value ?? "")) onSave(draft); }, 600);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draft]);

  return (
    <div className="mt-5 space-y-4">
      <p className="text-[13.5px] leading-relaxed text-[var(--text)]">{q.prompt}</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-3">
          <p className="mono-label mb-2 text-[9px]">Response requirements</p>
          <ul className="space-y-1">{q.requirements.map((r) => <li key={r} className="flex gap-2 text-[11.5px] leading-relaxed text-[var(--text-2)]"><span className="mt-1.5 h-1 w-1 shrink-0 rotate-45" style={{ background: accent }} />{r}</li>)}</ul>
        </div>
        <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-3">
          <p className="mono-label mb-2 text-[9px]">Marking rubric</p>
          <ul className="space-y-1">{q.rubric.map((r) => <li key={r} className="text-[11.5px] leading-relaxed text-[var(--text-2)]">{r}</li>)}</ul>
        </div>
      </div>

      <textarea value={draft} disabled={locked} rows={9} onChange={(e) => setDraft(e.target.value)} placeholder="Write your response…"
        className={cn("w-full resize-y border bg-[var(--surface-solid)] p-3 text-[13px] leading-relaxed text-[var(--text)] focus:outline-none",
          over ? "border-[#FF6B6B]" : "border-[var(--border)] focus:border-[var(--blue)]")} />

      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className={cn("font-mono text-[11px]", over ? "text-[#FF6B6B]" : "text-[var(--text-3)]")}>
          {words} / {q.wordLimit} words {over && "· over limit"}
        </p>
        <div className="flex items-center gap-2">
          {entry?.confirmed && <span className="font-mono text-[10px] text-[#5DD39E]">✓ final answer confirmed</span>}
          <button disabled={locked || over || !draft.trim()} onClick={() => onConfirm(draft)} className="btn-shell btn-ghost-shell btn-shell-sm disabled:opacity-40">
            <span className="btn-core">Confirm final answer</span>
          </button>
        </div>
      </div>
      <p className="font-mono text-[10px] text-[var(--text-3)]">Autosaved locally as you type. Written responses are graded by the jury — no feedback is shown during the competition.</p>
    </div>
  );
}

/* ══════════════ CODE PANE ══════════════ */

function CodePane(props: {
  q: CodeQuestion; competition: Competition; locked: boolean; accent: string;
  saved?: { value: string; language?: string; localResult?: { passed: number; total: number; ms: number } };
  write: (e: { questionId: string; kind: "code"; value: string; language?: string; localResult?: { passed: number; total: number; ms: number } }) => void;
  running: boolean; setRunning: (v: boolean) => void; rows: Row[]; setRows: (r: Row[]) => void;
  customInput: string; setCustomInput: (v: string) => void; customOut: string | null; setCustomOut: (v: string | null) => void;
  problemWidth: number; setProblemWidth: (n: number) => void; problemCollapsed: boolean; setProblemCollapsed: (v: boolean) => void;
  testsHeight: number; drag: React.MutableRefObject<null | "x" | "y">; editorFont: number; setEditorFont: (n: number) => void;
  dark: boolean; mobilePane: "problem" | "code" | "tests"; setMobilePane: (v: "problem" | "code" | "tests") => void; reduced: boolean;
  nextLabel: string; onNext: () => void; flagged: boolean; onFlag: () => void; canRevisit: boolean; canChange: boolean;
  connection: string; simulate: () => void; restore: () => void;
}) {
  const { q, accent, locked, saved, write, running, setRunning, rows, setRows } = props;
  const [language, setLanguage] = useState(saved?.language ?? q.runnable[0] ?? q.languages[0]);
  const [code, setCode] = useState(saved?.value ?? q.starter[language] ?? q.starter.javascript ?? "");
  const runnable = q.runnable.includes(language);

  useEffect(() => {
    const t = window.setTimeout(() => { if (code !== (saved?.value ?? "")) write({ questionId: q.id, kind: "code", value: code, language }); }, 700);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [code]);

  const run = () => {
    if (!runnable || locked) return;
    setRunning(true);
    window.setTimeout(() => {
      const res = runVisible(code, q);
      setRows(res.rows);
      setRunning(false);
      write({ questionId: q.id, kind: "code", value: code, language, localResult: { passed: res.passed, total: res.total, ms: Math.round(res.ms) } });
    }, 420);
  };

  const runCustom = () => {
    if (!runnable) return;
    try {
      const args = JSON.parse(props.customInput || "[]");
      const solve = new Function(`"use strict";\n${code}\n;return solve;`)();
      const out = solve(...(Array.isArray(args) ? args : [args]));
      props.setCustomOut(JSON.stringify(out));
    } catch (e) {
      props.setCustomOut(`Error: ${e instanceof Error ? e.message : String(e)}`);
    }
  };

  const extensions = useMemo(() => [
    language === "python" ? python() : javascript(),
    EditorView.lineWrapping,
    EditorView.theme({ "&": { fontSize: `${props.editorFont}px`, height: "100%" }, ".cm-scroller": { fontFamily: "var(--font-mono)", lineHeight: "1.6" } }),
  ], [language, props.editorFont]);

  return (
    <>
      {/* mobile pane switch */}
      <div className="flex shrink-0 gap-1 border-b border-[var(--border)] bg-[var(--sidebar)] p-1.5 lg:hidden">
        {(["problem", "code", "tests"] as const).map((p) => (
          <button key={p} onClick={() => props.setMobilePane(p)}
            className={cn("flex-1 py-1.5 font-mono text-[10px] uppercase", props.mobilePane === p ? "bg-[var(--blue)] text-white" : "text-[var(--text-3)]")}>
            {p}
          </button>
        ))}
      </div>

      {/* problem pane */}
      {!props.problemCollapsed && (
        <section className={cn("min-h-0 overflow-y-auto border-b border-[var(--border)] bg-[var(--surface-solid)] p-4 lg:border-b-0 lg:border-r",
          props.mobilePane === "problem" ? "block max-h-[45%] lg:max-h-none" : "hidden lg:block")}
          style={{ width: undefined }}>
          <div className="lg:sticky lg:top-0" style={{ maxWidth: props.problemWidth }}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="mono-label text-[9px]" style={{ color: accent }}>CODING CHALLENGE · {q.points} POINTS</p>
                <h2 className="display mt-1 text-base font-bold tracking-tight">{q.title}</h2>
              </div>
              <button onClick={() => props.setProblemCollapsed(true)} className="hidden font-mono text-[10px] text-[var(--text-3)] hover:text-[var(--blue)] lg:block">collapse →</button>
            </div>
            <p className="mt-3 border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-[11.5px] leading-relaxed text-[var(--text-2)]">{q.scenario}</p>
            <p className="mt-3 text-[12.5px] leading-relaxed text-[var(--text)]">{q.statement}</p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <div><p className="mono-label text-[9px]">Input</p><p className="mt-1 font-mono text-[10.5px] text-[var(--text-2)]">{q.inputFormat}</p></div>
              <div><p className="mono-label text-[9px]">Output</p><p className="mt-1 font-mono text-[10.5px] text-[var(--text-2)]">{q.outputFormat}</p></div>
            </div>
            <div className="mt-3"><p className="mono-label text-[9px]">Constraints</p><ul className="mt-1 space-y-0.5">{q.constraints.map((c) => <li key={c} className="font-mono text-[10.5px] text-[var(--text-2)]">· {c}</li>)}</ul></div>
            <div className="mt-3 space-y-2">{q.examples.map((e, i) => (
              <div key={i} className="border border-[var(--border)] bg-[var(--surface-2)] p-2.5 font-mono text-[10.5px]">
                <p className="text-[var(--text-3)]">sample {i + 1}</p><p className="text-[var(--text)]">in: {e.input}</p><p className="text-[#5DD39E]">out: {e.output}</p>
              </div>))}</div>
            <div className="mt-3"><p className="mono-label text-[9px]">Permitted languages</p><p className="mt-1 font-mono text-[10.5px] text-[var(--text-2)]">{q.languages.join(" · ")}</p></div>
            <div className="mt-3 border-t border-[var(--border)] pt-3"><p className="mono-label text-[9px]">Marking</p><ul className="mt-1 space-y-0.5">{q.marking.map((m) => <li key={m} className="text-[11px] leading-relaxed text-[var(--text-2)]">· {m}</li>)}</ul></div>
          </div>
        </section>
      )}

      {props.problemCollapsed && (
        <button onClick={() => props.setProblemCollapsed(false)} className="hidden w-8 shrink-0 items-center justify-center border-r border-[var(--border)] bg-[var(--sidebar)] font-mono text-[10px] text-[var(--text-3)] hover:text-[var(--blue)] lg:flex">
          <ChevronRight className="h-3.5 w-3.5" />
        </button>
      )}

      {/* editor + tests */}
      <section className={cn("flex min-h-0 min-w-0 flex-1 flex-col", props.mobilePane === "code" || props.mobilePane === "tests" ? "flex" : "hidden lg:flex")}>
        {/* editor toolbar */}
        <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-[var(--border)] bg-[var(--sidebar)] px-2.5 py-1.5">
          <span style={{ color: accent }}>
            <TerminalIcon className="h-3.5 w-3.5" />
          </span>
          <select value={language} onChange={(e) => { const l = e.target.value; setLanguage(l); setCode(saved?.language === l ? saved.value : q.starter[l] ?? q.starter.javascript ?? ""); }}
            className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1 font-mono text-[10.5px] text-[var(--text)] focus:border-[var(--blue)] focus:outline-none">
            {q.languages.map((l) => <option key={l} value={l}>{l}{q.runnable.includes(l) ? " · runnable here" : " · judge offline"}</option>)}
          </select>
          <div className="flex items-center gap-1">
            {[12, 13, 15].map((s) => <button key={s} onClick={() => props.setEditorFont(s)} className={cn("clip-oct-sm px-1.5 py-0.5 font-mono text-[10px]", props.editorFont === s ? "bg-[var(--blue)] text-white" : "text-[var(--text-3)] hover:text-[var(--text)]")}>{s}</button>)}
          </div>
          <span className="ml-auto hidden font-mono text-[9.5px] text-[var(--text-3)] sm:inline">⌘/Ctrl+↵ run · autosaves locally</span>
          <button onClick={props.onFlag} className={cn("comm-small", props.flagged && "border-[#F2C94C] text-[#F2C94C]")}>{props.flagged ? "⚑ Flagged" : "⚑ Flag"}</button>
        </div>

        {!runnable && (
          <p className="shrink-0 border-b border-[#F2C94C]/40 bg-[#F2C94C]/10 px-3 py-2 font-mono text-[10.5px] text-[#F2C94C]">
            {language} is graded by the server judge, which is not connected in this prototype. You can still write and save code; switch to {q.runnable.join(" or ")} to execute locally.
          </p>
        )}

        <div className={cn("min-h-0 flex-1 overflow-hidden bg-[var(--surface-solid)]", props.mobilePane === "tests" && "hidden lg:block")}>
          <CodeMirror value={code} onChange={setCode} extensions={extensions} theme={props.dark ? oneDark : "light"} height="100%"
            readOnly={locked} editable={!locked}
            basicSetup={{ lineNumbers: true, foldGutter: true, highlightActiveLine: true, bracketMatching: true, closeBrackets: true, autocompletion: true, indentOnInput: true, tabSize: 2 }} />
        </div>

        {/* resize handle */}
        <div role="separator" aria-orientation="horizontal" onPointerDown={() => { props.drag.current = "y"; document.body.style.cursor = "row-resize"; document.body.style.userSelect = "none"; }}
          className={cn("hidden h-[4px] shrink-0 cursor-row-resize bg-[var(--border)] hover:bg-[var(--blue)] lg:block", props.mobilePane === "tests" && "hidden")} />

        {/* tests */}
        <div className={cn("flex shrink-0 flex-col border-t border-[var(--border)] bg-[var(--sidebar)]", props.mobilePane === "tests" ? "flex max-h-none flex-1 overflow-y-auto" : "hidden lg:flex")}
          style={props.mobilePane === "tests" ? undefined : { height: props.testsHeight }}>
          <div className="flex shrink-0 items-center gap-2 border-b border-[var(--border)] px-2.5 py-1.5">
            <span className="mono-label text-[9px]">Test results</span>
            {saved?.localResult && <span className="font-mono text-[10px] text-[#5DD39E]">{saved.localResult.passed}/{saved.localResult.total} visible · {saved.localResult.ms}ms</span>}
            <div className="ml-auto flex items-center gap-1.5">
              <button onClick={run} disabled={!runnable || running || locked} className="btn-shell btn-ghost-shell btn-shell-sm disabled:opacity-40">
                <span className="btn-core"><PlayIcon className="h-3 w-3" />{running ? "Running…" : "Run Code"}</span>
              </button>
              <button onClick={run} disabled={!runnable || running || locked} className="btn-shell btn-primary-shell btn-shell-sm disabled:opacity-40">
                <span className="btn-core"><CheckIcon className="h-3 w-3" />Submit Solution</span>
              </button>
              <button onClick={props.onNext} className="btn-shell btn-ghost-shell btn-shell-sm">
                <span className="btn-core">{props.nextLabel} <ArrowRight className="h-3 w-3" /></span>
              </button>
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto p-2.5">
            {rows.length === 0 ? (
              <p className="py-4 text-center font-mono text-[10.5px] text-[var(--text-3)]">No local run yet. Run Code executes the visible samples in your browser.</p>
            ) : (
              <table className="w-full font-mono text-[10.5px]">
                <thead><tr className="text-left text-[var(--text-3)]"><th className="pb-1.5 font-normal">Test Case</th><th className="pb-1.5 font-normal">Status</th><th className="pb-1.5 font-normal">Execution</th></tr></thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.name} className="border-t border-[var(--border)]">
                      <td className="py-1.5 text-[var(--text-2)]">{r.name}</td>
                      <td className={cn("py-1.5", r.status === "pass" ? "text-[#5DD39E]" : "text-[#FF6B6B]")}>{r.status === "pass" ? "Passed" : r.status === "fail" ? `Failed · got ${r.got}` : `Error · ${r.error}`}</td>
                      <td className="py-1.5 text-[var(--text-3)]">{r.ms.toFixed(1)} ms</td>
                    </tr>
                  ))}
                  {Array.from({ length: q.hiddenTestCount }).map((_, i) => (
                    <tr key={`h${i}`} className="border-t border-[var(--border)]">
                      <td className="py-1.5 text-[var(--text-3)]">Hidden Test {i + 1}</td>
                      <td className="py-1.5 text-[var(--text-3)]">Pending — server-side</td>
                      <td className="py-1.5 text-[var(--text-3)]">—</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            <div className="mt-3 border-t border-[var(--border)] pt-2.5">
              <p className="mono-label text-[9px]">Custom input (runs locally)</p>
              <div className="mt-1.5 flex gap-2">
                <input value={props.customInput} onChange={(e) => props.setCustomInput(e.target.value)} placeholder='[[1,3,-1,-3,5,3,6,7], 3]'
                  className="comm-input flex-1 font-mono text-[11px]" disabled={!runnable} />
                <button onClick={runCustom} disabled={!runnable} className="comm-small disabled:opacity-40">Run input</button>
              </div>
              {props.customOut && <p className="mt-1.5 font-mono text-[10.5px] text-[var(--text-2)]">→ {props.customOut}</p>}
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-[var(--border)] pt-2.5 font-mono text-[9.5px] text-[var(--text-3)]">
              <span>hidden inputs and expected outputs are never sent to the browser</span>
              <button onClick={props.connection === "connected" ? props.simulate : props.restore} className="ml-auto underline decoration-dotted hover:text-[var(--blue)]">
                {props.connection === "connected" ? "simulate disconnect" : "reconnect"}
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
