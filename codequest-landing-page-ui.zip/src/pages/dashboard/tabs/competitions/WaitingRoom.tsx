import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "../../../../utils/cn";
import {
  CHECKLIST,
  accentVar,
  countdownParts,
  dateLong,
  timeShort,
  type Competition,
} from "../../../../data/competitionsData";
import { useCompetitions } from "../../../../lib/competitionStore";
import { prefersReducedMotion } from "../../../../lib/grid";
import { ArrowLeft, ArrowRight, CloseIcon, UsersIcon } from "../../../../components/icons";

type RoomState = "waiting" | "starting-soon" | "ready" | "delayed" | "cancelled" | "reconnecting";

const pad = (n: number) => String(n).padStart(2, "0");

export default function WaitingRoom({
  competition,
  onEnter,
  onLeave,
}: {
  competition: Competition;
  onEnter: () => void;
  onLeave: () => void;
}) {
  const {
    serverNow, now, connection, simulateDisconnection, restoreConnection,
    soundEnabled, setSoundEnabled, clockOffsetMs, reschedule, clearControl,
  } = useCompetitions();

  const [checklist, setChecklist] = useState<Record<number, boolean>>({});
  const [cancelled, setCancelled] = useState(false);
  const [entering, setEntering] = useState(false);
  const audioRef = useRef<AudioContext | null>(null);
  const lastBeepRef = useRef<number>(-1);

  const control = competition.control;

  /* Authoritative start: control's revised time wins over the published one.
     Compared against the simulated server clock, not a local browser timer. */
  const startMs = new Date(control?.revisedStart ?? competition.starts_at).getTime();
  const remaining = startMs - serverNow();

  // `now` is the one-second tick that drives re-render of every countdown.
  useEffect(() => { void now; }, [now]);
  const parts = countdownParts(remaining);
  const totalDurationMs = competition.durationMinutes * 60_000;

  const state: RoomState = useMemo(() => {
    if (cancelled || control?.kind === "cancelled") return "cancelled";
    if (connection === "offline" || connection === "reconnecting") return "reconnecting";
    if (control?.kind === "delayed") return "delayed";
    if (remaining <= 10_000) return "ready";
    if (remaining <= 60_000) return "starting-soon";
    return "waiting";
  }, [cancelled, control, connection, remaining]);

  const finalTen = remaining <= 10_000 && remaining > 0;
  const detailed = remaining <= 60_000;
  const checkedCount = Object.values(checklist).filter(Boolean).length;
  const readyCount = competition.participants.filter((p) => p.ready).length;

  /* Optional, off-by-default soft tick for the final ten seconds. */
  const beep = (freq: number) => {
    if (!soundEnabled || prefersReducedMotion()) return;
    try {
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioRef.current) audioRef.current = new Ctx();
      const ctx = audioRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.06, ctx.currentTime + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);
      osc.connect(gain).connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    } catch {
      /* audio unavailable — silent fallback */
    }
  };

  useEffect(() => {
    if (!finalTen) {
      lastBeepRef.current = -1;
      return;
    }
    if (parts.totalSeconds !== lastBeepRef.current) {
      lastBeepRef.current = parts.totalSeconds;
      beep(parts.totalSeconds <= 3 ? 880 : 560);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [finalTen, parts.totalSeconds]);

  /* Auto-transition at zero. */
  useEffect(() => {
    if (remaining <= 0 && !entering && state !== "cancelled") {
      setEntering(true);
      const t = window.setTimeout(onEnter, prefersReducedMotion() ? 60 : 1500);
      return () => window.clearTimeout(t);
    }
  }, [remaining, entering, onEnter, state]);

  const announcementList = [...competition.waitingRoomAnnouncements].sort(
    (a, b) => new Date(b.at).getTime() - new Date(a.at).getTime()
  );

  return (
    <div className={cn("arena-shell relative min-h-screen bg-[var(--bg)] pb-10", `accent-${competition.accent}`)}>
      {/* ═══ TOP IDENTITY BAR ═══ */}
      <header className="sticky top-0 z-20 flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] bg-[var(--sidebar)]/95 px-4 py-3 backdrop-blur-md sm:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <button
            onClick={onLeave}
            className="clip-oct-sm flex items-center gap-2 border border-[var(--border)] bg-[var(--surface-2)] px-2.5 py-1.5 font-mono text-[11px] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
          >
            <ArrowLeft className="h-3 w-3" /> Leave
          </button>
          <div className="min-w-0">
            <p className="mono-label flex items-center gap-2 text-[10px]" style={{ color: accentVar[competition.accent] }}>
              <span className="h-1.5 w-1.5 rotate-45" style={{ background: accentVar[competition.accent] }} />
              WAITING ROOM · {competition.category.toUpperCase()}
            </p>
            <h1 className="display truncate text-sm font-bold tracking-tight sm:text-base">{competition.title}</h1>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 font-mono text-[10px]">
          <span className="clip-oct-sm flex items-center gap-1.5 border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1 text-[var(--text-2)]">
            <span
              className={cn(
                "h-1.5 w-1.5 rounded-full",
                connection === "connected" && "bg-[#5DD39E]",
                connection === "unstable" && "bg-[#F2C94C]",
                (connection === "offline" || connection === "reconnecting") && "bg-[#FF6B6B]"
              )}
            />
            {connection}
          </span>
          <span className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1 text-[var(--text-3)]">
            server clock · offset {clockOffsetMs >= 0 ? "+" : ""}{clockOffsetMs}ms
          </span>
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            aria-pressed={soundEnabled}
            className={cn(
              "clip-oct-sm border px-2 py-1 transition-colors",
              soundEnabled
                ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]"
                : "border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-3)] hover:text-[var(--text)]"
            )}
          >
            sound {soundEnabled ? "on" : "off"}
          </button>
        </div>
      </header>

      {/* ═══ ENTERING TRANSITION ═══ */}
      {entering && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[var(--bg)]">
          <div className="flex gap-2" aria-hidden="true">
            {Array.from({ length: 7 }).map((_, i) => (
              <span
                key={i}
                className="clip-oct-sm h-8 w-8"
                style={{
                  background: accentVar[competition.accent],
                  animation: prefersReducedMotion() ? "none" : `cq-ignite 700ms ${i * 90}ms ease-out both`,
                }}
              />
            ))}
          </div>
          <p className="mono-label mt-6">Entering the arena…</p>
        </div>
      )}

      <div className="mx-auto grid max-w-[1240px] gap-6 px-4 pt-8 sm:px-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        {/* ═══ COUNTDOWN COLUMN ═══ */}
        <div>
          <p className="mono-label flex items-center gap-2.5" style={{ color: accentVar[competition.accent] }}>
            <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full" style={{ background: accentVar[competition.accent] }} />
            {state === "starting-soon" ? "STARTING SOON" : state === "ready" ? "READY TO ENTER" : state === "delayed" ? "START DELAYED" : state === "cancelled" ? "COMPETITION CANCELLED" : state === "reconnecting" ? "CONNECTION LOST" : "WAITING FOR START"}
          </p>

          <h2 className="display mt-3 text-3xl font-bold uppercase leading-[1.02] tracking-tight sm:text-5xl">
            {state === "cancelled" ? (
              <>This event was <span style={{ color: "#FF6B6B" }}>cancelled.</span></>
            ) : state === "reconnecting" ? (
              <>Reconnecting to the <span style={{ color: accentVar[competition.accent] }}>arena…</span></>
            ) : (
              <>Your arena is almost <span style={{ color: accentVar[competition.accent] }}>ready.</span></>
            )}
          </h2>

          <p className="mt-3 max-w-xl text-sm leading-relaxed text-[var(--text-2)]">
            {state === "cancelled"
              ? control?.note ?? "Competition control cancelled this event. Your registration carries over to the next edition."
              : state === "reconnecting"
              ? "Your seat is held and your saved answers are preserved. Reconnect to resume against official competition time."
              : state === "delayed"
              ? control?.note ?? "The start time was moved by competition control. The countdown below reflects the revised schedule."
              : "Take a moment to prepare. The competition will begin when the countdown reaches zero."}
          </p>

          {/* ── COUNTDOWN ── */}
          {state !== "cancelled" && (
            <div className="arena-texture relative mt-7 border border-[var(--border)] bg-[var(--surface-solid)] p-6 sm:p-8">
              {finalTen && (
                <span
                  aria-hidden="true"
                  className="pulse-ring pointer-events-none absolute inset-0 border"
                  style={{ borderColor: accentVar[competition.accent] }}
                />
              )}

              <div className="flex flex-wrap items-end justify-center gap-3 sm:gap-6">
                {detailed
                  ? [
                      { v: parts.minutes, l: "MINUTES" },
                      { v: parts.seconds, l: "SECONDS" },
                      { v: Math.floor((remaining % 1000) / 10), l: "CS" },
                    ].map((u) => (
                      <div key={u.l} className="text-center">
                        <span
                          className={cn(
                            "countdown-digit display block text-5xl font-bold leading-none sm:text-7xl",
                            u.l === "CS" ? "text-[var(--text-3)]" : "text-[var(--text)]"
                          )}
                          style={finalTen && u.l !== "CS" ? { color: accentVar[competition.accent] } : undefined}
                        >
                          {u.l === "CS" ? pad(u.v) : pad(u.v)}
                        </span>
                        <span className="mono-label mt-2 block text-[9px]">{u.l}</span>
                      </div>
                    ))
                  : [
                      { v: parts.hours, l: "HOURS" },
                      { v: parts.minutes, l: "MINUTES" },
                      { v: parts.seconds, l: "SECONDS" },
                    ].map((u, i) => (
                      <div key={u.l} className="flex items-end gap-3 sm:gap-6">
                        {i > 0 && (
                          <span className="countdown-digit display pb-6 text-3xl font-bold text-[var(--text-3)] sm:text-5xl">:</span>
                        )}
                        <div className="text-center">
                          <span className="countdown-digit display block text-5xl font-bold leading-none text-[var(--text)] sm:text-7xl">
                            {pad(u.v)}
                          </span>
                          <span className="mono-label mt-2 block text-[9px]">{u.l}</span>
                        </div>
                      </div>
                    ))}
              </div>

              {/* Ignition sequence in the final ten seconds */}
              {finalTen && (
                <div className="mt-6 flex justify-center gap-1.5" aria-hidden="true">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <span
                      key={i}
                      className={cn("clip-oct-sm h-2.5 w-7", i >= parts.totalSeconds ? "bg-[var(--border-strong)]" : "")}
                      style={
                        i < parts.totalSeconds
                          ? {
                              background: accentVar[competition.accent],
                              animation: prefersReducedMotion() ? "none" : `cq-ignite 700ms ${(10 - i) * 40}ms ease-out both`,
                            }
                          : undefined
                      }
                    />
                  ))}
                </div>
              )}

              <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 border-t border-[var(--border)] pt-4 font-mono text-[10.5px] text-[var(--text-3)]">
                <span>starts {dateLong(competition.starts_at)} · your local time</span>
                <span>duration {competition.durationMinutes} min</span>
                <span>{competition.rounds.length} rounds</span>
              </div>
            </div>
          )}

          {/* ── STATE-SPECIFIC ACTIONS ── */}
          <div className="mt-5 flex flex-wrap items-center gap-2.5">
            {state === "reconnecting" ? (
              <button
                onClick={restoreConnection}
                className="btn-shell btn-primary-shell btn-shell-md"
              >
                <span className="btn-core">Retry connection</span>
              </button>
            ) : state === "cancelled" ? (
              <button onClick={onLeave} className="btn-shell btn-primary-shell btn-shell-md">
                <span className="btn-core">
                  Back to competition details <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </button>
            ) : (
              <button onClick={onEnter} className="btn-shell btn-ghost-shell btn-shell-md">
                <span className="btn-core">
                  Enter now {remaining > 0 ? "(early entry)" : ""} <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </button>
            )}

            {connection === "connected" && (
              <button onClick={simulateDisconnection} className="btn-shell btn-ghost-shell btn-shell-md">
                <span className="btn-core">Simulate connection loss</span>
              </button>
            )}

            {/* Clearly-labelled prototype controls: no backend exists to drive these states. */}
            <div className="ml-auto flex flex-wrap items-center gap-2">
              <span className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-[var(--text-3)]">
                prototype state
              </span>
              {[
                {
                  label: "T−10s",
                  note: "move the official start to ten seconds from now",
                  fn: () => {
                    clearControl(competition.id);
                    reschedule(competition.id, new Date(serverNow() + 10_000).toISOString());
                  },
                },
                {
                  label: "Delayed",
                  note: "competition control pushes the start back by 8 minutes",
                  fn: () => {
                    const revised = new Date(serverNow() + 8 * 60_000).toISOString();
                    reschedule(competition.id, revised, {
                      kind: "delayed",
                      revisedStart: revised,
                      note: "Competition control delayed the start by 8 minutes due to a judge connection issue. The countdown reflects the revised time.",
                    });
                  },
                },
                {
                  label: "Resume",
                  note: "clear the delay and restore the published schedule",
                  fn: () => clearControl(competition.id),
                },
                {
                  label: "Cancelled",
                  note: "competition control cancels this event",
                  fn: () => setCancelled(true),
                },
              ].map((c) => (
                <button
                  key={c.label}
                  title={c.note}
                  onClick={c.fn}
                  className="clip-oct-sm border border-dashed border-[var(--border-strong)] px-2 py-1 font-mono text-[10px] text-[var(--text-3)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          <p className="mt-3 font-mono text-[10px] leading-relaxed text-[var(--text-3)]">
            Timing uses the official competition start timestamp, resolved once and persisted — refreshing resumes the
            true remaining time. The server clock here is a simulated handshake (offset {clockOffsetMs}ms); a real
            deployment replaces it with the service time response.
          </p>

          {/* ── ANNOUNCEMENTS ── */}
          {announcementList.length > 0 && state !== "cancelled" && (
            <section className="mt-7">
              <h3 className="mono-label mb-3">Competition control</h3>
              <div className="space-y-2">
                {announcementList.map((a) => (
                  <div
                    key={a.at}
                    className="flex items-start gap-3 border-l-2 bg-[var(--surface-solid)] p-3"
                    style={{ borderColor: accentVar[a.tone] }}
                  >
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rotate-45" style={{ background: accentVar[a.tone] }} />
                    <div className="min-w-0">
                      <p className="text-[12.5px] leading-relaxed text-[var(--text)]">{a.text}</p>
                      <p className="mt-1 font-mono text-[10px] text-[var(--text-3)]">
                        authorised notice · {timeShort(a.at)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* ═══ SIDE COLUMN ═══ */}
        <aside className="space-y-4">
          {/* Checklist */}
          <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
            <div className="flex items-center justify-between">
              <h3 className="mono-label text-[var(--text)]">Preparation checklist</h3>
              <span className="font-mono text-[10px] text-[var(--text-3)]">
                {checkedCount}/{CHECKLIST.length}
              </span>
            </div>
            <div className="mt-2 h-1 w-full overflow-hidden bg-[var(--border)]">
              <div
                className="h-full transition-all duration-500"
                style={{
                  width: `${(checkedCount / CHECKLIST.length) * 100}%`,
                  background: accentVar[competition.accent],
                }}
              />
            </div>
            <ul className="mt-3 space-y-1.5">
              {CHECKLIST.map((item, i) => (
                <li key={item}>
                  <label className="flex cursor-pointer items-start gap-2.5 text-[12px] leading-snug text-[var(--text-2)]">
                    <input
                      type="checkbox"
                      checked={Boolean(checklist[i])}
                      onChange={() => setChecklist((c) => ({ ...c, [i]: !c[i] }))}
                      className="mt-0.5 accent-[var(--blue)]"
                    />
                    <span className={cn(checklist[i] && "text-[var(--text-3)] line-through")}>{item}</span>
                  </label>
                </li>
              ))}
            </ul>
            <p className="mt-3 border-t border-[var(--border)] pt-2.5 font-mono text-[9.5px] leading-relaxed text-[var(--text-3)]">
              Guidance only — this checklist does not gate entry.
            </p>
          </div>

          {/* Participants */}
          <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
            <div className="flex items-center justify-between">
              <h3 className="mono-label flex items-center gap-2 text-[var(--text)]">
                <UsersIcon className="h-3.5 w-3.5" /> In the room
              </h3>
              <span className="font-mono text-[10px] text-[var(--text-3)]">
                {readyCount}/{competition.participants.length || competition.registeredCount} ready
              </span>
            </div>

            {competition.participants.length ? (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {competition.participants.map((p) => (
                  <span
                    key={p.name}
                    title={`${p.name} · ${p.school} · ${p.ready ? "ready" : "waiting"}`}
                    className={cn(
                      "clip-oct-sm flex h-8 w-8 items-center justify-center border font-display text-[10px] font-bold transition-transform hover:-translate-y-0.5",
                      p.ready
                        ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]"
                        : "border-[var(--border-strong)] bg-[var(--surface-2)] text-[var(--text-3)]"
                    )}
                  >
                    {p.name
                      .split(" ")
                      .map((w) => w[0])
                      .slice(0, 2)
                      .join("")}
                  </span>
                ))}
              </div>
            ) : (
              <p className="mt-3 font-mono text-[10px] leading-relaxed text-[var(--text-3)]">
                The roster service is not connected, so individual participants are not listed. Registered count:{" "}
                {competition.registeredCount} across {competition.schoolCount} schools.
              </p>
            )}

            <ul className="mt-3 space-y-1 border-t border-[var(--border)] pt-2.5 font-mono text-[10px] text-[var(--text-3)]">
              <li className="flex justify-between">
                <span>registered</span>
                <span className="text-[var(--text-2)]">{competition.registeredCount}</span>
              </li>
              <li className="flex justify-between">
                <span>schools</span>
                <span className="text-[var(--text-2)]">{competition.schoolCount}</span>
              </li>
              <li className="flex justify-between">
                <span>your seat</span>
                <span style={{ color: accentVar[competition.accent] }}>confirmed</span>
              </li>
            </ul>
          </div>

          {/* Instructions */}
          <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
            <h3 className="mono-label text-[var(--text)]">Instructions</h3>
            <ul className="mt-2.5 space-y-2 text-[11.5px] leading-relaxed text-[var(--text-2)]">
              <li className="flex gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rotate-45" style={{ background: accentVar[competition.accent] }} />
                {competition.rounds.length} rounds · {totalDurationMs / 60000} minutes total. Round
                {" "}2 unlocks automatically {competition.rounds[1]?.unlocksAtMinute ?? 0} minutes after start.
              </li>
              <li className="flex gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rotate-45" style={{ background: accentVar[competition.accent] }} />
                External resources: {competition.rules.externalResources ? "permitted" : "not permitted"}. Attempt logs are retained.
              </li>
              <li className="flex gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rotate-45" style={{ background: accentVar[competition.accent] }} />
                Grace period {competition.rules.graceMinutes} min; late submissions{" "}
                {competition.rules.acceptLate ? "accepted" : "not accepted"}.
              </li>
            </ul>
            {competition.rules.deviceRequirement && (
              <p className="mt-3 border-t border-[var(--border)] pt-2.5 text-[11px] leading-relaxed text-[#F2C94C]">
                {competition.rules.deviceRequirement}
              </p>
            )}
          </div>

          <div className="border border-dashed border-[var(--border-strong)] p-3 font-mono text-[9.5px] leading-relaxed text-[var(--text-3)]">
            <span className="flex items-center gap-1.5 text-[var(--text-2)]">
              <CloseIcon className="h-3 w-3" /> Frontend rehearsal
            </span>
            <span className="mt-1.5 block">
              Entry, eligibility and start time are validated by the server in production. This prototype lets you walk
              the arena without a backend; no official attempt is recorded.
            </span>
          </div>
        </aside>
      </div>
    </div>
  );
}
