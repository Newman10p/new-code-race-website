import { useState } from "react";
import { cn } from "../../../utils/cn";
import { currentStudent } from "../../../data/dashboardData";
import { useTheme } from "../../../lib/theme";
import { CheckIcon } from "../../../components/icons";

export default function SettingsTab() {
  const { theme, toggle } = useTheme();
  const [activeCategory, setActiveCategory] = useState<"account" | "appearance" | "learning" | "competition" | "notifications">("account");

  // Account state
  const [name, setName] = useState(currentStudent.name);
  const [school, setSchool] = useState(currentStudent.school);
  const [email, setEmail] = useState("farid.bulega@northview.edu");
  const [bio, setBio] = useState("Grade 11 developer competing in Season 01. Focus on Python, BFS/DFS, and dynamic programming.");

  // Learning state
  const [favLang, setFavLang] = useState("Python 3");
  const [difficultyTarget, setDifficultyTarget] = useState("Medium");
  const [dailyGoalXp, setDailyGoalXp] = useState("50 XP (1 problem)");

  // Notification toggles
  const [contestAlerts, setContestAlerts] = useState(true);
  const [dailyReminders, setDailyReminders] = useState(true);
  const [hubMentions, setHubMentions] = useState(true);
  const [leaderboardPublic, setLeaderboardPublic] = useState(true);

  // Save toast
  const [savedToast, setSavedToast] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 2500);
  };

  const navs = [
    { id: "account", label: "Account & Profile" },
    { id: "appearance", label: "Appearance & Theme" },
    { id: "learning", label: "Learning & Practice" },
    { id: "competition", label: "Competitions & Ranking" },
    { id: "notifications", label: "Notification Channels" },
  ] as const;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-3 border-b border-[var(--border)] pb-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-label text-[var(--blue)]">ACCOUNT / PREFERENCES</p>
          <h1 className="display mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
            Settings & Configurations
          </h1>
          <p className="mt-1 text-sm text-[var(--text-2)]">
            Configure your student identity, learning preferences, notification alerts, and theme density.
          </p>
        </div>

        {savedToast && (
          <div className="panel-in clip-oct-sm flex items-center gap-2 border border-[#5DD39E]/50 bg-[#5DD39E]/10 px-3 py-1.5 font-mono text-xs text-[#5DD39E]">
            <CheckIcon className="h-3.5 w-3.5" />
            <span>Preferences saved successfully</span>
          </div>
        )}
      </div>

      {/* 2-Column Layout: Settings Nav | Form Panel */}
      <div className="grid gap-6 md:grid-cols-[200px_1fr]">
        {/* Settings Sub-nav */}
        <div className="panel clip-oct p-2">
          <div className="space-y-1">
            {navs.map((n) => (
              <button
                key={n.id}
                onClick={() => setActiveCategory(n.id)}
                className={cn(
                  "w-full text-left px-3 py-2 font-display text-xs transition-colors",
                  activeCategory === n.id
                    ? "bg-[var(--blue-soft)] font-semibold text-[var(--blue)]"
                    : "text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--text)]"
                )}
              >
                {n.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content Form Panel */}
        <form onSubmit={handleSave} className="panel clip-oct space-y-6 p-6">
          {activeCategory === "account" && (
            <div className="space-y-4">
              <h3 className="font-display text-sm font-bold uppercase tracking-wide">
                Student Profile Information
              </h3>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mono-label block pb-1 text-[var(--text-3)]">Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="mono-label block pb-1 text-[var(--text-3)]">Enrolled School</label>
                  <input
                    type="text"
                    value={school}
                    onChange={(e) => setSchool(e.target.value)}
                    className="w-full border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="mono-label block pb-1 text-[var(--text-3)]">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
                />
              </div>

              <div>
                <label className="mono-label block pb-1 text-[var(--text-3)]">Bio / Bio-Tagline</label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
                />
              </div>
            </div>
          )}

          {activeCategory === "appearance" && (
            <div className="space-y-4">
              <h3 className="font-display text-sm font-bold uppercase tracking-wide">
                Theme & Interface Density
              </h3>

              <div className="space-y-2">
                <p className="mono-label text-[var(--text-3)]">Color Scheme</p>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={theme === "light" ? toggle : undefined}
                    className={cn(
                      "clip-oct flex flex-1 items-center justify-center gap-2 border p-3 font-mono text-xs transition-colors",
                      theme === "dark"
                        ? "border-[var(--blue)] bg-[var(--blue-soft)] font-bold text-[var(--blue)]"
                        : "border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)]"
                    )}
                  >
                    Dark (Default)
                  </button>
                  <button
                    type="button"
                    onClick={theme === "dark" ? toggle : undefined}
                    className={cn(
                      "clip-oct flex flex-1 items-center justify-center gap-2 border p-3 font-mono text-xs transition-colors",
                      theme === "light"
                        ? "border-[var(--blue)] bg-[var(--blue-soft)] font-bold text-[var(--blue)]"
                        : "border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)]"
                    )}
                  >
                    Light
                  </button>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <p className="mono-label text-[var(--text-3)]">Octagon Grid Intensity</p>
                <select className="w-full border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none">
                  <option value="restrained">Restrained (Recommended for Dashboard)</option>
                  <option value="dynamic">Dynamic Interactive (Full motion)</option>
                  <option value="minimal">Minimal / Flat</option>
                </select>
              </div>
            </div>
          )}

          {activeCategory === "learning" && (
            <div className="space-y-4">
              <h3 className="font-display text-sm font-bold uppercase tracking-wide">
                Learning & Practice Preferences
              </h3>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mono-label block pb-1 text-[var(--text-3)]">Preferred Coding Language</label>
                  <select
                    value={favLang}
                    onChange={(e) => setFavLang(e.target.value)}
                    className="w-full border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
                  >
                    <option value="Python 3">Python 3 (CP Default)</option>
                    <option value="C++ 20">C++ 20 (Speed Target)</option>
                    <option value="Java 17">Java 17</option>
                    <option value="TypeScript">TypeScript</option>
                  </select>
                </div>

                <div>
                  <label className="mono-label block pb-1 text-[var(--text-3)]">Target Difficulty</label>
                  <select
                    value={difficultyTarget}
                    onChange={(e) => setDifficultyTarget(e.target.value)}
                    className="w-full border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
                  >
                    <option value="Easy">Easy (Fundamentals)</option>
                    <option value="Medium">Medium (Tournament Target)</option>
                    <option value="Hard">Hard (Finals Bracket)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="mono-label block pb-1 text-[var(--text-3)]">Daily Practice Goal</label>
                <select
                  value={dailyGoalXp}
                  onChange={(e) => setDailyGoalXp(e.target.value)}
                  className="w-full border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
                >
                  <option value="50 XP (1 problem)">50 XP (1 problem daily)</option>
                  <option value="100 XP (2 problems)">100 XP (2 problems daily)</option>
                  <option value="150 XP (Power Competitor)">150 XP (Power Competitor)</option>
                </select>
              </div>
            </div>
          )}

          {activeCategory === "competition" && (
            <div className="space-y-4">
              <h3 className="font-display text-sm font-bold uppercase tracking-wide">
                Competition & Leaderboard Standing
              </h3>

              <div className="space-y-3">
                <label className="flex cursor-pointer items-center justify-between border border-[var(--border)] bg-[var(--surface-2)] p-3 text-xs">
                  <div>
                    <span className="font-semibold text-[var(--text)]">Public Leaderboard Visibility</span>
                    <p className="text-[var(--text-3)]">Show display name and score on Season 01 rankings</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={leaderboardPublic}
                    onChange={(e) => setLeaderboardPublic(e.target.checked)}
                    className="h-4 w-4 accent-[var(--blue)]"
                  />
                </label>
              </div>
            </div>
          )}

          {activeCategory === "notifications" && (
            <div className="space-y-4">
              <h3 className="font-display text-sm font-bold uppercase tracking-wide">
                Notification Channels & Alerts
              </h3>

              <div className="space-y-2">
                <label className="flex cursor-pointer items-center justify-between border border-[var(--border)] bg-[var(--surface-2)] p-3 text-xs">
                  <div>
                    <span className="font-semibold text-[var(--text)]">Tournament Start Alerts</span>
                    <p className="text-[var(--text-3)]">Receive email and in-app countdown 1 hour before live rounds</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={contestAlerts}
                    onChange={(e) => setContestAlerts(e.target.checked)}
                    className="h-4 w-4 accent-[var(--blue)]"
                  />
                </label>

                <label className="flex cursor-pointer items-center justify-between border border-[var(--border)] bg-[var(--surface-2)] p-3 text-xs">
                  <div>
                    <span className="font-semibold text-[var(--text)]">Daily Practice Reminders</span>
                    <p className="text-[var(--text-3)]">Alert me if my 7-day flame streak is about to lapse at 20:00 UTC</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={dailyReminders}
                    onChange={(e) => setDailyReminders(e.target.checked)}
                    className="h-4 w-4 accent-[var(--blue)]"
                  />
                </label>

                <label className="flex cursor-pointer items-center justify-between border border-[var(--border)] bg-[var(--surface-2)] p-3 text-xs">
                  <div>
                    <span className="font-semibold text-[var(--text)]">Student Hub Mentions</span>
                    <p className="text-[var(--text-3)]">Notify when a school peer replies to your code solution</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={hubMentions}
                    onChange={(e) => setHubMentions(e.target.checked)}
                    className="h-4 w-4 accent-[var(--blue)]"
                  />
                </label>
              </div>
            </div>
          )}

          {/* Submit Save Button */}
          <div className="flex items-center justify-end border-t border-[var(--border)] pt-4">
            <button
              type="submit"
              className="btn-shell btn-primary-shell btn-shell-md"
            >
              <span className="btn-core">
                Save Changes
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
