import { HubProvider } from "../../../lib/hubStore";
import HubShell from "./hub/HubShell";

/**
 * Student Hub entry point.
 *
 * The Hub replaces the dashboard shell entirely — it owns its header, its
 * single navigation rail and the Back to CodeQuest control. This provider
 * holds profiles, conversations, DM requests, posts, communities, battles
 * and notifications so every destination reads the same records.
 */
export default function StudentHubTab({ param }: { param?: string | null }) {
  return (
    <HubProvider>
      <HubShell param={param} />
    </HubProvider>
  );
}
