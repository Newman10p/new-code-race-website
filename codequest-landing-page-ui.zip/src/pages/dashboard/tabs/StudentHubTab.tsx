import { useState } from "react";
import { cn } from "../../../utils/cn";
import {
  hubRoomsData,
  initialHubMessages,
  type HubMessage,
} from "../../../data/dashboardData";
import {
  HashIcon,
  SendIcon,
  CodeIcon,
} from "../../../components/icons";

export default function StudentHubTab() {
  const [activeRoomId, setActiveRoomId] = useState<string>("general");
  const [messages, setMessages] = useState<HubMessage[]>(initialHubMessages);
  const [newMessageText, setNewMessageText] = useState("");
  const [includeCode, setIncludeCode] = useState(false);
  const [newCodeText, setNewCodeText] = useState("");

  const activeRoom = hubRoomsData.find((r) => r.id === activeRoomId) || hubRoomsData[0];
  const roomMessages = messages.filter((m) => m.roomId === activeRoomId);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessageText.trim() && !newCodeText.trim()) return;

    const newMsg: HubMessage = {
      id: "msg-" + Date.now(),
      roomId: activeRoomId,
      sender: "Farid Bulega",
      school: "Northview Academy",
      role: "You",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      avatarText: "FB",
      verified: true,
      content: newMessageText.trim(),
      codeSnippet: includeCode && newCodeText.trim() ? {
        language: "python",
        code: newCodeText.trim(),
      } : undefined,
      reactions: [{ emoji: "⚡", count: 1, reacted: true }],
    };

    setMessages([...messages, newMsg]);
    setNewMessageText("");
    setNewCodeText("");
    setIncludeCode(false);
  };

  const handleToggleReaction = (msgId: string, emoji: string) => {
    setMessages((prev) =>
      prev.map((msg) => {
        if (msg.id !== msgId) return msg;
        const exists = msg.reactions.find((r) => r.emoji === emoji);
        let updatedReactions;
        if (exists) {
          updatedReactions = msg.reactions.map((r) =>
            r.emoji === emoji
              ? { ...r, count: r.reacted ? r.count - 1 : r.count + 1, reacted: !r.reacted }
              : r
          );
        } else {
          updatedReactions = [...msg.reactions, { emoji, count: 1, reacted: true }];
        }
        return { ...msg, reactions: updatedReactions.filter((r) => r.count > 0) };
      })
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-3 border-b border-[var(--border)] pb-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-label text-[var(--blue)]">COMMUNITY / PEER NETWORK</p>
          <h1 className="display mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
            Student Hub & Discussions
          </h1>
          <p className="mt-1 text-sm text-[var(--text-2)]">
            Verified student chatrooms across partner schools. Share approaches, discuss system trade-offs, and form scrimmage squads.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="clip-oct-sm flex items-center gap-1.5 border border-[var(--blue)]/50 bg-[var(--blue-soft)] px-3 py-1 font-mono text-xs text-[var(--blue)]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#5DD39E]" />
            142 Students Online
          </span>
        </div>
      </div>

      {/* 3-Part Layout: Rooms list | Chat Feed | Online peers */}
      <div className="grid gap-4 lg:grid-cols-[220px_1fr_240px]">
        {/* Left: Rooms */}
        <div className="panel clip-oct p-3">
          <p className="mono-label px-2 pb-2 text-[10px] text-[var(--text-3)]">
            COMMUNITY ROOMS
          </p>

          <div className="space-y-1">
            {hubRoomsData.map((room) => {
              const active = activeRoomId === room.id;
              return (
                <button
                  key={room.id}
                  onClick={() => setActiveRoomId(room.id)}
                  className={cn(
                    "flex w-full items-center justify-between border px-2.5 py-2 text-left font-mono text-xs transition-colors",
                    active
                      ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]"
                      : "border-transparent text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--text)]"
                  )}
                >
                  <span className="truncate">{room.name}</span>
                  {room.unreadCount && (
                    <span className="clip-oct-sm bg-[var(--blue)] px-1.5 py-0.2 font-mono text-[9px] font-bold text-white">
                      {room.unreadCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="mt-6 border-t border-[var(--border)] pt-3 text-[11px] text-[var(--text-3)]">
            <p className="font-semibold text-[var(--text-2)]">Active Room:</p>
            <p className="mt-1 leading-snug">{activeRoom.description}</p>
          </div>
        </div>

        {/* Center: Message Feed & Composer */}
        <div className="panel clip-oct flex flex-col justify-between p-4 sm:p-5">
          {/* Active room header */}
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
            <div className="flex items-center gap-2">
              <HashIcon className="h-4 w-4 text-[var(--blue)]" />
              <span className="font-display font-bold text-[var(--text)]">
                {activeRoom.name}
              </span>
              <span className="hidden font-mono text-xs text-[var(--text-3)] sm:inline">
                · {activeRoom.description}
              </span>
            </div>
            <span className="font-mono text-[11px] text-[var(--text-3)]">
              {activeRoom.onlineCount} online
            </span>
          </div>

          {/* Messages list */}
          <div className="my-4 max-h-[50vh] min-h-[360px] space-y-4 overflow-y-auto pr-1">
            {roomMessages.length === 0 ? (
              <div className="py-12 text-center text-xs text-[var(--text-3)]">
                No messages in this room yet. Start the conversation!
              </div>
            ) : (
              roomMessages.map((msg) => (
                <div key={msg.id} className="space-y-1.5">
                  <div className="flex items-baseline justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="clip-oct-sm flex h-5 w-5 items-center justify-center bg-[var(--surface-2)] font-mono text-[10px] font-bold text-[var(--blue)]">
                        {msg.avatarText}
                      </span>
                      <span className="font-display text-xs font-semibold text-[var(--text)]">
                        {msg.sender}
                      </span>
                      {msg.verified && (
                        <span className="font-mono text-[10px] text-[#5DD39E]" title="Verified Student">
                          ✓
                        </span>
                      )}
                      <span className="font-mono text-[10.5px] text-[var(--text-3)]">
                        {msg.school}
                      </span>
                    </div>
                    <span className="font-mono text-[10px] text-[var(--text-3)]">
                      {msg.timestamp}
                    </span>
                  </div>

                  {/* Body text */}
                  <p className="text-xs leading-relaxed text-[var(--text-2)] pl-7">
                    {msg.content}
                  </p>

                  {/* Optional code snippet */}
                  {msg.codeSnippet && (
                    <div className="ml-7 mt-1.5 overflow-hidden border border-[var(--border)] bg-[var(--surface-solid)] p-2.5 font-mono text-[11.5px] text-[var(--text)]">
                      <div className="mb-1 flex items-center justify-between text-[10px] text-[var(--text-3)]">
                        <span>{msg.codeSnippet.language.toUpperCase()}</span>
                      </div>
                      <pre className="overflow-x-auto leading-snug">
                        <code>{msg.codeSnippet.code}</code>
                      </pre>
                    </div>
                  )}

                  {/* Emoji Reactions */}
                  <div className="ml-7 flex flex-wrap gap-1 pt-1">
                    {msg.reactions.map((r, rIdx) => (
                      <button
                        key={rIdx}
                        onClick={() => handleToggleReaction(msg.id, r.emoji)}
                        className={cn(
                          "clip-oct-sm flex items-center gap-1 border px-2 py-0.5 font-mono text-[10px] transition-colors",
                          r.reacted
                            ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]"
                            : "border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-3)] hover:text-[var(--text)]"
                        )}
                      >
                        <span>{r.emoji}</span>
                        <span>{r.count}</span>
                      </button>
                    ))}
                    <button
                      onClick={() => handleToggleReaction(msg.id, "💡")}
                      className="clip-oct-sm border border-dashed border-[var(--border)] px-1.5 py-0.5 font-mono text-[10px] text-[var(--text-3)] hover:border-[var(--blue)] hover:text-[var(--blue)]"
                      title="Add reaction"
                    >
                      +
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Interactive message composer */}
          <form onSubmit={handleSendMessage} className="space-y-2 border-t border-[var(--border)] pt-3">
            <textarea
              rows={2}
              value={newMessageText}
              onChange={(e) => setNewMessageText(e.target.value)}
              placeholder={`Message ${activeRoom.name}...`}
              className="w-full resize-none border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
            />

            {includeCode && (
              <textarea
                rows={3}
                value={newCodeText}
                onChange={(e) => setNewCodeText(e.target.value)}
                placeholder="// Enter code snippet..."
                className="w-full resize-none border border-[var(--border)] bg-[var(--surface-solid)] p-2 font-mono text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
              />
            )}

            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => setIncludeCode(!includeCode)}
                className={cn(
                  "flex items-center gap-1 font-mono text-xs transition-colors",
                  includeCode ? "text-[var(--blue)]" : "text-[var(--text-3)] hover:text-[var(--text)]"
                )}
              >
                <CodeIcon className="h-3.5 w-3.5" />
                <span>{includeCode ? "Remove Code Block" : "Attach Code"}</span>
              </button>

              <button
                type="submit"
                disabled={!newMessageText.trim() && !newCodeText.trim()}
                className="btn-shell btn-primary-shell btn-shell-sm"
              >
                <span className="btn-core">
                  <SendIcon className="h-3 w-3" /> Post
                </span>
              </button>
            </div>
          </form>
        </div>

        {/* Right: Peers Online & Guidelines */}
        <div className="space-y-4">
          <div className="panel clip-oct p-4">
            <p className="mono-label text-[10px] text-[var(--blue)]">
              SCHOOL PEERS ONLINE
            </p>
            <div className="mt-3 space-y-2">
              {[
                { name: "Farid Bulega", role: "Rank #14", status: "In Practice" },
                { name: "Sarah K.", role: "Rank #2", status: "Coding" },
                { name: "Daniel O.", role: "Rank #3", status: "Reviewing" },
                { name: "Meera D.", role: "Rank #6", status: "In Daily" },
              ].map((peer, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs">
                  <div>
                    <p className="font-semibold text-[var(--text)]">{peer.name}</p>
                    <p className="font-mono text-[10px] text-[var(--text-3)]">{peer.role}</p>
                  </div>
                  <span className="flex items-center gap-1 font-mono text-[10px] text-[#5DD39E]">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#5DD39E]" />
                    {peer.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="panel clip-oct p-4 text-xs">
            <p className="mono-label text-[10px] text-[var(--text-3)]">
              COMMUNITY GUIDELINES
            </p>
            <p className="mt-2 text-[var(--text-2)]">
              • No sharing direct solutions during live competition rounds.
              <br />
              • Respect all schools and competitors.
              <br />
              • Format code using backticks for readability.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
