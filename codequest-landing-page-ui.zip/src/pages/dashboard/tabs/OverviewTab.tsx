import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "../../../utils/cn";
import { currentStudent } from "../../../data/dashboardData";
import { getQuestion, usePractice } from "../../../lib/practiceStore";
import { OctagonNode, Reveal, useAnimatedNumber, useInView } from "../../../components/ui";
import {
  FlameIcon,
  TrophyIcon,
  SparklesIcon,
  BookOpenIcon,
  ArrowRight,
  PlayIcon,
  CheckIcon,
  ClockIcon,
  CodeIcon,
  MegaphoneIcon,
  UploadCloudIcon,
  UsersIcon,
} from "../../../components/icons";

/* ══════════════════════════════════════════════════════════
   MOCK ANALYTICS
   ══════════════════════════════════════════════════════════ */

type Point = { label: string; value: number };

const xpSeries: Record<"7" | "30" | "all", Point[]> = {
  "7": [
    { label: "Mon", value: 40 },
    { label: "Tue", value: 85 },
    { label: "Wed", value: 60 },
    { label: "Thu", value: 130 },
    { label: "Fri", value: 95 },
    { label: "Sat", value: 175 },
    { label: "Sun", value: 210 },
  ],
  "30": [
    { label: "W1", value: 180 },
    { label: "W1", value: 260 },
    { label: "W2", value: 220 },
    { label: "W2", value: 340 },
    { label: "W3", value: 410 },
    { label: "W3", value: 380 },
    { label: "W4", value: 520 },
    { label: "W4", value: 610 },
    { label: "Now", value: 700 },
  ],
  all: [
    { label: "Sep", value: 120 },
    { label: "Oct", value: 340 },
    { label: "Nov", value: 520 },
    { label: "Dec", value: 480 },
    { label: "Jan", value: 890 },
    { label: "Feb", value: 1420 },
    { label: "Now", value: 2480 },
  ],
};

const solvedSeries: Record<"7" | "30" | "all", Point[]> = {
  "7": [
    { label: "Mon", value: 1 },
    { label: "Tue", value: 3 },
    { label: "Wed", value: 2 },
    { label: "Thu", value: 5 },
    { label: "Fri", value: 4 },
    { label: "Sat", value: 7 },
    { label: "Sun", value: 9 },
  ],
  "30": [
    { label: "W1", value: 8 },
    { label: "W1", value: 14 },
    { label: "W2", value: 12 },
    { label: "W2", value: 22 },
    { label: "W3", value: 28 },
    { label: "W3", value: 31 },
    { label: "W4", value: 44 },
    { label: "W4", value: 51 },
    { label: "Now", value: 58 },
  ],
  all: [
    { label: "Sep", value: 4 },
    { label: "Oct", value: 18 },
    { label: "Nov", value: 34 },
    { label: "Dec", value: 41 },
    { label: "Jan", value: 78 },
    { label: "Feb", value: 104 },
    { label: "Now", value: 126 },
  ],
};


const practiceBreakdown = [
  { label: "Daily Questions", xp: 180, color: "var(--blue)" },
  { label: "Coding Practice", xp: 140, color: "#5DD39E" },
  { label: "MCQ Practice", xp: 60, color: "#F2C94C" },
  { label: "System Design", xp: 40, color: "#9199A6" },
];

const weeklyActivity = [45, 70, 35, 90, 60, 100, 80];

const learningPaths = [
  {
    id: "py-fund",
    title: "Python Fundamentals",
    lesson: "Lesson 08 — Functions & Scope",
    progress: 68,
    remaining: "12 min remaining",
    accent: "var(--blue)",
  },
  {
    id: "algo-101",
    title: "Competitive Problem Solving",
    lesson: "Lesson 05 — Dijkstra & Shortest Paths",
    progress: 42,
    remaining: "26 min remaining",
    accent: "#5DD39E",
  },
  {
    id: "sys-design",
    title: "System Design Essentials",
    lesson: "Lesson 02 — Normalization & Indexing",
    progress: 20,
    remaining: "38 min remaining",
    accent: "#F2C94C",
  },
];

const recentActivity = [
  { icon: "book", title: "Completed Python Functions", meta: "+25 XP", time: "08:14", tone: "#5DD39E" },
  { icon: "code", title: "Solved Daily Challenge", meta: "+10 XP", time: "07:42", tone: "var(--blue)" },
  { icon: "upload", title: "Submitted System Design Project", meta: "Awaiting Review", time: "Yesterday", tone: "#F2C94C" },
  { icon: "users", title: "Joined Python Practice Room", meta: "#python-mastery", time: "Yesterday", tone: "var(--text-2)" },
  { icon: "spark", title: 'Earned "7 Day Streak" achievement', meta: "+120 XP", time: "2 days ago", tone: "#FF6B6B" },
];

const announcementsFeed = [
  { cat: "Competition", title: "CodeQuest Regional Competition Opens Friday", time: "2 hours ago", unread: true },
  { cat: "Course Update", title: "New Python Course Module Available", time: "Yesterday", unread: true },
  { cat: "Submission", title: "System Design Submissions Reviewed", time: "2 days ago", unread: false },
];

/* ══════════════════════════════════════════════════════════
   LEVEL MATH
   ══════════════════════════════════════════════════════════ */

const XP_PER_LEVEL = 250;

function levelFromXp(xp: number) {
  return Math.floor(xp / XP_PER_LEVEL) + 1;
}

function levelTitle(level: number) {
  if (level <= 3) return "Novice";
  if (level <= 6) return "Apprentice";
  if (level <= 9) return "Builder";
  if (level <= 12) return "Advanced Beginner";
  if (level <= 15) return "Architect";
  return "Master";
}

function greetingForHour() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

/* ══════════════════════════════════════════════════════════
   PROGRESS CHART (hand-built SVG, CodeQuest design language)
   ══════════════════════════════════════════════════════════ */

function ProgressChart({
  data,
  metricLabel,
  unit,
}: {
  data: Point[];
  metricLabel: string;
  unit: string;
}) {
  const { ref, inView } = useInView<HTMLDivElement>(0.25);
  const [hover, setHover] = useState<number | null>(null);

  const W = 640;
  const H = 210;
  const P = { t: 14, r: 14, b: 24, l: 38 };
  const iw = W - P.l - P.r;
  const ih = H - P.t - P.b;

  const max = Math.max(...data.map((d) => d.value));
  const niceMax = Math.ceil(max / 100) * 100 || 100;

  const pts = data.map((d, i) => {
    const x = P.l + (data.length === 1 ? iw / 2 : (i / (data.length - 1)) * iw);
    const y = P.t + ih - (d.value / niceMax) * ih;
    return { x, y, ...d };
  });

  let line = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1];
    const b = pts[i];
    const mx = (a.x + b.x) / 2;
    line += ` C ${mx} ${a.y}, ${mx} ${b.y}, ${b.x} ${b.y}`;
  }
  const area = `${line} L ${pts[pts.length - 1].x} ${P.t + ih} L ${pts[0].x} ${P.t + ih} Z`;

  const gridLines = [0, 0.25, 0.5, 0.75, 1];

  const onMove = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const vx = ((e.clientX - rect.left) / rect.width) * W;
    let best = 0;
    let bestD = Infinity;
    pts.forEach((p, i) => {
      const d = Math.abs(p.x - vx);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    });
    setHover(best);
  };

  const active = hover !== null ? pts[hover] : null;

  return (
    <div ref={ref} className="relative">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="h-auto w-full touch-none"
        onMouseMove={onMove}
        onMouseLeave={() => setHover(null)}
      >
        <defs>
          <linearGradient id="cqAreaFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--blue)" stopOpacity="0.32" />
            <stop offset="100%" stopColor="var(--blue)" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* Grid */}
        {gridLines.map((g) => {
          const y = P.t + ih * g;
          return (
            <g key={g}>
              <line
                x1={P.l}
                x2={W - P.r}
                y1={y}
                y2={y}
                stroke="var(--border)"
                strokeWidth="1"
                strokeDasharray={g === 1 ? "0" : "3 5"}
              />
              <text
                x={P.l - 8}
                y={y + 3.5}
                textAnchor="end"
                className="font-mono"
                fontSize="9"
                fill="var(--text-3)"
              >
                {Math.round(niceMax * (1 - g))}
              </text>
            </g>
          );
        })}

        {/* Area + line (animated draw on reveal) */}
        <path
          d={area}
          fill="url(#cqAreaFill)"
          style={{
            opacity: inView ? 1 : 0,
            transition: "opacity 900ms ease 350ms",
          }}
        />
        <path
          d={line}
          fill="none"
          stroke="var(--blue)"
          strokeWidth="2.25"
          strokeLinecap="round"
          pathLength={1}
          strokeDasharray="1"
          style={{
            strokeDashoffset: inView ? 0 : 1,
            transition: "stroke-dashoffset 1500ms cubic-bezier(0.22,1,0.36,1)",
            filter: "drop-shadow(0 3px 10px var(--glow))",
          }}
        />

        {/* X labels */}
        {pts.map((p, i) => (
          <text
            key={i}
            x={p.x}
            y={H - 6}
            textAnchor="middle"
            className="font-mono"
            fontSize="9"
            fill={hover === i ? "var(--blue)" : "var(--text-3)"}
          >
            {p.label}
          </text>
        ))}

        {/* Nodes */}
        {pts.map((p, i) => (
          <g key={`n-${i}`}>
            <circle
              cx={p.x}
              cy={p.y}
              r={hover === i ? 4.5 : 2.5}
              fill="var(--surface-solid)"
              stroke="var(--blue)"
              strokeWidth="2"
              style={{ transition: "r 160ms ease" }}
            />
          </g>
        ))}

        {/* Crosshair + readout */}
        {active && (
          <g>
            <line
              x1={active.x}
              x2={active.x}
              y1={P.t}
              y2={P.t + ih}
              stroke="var(--blue)"
              strokeWidth="1"
              strokeDasharray="2 4"
              opacity="0.55"
            />
            <g
              transform={`translate(${Math.min(Math.max(active.x, P.l + 46), W - P.r - 46)}, ${Math.max(active.y - 14, P.t + 10)})`}
            >
              <rect x="-45" y="-16" width="90" height="24" rx="2" fill="var(--surface-solid)" stroke="var(--blue)" strokeWidth="1" />
              <text textAnchor="middle" y="0" className="font-mono" fontSize="10" fill="var(--text)">
                {active.value.toLocaleString()} {unit}
              </text>
            </g>
          </g>
        )}
      </svg>

      <p className="mono-label mt-1 text-[10px]">
        {metricLabel} · {data.length} data points
      </p>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   COMPACT METRIC
   ══════════════════════════════════════════════════════════ */

function Metric({
  label,
  value,
  suffix,
  animate,
}: {
  label: string;
  value: number;
  suffix?: string;
  animate?: boolean;
}) {
  const shown = useAnimatedNumber(animate ? value : value, 1100);
  return (
    <div className="border-l border-[var(--border)] pl-3">
      <p className="mono-label text-[9.5px]">{label}</p>
      <p className="display mt-1 text-lg font-bold tracking-tight text-[var(--text)]">
        {shown.toLocaleString()}
        {suffix && <span className="ml-0.5 text-[11px] font-normal text-[var(--text-3)]">{suffix}</span>}
      </p>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   MAIN DASHBOARD
   ══════════════════════════════════════════════════════════ */

/** The dashboard's daily question is a real archive entry, graded by the same runner. */
const QOTD_ID = "first-duplicate";

export default function OverviewTab({
  onNavigate,
  onOpenQuestion,
}: {
  onNavigate: (tab: string) => void;
  onOpenQuestion: (questionId: string) => void;
}) {
  const qod = getQuestion(QOTD_ID);

  /* ---- countdown to next daily reset (starts 08:42:16) ---- */
  const [resetLeft, setResetLeft] = useState(8 * 3600 + 42 * 60 + 16);
  useEffect(() => {
    const t = window.setInterval(() => setResetLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => window.clearInterval(t);
  }, []);
  const resetClock = useMemo(() => {
    const h = Math.floor(resetLeft / 3600);
    const m = Math.floor((resetLeft % 3600) / 60);
    const s = resetLeft % 60;
    return [h, m, s].map((n) => String(n).padStart(2, "0")).join(":");
  }, [resetLeft]);

  /* ---- competition countdown (2D 04H 18M from mount) ---- */
  const compTarget = useRef(Date.now() + (2 * 24 * 3600 + 4 * 3600 + 18 * 60) * 1000);
  const [compLeft, setCompLeft] = useState(compTarget.current - Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setCompLeft(Math.max(0, compTarget.current - Date.now())), 1000);
    return () => window.clearInterval(t);
  }, []);
  const comp = useMemo(() => {
    const d = Math.floor(compLeft / 86400000);
    const h = Math.floor((compLeft % 86400000) / 3600000);
    const m = Math.floor((compLeft % 3600000) / 60000);
    const s = Math.floor((compLeft % 60000) / 1000);
    return { d, h, m, s };
  }, [compLeft]);
  const compRegistered = true;
  const compLive = false;

  /* ---- chart controls ---- */
  const [range, setRange] = useState<"7" | "30" | "all">("7");
  const [metric, setMetric] = useState<"xp" | "solved">("xp");

  const chartData = metric === "xp" ? xpSeries[range] : solvedSeries[range];

  /* ---- shared practice state: verdict, XP and rank all come from the runner ---- */
  const { rank: schoolRank, stats, totalXp: bankedXp, statuses, attempts, best } = usePractice();
  const leaderboardRows = schoolRank.board;
  const challengeDone = (statuses[QOTD_ID] ?? qod?.status) === "COMPLETED";
  const qodAttempts = attempts[QOTD_ID] ?? 0;
  const qodBest = best[QOTD_ID];

  const { ref: rankRef, inView: rankIn } = useInView<HTMLDivElement>(0.4);
  const rankShown = useAnimatedNumber(rankIn ? schoolRank.position : 0, 1200);

  const totalXp = useAnimatedNumber(bankedXp, 1000);
  const solved = useAnimatedNumber(stats.solved, 1000);

  const level = levelFromXp(totalXp);
  const xpIntoLevel = totalXp % XP_PER_LEVEL;
  const levelPercent = Math.round((xpIntoLevel / XP_PER_LEVEL) * 100);

  const firstName = currentStudent.name.split(" ")[0];

  const activityIcon: Record<string, React.ComponentType<{ className?: string }>> = {
    book: BookOpenIcon,
    code: CodeIcon,
    upload: UploadCloudIcon,
    users: UsersIcon,
    spark: SparklesIcon,
  };

  return (
    <div className="space-y-7">
      {/* ═══════════ GREETING HERO ═══════════ */}
      <Reveal>
        <div className="flex flex-col justify-between gap-5 border-b border-[var(--border)] pb-6 lg:flex-row lg:items-end">
          <div className="min-w-0">
            <p className="mono-label flex items-center gap-2 text-[var(--blue)]">
              <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />
              Student Command Center
            </p>
            <h1 className="display mt-1.5 text-[1.7rem] font-bold leading-tight tracking-tight sm:text-4xl">
              {greetingForHour()}, {firstName}.
            </h1>
            <p className="display mt-1 text-base font-semibold text-[var(--text)] sm:text-lg">
              Ready for today's challenge?
            </p>
            <p className="mt-2 max-w-lg text-[13px] leading-relaxed text-[var(--text-2)]">
              Keep building your skills. Every problem you solve moves you
              closer to the top.
            </p>
          </div>

          {/* Streak + Level status */}
          <div className="flex shrink-0 gap-3">
            <div className="clip-oct flex items-center gap-3 border border-[#FF6B6B]/35 bg-[#FF6B6B]/[0.07] px-4 py-2.5">
              <FlameIcon className="h-5 w-5 text-[#FF6B6B]" />
              <div>
                <p className="mono-label text-[9px]">Current Streak</p>
                <p className="display text-lg font-bold leading-none text-[#FF6B6B]">
                  {currentStudent.streakDays} <span className="text-[11px] font-normal">DAYS</span>
                </p>
              </div>
            </div>

            <div className="clip-oct flex items-center gap-3 border border-[var(--blue)]/35 bg-[var(--blue-soft)] px-4 py-2.5">
              <div>
                <p className="mono-label text-[9px]">Level {level}</p>
                <p className="display text-lg font-bold leading-none text-[var(--blue)]">
                  {levelTitle(level)}
                </p>
                <div className="mt-1.5 h-0.5 w-24 overflow-hidden bg-[var(--border)]">
                  <div
                    className="h-full bg-[var(--blue)] transition-all duration-700"
                    style={{ width: `${levelPercent}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {/* ═══════════ ROW 1 — QUESTION OF THE DAY + SCHOOL RANK ═══════════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        {/* QUESTION OF THE DAY */}
        <Reveal className="lg:col-span-8">
          <div
            className={cn(
              "clip-oct relative h-full overflow-hidden border p-5 transition-all duration-500 sm:p-6",
              challengeDone
                ? "border-[#5DD39E]/50 bg-[#5DD39E]/[0.05]"
                : "border-[var(--blue)]/45 bg-gradient-to-br from-[var(--surface-solid)] via-[var(--surface-solid)] to-[var(--blue-soft)]"
            )}
          >
            <span
              aria-hidden="true"
              className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[var(--blue)] to-transparent"
            />

            {!challengeDone ? (
              <>
                <div className="flex flex-wrap items-center gap-3">
                  <span className="mono-label flex items-center gap-2 text-[var(--blue)]">
                    <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
                    Question of the Day
                  </span>
                  <span className="font-mono text-[11px] text-[var(--text-3)]">
                    resets in <span className="font-semibold text-[var(--text)] tabular-nums">{resetClock}</span>
                  </span>
                </div>

                <h2 className="display mt-3 text-xl font-bold tracking-tight sm:text-2xl">
                  Can you solve this in under 5 minutes?
                </h2>
                <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-[var(--text-2)]">
                  Given an array of integers, find the <strong className="text-[var(--text)]">first duplicate
                  value</strong> without using additional storage.
                </p>

                <div className="mt-4 flex flex-wrap items-center gap-2">
                  {[
                    (qod?.languages[0] ?? "python").toUpperCase(),
                    qod?.category ?? "Algorithms",
                    `+${qod?.points ?? 10} XP`,
                    `${qod?.estMinutes ?? 5} min`,
                  ].map((m) => (
                    <span
                      key={m}
                      className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-2)] px-2.5 py-0.5 font-mono text-[10.5px] text-[var(--text-2)]"
                    >
                      {m}
                    </span>
                  ))}
                </div>

                <div className="mt-5 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <button
                    onClick={() => onOpenQuestion(QOTD_ID)}
                    className="btn-shell btn-primary-shell btn-shell-lg w-full sm:w-auto"
                  >
                    <span className="btn-core">
                      Solve Today's Question <ArrowRight className="h-4 w-4" />
                    </span>
                  </button>

                  {/* Completion indicator */}
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="mono-label text-[9.5px]">Today's challenge</p>
                      <p className="font-mono text-xs text-[var(--text)]">
                        {qodAttempts > 0 ? `attempt ${qodAttempts + 1} · ` : ""}0 / 1 completed
                      </p>
                    </div>
                    <OctagonNode size={34}>
                      <span className="font-mono text-[10px]">0/1</span>
                    </OctagonNode>
                  </div>
                </div>

                <p className="mono-label mt-4 flex items-center gap-2 text-[9.5px] opacity-70">
                  <span className="h-1 w-1 rotate-45 bg-[var(--blue)]" />
                  graded live by the archive runner · {qodBest === undefined ? "no score banked yet" : `best ${qodBest}%`}
                </p>
              </>
            ) : (
              <div className="panel-in">
                <div className="flex items-center gap-3">
                  <OctagonNode active size={40}>
                    <CheckIcon className="h-5 w-5" />
                  </OctagonNode>
                  <span className="mono-label text-[#5DD39E]">Challenge Complete</span>
                </div>
                <h2 className="display mt-4 text-xl font-bold tracking-tight text-[#5DD39E] sm:text-2xl">
                  +{qod?.points ?? 10} XP earned
                </h2>
                <p className="mt-2 max-w-lg text-[13px] leading-relaxed text-[var(--text-2)]">
                  First duplicate found in <span className="font-mono text-[var(--text)]">O(n) time</span> with
                  constant space. Your streak continues — come back tomorrow for a harder set.
                </p>
                <div className="mt-5 flex flex-wrap gap-2.5">
                  <button
                    onClick={() => onOpenQuestion(QOTD_ID)}
                    className="btn-shell btn-primary-shell btn-shell-md"
                  >
                    <span className="btn-core">
                      View Solution Breakdown <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </button>
                  <button
                    onClick={() => onOpenQuestion(QOTD_ID)}
                    className="btn-shell btn-ghost-shell btn-shell-md"
                  >
                    <span className="btn-core">Open in workspace</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </Reveal>

        {/* SCHOOL RANK */}
        <Reveal delay={90} className="lg:col-span-4">
          <div ref={rankRef} className="panel clip-oct flex h-full flex-col p-5">
            <div className="flex items-start justify-between">
              <span className="mono-label flex items-center gap-2">
                <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
                Your School Rank
              </span>
              <TrophyIcon className="h-4 w-4 text-[#F2C94C]" />
            </div>

            <div className="mt-4 flex items-end gap-3">
              <span className="display text-5xl font-bold leading-none tracking-tighter text-[var(--text)]">
                #{String(rankShown).padStart(2, "0")}
              </span>
              <div className="pb-1">
                <span className="clip-oct-sm border border-[#5DD39E]/50 bg-[#5DD39E]/10 px-2 py-0.5 font-mono text-[10px] font-bold text-[#5DD39E]">
                  TOP {Math.max(1, Math.round((schoolRank.position / currentStudent.schoolTotal) * 100))}%
                </span>
                <p className="mt-1.5 font-mono text-[11px] text-[var(--text-3)]">
                  {totalXp.toLocaleString()} XP
                </p>
              </div>
            </div>

            {/* Mini leaderboard */}
            <div className="mt-5 space-y-1 border-t border-[var(--border)] pt-3">
              {leaderboardRows.map((row) => (
                <div
                  key={row.rank}
                  className={cn(
                    "grid grid-cols-[1.6rem_1fr_4.2rem] items-center gap-2 border px-2 py-1.5 text-xs transition-colors",
                    row.you
                      ? "border-[var(--blue)] bg-[var(--blue-soft)]"
                      : "border-transparent hover:bg-[var(--surface-2)]"
                  )}
                >
                  <span
                    className={cn(
                      "font-mono text-[11px]",
                      row.you ? "font-bold text-[var(--blue)]" : "text-[var(--text-3)]"
                    )}
                  >
                    {String(row.rank).padStart(2, "0")}
                  </span>
                  <span
                    className={cn(
                      "truncate",
                      row.you
                        ? "font-display font-bold text-[var(--text)]"
                        : "text-[var(--text-2)]"
                    )}
                  >
                    {row.name}
                    {row.you && (
                      <span className="ml-1.5 font-mono text-[9px] text-[var(--blue)]">YOU</span>
                    )}
                  </span>
                  <span
                    className={cn(
                      "text-right font-mono text-[11px] tabular-nums",
                      row.you ? "font-bold text-[var(--blue)]" : "text-[var(--text-2)]"
                    )}
                  >
                    {row.xp.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>

            <button
              onClick={() => onNavigate("competitions")}
              className="mt-auto flex items-center justify-between pt-4 font-display text-xs font-semibold text-[var(--blue)] transition-opacity hover:opacity-75"
            >
              View Full Leaderboard <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </Reveal>
      </div>

      {/* ═══════════ ROW 2 — PROGRESS CHART + PRACTICE POINTS ═══════════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        {/* PROGRESS */}
        <Reveal className="lg:col-span-8">
          <div className="panel clip-oct h-full p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <span className="mono-label flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
                  Progress Overview
                </span>
                <h2 className="display mt-1 text-base font-bold tracking-tight sm:text-lg">
                  {metric === "xp" ? "XP Progress" : "Problems Solved"}
                </h2>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* metric switch */}
                <div className="clip-oct-sm flex border border-[var(--border)] p-0.5">
                  {(
                    [
                      { id: "xp", label: "XP" },
                      { id: "solved", label: "Solved" },
                    ] as const
                  ).map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setMetric(m.id)}
                      className={cn(
                        "clip-oct-sm px-2.5 py-1 font-mono text-[10.5px] uppercase transition-colors",
                        metric === m.id
                          ? "bg-[var(--blue)] text-white"
                          : "text-[var(--text-3)] hover:text-[var(--text)]"
                      )}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>

                {/* range switch */}
                <div className="clip-oct-sm flex border border-[var(--border)] p-0.5">
                  {(
                    [
                      { id: "7", label: "7 Days" },
                      { id: "30", label: "30 Days" },
                      { id: "all", label: "All Time" },
                    ] as const
                  ).map((r) => (
                    <button
                      key={r.id}
                      onClick={() => setRange(r.id)}
                      className={cn(
                        "clip-oct-sm px-2.5 py-1 font-mono text-[10.5px] uppercase transition-colors",
                        range === r.id
                          ? "bg-[var(--blue)] text-white"
                          : "text-[var(--text-3)] hover:text-[var(--text)]"
                      )}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-4">
              <ProgressChart
                key={`${metric}-${range}`}
                data={chartData}
                metricLabel={metric === "xp" ? "Experience earned" : "Problems solved"}
                unit={metric === "xp" ? "XP" : "solved"}
              />
            </div>

            {/* Compact metrics */}
            <div className="mt-4 grid grid-cols-2 gap-4 border-t border-[var(--border)] pt-4 sm:grid-cols-4">
              <Metric label="Total XP" value={totalXp} animate />
              <Metric label="Problems Solved" value={solved} animate />
              <Metric label="Current Streak" value={currentStudent.streakDays} suffix="days" />
              <Metric label="Accuracy" value={stats.successRate} suffix="%" />
            </div>
          </div>
        </Reveal>

        {/* PRACTICE POINTS */}
        <Reveal delay={90} className="lg:col-span-4">
          <div className="panel clip-oct flex h-full flex-col p-5">
            <span className="mono-label flex items-center gap-2">
              <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
              Practice Performance
            </span>

            <div className="mt-4">
              <p className="display text-4xl font-bold leading-none tracking-tighter text-[var(--blue)]">
                +420 <span className="text-sm font-normal text-[var(--text-3)]">XP</span>
              </p>
              <p className="mt-1.5 text-[12.5px] text-[var(--text-2)]">
                earned from practice this week
              </p>
            </div>

            {/* Breakdown */}
            <div className="mt-5 space-y-2.5 border-t border-[var(--border)] pt-4">
              {practiceBreakdown.map((b) => {
                const pct = Math.round((b.xp / 420) * 100);
                return (
                  <div key={b.label}>
                    <div className="flex items-baseline justify-between font-mono text-[11px]">
                      <span className="text-[var(--text-2)]">{b.label}</span>
                      <span className="font-semibold" style={{ color: b.color }}>
                        +{b.xp}
                      </span>
                    </div>
                    <div className="mt-1 h-1 w-full overflow-hidden bg-[var(--border)]">
                      <div
                        className="h-full transition-all duration-700"
                        style={{ width: `${pct}%`, backgroundColor: b.color }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Weekly activity bars */}
            <div className="mt-5 border-t border-[var(--border)] pt-4">
              <p className="mono-label mb-3 text-[9.5px]">Weekly Activity</p>
              <div className="flex h-16 items-end gap-1.5">
                {weeklyActivity.map((v, i) => (
                  <div key={i} className="group flex flex-1 flex-col items-center gap-1">
                    <div
                      className={cn(
                        "w-full transition-all duration-500 group-hover:opacity-100",
                        i === 6 ? "bg-[var(--blue)]" : "bg-[var(--border-strong)] group-hover:bg-[var(--blue)]"
                      )}
                      style={{ height: `${v}%` }}
                    />
                    <span className="font-mono text-[8px] text-[var(--text-3)]">
                      {["M", "T", "W", "T", "F", "S", "S"][i]}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <p className="mt-auto pt-4 font-mono text-[10px] leading-relaxed text-[var(--text-3)]">
              Practice contributes directly to your CodeQuest rank.
            </p>
          </div>
        </Reveal>
      </div>

      {/* ═══════════ ROW 3 — UPCOMING COMPETITION + CONTINUE LEARNING ═══════════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        {/* UPCOMING COMPETITION */}
        <Reveal className="lg:col-span-5">
          <div
            className={cn(
              "clip-oct flex h-full flex-col border p-5",
              compLive
                ? "border-[#5DD39E]/50 bg-[#5DD39E]/[0.05]"
                : "panel"
            )}
          >
            <div className="flex items-start justify-between gap-2">
              <span className="mono-label flex items-center gap-2">
                <TrophyIcon className="h-3.5 w-3.5 text-[var(--blue)]" />
                Upcoming Competition
              </span>
              <span
                className={cn(
                  "clip-oct-sm px-2 py-0.5 font-mono text-[9.5px] font-bold",
                  compLive
                    ? "bg-[#5DD39E] text-black"
                    : compRegistered
                    ? "border border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]"
                    : "border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)]"
                )}
              >
                {compLive ? "⬡ LIVE" : compRegistered ? "REGISTERED" : "OPEN"}
              </span>
            </div>

            <h2 className="display mt-3 text-lg font-bold uppercase leading-tight tracking-tight sm:text-xl">
              CodeQuest Weekly Sprint
            </h2>
            <p className="mt-1 text-[13px] font-semibold text-[var(--text-2)]">
              Python Algorithms
            </p>

            <div className="mt-4 grid grid-cols-3 gap-2 border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-center">
              {[
                { v: "SAT 14:00", l: "STARTS" },
                { v: "45 MIN", l: "LENGTH" },
                { v: "120", l: "CODERS" },
              ].map((c) => (
                <div key={c.l}>
                  <p className="display text-[11px] font-bold text-[var(--text)] sm:text-xs">{c.v}</p>
                  <p className="mono-label mt-0.5 text-[8.5px]">{c.l}</p>
                </div>
              ))}
            </div>

            {/* Countdown */}
            <div className="mt-4">
              <p className="mono-label mb-2 text-[9.5px]">
                {compLive ? "Closes in" : "Begins in"}
              </p>
              <div className="flex items-end gap-1.5 font-mono">
                {[
                  { v: comp.d, l: "D" },
                  { v: comp.h, l: "H" },
                  { v: comp.m, l: "M" },
                  { v: comp.s, l: "S" },
                ].map((c) => (
                  <div key={c.l} className="clip-oct-sm flex-1 border border-[var(--border)] bg-[var(--surface-2)] px-1 py-2 text-center">
                    <span className="display block text-lg font-bold leading-none tabular-nums text-[var(--text)]">
                      {String(c.v).padStart(2, "0")}
                    </span>
                    <span className="mt-1 block text-[8.5px] text-[var(--text-3)]">{c.l}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-5 border-t border-[var(--border)] pt-4">
              <button
                onClick={() => onNavigate("competitions")}
                className={cn(
                  "btn-shell w-full",
                  compLive ? "btn-primary-shell" : compRegistered ? "btn-ghost-shell" : "btn-primary-shell",
                  "btn-shell-md"
                )}
              >
                <span className="btn-core">
                  {compLive ? (
                    <>
                      <PlayIcon className="h-3.5 w-3.5" /> Enter Competition
                    </>
                  ) : compRegistered ? (
                    <>
                      View Competition <ArrowRight className="h-3.5 w-3.5" />
                    </>
                  ) : (
                    <>
                      Register Now <ArrowRight className="h-3.5 w-3.5" />
                    </>
                  )}
                </span>
              </button>
            </div>
          </div>
        </Reveal>

        {/* CONTINUE LEARNING */}
        <Reveal delay={90} className="lg:col-span-7">
          <div className="panel clip-oct flex h-full flex-col p-5">
            <div className="flex items-center justify-between">
              <span className="mono-label flex items-center gap-2">
                <BookOpenIcon className="h-3.5 w-3.5 text-[var(--blue)]" />
                Continue Learning
              </span>
              <button
                onClick={() => onNavigate("courses")}
                className="font-mono text-[11px] text-[var(--text-3)] transition-colors hover:text-[var(--blue)]"
              >
                All courses →
              </button>
            </div>

            {/* Featured path */}
            <div className="mt-4 border border-[var(--border)] bg-[var(--surface-2)] p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="mono-label text-[10px] text-[var(--blue)]">Python Fundamentals</p>
                  <h3 className="display mt-1 text-base font-bold tracking-tight sm:text-lg">
                    Lesson 08 — Functions &amp; Scope
                  </h3>
                  <p className="mt-1 font-mono text-[11px] text-[var(--text-3)]">
                    68% · 12 min remaining
                  </p>
                </div>
                <button
                  onClick={() => onNavigate("courses")}
                  className="btn-shell btn-primary-shell btn-shell-md shrink-0"
                >
                  <span className="btn-core">
                    Continue Lesson <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </button>
              </div>
              <div className="mt-3 h-1.5 w-full overflow-hidden bg-[var(--border)]">
                <div
                  className="h-full bg-[var(--blue)] transition-all duration-1000"
                  style={{ width: "68%" }}
                />
              </div>
            </div>

            {/* Horizontal scroll learning paths */}
            <div className="mt-4 flex gap-3 overflow-x-auto pb-2">
              {learningPaths.map((p) => (
                <button
                  key={p.id}
                  onClick={() => onNavigate("courses")}
                  className="group w-[240px] shrink-0 border border-[var(--border)] bg-[var(--surface-solid)] p-3 text-left transition-all duration-300 hover:-translate-y-0.5 hover:border-[var(--blue)]"
                >
                  <div className="flex items-center justify-between">
                    <span
                      className="clip-oct-sm px-1.5 py-0.5 font-mono text-[9px] font-bold"
                      style={{ color: p.accent, border: `1px solid ${p.accent}` }}
                    >
                      {p.progress}%
                    </span>
                    <ArrowRight className="h-3.5 w-3.5 text-[var(--text-3)] transition-transform group-hover:translate-x-0.5 group-hover:text-[var(--blue)]" />
                  </div>
                  <h4 className="display mt-2 text-[13px] font-bold leading-tight text-[var(--text)]">
                    {p.title}
                  </h4>
                  <p className="mt-1 truncate font-mono text-[10px] text-[var(--text-3)]">
                    {p.lesson}
                  </p>
                  <div className="mt-2.5 h-1 w-full overflow-hidden bg-[var(--border)]">
                    <div
                      className="h-full transition-all duration-700"
                      style={{ width: `${p.progress}%`, backgroundColor: p.accent }}
                    />
                  </div>
                  <p className="mt-1.5 flex items-center gap-1 font-mono text-[9.5px] text-[var(--text-3)]">
                    <ClockIcon className="h-2.5 w-2.5" />
                    {p.remaining}
                  </p>
                </button>
              ))}
            </div>
          </div>
        </Reveal>
      </div>

      {/* ═══════════ ROW 4 — ACTIVITY + ANNOUNCEMENTS ═══════════ */}
      <div className="grid gap-5 lg:grid-cols-12">
        {/* RECENT ACTIVITY */}
        <Reveal className="lg:col-span-7">
          <div className="panel clip-oct h-full p-5">
            <div className="flex items-center justify-between">
              <span className="mono-label flex items-center gap-2">
                <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
                Recent Activity
              </span>
              <button
                onClick={() => onNavigate("submissions")}
                className="font-mono text-[11px] text-[var(--text-3)] transition-colors hover:text-[var(--blue)]"
              >
                All submissions →
              </button>
            </div>

            {/* Timeline */}
            <div className="relative mt-4 pl-1">
              <div
                className="absolute bottom-2 left-[15px] top-2 w-px bg-[var(--border)]"
                aria-hidden="true"
              />
              <div className="space-y-3.5">
                {recentActivity.map((a, i) => {
                  const Icon = activityIcon[a.icon] ?? CodeIcon;
                  return (
                    <div key={i} className="relative flex items-start gap-3.5">
                      <span
                        className={cn(
                          "clip-oct-sm z-10 flex h-8 w-8 shrink-0 items-center justify-center border bg-[var(--surface-solid)]",
                          a.tone === "var(--text-2)"
                            ? "border-[var(--border-strong)] text-[var(--text-2)]"
                            : "border-[var(--border-strong)]"
                        )}
                        style={a.tone === "var(--text-2)" ? undefined : { color: a.tone, borderColor: a.tone }}
                      >
                        <Icon className="h-3.5 w-3.5" />
                      </span>
                      <div className="min-w-0 flex-1 pt-0.5">
                        <p className="truncate text-[13px] font-medium leading-snug text-[var(--text)]">
                          {a.title}
                        </p>
                        <p className="mt-0.5 font-mono text-[10.5px]" style={{ color: a.tone }}>
                          {a.meta}
                          <span className="ml-2 text-[var(--text-3)]">{a.time}</span>
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </Reveal>

        {/* ANNOUNCEMENTS */}
        <Reveal delay={90} className="lg:col-span-5">
          <div className="panel clip-oct flex h-full flex-col p-5">
            <div className="flex items-center justify-between">
              <span className="mono-label flex items-center gap-2">
                <MegaphoneIcon className="h-3.5 w-3.5 text-[var(--blue)]" />
                Latest Announcements
              </span>
              <span className="clip-oct-sm bg-[var(--blue)] px-1.5 py-0.5 font-mono text-[9px] font-bold text-white">
                2 NEW
              </span>
            </div>

            <div className="mt-3 divide-y divide-[var(--border)]">
              {announcementsFeed.map((a) => (
                <button
                  key={a.title}
                  onClick={() => onNavigate("announcements")}
                  className="group flex w-full items-start gap-3 py-3 text-left"
                >
                  <span
                    className={cn(
                      "mt-1.5 h-1.5 w-1.5 shrink-0 rotate-45",
                      a.unread ? "bg-[var(--blue)]" : "bg-[var(--border-strong)]"
                    )}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-medium leading-snug text-[var(--text)] transition-colors group-hover:text-[var(--blue)]">
                      {a.title}
                    </p>
                    <p className="mt-1 font-mono text-[10px] text-[var(--text-3)]">
                      {a.cat} · {a.time}
                    </p>
                  </div>
                </button>
              ))}
            </div>

            <button
              onClick={() => onNavigate("announcements")}
              className="mt-auto flex items-center justify-between border-t border-[var(--border)] pt-3.5 font-display text-xs font-semibold text-[var(--blue)] transition-opacity hover:opacity-75"
            >
              View All Announcements <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </Reveal>
      </div>

      {/* ═══════════ ROW 5 — ACHIEVEMENTS ═══════════ */}
      <Reveal>
        <div className="panel clip-oct p-5">
          <div className="flex items-center justify-between">
            <span className="mono-label flex items-center gap-2">
              <SparklesIcon className="h-3.5 w-3.5 text-[var(--blue)]" />
              Achievements
            </span>
            <button
              onClick={() => onNavigate("profile")}
              className="font-mono text-[11px] text-[var(--text-3)] transition-colors hover:text-[var(--blue)]"
            >
              View collection →
            </button>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { name: "7 DAY STREAK", sub: "Consistency", earned: true },
              { name: "100 PROBLEMS", sub: "Milestone", earned: true },
              { name: "TOP 10 SCHOOL", sub: "Ranking", earned: true },
              { name: "PYTHON BUILDER", sub: "Language", earned: true },
            ].map((b) => (
              <div
                key={b.name}
                className="group flex items-center gap-3 border border-[var(--border)] bg-[var(--surface-2)] p-3 transition-all duration-300 hover:-translate-y-0.5 hover:border-[var(--blue)]"
              >
                <OctagonNode active size={38}>
                  <span className="font-mono text-[11px] font-bold">⬡</span>
                </OctagonNode>
                <div className="min-w-0">
                  <p className="display truncate text-[11.5px] font-bold tracking-tight text-[var(--text)]">
                    {b.name}
                  </p>
                  <p className="font-mono text-[9.5px] text-[var(--text-3)]">{b.sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Reveal>
    </div>
  );
}
