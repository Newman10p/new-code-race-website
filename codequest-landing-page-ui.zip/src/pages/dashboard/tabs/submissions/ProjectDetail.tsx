import { useEffect, useRef, useState, type DragEvent } from "react";
import { cn } from "../../../../utils/cn";
import {
  competitionById, formatBytes, when,
  type CommunityComment, type JudgingStatus, type PatronStatus, type Project,
} from "../../../../data/submissionsData";
import { judgingLock, useSubmissions, type Result } from "../../../../lib/submissionStore";
import { useCommunications } from "../../../../lib/communicationsStore";
import { studentId } from "../../../../data/communicationsData";
import { prefersReducedMotion } from "../../../../lib/grid";
import {
  ArrowLeft, ArrowRight, AwardIcon, CheckIcon, CloseIcon, FileIcon, FlagIcon, GlobeIcon,
  HeartIcon, LockIcon, PaperclipIcon, TrashIcon, UploadCloudIcon,
} from "../../../../components/icons";

export const MINT = "#5DD39E";
export const VIOLET = "#AA8CFF";

const PATRON_TONE: Record<PatronStatus, string> = {
  "NOT SUBMITTED": "var(--text-3)", SUBMITTED: "var(--blue)", "UNDER REVIEW": "#F2C94C",
  "FEEDBACK AVAILABLE": MINT, "REVISION REQUESTED": "#F2C94C", "REVIEW COMPLETED": MINT,
};
const JUDGING_TONE: Record<JudgingStatus, string> = {
  "NOT SUBMITTED": "var(--text-3)", SUBMITTED: "var(--blue)", RECEIVED: "var(--blue)", "QUEUED FOR JUDGING": "var(--blue)",
  "UNDER EVALUATION": "#F2C94C", "JUDGING COMPLETED": "#F2C94C", "RESULTS PUBLISHED": MINT, DISQUALIFIED: "#FF6B6B",
};

export function StatusChip({ label, tone }: { label: string; tone: string }) {
  return (
    <span className="clip-oct-sm inline-flex items-center gap-1.5 whitespace-nowrap border px-2 py-0.5 font-mono text-[9.5px] font-semibold tracking-wider" style={{ borderColor: tone, color: tone }}>
      <span className="h-1 w-1 rotate-45" style={{ background: tone }} />
      {label}
    </span>
  );
}
export const patronChip = (s: PatronStatus) => <StatusChip label={s} tone={PATRON_TONE[s]} />;
export const judgingChip = (s: JudgingStatus) => <StatusChip label={s} tone={JUDGING_TONE[s]} />;

function Timeline({ steps, tone }: { steps: { label: string; at: string }[]; tone: string }) {
  if (!steps.length) return <p className="font-mono text-[10.5px] text-[var(--text-3)]">No activity yet.</p>;
  return (
    <ol className="border-l pl-4" style={{ borderColor: `${tone}66` }}>
      {steps.map((s, i) => (
        <li key={`${s.label}-${i}`} className="relative pb-3 last:pb-0" style={{ animation: prefersReducedMotion() ? "none" : `cq-panel-in 0.4s ${i * 70}ms both` }}>
          <span className="absolute -left-[21px] top-1 h-2 w-2 rotate-45" style={{ background: tone }} />
          <p className="text-[12px] text-[var(--text)]">{s.label}</p>
          <p className="font-mono text-[10px] text-[var(--text-3)]">{when(s.at)}</p>
        </li>
      ))}
    </ol>
  );
}

type Tab = "overview" | "patron" | "judging" | "community" | "versions";

export default function ProjectDetail({ project, onBack, initialTab = "overview" }: { project: Project; onBack: () => void; initialTab?: Tab }) {
  const { setNotifications } = useCommunications();
  const comp = competitionById(project.competitionId)!;
  const cfg = comp.config;
  const [tab, setTab] = useState<Tab>(initialTab);
  const [toast, setToast] = useState<{ text: string; ok: boolean } | null>(null);

  useEffect(() => { if (toast) { const t = window.setTimeout(() => setToast(null), 5000); return () => window.clearTimeout(t); } }, [toast]);

  const notify = (title: string, message: string) =>
    setNotifications((items) => [{
      id: `n-sub-${Date.now()}`, student_id: studentId, type: "submission", source_type: "submission", title, message,
      created_at: new Date().toISOString(), is_read: false, read_at: null, is_archived: false, is_pinned: false,
      action_url: "#/dashboard/user/submissions", related_entity: { type: "project", id: project.id, tab: "submissions" }, priority: "normal",
    }, ...items]);

  const report = (r: Result, success: string) => setToast(r.ok ? { text: success, ok: true } : { text: r.error, ok: false });

  const tabs: { id: Tab; label: string; hidden?: boolean }[] = [
    { id: "overview", label: "Overview" },
    { id: "patron", label: "Patron Review", hidden: !cfg.patron.enabled },
    { id: "judging", label: "Official Judging" },
    { id: "community", label: "Community" },
    { id: "versions", label: `Versions (${project.versions.length})` },
  ];

  return (
    <div className="mx-auto max-w-[1180px] pb-12">
      <button onClick={onBack} className="mono-label inline-flex items-center gap-2 transition-colors hover:text-[var(--blue)]"><ArrowLeft className="h-3 w-3" /> All submissions</button>

      <header className="mt-4 flex flex-wrap items-end justify-between gap-4 border-b border-[var(--border)] pb-5">
        <div className="min-w-0">
          <p className="mono-label text-[var(--blue)]">{comp.name} · {comp.category}</p>
          <h1 className="display mt-1.5 text-2xl font-bold tracking-tight sm:text-3xl">{project.title}</h1>
          <p className="mt-1 font-mono text-[10.5px] text-[var(--text-3)]">Last updated {when(project.updatedAt)} · v{project.versions[project.versions.length - 1].no}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {cfg.patron.enabled && patronChip(project.patron.status)}
          {judgingChip(project.judging.status)}
          <StatusChip label={project.showcase.published ? "PUBLIC" : cfg.showcase.enabled ? "PRIVATE" : "SHARING OFF"} tone={project.showcase.published ? VIOLET : "var(--text-3)"} />
        </div>
      </header>

      <div role="tablist" className="mt-1 flex flex-wrap gap-x-5 border-b border-[var(--border)]">
        {tabs.filter((t) => !t.hidden).map((t) => (
          <button key={t.id} role="tab" aria-selected={tab === t.id} onClick={() => setTab(t.id)}
            className={cn("relative py-3 font-display text-[12.5px] font-semibold transition-colors", tab === t.id ? "text-[var(--text)]" : "text-[var(--text-3)] hover:text-[var(--text)]")}>
            {t.label}{tab === t.id && <span className="absolute inset-x-0 bottom-0 h-[2px] bg-[var(--blue)]" />}
          </button>
        ))}
      </div>

      <div key={tab} className="page-in pt-6">
        {tab === "overview" && <Overview project={project} report={report} />}
        {tab === "patron" && <PatronTab project={project} report={report} notify={notify} />}
        {tab === "judging" && <JudgingTab project={project} report={report} notify={notify} />}
        {tab === "community" && <CommunityTab project={project} report={report} notify={notify} />}
        {tab === "versions" && <VersionsTab project={project} />}
      </div>

      {toast && (
        <div role="status" className={cn("fixed bottom-20 right-5 z-[96] flex max-w-sm items-start gap-3 border bg-[var(--surface-solid)] p-3 text-xs shadow-2xl md:bottom-5", toast.ok ? "border-[#5DD39E]" : "border-[#FF6B6B]")}>
          {toast.ok ? <CheckIcon className="h-4 w-4 shrink-0 text-[#5DD39E]" /> : <CloseIcon className="h-4 w-4 shrink-0 text-[#FF6B6B]" />}
          <span className="leading-relaxed">{toast.text}</span>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════ OVERVIEW / EDITOR ═══════════════════ */

function Overview({ project, report }: { project: Project; report: (r: Result, s: string) => void }) {
  const store = useSubmissions();
  const cfg = competitionById(project.competitionId)!.config;
  const [uploads, setUploads] = useState<{ name: string; pct: number; error?: string }[]>([]);
  const [previews, setPreviews] = useState<Record<string, string>>({});
  const [dragging, setDragging] = useState(false);
  const [link, setLink] = useState({ label: "", url: "" });
  const inputRef = useRef<HTMLInputElement>(null);

  const accept = (files: FileList | null) => {
    if (!files) return;
    Array.from(files).forEach((file) => {
      const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
      const meta = { id: `f-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, name: file.name, size: file.size, ext, addedAt: new Date().toISOString() };
      // Validate before showing any progress: a rejected file never looks uploaded.
      if (!cfg.files.types.includes(ext)) return setUploads((u) => [...u, { name: file.name, pct: 0, error: `.${ext || "?"} not permitted` }]);
      if (file.size > cfg.files.maxMb * 1_000_000) return setUploads((u) => [...u, { name: file.name, pct: 0, error: `exceeds ${cfg.files.maxMb} MB` }]);
      setUploads((u) => [...u, { name: file.name, pct: 0 }]);
      let pct = 0;
      const t = window.setInterval(() => {
        pct = Math.min(100, pct + 20 + Math.random() * 25);
        setUploads((u) => u.map((x) => (x.name === file.name && !x.error ? { ...x, pct } : x)));
        if (pct >= 100) {
          window.clearInterval(t);
          const r = store.addFile(project.id, meta);
          if (r.ok) {
            if (["png", "jpg", "jpeg"].includes(ext)) setPreviews((p) => ({ ...p, [meta.id]: URL.createObjectURL(file) }));
            setUploads((u) => u.filter((x) => x.name !== file.name));
          } else setUploads((u) => u.map((x) => (x.name === file.name ? { ...x, error: r.error } : x)));
        }
      }, 180);
    });
  };

  const onDrop = (e: DragEvent) => { e.preventDefault(); setDragging(false); accept(e.dataTransfer.files); };
  const field = "comm-input";

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_330px]">
      <div className="space-y-4">
        <p className="font-mono text-[10.5px] leading-relaxed text-[var(--text-3)]">
          Edits are saved to the working draft. Versions already sent to a reviewer are frozen and kept for audit.
        </p>
        <label className="block"><span className="mono-label mb-1.5 block">Project name *</span>
          <input className={field} value={project.title} onChange={(e) => store.updateDraft(project.id, { title: e.target.value })} /></label>
        <label className="block"><span className="mono-label mb-1.5 block">Short summary *</span>
          <textarea rows={2} className={cn(field, "resize-none")} value={project.summary} onChange={(e) => store.updateDraft(project.id, { summary: e.target.value })} /></label>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block"><span className="mono-label mb-1.5 block">Problem being solved *</span>
            <textarea rows={5} className={cn(field, "resize-none")} value={project.problem} onChange={(e) => store.updateDraft(project.id, { problem: e.target.value })} /></label>
          <label className="block"><span className="mono-label mb-1.5 block">Proposed solution *</span>
            <textarea rows={5} className={cn(field, "resize-none")} value={project.solution} onChange={(e) => store.updateDraft(project.id, { solution: e.target.value })} /></label>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block"><span className="mono-label mb-1.5 block">Technologies * (comma separated)</span>
            <input className={field} defaultValue={project.technologies.join(", ")} onBlur={(e) => store.updateDraft(project.id, { technologies: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })} /></label>
          <label className="block"><span className="mono-label mb-1.5 block">Team members</span>
            <input className={field} defaultValue={project.team.join(", ")} onBlur={(e) => store.updateDraft(project.id, { team: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })} /></label>
        </div>
        {cfg.judging.extraField && (
          <label className="block"><span className="mono-label mb-1.5 block">Setter requires: {cfg.judging.extraField}</span>
            <textarea rows={2} className={cn(field, "resize-none")} value={project.extra} onChange={(e) => store.updateDraft(project.id, { extra: e.target.value })} /></label>
        )}
        {cfg.judging.videoEnabled && (
          <label className="block"><span className="mono-label mb-1.5 block">Demonstration video URL (enabled for this competition)</span>
            <input className={field} placeholder="https://" value={project.videoUrl} onChange={(e) => store.updateDraft(project.id, { videoUrl: e.target.value })} /></label>
        )}

        {/* links */}
        <div>
          <span className="mono-label mb-1.5 block">Repository & demo links</span>
          <div className="space-y-1.5">
            {project.links.map((l, i) => (
              <div key={l.url + i} className="flex items-center gap-2 border border-[var(--border)] bg-[var(--surface-solid)] px-3 py-2 text-xs">
                <span className="font-semibold">{l.label}</span><span className="truncate font-mono text-[10.5px] text-[var(--text-3)]">{l.url}</span>
                <button aria-label={`Remove ${l.label}`} className="ml-auto text-[var(--text-3)] hover:text-[#FF6B6B]" onClick={() => store.updateDraft(project.id, { links: project.links.filter((_, j) => j !== i) })}><TrashIcon className="h-3.5 w-3.5" /></button>
              </div>
            ))}
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            <input className={cn(field, "w-36")} placeholder="Label" value={link.label} onChange={(e) => setLink({ ...link, label: e.target.value })} />
            <input className={cn(field, "min-w-[180px] flex-1")} placeholder="https://…" value={link.url} onChange={(e) => setLink({ ...link, url: e.target.value })} />
            <button className="comm-button" onClick={() => {
              if (!/^https?:\/\/\S+\.\S+/.test(link.url)) return report({ ok: false, error: "Enter a full URL starting with https://" }, "");
              store.updateDraft(project.id, { links: [...project.links, { label: link.label || "Link", url: link.url }] }); setLink({ label: "", url: "" });
            }}>Add link</button>
          </div>
        </div>
      </div>

      {/* attachments */}
      <aside className="space-y-3">
        <div onDragOver={(e) => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={onDrop}
          className={cn("flex flex-col items-center justify-center border border-dashed p-6 text-center transition-colors", dragging ? "border-[var(--blue)] bg-[var(--blue-soft)]" : "border-[var(--border-strong)] bg-[var(--surface-solid)]")}>
          <UploadCloudIcon className="h-7 w-7 text-[var(--blue)]" />
          <p className="mt-2 text-[12.5px] font-semibold">Drop files here</p>
          <p className="mt-1 font-mono text-[10px] text-[var(--text-3)]">{cfg.files.types.join(" · ")} · max {cfg.files.maxMb} MB · {project.files.length}/{cfg.files.maxFiles} files</p>
          <button className="comm-button mt-3" onClick={() => inputRef.current?.click()}>Browse files</button>
          <input ref={inputRef} type="file" multiple className="sr-only" accept={cfg.files.types.map((t) => `.${t}`).join(",")} onChange={(e) => { accept(e.target.files); e.target.value = ""; }} />
        </div>

        {uploads.map((u) => (
          <div key={u.name} className={cn("border p-2.5", u.error ? "border-[#FF6B6B]/50 bg-[#FF6B6B]/10" : "border-[var(--border)] bg-[var(--surface-solid)]")}>
            <div className="flex items-center justify-between gap-2 font-mono text-[10.5px]">
              <span className="truncate">{u.name}</span>
              {u.error ? <button className="text-[#FF6B6B]" onClick={() => setUploads((x) => x.filter((y) => y.name !== u.name))}>dismiss</button> : <span className="text-[var(--text-3)]">{Math.round(u.pct)}%</span>}
            </div>
            {u.error ? <p className="mt-1 text-[11px] text-[#FF6B6B]">Rejected — {u.error}. Not attached.</p>
              : <div className="mt-1.5 h-1 overflow-hidden bg-[var(--border)]"><div className="h-full bg-[var(--blue)] transition-all" style={{ width: `${u.pct}%` }} /></div>}
          </div>
        ))}

        <div className="space-y-1.5">
          {project.files.map((f) => (
            <div key={f.id} className="flex items-center gap-2.5 border border-[var(--border)] bg-[var(--surface-solid)] p-2.5">
              {previews[f.id] ? <img src={previews[f.id]} alt="" className="h-9 w-9 object-cover" /> : <span className="flex h-9 w-9 items-center justify-center bg-[var(--surface-2)] font-mono text-[9px] uppercase text-[var(--blue)]">{f.ext}</span>}
              <div className="min-w-0 flex-1"><p className="truncate text-[12px] font-medium">{f.name}</p><p className="font-mono text-[10px] text-[var(--text-3)]">{formatBytes(f.size)} · {when(f.addedAt)}</p></div>
              <button aria-label={`Remove ${f.name}`} className="text-[var(--text-3)] hover:text-[#FF6B6B]" onClick={() => report(store.removeFile(project.id, f.id), `${f.name} removed from the draft.`)}><TrashIcon className="h-3.5 w-3.5" /></button>
            </div>
          ))}
          {project.files.length === 0 && uploads.length === 0 && <p className="py-3 text-center font-mono text-[10.5px] text-[var(--text-3)]">No files attached yet.</p>}
        </div>
        <p className="font-mono text-[9.5px] leading-relaxed text-[var(--text-3)]">Prototype: type and size are validated here; file contents stay in this browser. Production uploads are validated again server-side.</p>
      </aside>
    </div>
  );
}

/* ═══════════════════ PATRON ═══════════════════ */

function PatronTab({ project, report, notify }: { project: Project; report: (r: Result, s: string) => void; notify: (t: string, m: string) => void }) {
  const store = useSubmissions();
  const cfg = competitionById(project.competitionId)!.config.patron;
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const fb = project.patron.feedback;
  const canSend = !["SUBMITTED", "UNDER REVIEW"].includes(project.patron.status);

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
      <div className="space-y-5">
        <div className="flex flex-wrap items-center gap-3 border-l-[3px] bg-[var(--surface-solid)] p-4" style={{ borderColor: MINT }}>
          <span className="clip-oct-sm flex h-10 w-10 items-center justify-center font-display text-sm font-bold" style={{ background: `${MINT}22`, color: MINT }}>{cfg.patronInitials}</span>
          <div className="min-w-0"><p className="font-semibold">{cfg.patronName}</p><p className="font-mono text-[10.5px] text-[var(--text-3)]">{cfg.patronRole}</p></div>
          <div className="ml-auto flex items-center gap-2"><LockIcon className="h-3.5 w-3.5" />{patronChip(project.patron.status)}</div>
        </div>
        <p className="text-[12.5px] leading-relaxed text-[var(--text-2)]">
          Private between you and authorised reviewers. Patron feedback never appears on the showcase or affects official judging.
          {cfg.required ? " This competition requires a completed patron review before official submission." : " This review is optional."}
        </p>

        {fb ? (
          <section className="border bg-[var(--surface-solid)] p-5" style={{ borderColor: `${MINT}55` }}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="mono-label" style={{ color: MINT }}>PATRON FEEDBACK · {cfg.patronName}</p>
              <span className="font-mono text-[10px] text-[var(--text-3)]">{when(fb.at)}</span>
            </div>
            <p className="mt-3 text-[13.5px] leading-relaxed">{fb.overall}</p>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              {[["Strengths", fb.strengths, MINT], ["Needs improvement", fb.improvements, "#F2C94C"], ["Suggested next steps", fb.suggestions, "var(--blue)"]].map(([label, items, tone]) => (
                <div key={label as string}><p className="mono-label mb-2 text-[9px]" style={{ color: tone as string }}>{label as string}</p>
                  <ul className="space-y-1.5">{(items as string[]).map((i) => <li key={i} className="flex gap-2 text-[11.5px] leading-relaxed text-[var(--text-2)]"><span className="mt-1.5 h-1 w-1 shrink-0 rotate-45" style={{ background: tone as string }} />{i}</li>)}</ul></div>
              ))}
            </div>
            {fb.attachments.length > 0 && <p className="mt-4 flex items-center gap-2 font-mono text-[10.5px] text-[var(--text-2)]"><PaperclipIcon className="h-3.5 w-3.5" />{fb.attachments.join(", ")} (annotated by patron)</p>}
            <p className="mt-4 border-t border-[var(--border)] pt-3 text-[12px]">Recommendation: <span className="font-semibold" style={{ color: fb.recommendation === "Revise and resubmit" ? "#F2C94C" : MINT }}>{fb.recommendation}</span></p>
          </section>
        ) : (
          <p className="border border-dashed border-[var(--border-strong)] p-5 text-center text-[12.5px] text-[var(--text-2)]">
            {project.patron.status === "NOT SUBMITTED" ? "You haven't sent this project to your patron yet." : "Your patron hasn't returned feedback yet. You'll get a notification when they do."}
          </p>
        )}

        {canSend ? (
          <button onClick={() => setOpen(true)} className="comm-button" style={{ borderColor: MINT, color: MINT }}>
            <LockIcon className="h-3.5 w-3.5" />{project.patron.status === "NOT SUBMITTED" ? "Submit for review" : "Send revised version"}
          </button>
        ) : <p className="font-mono text-[10.5px] text-[var(--text-3)]">A version is with your patron — you can send another after feedback returns.</p>}
      </div>

      <aside className="border border-[var(--border)] bg-[var(--surface-solid)] p-4"><p className="mono-label mb-3">Review timeline</p><Timeline steps={project.patron.timeline} tone={MINT} /></aside>

      {open && (
        <Dialog title="Send to your patron" tone={MINT} onClose={() => setOpen(false)}>
          <Summary project={project} />
          <label className="mt-4 block"><span className="mono-label mb-1.5 block">Message to {cfg.patronName} (optional)</span>
            <textarea rows={3} className="comm-input resize-none" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="What would you like feedback on?" /></label>
          <div className="mt-5 flex justify-end gap-2">
            <button className="comm-button" onClick={() => setOpen(false)}>Cancel</button>
            <button className="comm-button comm-button-blue" onClick={() => {
              const r = store.submitToPatron(project.id, message);
              report(r, `Sent to ${cfg.patronName}. Reference ${r.ok ? r.reference : ""} — recorded locally.`);
              if (r.ok) { notify("Patron received your submission", `${project.title} was sent to ${cfg.patronName} for review.`); setOpen(false); }
            }}>Submit for review</button>
          </div>
        </Dialog>
      )}
    </div>
  );
}

/* ═══════════════════ JUDGING ═══════════════════ */

function JudgingTab({ project, report, notify }: { project: Project; report: (r: Result, s: string) => void; notify: (t: string, m: string) => void }) {
  const store = useSubmissions();
  const comp = competitionById(project.competitionId)!;
  const [open, setOpen] = useState(false);
  const [changes, setChanges] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [receipt, setReceipt] = useState<{ reference: string; at: string } | null>(null);
  const lock = judgingLock(project);
  const res = project.judging.result;
  const left = new Date(comp.config.judging.deadline).getTime() - Date.now();
  const deadlineText = left > 0 ? `${Math.floor(left / 86400_000)}d ${Math.floor((left % 86400_000) / 3600_000)}h left` : "deadline passed";

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
      <div className="space-y-5">
        <div className="arena-texture border border-[var(--blue)]/45 bg-[var(--surface-solid)] p-5">
          <div className="flex flex-wrap items-center gap-2"><AwardIcon className="h-4 w-4 text-[var(--blue)]" /><p className="mono-label text-[var(--blue)]">OFFICIAL JUDGING · {comp.name}</p><span className="ml-auto">{judgingChip(project.judging.status)}</span></div>
          <dl className="mt-4 grid grid-cols-2 gap-4 font-mono text-[10.5px] sm:grid-cols-4">
            {[["Deadline", when(comp.config.judging.deadline)], ["Remaining", deadlineText], ["Version", project.judging.versionNo ? `v${project.judging.versionNo}` : "—"], ["Resubmission", comp.config.judging.resubmission ? `allowed · max ${comp.config.judging.maxVersions}` : "not allowed"]].map(([k, v]) => (
              <div key={k}><dt className="text-[var(--text-3)]">{k}</dt><dd className="mt-1 text-[var(--text)]">{v}</dd></div>
            ))}
          </dl>
        </div>

        {(receipt || project.judging.reference) && (
          <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4" style={{ animation: receipt && !prefersReducedMotion() ? "cq-panel-in .5s both" : undefined }}>
            <p className="mono-label text-[9px]">Submission receipt</p>
            <p className="display mt-1 text-xl font-bold tracking-tight">{receipt?.reference ?? project.judging.reference}</p>
            <p className="mt-1 font-mono text-[10.5px] text-[var(--text-3)]">Submitted {when(receipt?.at ?? project.judging.submittedAt!)} · v{project.judging.versionNo} preserved · {lock ? "locked" : "replaceable before deadline"}</p>
            {project.judging.status === "SUBMITTED" && <p className="mt-2 text-[11px] text-[#F2C94C]">Local receipt. In production the judging service confirms receipt and moves this to RECEIVED — this prototype never claims that on its own.</p>}
          </div>
        )}

        {res ? (
          <section className="space-y-4">
            <div className="flex flex-wrap items-end gap-6 border border-[#5DD39E]/40 bg-[var(--surface-solid)] p-5">
              <div><p className="mono-label text-[9px]">Official score</p><p className="countdown-digit display text-5xl font-bold text-[#5DD39E]">{res.score}<span className="text-lg text-[var(--text-3)]">/{res.maxScore}</span></p></div>
              <div><p className="mono-label text-[9px]">Rank</p><p className="display text-3xl font-bold">#{res.rank}<span className="text-sm font-normal text-[var(--text-3)]"> of {res.field}</span></p></div>
            </div>
            <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-5">
              <p className="mono-label mb-3 text-[var(--blue)]">OFFICIAL JUDGES' FEEDBACK · rubric</p>
              <div className="space-y-3">{res.criteria.map((c) => (
                <div key={c.name}><div className="flex justify-between text-[12px]"><span>{c.name}</span><span className="font-mono">{c.score}/{c.max}</span></div>
                  <div className="mt-1 h-1 overflow-hidden bg-[var(--border)]"><div className="h-full bg-[var(--blue)]" style={{ width: `${(c.score / c.max) * 100}%` }} /></div>
                  <p className="mt-1 text-[11.5px] text-[var(--text-2)]">{c.comment}</p></div>))}</div>
              <p className="mt-4 border-t border-[var(--border)] pt-3 text-[13px] leading-relaxed">{res.comments}</p>
              <div className="mt-3 grid gap-3 sm:grid-cols-3">{[["Strengths", res.strengths], ["Weaknesses", res.weaknesses], ["Recommendations", res.recommendations]].map(([l, items]) => (
                <div key={l as string}><p className="mono-label mb-1.5 text-[9px]">{l as string}</p><ul className="space-y-1">{(items as string[]).map((i) => <li key={i} className="text-[11.5px] text-[var(--text-2)]">· {i}</li>)}</ul></div>))}</div>
            </div>
            <div className="overflow-x-auto border border-[var(--border)] bg-[var(--surface-solid)]">
              <table className="w-full min-w-[420px] text-left text-[12px]"><thead><tr className="border-b border-[var(--border)] font-mono text-[9.5px] uppercase text-[var(--text-3)]"><th className="px-3 py-2 font-normal">Rank</th><th className="px-3 py-2 font-normal">Entry</th><th className="px-3 py-2 font-normal">School</th><th className="px-3 py-2 text-right font-normal">Score</th></tr></thead>
                <tbody>{res.leaderboard.map((r) => <tr key={r.rank} className={cn("border-b border-[var(--border)] last:border-0", r.you && "bg-[var(--blue-soft)]")}><td className="px-3 py-2 font-mono">{String(r.rank).padStart(2, "0")}</td><td className="px-3 py-2 font-semibold">{r.name}{r.you && <span className="ml-2 font-mono text-[9px] text-[var(--blue)]">YOU</span>}</td><td className="px-3 py-2 font-mono text-[10.5px] text-[var(--text-3)]">{r.school}</td><td className="px-3 py-2 text-right font-mono">{r.score}</td></tr>)}</tbody></table>
            </div>
            <p className="font-mono text-[10px] text-[var(--text-3)]">Community reactions and comments have no effect on these scores.</p>
          </section>
        ) : project.judging.status !== "NOT SUBMITTED" ? (
          <p className="border border-dashed border-[var(--border-strong)] p-5 text-[12.5px] leading-relaxed text-[var(--text-2)]">Your project has been received. Official evaluation results and judges' feedback will appear here once published.</p>
        ) : null}

        {lock ? <p className="flex items-start gap-2 font-mono text-[11px] text-[#F2C94C]"><LockIcon className="mt-0.5 h-3.5 w-3.5 shrink-0" />{lock}</p> : (
          <button onClick={() => { setOpen(true); setConfirmed(false); }} className="btn-shell btn-primary-shell btn-shell-md">
            <span className="btn-core"><AwardIcon className="h-4 w-4" />{project.judging.status === "NOT SUBMITTED" ? "Submit to judges" : "Replace submission"}</span>
          </button>
        )}
      </div>

      <aside className="border border-[var(--border)] bg-[var(--surface-solid)] p-4"><p className="mono-label mb-3">Judging progress</p><Timeline steps={project.judging.timeline} tone="var(--blue)" /></aside>

      {open && (
        <Dialog title="Final submission to the judges" tone="var(--blue)" onClose={() => setOpen(false)}>
          <Summary project={project} />
          <label className="mt-4 block"><span className="mono-label mb-1.5 block">What changed in this version?</span>
            <input className="comm-input" value={changes} onChange={(e) => setChanges(e.target.value)} placeholder="e.g. Added caching layer" /></label>
          <label className="mt-4 flex items-start gap-2.5 text-[12px] leading-relaxed text-[var(--text-2)]">
            <input type="checkbox" className="mt-0.5 accent-[var(--blue)]" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
            I confirm this is my team's own work and that this version will be preserved as submitted.
          </label>
          <div className="mt-5 flex justify-end gap-2">
            <button className="comm-button" onClick={() => setOpen(false)}>Cancel</button>
            <button disabled={!confirmed} className="comm-button comm-button-blue disabled:opacity-40" onClick={() => {
              const r = store.submitToJudges(project.id, changes);
              report(r, `Submitted to the judges. Reference ${r.ok ? r.reference : ""}.`);
              if (r.ok) { setReceipt({ reference: r.reference!, at: r.at! }); notify("Official submission recorded", `${project.title} — reference ${r.reference}. Awaiting confirmation from the judging service.`); setOpen(false); }
            }}>Submit to judges</button>
          </div>
        </Dialog>
      )}
    </div>
  );
}

/* ═══════════════════ COMMUNITY ═══════════════════ */

function CommunityTab({ project, report, notify }: { project: Project; report: (r: Result, s: string) => void; notify: (t: string, m: string) => void }) {
  const store = useSubmissions();
  const comp = competitionById(project.competitionId)!;
  const cfg = comp.config.showcase;
  const [desc, setDesc] = useState(project.showcase.description || project.summary);
  const [consent, setConsent] = useState(false);
  const [sort, setSort] = useState<"recent" | "helpful" | "discussed">("recent");
  const [compose, setCompose] = useState<{ kind: CommunityComment["kind"]; category?: CommunityComment["category"]; body: string }>({ kind: "comment", body: "" });
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [reply, setReply] = useState("");

  if (!cfg.enabled) return (
    <div className="flex flex-col items-center border border-dashed border-[var(--border-strong)] p-10 text-center">
      <GlobeIcon className="h-7 w-7 text-[var(--text-3)]" />
      <h2 className="display mt-3 text-base font-bold">Public sharing isn't enabled for this competition</h2>
      <p className="mt-1.5 max-w-md text-[12.5px] text-[var(--text-2)]">The competition setter has turned off the community showcase for {comp.name}. Your project stays between you, your patron, and the judges.</p>
    </div>
  );

  if (!project.showcase.published) return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="space-y-4">
        <p className="mono-label" style={{ color: VIOLET }}>PUBLISH TO THE COMMUNITY SHOWCASE</p>
        <p className="text-[12.5px] leading-relaxed text-[var(--text-2)]">Only what you choose below is published. Patron feedback, judges' feedback and private files stay private.</p>
        <label className="block"><span className="mono-label mb-1.5 block">Public description</span>
          <textarea rows={5} className="comm-input resize-none" value={desc} onChange={(e) => setDesc(e.target.value)} /></label>
        <p className="font-mono text-[10px] text-[var(--text-3)]">{desc.trim().length}/40 characters minimum · comments {cfg.comments ? "on" : "off"} · reactions {cfg.reactions ? "on" : "off"}</p>
        <label className="flex items-start gap-2.5 text-[12px] text-[var(--text-2)]"><input type="checkbox" className="mt-0.5 accent-[var(--blue)]" checked={consent} onChange={(e) => setConsent(e.target.checked)} />I want other students to see and discuss this project.</label>
        <button disabled={!consent} className="comm-button disabled:opacity-40" style={{ borderColor: VIOLET, color: VIOLET }} onClick={() => report(store.publishShowcase(project.id, desc), "Published to the community showcase.")}><GlobeIcon className="h-3.5 w-3.5" />Publish project</button>
      </div>
      <div>
        <p className="mono-label mb-2">Preview — what other students will see</p>
        <ShowcaseCard project={{ ...project, showcase: { ...project.showcase, description: desc } }} competition={comp.name} />
      </div>
    </div>
  );

  const count = (c: CommunityComment): number => 1 + c.replies.reduce((s, r) => s + count(r), 0);
  const sorted = [...project.showcase.comments].sort((a, b) =>
    sort === "helpful" ? b.helpful - a.helpful : sort === "discussed" ? count(b) - count(a) : new Date(b.at).getTime() - new Date(a.at).getTime());

  const Comment = ({ c, depth }: { c: CommunityComment; depth: number }) => (
    <div className={cn(depth > 0 && "ml-6 border-l border-[var(--border)] pl-4")}>
      <div className="py-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="clip-oct-sm flex h-6 w-6 items-center justify-center bg-[var(--surface-2)] font-mono text-[9px] font-bold" style={{ color: VIOLET }}>{c.initials}</span>
          <span className="text-[12px] font-semibold">{c.author}</span>
          {c.own && <span className="font-mono text-[9px] text-[var(--blue)]">OWNER</span>}
          <span className="font-mono text-[9.5px] text-[var(--text-3)]">{c.kind === "question" ? "asked" : c.kind === "feedback" ? `feedback · ${c.category}` : "commented"} · {when(c.at)}</span>
        </div>
        {c.reported ? <p className="mt-1.5 font-mono text-[11px] text-[var(--text-3)]">Reported — hidden pending moderator review.</p> : <p className="mt-1.5 text-[12.5px] leading-relaxed text-[var(--text-2)]">{c.body}</p>}
        <div className="mt-1.5 flex gap-4 font-mono text-[10px] text-[var(--text-3)]">
          <button className={cn("hover:text-[var(--blue)]", c.markedHelpful && "text-[var(--blue)]")} onClick={() => store.markHelpful(project.id, c.id)}>Helpful · {c.helpful}</button>
          {project.showcase.commentsEnabled && <button className="hover:text-[var(--blue)]" onClick={() => { setReplyTo(c.id); setReply(""); }}>Reply</button>}
          {!c.own && !c.reported && <button className="flex items-center gap-1 hover:text-[#FF6B6B]" onClick={() => { store.reportComment(project.id, c.id); report({ ok: true }, "Reported to moderators."); }}><FlagIcon className="h-3 w-3" />Report</button>}
        </div>
        {replyTo === c.id && (
          <div className="mt-2 flex gap-2"><input autoFocus className="comm-input" value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Write a reply…" />
            <button className="comm-small" onClick={() => { if (!reply.trim()) return; store.addComment(project.id, { author: "Farid Bulega", initials: "FB", kind: "comment", body: reply.trim(), own: true }, c.id); setReplyTo(null); }}>Reply</button>
            <button className="comm-small" onClick={() => setReplyTo(null)}>Cancel</button></div>
        )}
      </div>
      {c.replies.map((r) => <Comment key={r.id} c={r} depth={depth + 1} />)}
    </div>
  );

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
      <div>
        <ShowcaseCard project={project} competition={comp.name} onReact={cfg.reactions ? () => store.toggleReaction(project.id) : undefined} />
        <div className="mt-6 flex flex-wrap items-center justify-between gap-2 border-b border-[var(--border)] pb-2">
          <p className="mono-label" style={{ color: VIOLET }}>STUDENT COMMUNITY FEEDBACK · {project.showcase.comments.reduce((s, c) => s + count(c), 0)}</p>
          <select className="comm-input w-auto" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} aria-label="Sort comments"><option value="recent">Most recent</option><option value="helpful">Most helpful</option><option value="discussed">Most discussed</option></select>
        </div>
        {project.showcase.commentsEnabled ? (
          <div className="mt-3 border border-[var(--border)] bg-[var(--surface-solid)] p-3">
            <div className="flex flex-wrap gap-1.5">{(["comment", "question", "feedback"] as const).map((k) => <button key={k} onClick={() => setCompose({ ...compose, kind: k, category: k === "feedback" ? "Technical implementation" : undefined })} className={cn("comm-small", compose.kind === k && "border-[var(--blue)] text-[var(--blue)]")}>{k === "comment" ? "Comment" : k === "question" ? "Ask a question" : "Leave feedback"}</button>)}
              {compose.kind === "feedback" && <select className="comm-input w-auto" value={compose.category} onChange={(e) => setCompose({ ...compose, category: e.target.value as CommunityComment["category"] })}>{["Usability", "Creativity", "Technical implementation", "Presentation"].map((c) => <option key={c}>{c}</option>)}</select>}</div>
            <textarea rows={2} className="comm-input mt-2 resize-none" placeholder="Reply to the community as the project owner…" value={compose.body} onChange={(e) => setCompose({ ...compose, body: e.target.value })} />
            <div className="mt-2 flex justify-end"><button className="comm-small" onClick={() => {
              if (!compose.body.trim()) return;
              store.addComment(project.id, { author: "Farid Bulega", initials: "FB", kind: compose.kind, category: compose.category, body: compose.body.trim(), own: true });
              setCompose({ kind: "comment", body: "" }); notify("You posted on your showcase", `Your comment on ${project.title} is live.`);
            }}>Post</button></div>
          </div>
        ) : <p className="mt-3 font-mono text-[11px] text-[var(--text-3)]">Comments are turned off for this showcase.</p>}
        <div className="divide-y divide-[var(--border)]">{sorted.map((c) => <Comment key={c.id} c={c} depth={0} />)}</div>
        {sorted.length === 0 && <p className="py-6 text-center text-[12px] text-[var(--text-3)]">No community feedback yet.</p>}
      </div>

      <aside className="space-y-3">
        <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
          <p className="mono-label mb-3">Owner controls</p>
          <label className="block"><span className="mono-label mb-1.5 block text-[9px]">Public description</span>
            <textarea rows={4} className="comm-input resize-none" value={desc} onChange={(e) => setDesc(e.target.value)} /></label>
          <button className="comm-small mt-2" onClick={() => { store.updateShowcase(project.id, { description: desc }); report({ ok: true }, "Public description updated."); }}>Save description</button>
          {cfg.comments && <label className="mt-4 flex items-center justify-between text-[12px]">Allow comments<input type="checkbox" className="accent-[var(--blue)]" checked={project.showcase.commentsEnabled} onChange={(e) => store.updateShowcase(project.id, { commentsEnabled: e.target.checked })} /></label>}
          <button disabled={!cfg.ownerCanUnpublish} className="comm-button mt-4 w-full justify-center border-[#FF6B6B]/60 text-[#FF6B6B] disabled:opacity-40" onClick={() => { if (window.confirm("Unpublish this showcase? Comments are kept but hidden.")) report(store.unpublishShowcase(project.id), "Showcase unpublished."); }}>Unpublish showcase</button>
        </div>
        <p className="font-mono text-[9.5px] leading-relaxed text-[var(--text-3)]">Community feedback is separate from judging. Likes and comments never change official scores or leaderboard rankings.</p>
      </aside>
    </div>
  );
}

function ShowcaseCard({ project, competition, onReact }: { project: Project; competition: string; onReact?: () => void }) {
  const initials = project.title.split(" ").map((w) => w[0]).slice(0, 2).join("");
  return (
    <article className="overflow-hidden border border-[var(--border)] bg-[var(--surface-solid)]">
      {/* cover generated from project content, not stock imagery */}
      <div className="arena-texture relative flex h-32 items-end border-b border-[var(--border)] p-4" style={{ background: `linear-gradient(135deg, ${VIOLET}22, transparent 60%)` }}>
        <span className="display absolute right-4 top-2 text-6xl font-bold opacity-[0.12]" style={{ color: VIOLET }}>{initials}</span>
        <div className="flex flex-wrap gap-1.5">{project.technologies.slice(0, 5).map((t) => <span key={t} className="clip-oct-sm border border-[var(--border-strong)] bg-[var(--bg)]/60 px-2 py-0.5 font-mono text-[9.5px] text-[var(--text-2)]">{t}</span>)}</div>
      </div>
      <div className="p-4">
        <p className="mono-label text-[9px]" style={{ color: VIOLET }}>{competition}</p>
        <h3 className="display mt-1 text-lg font-bold">{project.title}</h3>
        <p className="font-mono text-[10.5px] text-[var(--text-3)]">by {project.team.join(", ")}{project.showcase.publishedAt && ` · published ${when(project.showcase.publishedAt)}`}</p>
        <p className="mt-3 text-[12.5px] leading-relaxed text-[var(--text-2)]">{project.showcase.description || "Your public description will appear here."}</p>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          {project.links.map((l) => <a key={l.url} href={l.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-mono text-[10.5px] text-[var(--blue)] hover:underline">{l.label} <ArrowRight className="h-3 w-3" /></a>)}
          {project.files.length > 0 && <span className="inline-flex items-center gap-1 font-mono text-[10.5px] text-[var(--text-3)]"><FileIcon className="h-3 w-3" />{project.files.length} documentation file{project.files.length > 1 ? "s" : ""}</span>}
          {onReact && <button onClick={onReact} className={cn("ml-auto inline-flex items-center gap-1.5 border px-2.5 py-1 font-mono text-[10.5px] transition-colors", project.showcase.reacted ? "border-[#FF6B6B] text-[#FF6B6B]" : "border-[var(--border-strong)] text-[var(--text-2)] hover:border-[#FF6B6B]")}><HeartIcon className="h-3.5 w-3.5" />Appreciate · {project.showcase.reactions}</button>}
        </div>
      </div>
    </article>
  );
}

/* ═══════════════════ VERSIONS ═══════════════════ */

function VersionsTab({ project }: { project: Project }) {
  return (
    <div className="overflow-x-auto border border-[var(--border)] bg-[var(--surface-solid)]">
      <table className="w-full min-w-[640px] text-left text-[12px]">
        <thead><tr className="border-b border-[var(--border)] font-mono text-[9.5px] uppercase tracking-wider text-[var(--text-3)]">{["Version", "Created", "Submitted", "Destination", "Changes", "Reference"].map((h) => <th key={h} className="px-3 py-2.5 font-normal">{h}</th>)}</tr></thead>
        <tbody>{[...project.versions].reverse().map((v) => (
          <tr key={v.no} className="border-b border-[var(--border)] last:border-0">
            <td className="px-3 py-2.5 font-mono font-bold">v{v.no}</td>
            <td className="px-3 py-2.5 font-mono text-[10.5px] text-[var(--text-3)]">{when(v.createdAt)}</td>
            <td className="px-3 py-2.5 font-mono text-[10.5px] text-[var(--text-3)]">{v.submittedAt ? when(v.submittedAt) : "—"}</td>
            <td className="px-3 py-2.5">{v.destination === "draft" ? <StatusChip label="DRAFT · EDITABLE" tone="var(--text-3)" /> : v.destination === "patron" ? <StatusChip label="PATRON · FROZEN" tone={MINT} /> : <StatusChip label="JUDGES · FROZEN" tone="var(--blue)" />}</td>
            <td className="px-3 py-2.5 text-[var(--text-2)]">{v.changes}</td>
            <td className="px-3 py-2.5 font-mono text-[10.5px]">{v.reference ?? "—"}</td>
          </tr>))}</tbody>
      </table>
      <p className="border-t border-[var(--border)] p-3 font-mono text-[10px] text-[var(--text-3)]">Submitted versions are never overwritten. Editing after a submission starts a new draft version.</p>
    </div>
  );
}

/* ═══════════════════ SHARED ═══════════════════ */

function Dialog({ title, tone, onClose, children }: { title: string; tone: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center bg-black/70 sm:items-center sm:p-5" onMouseDown={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title} onMouseDown={(e) => e.stopPropagation()} className="panel-in max-h-[92vh] w-full max-w-lg overflow-y-auto border-t-[3px] border-x border-b border-[var(--border-strong)] bg-[var(--surface-solid)] p-6" style={{ borderTopColor: tone }}>
        <div className="flex items-start justify-between"><h2 className="display text-xl font-bold">{title}</h2><button onClick={onClose} aria-label="Close"><CloseIcon className="h-5 w-5" /></button></div>
        <div className="mt-4">{children}</div>
      </div>
    </div>
  );
}

function Summary({ project }: { project: Project }) {
  return (
    <dl className="space-y-2 border border-[var(--border)] bg-[var(--surface-2)] p-3 text-[12px]">
      <div><dt className="mono-label text-[9px]">Project</dt><dd className="font-semibold">{project.title}</dd></div>
      <div><dt className="mono-label text-[9px]">Summary</dt><dd className="text-[var(--text-2)]">{project.summary || <span className="text-[#F2C94C]">Missing</span>}</dd></div>
      <div className="flex gap-6"><div><dt className="mono-label text-[9px]">Files</dt><dd className="font-mono">{project.files.length}</dd></div>
        <div><dt className="mono-label text-[9px]">Links</dt><dd className="font-mono">{project.links.length}</dd></div>
        <div><dt className="mono-label text-[9px]">Will be</dt><dd className="font-mono">v{project.versions[project.versions.length - 1].destination === "draft" ? project.versions[project.versions.length - 1].no : project.versions[project.versions.length - 1].no + 1}</dd></div></div>
    </dl>
  );
}
