import { useMemo, useState } from "react";
import { cn } from "../../../utils/cn";
import { PATH_EDGES, pathLayout, type Course } from "../../../data/academyData";
import { useAcademy, visibleCourses } from "../../../lib/academyStore";
import { ArrowRight, CheckIcon, GraduationCapIcon, LockIcon, MapRouteIcon, SparklesIcon, TrophyIcon } from "../../../components/icons";

type NodeStatus = "completed" | "progress" | "available" | "locked" | "recommended";
type Filter = "all" | Course["subject"] | "completed" | "progress" | "available";

const R = 30;

export default function LearningPathTab({ onOpenCourse }: { onOpenCourse: (courseId: string) => void }) {
  const academy = useAcademy();
  const [selected, setSelected] = useState<string>("node-py-mastery");
  const [filter, setFilter] = useState<Filter>("all");

  const courseStatus = (id: string): NodeStatus => {
    const course = visibleCourses().find((c) => c.id === id);
    if (!course) return "locked";
    const p = academy.courseProgress(course);
    if (p.status === "COMPLETED") return "completed";
    const prereqsDone = course.prerequisites.every((pr) => {
      const pc = visibleCourses().find((c) => c.id === pr);
      return pc ? academy.courseProgress(pc).status === "COMPLETED" : true;
    });
    if (!prereqsDone) return "locked";
    if (p.status === "IN PROGRESS") return "progress";
    return course.recommended ? "recommended" : "available";
  };

  const nodeStatus = (nodeId: string): NodeStatus => {
    const node = pathLayout.find((n) => n.id === nodeId)!;
    if (node.kind === "milestone") return courseStatus(node.courseId) === "completed" ? "completed" : "locked";
    return courseStatus(node.courseId);
  };

  const matchFilter = (nodeId: string): boolean => {
    const node = pathLayout.find((n) => n.id === nodeId)!;
    if (filter === "all") return true;
    if (filter === "completed" || filter === "progress" || filter === "available")
      return filter === "available"
        ? ["available", "recommended"].includes(nodeStatus(nodeId))
        : nodeStatus(nodeId) === filter;
    return node.subject === filter;
  };

  const selectedNode = pathLayout.find((n) => n.id === selected)!;
  const selectedCourse = visibleCourses().find((c) => c.id === selectedNode.courseId);
  const selStatus = nodeStatus(selectedNode.id);

  const st = academy.stats;
  const overview = [
    ["Learning progress", `${Math.round(visibleCourses().reduce((s, c) => s + academy.courseProgress(c).percent, 0) / visibleCourses().length)}%`],
    ["Courses completed", String(st.completedCourses)],
    ["Active courses", String(st.inProgress)],
    ["Skills acquired", String(st.lessons)],
    ["Learning points", st.points.toLocaleString()],
    ["Streak", `${st.streakDays} day${st.streakDays === 1 ? "" : "s"}`],
  ];

  const filters: Filter[] = ["all", "Computer Fundamentals", "Programming", "AI & Automation", "System Design", "completed", "progress", "available"];
  const dimmed = (id: string) => !matchFilter(id);

  const actionLabel = useMemo(() => {
    if (!selectedCourse) return null;
    if (selStatus === "completed") return "Review completed course";
    if (selStatus === "progress") return "Continue learning";
    if (selStatus === "locked") return "Complete prerequisites";
    return "Begin course";
  }, [selStatus, selectedCourse]);

  const actionDisabled = selStatus === "locked" || selectedNode.kind === "milestone";

  return (
    <div className="mx-auto max-w-[1380px] space-y-7 pb-10">
      <header className="border-b border-[var(--border)] pb-6">
        <p className="mono-label flex items-center gap-2 text-[var(--blue)]">
          <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />LEARN / MY LEARNING JOURNEY
        </p>
        <h1 className="display mt-2 text-3xl font-bold uppercase leading-[1.03] tracking-tight sm:text-[2.6rem]">
          Every skill unlocked brings you <span className="text-[var(--blue)]">closer to mastery.</span>
        </h1>
        <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-3 lg:grid-cols-6">
          {overview.map(([k, v]) => (
            <div key={k} className="border-l border-[var(--border-strong)] pl-3">
              <dt className="mono-label text-[9px]">{k}</dt>
              <dd className="display mt-1 text-xl font-bold">{v}</dd>
            </div>
          ))}
        </dl>
      </header>

      {/* filters */}
      <div className="flex flex-wrap gap-1.5" role="group" aria-label="Filter skill map">
        {filters.map((f) => (
          <button key={f} onClick={() => setFilter(f)} aria-pressed={filter === f}
            className={cn("comm-small uppercase", filter === f && "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]")}>
            {f === "all" ? "All skills" : f}
          </button>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_320px]">
        {/* ── SKILL MAP ── */}
        <div className="arena-texture relative overflow-x-auto border border-[var(--border)] bg-[var(--surface-solid)] p-3">
          <svg viewBox="0 0 680 540" className="min-w-[620px]" role="img" aria-label="Learning path map">
            {/* edges */}
            {PATH_EDGES.map(([from, to]) => {
              const a = pathLayout.find((n) => n.id === from)!;
              const b = pathLayout.find((n) => n.id === to)!;
              const lit = nodeStatus(from) === "completed";
              return (
                <path key={`${from}-${to}`} d={`M${a.x + R} ${a.y} C${(a.x + b.x) / 2} ${a.y}, ${(a.x + b.x) / 2} ${b.y}, ${b.x - R} ${b.y}`}
                  fill="none" stroke={lit ? "var(--blue)" : "var(--border-strong)"} strokeWidth={lit ? 2 : 1.4}
                  strokeDasharray={lit ? "0" : "5 6"} opacity={dimmed(from) || dimmed(to) ? 0.25 : 1}
                  style={{ transition: "stroke 400ms ease" }} />
              );
            })}

            {/* nodes */}
            {pathLayout.map((node) => {
              const status = nodeStatus(node.id);
              const active = selected === node.id;
              const dim = dimmed(node.id);
              const fill = status === "completed" ? "var(--blue)" : status === "progress" ? "var(--blue-soft)" : status === "recommended" ? "rgba(242,201,76,0.14)" : status === "available" ? "var(--surface-2)" : "var(--surface-solid)";
              const stroke = status === "completed" ? "var(--blue)" : status === "progress" ? "var(--blue)" : status === "recommended" ? "#F2C94C" : status === "available" ? "var(--border-strong)" : "var(--border)";
              return (
                <g key={node.id} transform={`translate(${node.x},${node.y})`} className="cursor-pointer" opacity={dim ? 0.35 : 1}
                  onClick={() => setSelected(node.id)} tabIndex={0} role="button" aria-label={`${node.label}: ${status}`}
                  onKeyDown={(e) => { if (e.key === "Enter") setSelected(node.id); }}>
                  {status === "progress" && <circle r={R + 7} fill="none" stroke="var(--blue)" strokeWidth="1" opacity="0.35" className="pulse-ring" />}
                  <rect x={-R} y={-R} width={R * 2} height={R * 2} rx="8"
                    fill={fill} stroke={stroke} strokeWidth={active ? 2.4 : 1.4}
                    style={{ transition: "all 350ms ease" }}
                    clipPath="url(#octclip)" />
                  <g clipPath="url(#octclip)">
                    <text y="4" textAnchor="middle" fontSize="13" fontFamily="var(--font-mono)" fill={status === "completed" ? "#fff" : status === "locked" ? "var(--text-3)" : status === "recommended" ? "#F2C94C" : "var(--blue)"}>
                      {status === "completed" ? "✓" : node.kind === "milestone" ? "⬡" : status === "locked" ? "🔒" : node.label.slice(0, 2).toUpperCase()}
                    </text>
                  </g>
                  <text y={R + 16} textAnchor="middle" fontSize="11" fontFamily="var(--font-mono)" fill="var(--text-2)">{node.label}</text>
                </g>
              );
            })}

            <defs>
              <clipPath id="octclip">
                <path d="M-22 -30 H22 L30 -22 V22 L22 30 H-22 L-30 22 V-22 Z" transform={`translate(0,0)`} />
              </clipPath>
            </defs>
          </svg>

          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1.5 border-t border-[var(--border)] pt-2.5 font-mono text-[10px] text-[var(--text-3)]">
            {[["✓", "completed"], ["⬡", "milestone"], ["●", "in progress"], ["◐", "recommended"], ["◇", "available"], ["🔒", "locked"]].map(([g, l]) => (
              <span key={l} className="flex items-center gap-1.5"><span>{g}</span>{l}</span>
            ))}
          </div>
        </div>

        {/* ── INFO PANEL ── */}
        <aside className="space-y-4">
          <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-5">
            <p className="mono-label text-[9px]" style={{ color: selStatus === "completed" ? "#5DD39E" : selStatus === "locked" ? "var(--text-3)" : "var(--blue)" }}>
              {selStatus.replace("-", " ").toUpperCase()}
              {selectedNode.kind === "milestone" && " · MILESTONE"}
            </p>
            <h2 className="display mt-1.5 text-lg font-bold leading-tight">{selectedNode.label}</h2>

            {selectedCourse ? (
              <div className="mt-3 space-y-3">
                <p className="text-[12.5px] leading-relaxed text-[var(--text-2)]">{selectedCourse.description}</p>
                <dl className="grid grid-cols-2 gap-3 font-mono text-[10.5px]">
                  <div><dt className="text-[var(--text-3)]">Progress</dt><dd className="mt-0.5">{academy.courseProgress(selectedCourse).percent}% · {academy.courseProgress(selectedCourse).done}/{academy.courseProgress(selectedCourse).total} lessons</dd></div>
                  <div><dt className="text-[var(--text-3)]">Estimated time</dt><dd className="mt-0.5">{selectedCourse.estimatedHours} hours</dd></div>
                  <div><dt className="text-[var(--text-3)]">Difficulty</dt><dd className="mt-0.5">{selectedCourse.difficulty}</dd></div>
                  <div><dt className="text-[var(--text-3)]">Points</dt><dd className="mt-0.5">{selectedCourse.points} XP</dd></div>
                </dl>
                <div>
                  <p className="mono-label text-[9px]">Prerequisites</p>
                  <ul className="mt-1.5 space-y-1">
                    {selectedCourse.prerequisites.length === 0 && <li className="text-[12px] text-[var(--text-3)]">None — open to everyone.</li>}
                    {selectedCourse.prerequisites.map((pr) => {
                      const pc = visibleCourses().find((c) => c.id === pr);
                      const done = pc ? academy.courseProgress(pc).status === "COMPLETED" : false;
                      return (
                        <li key={pr} className={cn("flex items-center gap-2 text-[12px]", done ? "text-[#5DD39E]" : "text-[#F2C94C]")}>
                          {done ? <CheckIcon className="h-3 w-3" /> : <LockIcon className="h-3 w-3" />}
                          {pc?.title}{!done && " — required"}
                        </li>
                      );
                    })}
                  </ul>
                </div>
                <p className="border-t border-[var(--border)] pt-2.5 font-mono text-[10px] leading-relaxed text-[var(--text-3)]">
                  Completion requirement: every lesson of every module. Unlocking is enforced by the same rules the map shows — the map never grants access.
                </p>
                <button disabled={actionDisabled} onClick={() => selectedCourse && onOpenCourse(selectedCourse.id)}
                  className="btn-shell btn-primary-shell btn-shell-md w-full disabled:opacity-40">
                  <span className="btn-core">{actionLabel} <ArrowRight className="h-3.5 w-3.5" /></span>
                </button>
                {selStatus === "locked" && <p className="font-mono text-[10.5px] text-[#F2C94C]">Finish the prerequisite course first — visible, but correctly unavailable.</p>}
              </div>
            ) : (
              <p className="mt-3 text-[12.5px] text-[var(--text-2)]">Milestone — earned when {selectedNode.prerequisites[0] ? visibleCourses().find((c) => c.id === selectedNode.prerequisites[0])?.title ?? "its course" : "the linked course"} is fully completed. Select a course node to see its details.</p>
            )}
          </div>

          {/* weekly activity — real completion days */}
          <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
            <div className="flex items-center justify-between">
              <p className="mono-label text-[var(--text)]">Weekly activity</p>
              <span className="font-mono text-[10px] text-[var(--text-3)]">{st.lessons} lessons total</span>
            </div>
            <div className="mt-3 flex h-16 items-end gap-1.5">
              {academy.weeklyActivity.map((d, i) => (
                <div key={i} className="flex flex-1 flex-col items-center gap-1">
                  <div className={cn("w-full transition-all duration-500", d.count > 0 ? "bg-[var(--blue)]" : "bg-[var(--border-strong)]")} style={{ height: `${Math.max(8, d.count * 100)}%` }} />
                  <span className="font-mono text-[8.5px] text-[var(--text-3)]">{d.day}</span>
                </div>
              ))}
            </div>
          </div>

          {/* subject progress */}
          <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
            <p className="mono-label text-[var(--text)]">Subject progress</p>
            <div className="mt-3 space-y-2.5">
              {academy.subjectProgress.map((s) => (
                <div key={s.subject}>
                  <div className="flex justify-between text-[11.5px]"><span className="text-[var(--text-2)]">{s.subject}</span><span className="font-mono text-[var(--text)]">{s.percent}%</span></div>
                  <div className="mt-1 h-1 overflow-hidden bg-[var(--border)]"><div className="h-full bg-[var(--blue)] transition-all duration-700" style={{ width: `${s.percent}%` }} /></div>
                </div>
              ))}
            </div>
          </div>

          {/* achievements */}
          <div className="border border-[var(--border)] bg-[var(--surface-solid)] p-4">
            <div className="flex items-center justify-between">
              <p className="mono-label text-[var(--text)]">Achievements</p>
              <span className="font-mono text-[10px] text-[var(--text-3)]">{academy.achievements.filter((a) => a.earned).length}/{academy.achievements.length}</span>
            </div>
            <div className="mt-3 space-y-2">
              {academy.achievements.map((a) => (
                <div key={a.id} className={cn("flex items-center gap-2.5 border p-2.5 transition-colors", a.earned ? "border-[var(--blue)]/40 bg-[var(--blue-soft)]/40" : "border-dashed border-[var(--border)] opacity-60")}>
                  <span className={cn("clip-oct-sm flex h-7 w-7 items-center justify-center", a.earned ? "bg-[var(--blue)] text-white" : "bg-[var(--surface-2)] text-[var(--text-3)]")}>
                    {a.earned ? <CheckIcon className="h-3.5 w-3.5" /> : <LockIcon className="h-3 w-3" />}
                  </span>
                  <div className="min-w-0"><p className="display truncate text-[11.5px] font-bold">{a.name}</p><p className="truncate font-mono text-[9.5px] text-[var(--text-3)]">{a.desc}</p></div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>

      {/* integration note */}
      <p className="flex flex-wrap items-center gap-4 border-t border-[var(--border)] pt-4 font-mono text-[10px] text-[var(--text-3)]">
        <span className="flex items-center gap-1.5"><MapRouteIcon className="h-3 w-3" />Map and Lesson Studio share one progress record</span>
        <span className="flex items-center gap-1.5"><GraduationCapIcon className="h-3 w-3" />Learning points are separate from competition scores</span>
        <span className="flex items-center gap-1.5"><TrophyIcon className="h-3 w-3" />{st.points.toLocaleString()} XP · {st.completedCourses} certificates</span>
        <span className="flex items-center gap-1.5"><SparklesIcon className="h-3 w-3" />{academy.achievements.filter((a) => a.earned).length} badges earned</span>
      </p>
    </div>
  );
}
