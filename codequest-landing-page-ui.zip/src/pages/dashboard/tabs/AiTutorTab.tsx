import { useState } from "react";
import { cn } from "../../../utils/cn";
import { aiTutorSamplePrompts, type AiTutorPrompt } from "../../../data/dashboardData";
import {
  SparklesIcon,
  SendIcon,
  ArrowRight,
} from "../../../components/icons";

export default function AiTutorTab({
  onNavigate,
}: {
  onNavigate: (tab: string) => void;
}) {
  const [activePrompt, setActivePrompt] = useState<AiTutorPrompt>(aiTutorSamplePrompts[0]);
  const [customInput, setCustomInput] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [explanationMode, setExplanationMode] = useState<"diagram" | "deep" | "simple">("diagram");

  const handleAskCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;

    setIsThinking(true);
    setTimeout(() => {
      setIsThinking(false);
      setActivePrompt({
        id: "custom-" + Date.now(),
        title: customInput,
        category: "Challenge",
        question: customInput,
        response: {
          explanation: `Here is the architectural and algorithmic analysis for: "${customInput}".\n\nWhen designing this algorithm, consider the invariant: at every step, ensure the state matches the optimal substructure.`,
          diagram: `
+-------------------------------------------------------+
|  ALGORITHM DATA FLOW & CONCEPTUAL STATE               |
+-------------------------------------------------------+
|  Input State -> [ Invariant Check ] -> Branch Condition |
|                      |                                |
|                      v                                |
|              [ Memoization Cache ]                     |
+-------------------------------------------------------+
`,
          code: `# Generated concept scaffold for: ${customInput}
def solve_concept(data: list[int]) -> int:
    cache = {}
    def helper(idx: int) -> int:
        if idx in cache:
            return cache[idx]
        # Invariant computation
        res = idx * 2
        cache[idx] = res
        return res
    return helper(len(data))`,
          practicePrompt: "Try implementing edge case verification for empty inputs and single-element arrays.",
        },
      });
      setCustomInput("");
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-3 border-b border-[var(--border)] pb-5 sm:flex-row sm:items-end">
        <div>
          <p className="mono-label text-[var(--blue)]">LEARN / CONCEPT STUDIO</p>
          <h1 className="display mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
            AI Tutor & Concept Visualizer
          </h1>
          <p className="mt-1 text-sm text-[var(--text-2)]">
            Interactive computer science tutor. Request ASCII memory diagrams, call stack unwinding, step-by-step algorithms, and custom challenges.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="clip-oct-sm border border-[var(--blue)]/50 bg-[var(--blue-soft)] px-3 py-1 font-mono text-xs font-semibold text-[var(--blue)]">
            AI Model: CodeQuest Tutor v2
          </span>
        </div>
      </div>

      {/* Suggested Quick Prompts */}
      <div className="space-y-2">
        <p className="mono-label text-[10.5px] text-[var(--text-3)]">
          SELECT A CONCEPT OR ASK A QUESTION:
        </p>
        <div className="flex flex-wrap gap-2">
          {aiTutorSamplePrompts.map((p) => (
            <button
              key={p.id}
              onClick={() => setActivePrompt(p)}
              className={cn(
                "clip-oct-sm flex items-center gap-2 border px-3 py-1.5 font-mono text-xs transition-colors",
                activePrompt.id === p.id
                  ? "border-[var(--blue)] bg-[var(--blue)] text-white shadow-[0_0_10px_var(--glow)]"
                  : "border-[var(--border)] bg-[var(--surface-2)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
              )}
            >
              <SparklesIcon className="h-3 w-3" />
              <span>{p.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Interactive Workspace Area */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left 2 cols: Response, Visual Diagram, and Generated Code */}
        <div className="panel clip-oct space-y-5 p-6 lg:col-span-2">
          {/* Active Question Banner */}
          <div className="flex items-start justify-between border-b border-[var(--border)] pb-4">
            <div>
              <span className="mono-label text-[var(--blue)]">
                {activePrompt.category}
              </span>
              <h2 className="display mt-1 text-xl font-bold">
                {activePrompt.question}
              </h2>
            </div>

            {/* Mode switch */}
            <div className="flex gap-1">
              {(["diagram", "deep", "simple"] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setExplanationMode(mode)}
                  className={cn(
                    "clip-oct-sm px-2 py-0.5 font-mono text-[10px] uppercase transition-colors",
                    explanationMode === mode
                      ? "bg-[var(--blue)] text-white"
                      : "bg-[var(--surface-2)] text-[var(--text-3)] hover:text-[var(--text)]"
                  )}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          {/* Explanation Text */}
          <div className="prose prose-invert max-w-none text-xs leading-relaxed text-[var(--text)] sm:text-sm">
            <p className="whitespace-pre-line">
              {activePrompt.response.explanation}
            </p>
          </div>

          {/* Visual Concept Diagram */}
          {activePrompt.response.diagram && (
            <div className="space-y-1.5">
              <span className="mono-label text-[10.5px] text-[var(--blue)]">
                VISUAL CONCEPT MAP / CALL STACK DIAGRAM
              </span>
              <pre className="overflow-x-auto border border-[var(--border)] bg-[var(--surface-2)] p-4 font-mono text-xs leading-tight text-[#5DD39E]">
                <code>{activePrompt.response.diagram}</code>
              </pre>
            </div>
          )}

          {/* Annotated Code Block */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="mono-label text-[10.5px] text-[var(--text-3)]">
                ANNOTATED IMPLEMENTATION (PYTHON)
              </span>
              <button
                onClick={() => onNavigate("practice")}
                className="font-mono text-[11px] text-[var(--blue)] hover:underline"
              >
                Open in Practice IDE →
              </button>
            </div>
            <pre className="overflow-x-auto border border-[var(--border)] bg-[var(--surface-solid)] p-4 font-mono text-xs leading-relaxed text-[var(--text-2)]">
              <code>{activePrompt.response.code}</code>
            </pre>
          </div>

          {/* Next practice challenge */}
          <div className="border border-[var(--blue)]/40 bg-[var(--blue-soft)]/50 p-4">
            <div className="flex items-center gap-2 font-mono text-xs font-semibold text-[var(--blue)]">
              <SparklesIcon className="h-3.5 w-3.5" />
              <span>FOLLOW-UP PRACTICE CHALLENGE</span>
            </div>
            <p className="mt-1 text-xs text-[var(--text)]">
              {activePrompt.response.practicePrompt}
            </p>
            <div className="mt-3 flex gap-2">
              <button
                onClick={() => onNavigate("practice")}
                className="btn-shell btn-primary-shell btn-shell-sm"
              >
                <span className="btn-core">
                  Solve in Practice Arena <ArrowRight className="h-3 w-3" />
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Col: Ask question composer & Learning Modes */}
        <div className="space-y-4">
          <div className="panel clip-oct p-5">
            <h3 className="font-display text-sm font-bold uppercase tracking-wide">
              Ask AI Tutor
            </h3>
            <p className="mt-1 text-xs text-[var(--text-2)]">
              Type any algorithm, time complexity query, or syntax dilemma:
            </p>

            <form onSubmit={handleAskCustom} className="mt-3 space-y-3">
              <textarea
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder="e.g. How does Quicksort partitioning avoid extra memory? Show me a diagram..."
                rows={4}
                className="w-full resize-none border border-[var(--border)] bg-[var(--surface-2)] p-2.5 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
              />

              <button
                type="submit"
                disabled={isThinking || !customInput.trim()}
                className="btn-shell btn-primary-shell btn-shell-md w-full"
              >
                <span className="btn-core">
                  <SendIcon className="h-3.5 w-3.5" />
                  {isThinking ? "Generating Concept..." : "Analyze & Diagram"}
                </span>
              </button>
            </form>
          </div>

          {/* Tutor Capabilities */}
          <div className="panel clip-oct p-5">
            <h4 className="mono-label text-[var(--text-3)]">Studio Capabilities</h4>
            <ul className="mt-3 space-y-2 text-xs text-[var(--text-2)]">
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
                Memory Stack Frame Unwinding
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
                Binary Tree & Graph Traversals
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
                Two-Pointer Window Visualizations
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
                Dynamic Programming Grid Fill Maps
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
