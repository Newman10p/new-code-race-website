import type { EnvironmentType } from "../../../../data/codeLabData";
import { CloseIcon, SparklesIcon, ArrowRight } from "../../../../components/icons";

export default function CodeLabWelcomeModal({
  open,
  onClose,
  onSelectEnvironment,
}: {
  open: boolean;
  onClose: () => void;
  onSelectEnvironment: (env: EnvironmentType, projectName?: string) => void;
}) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="panel-in clip-oct flex w-full max-w-2xl flex-col border border-[var(--border-strong)] bg-[var(--surface-solid)] p-6 shadow-2xl sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b border-[var(--border)] pb-4">
          <div>
            <div className="flex items-center gap-2 font-mono text-[11px] text-[var(--blue)]">
              <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
              <span>THE CODE LAB · WORKSPACE LAUNCHER</span>
            </div>
            <h2 className="display mt-1 text-2xl font-bold uppercase tracking-tight sm:text-3xl">
              Welcome to your Code Lab.
            </h2>
            <p className="mt-1 text-xs text-[var(--text-2)] sm:text-sm">
              Pick an environment, open a project, and bring an idea to life.
            </p>
          </div>
          <button
            onClick={onClose}
            className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
          >
            <CloseIcon className="h-4 w-4" />
          </button>
        </div>

        {/* 3 Environment Cards */}
        <div className="grid gap-4 py-6 sm:grid-cols-3">
          {/* Web */}
          <div
            onClick={() => onSelectEnvironment("web", "My Web App")}
            className="group flex cursor-pointer flex-col justify-between border border-[var(--border)] bg-[var(--surface-2)] p-4 transition-all duration-200 hover:-translate-y-1 hover:border-[var(--blue)] hover:shadow-[0_0_20px_var(--glow)]"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[#F2C94C]/40 bg-[#F2C94C]/10 font-mono text-xs font-bold text-[#F2C94C]">
                  &lt;&gt;
                </span>
                <span className="mono-label text-[9px]">Web</span>
              </div>
              <h3 className="display mt-3 text-base font-bold text-[var(--text)] group-hover:text-[var(--blue)]">
                Web Playground
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-[var(--text-2)]">
                HTML5, CSS3, and modern JavaScript. Perfect for websites, DOM manipulation, and interactive canvas toys.
              </p>
            </div>
            <button className="mt-4 flex items-center gap-1 font-mono text-xs font-semibold text-[var(--blue)]">
              Start Coding <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* React */}
          <div
            onClick={() => onSelectEnvironment("react", "React Portfolio")}
            className="group flex cursor-pointer flex-col justify-between border border-[var(--border)] bg-[var(--surface-2)] p-4 transition-all duration-200 hover:-translate-y-1 hover:border-[var(--blue)] hover:shadow-[0_0_20px_var(--glow)]"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--blue)]/40 bg-[var(--blue-soft)] font-mono text-xs font-bold text-[var(--blue)]">
                  ⚛
                </span>
                <span className="mono-label text-[9px]">React</span>
              </div>
              <h3 className="display mt-3 text-base font-bold text-[var(--text)] group-hover:text-[var(--blue)]">
                React Studio
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-[var(--text-2)]">
                Build components with JSX, hooks, state, and modern styling. Live re-rendering as you code.
              </p>
            </div>
            <button className="mt-4 flex items-center gap-1 font-mono text-xs font-semibold text-[var(--blue)]">
              Start Coding <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* Python */}
          <div
            onClick={() => onSelectEnvironment("python", "Python Algorithms")}
            className="group flex cursor-pointer flex-col justify-between border border-[var(--border)] bg-[var(--surface-2)] p-4 transition-all duration-200 hover:-translate-y-1 hover:border-[var(--blue)] hover:shadow-[0_0_20px_var(--glow)]"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[#5DD39E]/40 bg-[#5DD39E]/10 font-mono text-xs font-bold text-[#5DD39E]">
                  py
                </span>
                <span className="mono-label text-[9px]">Python</span>
              </div>
              <h3 className="display mt-3 text-base font-bold text-[var(--text)] group-hover:text-[var(--blue)]">
                Python Lab
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-[var(--text-2)]">
                Explore programming logic, algorithms, math, data structures, and standard I/O with terminal execution.
              </p>
            </div>
            <button className="mt-4 flex items-center gap-1 font-mono text-xs font-semibold text-[var(--blue)]">
              Start Coding <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between border-t border-[var(--border)] pt-4 text-xs text-[var(--text-3)]">
          <span className="flex items-center gap-1.5 font-mono">
            <SparklesIcon className="h-3.5 w-3.5 text-[var(--blue)]" />
            Isolated local sandbox · Autosaves to browser
          </span>
          <button
            onClick={onClose}
            className="font-mono text-[11px] text-[var(--text-2)] hover:text-[var(--text)]"
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
}
