import { cn } from "../../../../utils/cn";
import { LAB_CHALLENGES, type LabChallenge } from "../../../../data/codeLabData";
import { CloseIcon, ArrowRight, SparklesIcon } from "../../../../components/icons";

export default function CodeLabChallengesDrawer({
  open,
  onClose,
  onLoadChallenge,
}: {
  open: boolean;
  onClose: () => void;
  onLoadChallenge: (challenge: LabChallenge) => void;
}) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="panel-in flex h-full w-full max-w-md flex-col border-l border-[var(--border)] bg-[var(--surface-solid)] p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b border-[var(--border)] pb-4">
          <div>
            <div className="flex items-center gap-2 font-mono text-[11px] text-[var(--blue)]">
              <SparklesIcon className="h-3.5 w-3.5" />
              <span>PLAYGROUND EXPERIMENTS</span>
            </div>
            <h3 className="display mt-1 text-xl font-bold uppercase tracking-tight">
              Project Ideas
            </h3>
            <p className="mt-1 text-xs text-[var(--text-2)]">
              Optional hands-on projects to build, experiment with, and customize in your Code Lab.
            </p>
          </div>
          <button
            onClick={onClose}
            className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
          >
            <CloseIcon className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto py-4 pr-1">
          {LAB_CHALLENGES.map((challenge) => (
            <div
              key={challenge.id}
              className="border border-[var(--border)] bg-[var(--surface-2)] p-4 transition-all hover:border-[var(--blue)]"
            >
              <div className="flex items-center justify-between">
                <span className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-solid)] px-2 py-0.5 font-mono text-[10px] uppercase text-[var(--blue)]">
                  {challenge.env}
                </span>
                <span
                  className={cn(
                    "clip-oct-sm px-2 py-0.5 font-mono text-[10px]",
                    challenge.difficulty === "Beginner" && "text-[#5DD39E]",
                    challenge.difficulty === "Intermediate" && "text-[var(--blue)]",
                    challenge.difficulty === "Advanced" && "text-[#FF6B6B]"
                  )}
                >
                  {challenge.difficulty}
                </span>
              </div>

              <h4 className="display mt-2.5 text-base font-bold text-[var(--text)]">
                {challenge.title}
              </h4>
              <p className="mt-1 text-xs text-[var(--text-2)]">
                {challenge.description}
              </p>

              <div className="mt-3 border-t border-[var(--border)] pt-2.5">
                <p className="mono-label text-[9px] text-[var(--text-3)]">Suggested Specs:</p>
                <ul className="mt-1 space-y-1 text-xs text-[var(--text-2)]">
                  {challenge.specs.map((s, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="mt-1 h-1 w-1 shrink-0 rotate-45 bg-[var(--blue)]" />
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={() => {
                  onLoadChallenge(challenge);
                  onClose();
                }}
                className="mt-4 flex w-full items-center justify-center gap-1.5 border border-[var(--blue)]/60 bg-[var(--blue-soft)] py-2 font-mono text-xs font-semibold text-[var(--blue)] transition-colors hover:bg-[var(--blue)] hover:text-white"
              >
                Load Starter Template <ArrowRight className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
