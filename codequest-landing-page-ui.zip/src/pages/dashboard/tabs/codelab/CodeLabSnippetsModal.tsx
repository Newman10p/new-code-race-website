import { useState } from "react";
import { cn } from "../../../../utils/cn";
import { CODE_SNIPPETS, type CodeSnippet } from "../../../../data/codeLabData";
import { CloseIcon, CheckIcon, SearchIcon, SparklesIcon } from "../../../../components/icons";

export default function CodeLabSnippetsModal({
  open,
  onClose,
  onInsertSnippet,
}: {
  open: boolean;
  onClose: () => void;
  onInsertSnippet: (code: string) => void;
}) {
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [search, setSearch] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!open) return null;

  const categories = ["All", "HTML", "CSS", "JavaScript", "React", "Python"];

  const filtered = CODE_SNIPPETS.filter((s) => {
    const matchCat = activeCategory === "All" || s.category === activeCategory;
    const matchSearch =
      s.title.toLowerCase().includes(search.toLowerCase()) ||
      s.description.toLowerCase().includes(search.toLowerCase()) ||
      s.code.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const handleCopy = (snippet: CodeSnippet) => {
    navigator.clipboard.writeText(snippet.code);
    setCopiedId(snippet.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="panel-in clip-oct flex max-h-[85vh] w-full max-w-3xl flex-col border border-[var(--border-strong)] bg-[var(--surface-solid)] p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b border-[var(--border)] pb-4">
          <div>
            <div className="flex items-center gap-2 font-mono text-[11px] text-[var(--blue)]">
              <SparklesIcon className="h-3.5 w-3.5" />
              <span>QUICK SNIPPETS LIBRARY</span>
            </div>
            <h3 className="display mt-1 text-xl font-bold uppercase tracking-tight">
              Pre-built Code Templates
            </h3>
            <p className="mt-1 text-xs text-[var(--text-2)]">
              Insert functional building blocks into your active editor file.
            </p>
          </div>
          <button
            onClick={onClose}
            className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
          >
            <CloseIcon className="h-4 w-4" />
          </button>
        </div>

        {/* Filter bar */}
        <div className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap gap-1.5">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setActiveCategory(c)}
                className={cn(
                  "clip-oct-sm px-2.5 py-1 font-mono text-xs transition-colors",
                  activeCategory === c
                    ? "bg-[var(--blue)] text-white"
                    : "bg-[var(--surface-2)] text-[var(--text-2)] hover:text-[var(--text)]"
                )}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="relative">
            <SearchIcon className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[var(--text-3)]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search snippets..."
              className="w-full border border-[var(--border)] bg-[var(--surface-2)] py-1 pl-8 pr-3 text-xs text-[var(--text)] focus:border-[var(--blue)] focus:outline-none sm:w-48"
            />
          </div>
        </div>

        {/* Snippets list */}
        <div className="flex-1 space-y-3 overflow-y-auto pr-1">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-xs text-[var(--text-3)]">
              No snippets matching your search.
            </div>
          ) : (
            filtered.map((snippet) => (
              <div
                key={snippet.id}
                className="border border-[var(--border)] bg-[var(--surface-2)] p-3.5"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-solid)] px-2 py-0.5 font-mono text-[10px] text-[var(--blue)]">
                        {snippet.category}
                      </span>
                      <h4 className="font-display text-sm font-semibold text-[var(--text)]">
                        {snippet.title}
                      </h4>
                    </div>
                    <p className="mt-1 text-xs text-[var(--text-2)]">
                      {snippet.description}
                    </p>
                  </div>

                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={() => handleCopy(snippet)}
                      className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-solid)] px-2.5 py-1 font-mono text-xs text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
                    >
                      {copiedId === snippet.id ? (
                        <span className="flex items-center gap-1 text-[#5DD39E]">
                          <CheckIcon className="h-3 w-3" /> Copied
                        </span>
                      ) : (
                        "Copy"
                      )}
                    </button>
                    <button
                      onClick={() => {
                        onInsertSnippet(snippet.code);
                        onClose();
                      }}
                      className="btn-shell btn-primary-shell btn-shell-sm"
                    >
                      <span className="btn-core">Insert</span>
                    </button>
                  </div>
                </div>

                <pre className="mt-2.5 max-h-28 overflow-x-auto border border-[var(--border)] bg-[var(--surface-solid)] p-2 font-mono text-[11px] text-[var(--text-2)]">
                  <code>{snippet.code}</code>
                </pre>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
