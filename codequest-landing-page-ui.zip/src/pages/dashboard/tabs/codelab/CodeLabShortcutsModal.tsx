import { CloseIcon } from "../../../../components/icons";

export default function CodeLabShortcutsModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  if (!open) return null;

  const shortcuts = [
    { action: "Run code / Preview", keys: ["Ctrl", "Enter"], mac: ["⌘", "Enter"] },
    { action: "Save project locally", keys: ["Ctrl", "S"], mac: ["⌘", "S"] },
    { action: "Format document", keys: ["Shift", "Alt", "F"], mac: ["⇧", "⌥", "F"] },
    { action: "Find in file", keys: ["Ctrl", "F"], mac: ["⌘", "F"] },
    { action: "Replace in file", keys: ["Ctrl", "H"], mac: ["⌘", "H"] },
    { action: "Toggle comment line", keys: ["Ctrl", "/"], mac: ["⌘", "/"] },
    { action: "Undo change", keys: ["Ctrl", "Z"], mac: ["⌘", "Z"] },
    { action: "Redo change", keys: ["Ctrl", "Shift", "Z"], mac: ["⇧", "⌘", "Z"] },
    { action: "Focus mode (editor only)", keys: ["Shift", "Alt", "M"], mac: ["⇧", "⌥", "M"] },
    { action: "Toggle File Explorer", keys: ["Ctrl", "B"], mac: ["⌘", "B"] },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="panel-in clip-oct flex w-full max-w-lg flex-col border border-[var(--border-strong)] bg-[var(--surface-solid)] p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b border-[var(--border)] pb-3">
          <div>
            <span className="mono-label text-[var(--blue)]">KEYBOARD REFERENCE</span>
            <h3 className="display mt-1 text-lg font-bold uppercase">
              Editor Shortcuts
            </h3>
          </div>
          <button
            onClick={onClose}
            className="clip-oct-sm flex h-8 w-8 items-center justify-center border border-[var(--border)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
          >
            <CloseIcon className="h-4 w-4" />
          </button>
        </div>

        <div className="divide-y divide-[var(--border)] py-4 text-xs">
          {shortcuts.map((s, idx) => (
            <div key={idx} className="flex items-center justify-between py-2">
              <span className="text-[var(--text)]">{s.action}</span>
              <div className="flex gap-1 font-mono text-[11px]">
                {s.keys.map((k, kIdx) => (
                  <kbd
                    key={kIdx}
                    className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-2)] px-2 py-0.5 text-[var(--text-2)]"
                  >
                    {k}
                  </kbd>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-[var(--border)] pt-3 text-right">
          <button
            onClick={onClose}
            className="btn-shell btn-primary-shell btn-shell-sm"
          >
            <span className="btn-core">Done</span>
          </button>
        </div>
      </div>
    </div>
  );
}
