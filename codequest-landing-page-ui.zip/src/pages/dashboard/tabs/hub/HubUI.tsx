import { useState, type ReactNode } from "react";
import { cn } from "../../../../utils/cn";
import { studentById, type Student } from "../../../../data/hubData";
import { Check, Code2, Copy, X } from "lucide-react";

export function Avatar({ student, id, size = 36, presence = false, onClick, className }: {
  student?: Student; id?: string; size?: number; presence?: boolean; onClick?: () => void; className?: string;
}) {
  const s = student ?? studentById(id ?? "") ?? studentById("stu-farid")!;
  const Wrapper = onClick ? "button" : "span";
  return (
    <Wrapper
      {...(onClick ? { onClick, type: "button" as const, "aria-label": `Open ${s.name}'s profile` } : {})}
      className={cn("hub-avatar", onClick && "cursor-pointer transition-transform hover:scale-105", className)}
      style={{ width: size, height: size, background: s.color, fontSize: Math.max(10, size * 0.34) }}
    >
      {s.initials}
      {presence && s.online && <span className="presence" />}
    </Wrapper>
  );
}

export function Empty({ icon, title, text, action }: { icon?: ReactNode; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="flex min-h-[220px] flex-col items-center justify-center border border-dashed border-[var(--border-strong)] p-8 text-center">
      {icon && <div className="mb-3 text-[var(--text-3)]">{icon}</div>}
      <h3 className="display text-base font-bold uppercase tracking-tight">{title}</h3>
      <p className="mx-auto mt-2 max-w-sm text-[12.5px] leading-relaxed text-[var(--text-2)]">{text}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Modal({ title, onClose, children, wide = false }: {
  title: string; onClose: () => void; children: ReactNode; wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-[95] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-5" onMouseDown={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title} onMouseDown={(e) => e.stopPropagation()}
        className={cn("panel-in hub-scroll max-h-[92vh] w-full overflow-y-auto border border-[var(--border-strong)] bg-[var(--surface-solid)] p-5 sm:p-6", wide ? "max-w-2xl" : "max-w-lg")}>
        <div className="flex items-start justify-between border-b border-[var(--border)] pb-3">
          <h2 className="display text-lg font-bold tracking-tight">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="text-[var(--text-2)] transition-colors hover:text-[var(--blue)]"><X className="h-5 w-5" /></button>
        </div>
        <div className="pt-4">{children}</div>
      </div>
    </div>
  );
}

export function Confirm({ title, text, confirmLabel, danger, onConfirm, onClose }: {
  title: string; text: string; confirmLabel: string; danger?: boolean; onConfirm: () => void; onClose: () => void;
}) {
  return (
    <Modal title={title} onClose={onClose}>
      <p className="text-[13px] leading-relaxed text-[var(--text-2)]">{text}</p>
      <div className="mt-5 flex justify-end gap-2">
        <button className="hub-btn" onClick={onClose}>Cancel</button>
        <button className={cn("hub-btn", danger ? "border-[#FF6B6B] text-[#FF6B6B]" : "hub-btn-primary")} onClick={() => { onConfirm(); onClose(); }}>{confirmLabel}</button>
      </div>
    </Modal>
  );
}

export type Toast = { text: string; ok: boolean } | null;
export function useToast() {
  const [toast, setToast] = useState<Toast>(null);
  const show = (text: string, ok = true) => {
    setToast({ text, ok });
    window.setTimeout(() => setToast(null), 4500);
  };
  return { toast, show };
}

export function ToastView({ toast }: { toast: Toast }) {
  if (!toast) return null;
  return (
    <div role="status" className={cn("fixed bottom-20 right-4 z-[110] flex max-w-sm items-start gap-3 border bg-[var(--surface-solid)] p-3 text-[12.5px] shadow-2xl md:bottom-5", toast.ok ? "border-[#5DD39E]" : "border-[#FF6B6B]")}>
      {toast.ok ? <Check className="mt-0.5 h-4 w-4 shrink-0 text-[#5DD39E]" /> : <X className="mt-0.5 h-4 w-4 shrink-0 text-[#FF6B6B]" />}
      <span className="leading-relaxed">{toast.text}</span>
    </div>
  );
}

/** Code snippet with copy, expand/collapse and an optional Practice hand-off. */
export function CodeBlock({ language, code, title, onOpenPractice }: {
  language: string; code: string; title?: string; onOpenPractice?: () => void;
}) {
  const [expanded, setExpanded] = useState(true);
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard?.writeText(code);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };
  return (
    <div className="hub-snippet">
      <div className="flex items-center gap-2 border-b border-[var(--border)] bg-[var(--surface-solid)] px-3 py-1.5 font-mono text-[10px] text-[var(--text-3)]">
        <Code2 className="h-3 w-3 text-[var(--blue)]" />
        <span className="uppercase">{language}</span>
        {title && <span className="truncate">· {title}</span>}
        <div className="ml-auto flex items-center gap-3">
          <button onClick={() => setExpanded((v) => !v)} className="hover:text-[var(--blue)]">{expanded ? "Collapse" : "Expand"}</button>
          <button onClick={copy} className="flex items-center gap-1 hover:text-[var(--blue)]">
            {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
            {copied ? "Copied" : "Copy"}
          </button>
        </div>
      </div>
      {expanded && <pre><code>{code}</code></pre>}
      {onOpenPractice && (
        <button onClick={onOpenPractice} className="block w-full border-t border-[var(--border)] px-3 py-1.5 text-left font-mono text-[10px] text-[var(--blue)] hover:bg-[var(--blue-soft)]">
          Open in CodeQuest Practice →
        </button>
      )}
    </div>
  );
}

/** Generated visual tile — no stock imagery, composed from geometry + type. */
export function PostArt({ art, className }: { art: { label: string; tone: string; kind: "code" | "grid" | "chart" }; className?: string }) {
  return (
    <div className={cn("hub-art", className)} style={{ height: 150 }}>
      <div className="absolute inset-0 opacity-40" style={{ background: `radial-gradient(70% 100% at 10% 0%, ${art.tone}33, transparent 70%)` }} />
      {art.kind === "grid" && Array.from({ length: 24 }).map((_, i) => (
        <span key={i} className="clip-oct-sm absolute border"
          style={{ width: 22, height: 22, left: `${(i % 8) * 12 + 4}%`, top: `${Math.floor(i / 8) * 32 + 16}%`, borderColor: i % 5 === 0 ? art.tone : "var(--border-strong)", opacity: i % 5 === 0 ? 0.85 : 0.35 }} />
      ))}
      {art.kind === "chart" && (
        <div className="absolute inset-x-8 bottom-6 flex items-end gap-2">
          {[35, 58, 42, 82, 64, 96].map((h, i) => <span key={i} className="flex-1" style={{ height: `${h}%`, background: i === 5 ? art.tone : `${art.tone}55` }} />)}
        </div>
      )}
      {art.kind === "code" && (
        <pre className="absolute left-5 top-5 font-mono text-[10.5px] leading-relaxed" style={{ color: art.tone }}>
{`function think() {
  // build → test → refine
  return clarity;
}`}
        </pre>
      )}
      <span className="absolute bottom-3 left-4 font-mono text-[10px] tracking-[0.14em]" style={{ color: art.tone }}>{art.label}</span>
    </div>
  );
}

export function SectionTitle({ eyebrow, title, right }: { eyebrow?: string; title: string; right?: ReactNode }) {
  return (
    <div className="mb-3 flex flex-wrap items-end justify-between gap-3 border-b border-[var(--border)] pb-3">
      <div>
        {eyebrow && <p className="mono-label mb-1.5 text-[9px] text-[var(--blue)]">{eyebrow}</p>}
        <h2 className="display text-lg font-bold uppercase tracking-tight">{title}</h2>
      </div>
      {right}
    </div>
  );
}

export function SaveIndicator() {
  return <span className="font-mono text-[10px] text-[var(--text-3)]">Saved locally · no server delivery</span>;
}
