import { useEffect, useMemo, useState } from "react";
import { cn } from "../../../../utils/cn";
import { ME, studentById, students, timeAgo, type Community } from "../../../../data/hubData";
import { useHub } from "../../../../lib/hubStore";
import {
  ArrowLeft, BookOpenCheck, Check, Compass, Ellipsis, FolderOpen, Globe,
  Lock, MessageCircle, Search, Send, X,
} from "lucide-react";
import { Avatar, Confirm, Empty, Modal, SectionTitle, ToastView, useToast } from "./HubUI";

const CATEGORIES = ["All", "Programming", "Competitions", "System Design", "Web Development", "AI & Automation", "Learning"];

/* ══════════════ CREATE COMMUNITY ══════════════ */

function CreateCommunityModal({ onClose, onCreated }: { onClose: () => void; onCreated: (id: string) => void }) {
  const hub = useHub();
  const [form, setForm] = useState({ name: "", description: "", category: "Programming", visibility: "open" as Community["visibility"] });
  const [error, setError] = useState("");
  return <Modal title="Create a community" onClose={onClose}>
    <p className="text-[12.5px] leading-relaxed text-[var(--text-2)]">Communities are topic spaces. Joining a community never adds anyone to a group chat — those memberships are separate.</p>
    <div className="mt-4 space-y-3">
      <label className="block"><span className="mono-label mb-1.5 block">Name *</span><input className="hub-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Robotics & IoT" /></label>
      <label className="block"><span className="mono-label mb-1.5 block">Description</span><textarea rows={3} className="hub-input resize-none" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
      <div className="grid gap-3 sm:grid-cols-2">
        <label><span className="mono-label mb-1.5 block">Category</span><select className="hub-input" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{CATEGORIES.slice(1).map((c) => <option key={c}>{c}</option>)}</select></label>
        <label><span className="mono-label mb-1.5 block">Visibility</span><select className="hub-input" value={form.visibility} onChange={(e) => setForm({ ...form, visibility: e.target.value as Community["visibility"] })}><option value="open">Open</option><option value="approval">Approval-based</option><option value="private">Private / invite-only</option></select></label>
      </div>
    </div>
    {error && <p role="alert" className="mt-3 text-[12px] text-[#FF6B6B]">{error}</p>}
    <div className="mt-5 flex justify-end gap-2"><button className="hub-btn" onClick={onClose}>Cancel</button>
      <button className="hub-btn hub-btn-primary" onClick={() => {
        const r = hub.createCommunity(form);
        if (!r.ok) return setError(r.error);
        onCreated(hub.state.communities[0].id); onClose();
      }}>Create community</button></div>
  </Modal>;
}

/* ══════════════ COMMUNITY DETAIL ══════════════ */

type DetailTab = "posts" | "discussions" | "resources" | "members" | "about";

function CommunityDetail({ community, onBack, onOpenProfile, onOpenBattle }: {
  community: Community; onBack: () => void; onOpenProfile: (id: string) => void; onOpenBattle: () => void;
}) {
  const hub = useHub();
  const { toast, show } = useToast();
  const [tab, setTab] = useState<DetailTab>("posts");
  const [leaveConfirm, setLeaveConfirm] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [ruleDraft, setRuleDraft] = useState("");
  const [modOpen, setModOpen] = useState(false);
  const isMod = community.moderators.includes(ME);
  const posts = hub.state.posts.filter((p) => p.communityId === community.id);

  return (
    <div className="mx-auto max-w-[1200px] space-y-5">
      <button onClick={onBack} className="mono-label inline-flex items-center gap-2 transition-colors hover:text-[var(--blue)]"><ArrowLeft className="h-3 w-3" /> Community discovery</button>

      {/* banner */}
      <header className="hub-surface relative overflow-hidden">
        <div className="hub-art h-28" style={{ background: `linear-gradient(110deg, ${community.color}22, transparent 70%)` }}>
          <span className="absolute right-5 top-4 font-mono text-[10px] tracking-[0.16em]" style={{ color: community.color }}>{community.category.toUpperCase()}</span>
        </div>
        <div className="flex flex-wrap items-end gap-4 p-4 sm:p-5">
          <span className="hub-avatar -mt-12 flex h-16 w-16 border-4 border-[var(--surface-solid)] text-lg" style={{ background: community.color }}>{community.initials}</span>
          <div className="min-w-0 flex-1"><h1 className="display text-2xl font-bold tracking-tight">{community.name}</h1>
            <p className="mt-1 max-w-2xl text-[12.5px] leading-relaxed text-[var(--text-2)]">{community.description}</p>
            <p className="mt-1.5 font-mono text-[10px] text-[var(--text-3)]">{community.members.length} members · {community.activity} · {community.visibility}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {community.membership === "none" && <button className="hub-btn hub-btn-primary" onClick={() => { const r = hub.joinCommunity(community.id); show(r.ok ? (community.visibility === "approval" ? "Request sent to moderators." : "You joined the community.") : r.error, r.ok); }}>{community.visibility === "approval" ? "Request to join" : community.visibility === "private" ? "Invite only" : "Join"}</button>}
            {community.membership === "joined" && <button className="hub-btn" onClick={() => setLeaveConfirm(true)}>Leave</button>}
            {community.membership === "pending" && <span className="clip-oct-sm border border-[#F2C94C] px-3 py-2 font-mono text-[10px] text-[#F2C94C]">REQUEST PENDING</span>}
            <button className="hub-btn" onClick={() => navigator.clipboard?.writeText(`#/dashboard/user/hub/communities/${community.id}`)}>Share</button>
            <div className="relative"><button className="hub-btn" onClick={() => setReportOpen((v) => !v)} aria-label="More"><Ellipsis className="h-4 w-4" /></button></div>
            {isMod && <button className="hub-btn" onClick={() => setModOpen(true)}>Moderate</button>}
          </div>
        </div>
      </header>

      {community.membership === "pending" && <div className="border border-[#F2C94C]/40 bg-[#F2C94C]/[0.07] p-3 text-[12px] text-[#F2C94C]">Waiting for a moderator to approve your request. <button onClick={() => { hub.state.communities.find((c) => c.id === community.id) && hub.setSettings({}); show("A real approval requires the community moderator service — this request stays pending."); }} className="underline">Why is this pending?</button></div>}
      {community.membership === "banned" && <div className="border border-[#FF6B6B]/40 bg-[#FF6B6B]/10 p-3 text-[12px] text-[#FF6B6B]">You are banned from this community. The join action is unavailable.</div>}

      <div className="flex flex-wrap gap-1.5 border-b border-[var(--border)] pb-2">
        {(["posts", "discussions", "resources", "members", "about"] as DetailTab[]).map((t) => <button key={t} aria-pressed={tab === t} onClick={() => setTab(t)} className={cn("hub-pill", tab === t && "is-active")}>{t[0].toUpperCase() + t.slice(1)}</button>)}
      </div>

      <div className="grid gap-8 xl:grid-cols-[minmax(0,1fr)_276px]">
        <div className="min-w-0">
          {tab === "posts" && <>
            {community.announcements.length > 0 && <div className="mb-4 border-l-2 bg-[var(--surface-solid)] p-3" style={{ borderColor: community.color }}>
              <p className="mono-label text-[9px]" style={{ color: community.color }}>PINNED ANNOUNCEMENT</p>
              {community.announcements.map((a) => <p key={a.id} className="mt-1.5 text-[12.5px] leading-relaxed">{a.text}<span className="ml-2 font-mono text-[10px] text-[var(--text-3)]">{timeAgo(a.at)}</span></p>)}
            </div>}
            <SectionTitle title="Community posts" right={<span className="font-mono text-[10px] text-[var(--text-3)]">{posts.length} posts</span>} />
            {posts.length === 0 ? <Empty title="No posts here yet" text="Community posts appear as students publish them." />
              : posts.map((p) => <div key={p.id} className="hub-surface mb-3 p-4"><div className="flex items-center gap-2"><Avatar id={p.authorId} size={26} onClick={() => onOpenProfile(p.authorId)} /><span className="text-[12.5px] font-semibold">{studentById(p.authorId)?.name}</span><span className="font-mono text-[10px] text-[var(--text-3)]">{timeAgo(p.at)}</span>
                {community.pinnedPostIds.includes(p.id) && <span className="ml-auto font-mono text-[9px] text-[var(--blue)]">📌 PINNED</span>}</div>
                <p className="mt-2 whitespace-pre-wrap text-[13px] leading-relaxed">{p.text}</p>
                <div className="mt-2 flex gap-4 font-mono text-[10.5px] text-[var(--text-3)]"><span>♥ {p.likes.length}</span><span>💬 {p.comments.length}</span>
                  {isMod && <><button className="ml-auto text-[var(--blue)]" onClick={() => { hub.pinCommunityPost(community.id, p.id); show("Post pin state updated."); }}>{community.pinnedPostIds.includes(p.id) ? "Unpin" : "Pin"}</button>
                    <button className="text-[#FF6B6B]" onClick={() => { hub.removeCommunityPost(community.id, p.id); show("Post removed by moderator."); }}>Remove</button></>}</div>
              </div>)}
          </>}

          {tab === "discussions" && <><SectionTitle title="Discussion threads" /><div className="space-y-2">{[
            { title: "Best way to explain invariants to beginners?", replies: 8, author: "stu-sarah" },
            { title: "Round 1 scrimmage — post your approach here", replies: 14, author: "stu-alex" },
            { title: community.category + " resources megathread", replies: 5, author: "stu-aisha" },
          ].map((d) => <div key={d.title} className="hub-surface flex items-center gap-3 p-3.5"><MessageCircle className="h-4 w-4 text-[var(--blue)]" /><div className="min-w-0 flex-1"><button onClick={() => onOpenProfile(d.author)} className="text-[13px] font-semibold hover:text-[var(--blue)]">{d.title}</button><p className="font-mono text-[10px] text-[var(--text-3)]">by {studentById(d.author)?.name} · {d.replies} replies</p></div><Send className="h-3.5 w-3.5 text-[var(--text-3)]" /></div>)}</div>
            <p className="mt-3 font-mono text-[10px] text-[var(--text-3)]">Community discussions are separate from group-chat membership.</p></>}

          {tab === "resources" && <><SectionTitle title="Featured resources" />
            {community.resources.length === 0 ? <Empty title="No resources yet" text="Moderators can pin reference material here." />
              : <div className="space-y-2">{community.resources.map((r) => <div key={r.id} className="hub-surface flex items-center gap-3 p-3.5"><span className="clip-oct-sm border border-[var(--border)] px-2 py-1 font-mono text-[10px] text-[var(--blue)]">{r.kind}</span><span className="text-[13px]">{r.title}</span><button className="ml-auto font-mono text-[10.5px] text-[var(--blue)]" onClick={() => show("Resource download needs the platform content service.")}>Open →</button></div>)}</div>}</>}

          {tab === "members" && <><SectionTitle title={`Members · ${community.members.length}`} />
            <div className="grid gap-2 sm:grid-cols-2">{community.members.map((id) => { const s = studentById(id); if (!s) return null; return <button key={id} onClick={() => onOpenProfile(id)} className="hub-surface flex items-center gap-3 p-3 text-left hover:border-[var(--blue)]"><Avatar student={s} size={32} presence /><span className="min-w-0"><span className="block truncate text-[12.5px] font-semibold">{s.name}</span><span className="block font-mono text-[10px] text-[var(--text-3)]">{community.moderators.includes(id) ? community.ownerId === id ? "Owner" : "Moderator" : "Member"} · {s.school}</span></span></button>; })}</div>
            {isMod && <div className="mt-4 border border-dashed border-[var(--border-strong)] p-3"><p className="mono-label text-[9px]">Moderator tools</p>
              <button className="hub-btn mt-2" onClick={() => show("Invite sent (local). Real invites are delivered by the notification service.")}>Invite student</button>
              <button className="hub-btn ml-2" onClick={() => show("Appointing moderators requires server-side role validation.")}>Appoint moderator</button></div>}</>}

          {tab === "about" && <><SectionTitle title="About & rules" />
            <div className="hub-surface p-4"><p className="text-[13px] leading-relaxed text-[var(--text-2)]">{community.description}</p>
              <h3 className="mono-label mt-5 mb-2 text-[var(--text)]">Community rules</h3><ol className="space-y-1.5">{community.rules.map((r, i) => <li key={r} className="flex gap-2 text-[12.5px] text-[var(--text-2)]"><span className="font-mono text-[var(--blue)]">{String(i + 1).padStart(2, "0")}</span>{r}</li>)}</ol>
              {isMod && <div className="mt-4 flex gap-2 border-t border-[var(--border)] pt-3"><input className="hub-input flex-1" value={ruleDraft} onChange={(e) => setRuleDraft(e.target.value)} placeholder="New rule…" /><button className="hub-btn" onClick={() => { if (!ruleDraft.trim()) return; show("Editing rules requires the community service — not applied locally."); }}>Add rule</button></div>}
            </div></>}
        </div>

        {/* right panel */}
        <aside className="hidden space-y-4 lg:block">
          <div className="hub-surface p-4"><p className="mono-label mb-3 text-[var(--text)]">Moderators</p>
            <div className="space-y-2">{community.moderators.map((id) => <button key={id} onClick={() => onOpenProfile(id)} className="flex w-full items-center gap-2.5 text-left hover:text-[var(--blue)]"><Avatar id={id} size={26} /><span className="text-[12px]">{studentById(id)?.name}</span></button>)}</div></div>
          <div className="hub-surface p-4"><p className="mono-label mb-2 text-[var(--text)]">Rules at a glance</p><ul className="space-y-1">{community.rules.map((r) => <li key={r} className="text-[11.5px] text-[var(--text-2)]">· {r}</li>)}</ul></div>
          <button onClick={onOpenBattle} className="hub-surface block w-full p-4 text-left"><p className="mono-label text-[#FF9F6B]">Upcoming battles</p><p className="mt-1.5 text-[12px]">{hub.state.battles.filter((b) => b.status === "open" || b.status === "waiting").length} sessions open</p></button>
          <div className="hub-surface p-4"><p className="mono-label mb-2 text-[var(--text)]">Related communities</p><div className="flex flex-wrap gap-1.5">{hub.state.communities.filter((c) => c.id !== community.id && c.category === community.category).slice(0, 3).map((c) => <button key={c.id} onClick={() => onOpenProfile(c.ownerId)} className="hub-pill px-2 py-1 text-[10px]">{c.name}</button>)}</div></div>
        </aside>
      </div>

      {leaveConfirm && <Confirm title="Leave community?" text={`You will lose access to ${community.name}'s member area. Group chats are unaffected.`} confirmLabel="Leave" danger onConfirm={() => { hub.leaveCommunity(community.id); show("You left the community."); }} onClose={() => setLeaveConfirm(false)} />}
      {reportOpen && <Modal title="Report community" onClose={() => setReportOpen(false)}><p className="text-[12.5px] text-[var(--text-2)]">Reports are reviewed by platform moderators, not community moderators.</p><div className="mt-4 flex justify-end gap-2"><button className="hub-btn" onClick={() => setReportOpen(false)}>Cancel</button><button className="hub-btn hub-btn-primary" onClick={() => { hub.submitReport("community", community.id, "Reported from community detail"); setReportOpen(false); show("Report submitted. Thank you."); }}>Submit report</button></div></Modal>}
      {modOpen && <Modal title="Moderation panel" onClose={() => setModOpen(false)}><p className="text-[12.5px] leading-relaxed text-[var(--text-2)]">As a moderator you can pin or remove posts in the Posts tab. Membership approval, bans and role changes are validated by the community service and are not applied locally.</p><div className="mt-4 space-y-2"><button className="hub-btn w-full justify-between" onClick={() => { show("Pending membership requests are delivered by the backend service."); setModOpen(false); }}>Approve pending requests <span>backend required</span></button><button className="hub-btn w-full justify-between" onClick={() => { show("Banning a member requires server-side role validation."); setModOpen(false); }}>Manage members <span>backend required</span></button></div></Modal>}
      <ToastView toast={toast} />
    </div>
  );
}

/* ══════════════ DISCOVERY ══════════════ */

export default function CommunitiesView({ focusId, onOpenProfile, onOpenBattle, createSignal }: {
  focusId?: string | null; onOpenProfile: (id: string) => void; onOpenBattle: () => void; createSignal?: number;
}) {
  const hub = useHub();
  const { toast, show } = useToast();
  const [openId, setOpenId] = useState<string | null>(focusId ?? null);
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [membershipFilter, setMembershipFilter] = useState("All");
  useEffect(() => { if (createSignal) setCreateOpen(true); }, [createSignal]);
  useEffect(() => { if (focusId) setOpenId(focusId); }, [focusId]);

  const visible = useMemo(() => hub.state.communities.filter((c) => {
    if (category !== "All" && c.category !== category) return false;
    if (membershipFilter === "Joined" && c.membership !== "joined") return false;
    if (membershipFilter === "Available" && c.membership === "joined") return false;
    if (query && !`${c.name} ${c.description}`.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  }), [hub.state.communities, category, query, membershipFilter]);

  if (openId && hub.state.communities.some((c) => c.id === openId)) {
    return <CommunityDetail community={hub.state.communities.find((c) => c.id === openId)!} onBack={() => setOpenId(null)} onOpenProfile={onOpenProfile} onOpenBattle={onOpenBattle} />;
  }

  const featured = hub.state.communities.filter((c) => c.activity === "Very active").slice(0, 2);

  return (
    <div className="mx-auto max-w-[1000px] space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--border)] pb-4">
        <div><p className="mono-label mb-1.5 text-[9px] text-[var(--blue)]">COMMUNITY / SPACES</p><h1 className="display text-2xl font-bold uppercase tracking-tight">Find your people. Build together.</h1>
          <p className="mt-1 text-[12.5px] text-[var(--text-2)]">Topic spaces separate from group chats — joining here never adds you to a private conversation.</p></div>
        <button className="hub-btn hub-btn-primary" onClick={() => setCreateOpen(true)}>+ Create community</button>
      </div>

      {featured.length > 0 && <div className="grid gap-3 sm:grid-cols-2">{featured.map((c) => <button key={c.id} onClick={() => setOpenId(c.id)} className="hub-surface group relative overflow-hidden p-4 text-left transition-all hover:-translate-y-0.5 hover:border-[var(--blue)]">
        <span className="hub-art pointer-events-none absolute inset-y-0 right-0 w-2/5 opacity-30" style={{ background: `radial-gradient(80% 100% at 100% 0%, ${c.color}55, transparent)` }} />
        <p className="mono-label text-[9px]" style={{ color: c.color }}>FEATURED · {c.activity.toUpperCase()}</p>
        <h3 className="display mt-1.5 text-lg font-bold">{c.name}</h3><p className="relative mt-1 line-clamp-2 text-[12.5px] text-[var(--text-2)]">{c.description}</p>
        <span className="mt-3 inline-flex items-center gap-1 font-mono text-[10.5px] text-[var(--blue)]">View community <Send className="h-3 w-3" /></span>
      </button>)}</div>}

      <div className="flex flex-wrap gap-1.5">
        {CATEGORIES.map((c) => <button key={c} aria-pressed={category === c} onClick={() => setCategory(c)} className={cn("hub-pill", category === c && "is-active")}>{c}</button>)}
        <div className="ml-auto flex gap-1.5">{["All", "Joined", "Available"].map((m) => <button key={m} aria-pressed={membershipFilter === m} onClick={() => setMembershipFilter(m)} className={cn("hub-pill px-2.5 py-1 text-[10px]", membershipFilter === m && "is-active")}>{m}</button>)}
          <label className="relative"><Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[var(--text-3)]" /><input className="hub-input w-40 pl-8" placeholder="Search…" value={query} onChange={(e) => setQuery(e.target.value)} /></label></div>
      </div>

      <SectionTitle eyebrow="DISCOVERY" title="Communities" right={<span className="font-mono text-[10px] text-[var(--text-3)]">{visible.length} spaces</span>} />
      {visible.length === 0 ? <Empty title="No communities match" text="Clear a filter or create a new space." action={<button className="hub-btn hub-btn-primary" onClick={() => setCreateOpen(true)}>Create community</button>} />
        : <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{visible.map((c) => (
          <div key={c.id} className="hub-surface flex flex-col p-4 transition-all hover:-translate-y-0.5 hover:border-[var(--blue)]">
            <div className="flex items-start gap-3"><span className="hub-avatar flex h-11 w-11 text-[13px]" style={{ background: c.color }}>{c.initials}</span>
              <div className="min-w-0 flex-1"><h3 className="display truncate text-[15px] font-bold">{c.name}</h3><p className="font-mono text-[10px] text-[var(--text-3)]">{c.category} · {c.members.length} members</p></div>
              {c.visibility === "private" ? <Lock className="h-3.5 w-3.5 text-[var(--text-3)]" /> : c.visibility === "approval" ? <Check className="h-3.5 w-3.5 text-[#F2C94C]" /> : <Globe className="h-3.5 w-3.5 text-[#5DD39E]" />}
            </div>
            <p className="mt-3 line-clamp-2 flex-1 text-[12.5px] leading-relaxed text-[var(--text-2)]">{c.description}</p>
            <div className="mt-3 flex items-center justify-between border-t border-[var(--border)] pt-3">
              <span className={cn("clip-oct-sm border px-2 py-0.5 font-mono text-[9.5px]", c.membership === "joined" ? "border-[#5DD39E] text-[#5DD39E]" : c.membership === "pending" ? "border-[#F2C94C] text-[#F2C94C]" : "border-[var(--border)] text-[var(--text-3)]")}>{c.membership.toUpperCase()}</span>
              <div className="flex gap-1.5"><button className="hub-btn px-2 py-1 text-[10px]" onClick={() => setOpenId(c.id)}>View</button>
                {c.membership === "none" && <button className="hub-btn hub-btn-primary px-2 py-1 text-[10px]" onClick={() => { const r = hub.joinCommunity(c.id); show(r.ok ? (c.visibility === "approval" ? "Request sent to moderators." : "You joined.") : r.error, r.ok); }}>{c.visibility === "approval" ? "Request" : "Join"}</button>}</div>
            </div>
          </div>
        ))}</div>}

      {createOpen && <CreateCommunityModal onClose={() => setCreateOpen(false)} onCreated={(id) => { setOpenId(id); show("Community created — you are the owner."); }} />}
      <ToastView toast={toast} />
    </div>
  );
}

/* keep shared imports referenced */
void BookOpenCheck; void Compass; void FolderOpen; void X; void students;
