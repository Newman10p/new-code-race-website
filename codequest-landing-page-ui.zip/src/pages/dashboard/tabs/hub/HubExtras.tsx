import { useMemo, useState } from "react";
import { cn } from "../../../../utils/cn";
import {
  ME, dateShort, studentById, students, timeAgo,
  type Student,
} from "../../../../data/hubData";
import { canDirectMessage, useHub, type HubState } from "../../../../lib/hubStore";
import {
  ArrowLeft, Bell, CircleUserRound, Ellipsis, Globe,
  Heart, Lock, MessageCircle, Newspaper, Search, SlidersHorizontal,
  Swords, UsersRound, X,
} from "lucide-react";
import { Avatar, Empty, Modal, SectionTitle, ToastView, useToast } from "./HubUI";

/* ══════════════ HUB HOME ══════════════ */

export function HubHome({ onNavigate, onOpenProfile, onOpenCommunity, onOpenBattle, onOpenConversation }: {
  onNavigate: (s: string) => void; onOpenProfile: (id: string) => void;
  onOpenCommunity: (id: string) => void; onOpenBattle: () => void; onOpenConversation: (id: string) => void;
}) {
  const hub = useHub();
  const unread = hub.unreadChats;
  const trending = [...hub.state.posts].sort((a, b) => b.likes.length + b.comments.length * 2 - (a.likes.length + a.comments.length * 2)).slice(0, 3);
  const activeBattles = hub.state.battles.filter((b) => ["live", "waiting", "starting-soon", "open"].includes(b.status)).slice(0, 2);

  return (
    <div className="mx-auto max-w-[960px] space-y-8">
      <header className="border-b border-[var(--border)] pb-5">
        <p className="mono-label flex items-center gap-2 text-[var(--blue)]"><span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />THE STUDENT HUB / HOME</p>
        <h1 className="display mt-2 text-3xl font-bold uppercase leading-[1.03] tracking-tight sm:text-[2.6rem]">Connect. Share. Collaborate. <span className="text-[var(--blue)]">Compete.</span></h1>
        <p className="mt-2 text-sm text-[var(--text-2)]">A digital campus for young developers — conversations, community and friendly battles in one place.</p>
      </header>

      <dl className="grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-4">
        {[["Unread messages", unread], ["Message requests", hub.pendingIncomingRequests.length], ["Communities", hub.state.communities.filter((c) => c.membership === "joined").length], ["Open battles", hub.state.battles.filter((b) => b.status === "open").length]].map(([k, v]) => (
          <div key={k as string} className="border-l border-[var(--border-strong)] pl-3"><dt className="mono-label text-[9px]">{k}</dt><dd className="display mt-1 text-2xl font-bold">{v}</dd></div>
        ))}
      </dl>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          {/* three experiences */}
          <div className="grid gap-3 sm:grid-cols-3">
            {[
              { key: "chats", icon: <MessageCircle className="h-5 w-5" />, title: "Conversations", text: "Group chats & permission-based private messages", tone: "var(--blue)" },
              { key: "posts", icon: <Globe className="h-5 w-5" />, title: "Community", text: "Posts, discussions and topic communities", tone: "#AA8CFF" },
              { key: "battles", icon: <Swords className="h-5 w-5" />, title: "Battle Arena", text: "Student-organised friendly coding battles", tone: "#FF9F6B" },
            ].map((e) => (
              <button key={e.key} onClick={() => onNavigate(e.key)} className="hub-surface group p-4 text-left transition-all hover:-translate-y-0.5 hover:border-[var(--blue)]">
                <span style={{ color: e.tone }}>{e.icon}</span>
                <h2 className="display mt-2.5 text-[15px] font-bold">{e.title}</h2>
                <p className="mt-1 text-[12px] leading-relaxed text-[var(--text-2)]">{e.text}</p>
                <span className="mt-3 inline-flex items-center gap-1 font-mono text-[10px] text-[var(--blue)]">Open <ArrowLeft className="h-3 w-3 transition-transform group-hover:translate-x-1" /></span>
              </button>
            ))}
          </div>

          <section><SectionTitle eyebrow="PICK UP WHERE YOU LEFT OFF" title="Recent conversations" right={<button onClick={() => onNavigate("chats")} className="font-mono text-[10px] text-[var(--blue)]">All chats →</button>} />
            <div className="hub-surface divide-y divide-[var(--border)]">
              {hub.state.conversations.slice(0, 4).map((c) => {
                const last = c.messages[c.messages.length - 1];
                return <button key={c.id} onClick={() => onOpenConversation(c.id)} className="flex w-full items-center gap-3 p-3 text-left hover:bg-[var(--surface-2)]">
                  <span className="hub-avatar flex h-8 w-8 text-[10px]" style={{ background: c.color }}>{c.initials}</span>
                  <span className="min-w-0 flex-1"><span className="block truncate text-[12.5px] font-semibold">{c.name}</span><span className="block truncate text-[11.5px] text-[var(--text-2)]">{last?.text || "No messages yet"}</span></span>
                  {c.unread > 0 && <span className="clip-oct-sm bg-[var(--blue)] px-1.5 py-0.5 font-mono text-[9px] text-white">{c.unread}</span>}
                  <span className="font-mono text-[10px] text-[var(--text-3)]">{last ? timeAgo(last.at) : ""}</span>
                </button>;
              })}
            </div>
          </section>

          <section><SectionTitle eyebrow="COMMUNITY" title="Trending posts" right={<button onClick={() => onNavigate("posts")} className="font-mono text-[10px] text-[var(--blue)]">Open feed →</button>} />
            <div className="space-y-2">{trending.map((p) => <button key={p.id} onClick={() => onNavigate("posts")} className="hub-surface flex w-full items-start gap-3 p-3 text-left hover:border-[var(--blue)]">
              <Avatar id={p.authorId} size={28} /><span className="min-w-0 flex-1"><span className="font-mono text-[10px] text-[var(--text-3)]">{studentById(p.authorId)?.name} · {p.category}</span>
                <span className="mt-1 block line-clamp-2 text-[12.5px] leading-relaxed">{p.text}</span></span>
              <span className="flex items-center gap-1 font-mono text-[10px] text-[var(--text-3)]"><Heart className="h-3 w-3" />{p.likes.length}</span>
            </button>)}</div>
          </section>
        </div>

        <aside className="space-y-5">
          <section><SectionTitle title="Suggested students" />
            <div className="hub-surface divide-y divide-[var(--border)]">{students.filter((s) => s.id !== ME && !hub.state.following.includes(s.id)).slice(0, 4).map((s) => <div key={s.id} className="flex items-center gap-2.5 p-3">
              <Avatar student={s} size={30} presence onClick={() => onOpenProfile(s.id)} />
              <span className="min-w-0 flex-1"><span className="block truncate text-[12px] font-semibold">{s.name}</span><span className="block truncate font-mono text-[9.5px] text-[var(--text-3)]">{s.interests[0]}</span></span>
              <button className="hub-btn px-2 py-1 text-[10px]" onClick={() => hub.toggleFollow(s.id)}>Follow</button></div>)}</div>
          </section>
          <section><SectionTitle title="Suggested communities" />
            <div className="space-y-2">{hub.state.communities.filter((c) => c.membership !== "joined" && c.visibility !== "private").slice(0, 3).map((c) => <button key={c.id} onClick={() => onOpenCommunity(c.id)} className="hub-surface flex w-full items-center gap-2.5 p-3 text-left hover:border-[var(--blue)]">
              <span className="hub-avatar flex h-8 w-8 text-[10px]" style={{ background: c.color }}>{c.initials}</span>
              <span className="min-w-0 flex-1"><span className="block truncate text-[12px] font-semibold">{c.name}</span><span className="block font-mono text-[9.5px] text-[var(--text-3)]">{c.members.length} members · {c.activity}</span></span>
              <ArrowLeft className="h-3 w-3 text-[var(--text-3)]" /></button>)}</div>
          </section>
          <section><SectionTitle title="Active battles" />
            <div className="space-y-2">{activeBattles.map((b) => <button key={b.id} onClick={onOpenBattle} className="hub-surface block w-full p-3 text-left hover:border-[#FF9F6B]"><span className="mono-label text-[9px] text-[#FF9F6B]">{b.status.toUpperCase()}</span><span className="mt-1 block text-[12.5px] font-semibold">{b.title}</span><span className="font-mono text-[10px] text-[var(--text-3)]">{b.participants.length}/{b.maxPlayers} players</span></button>)}</div>
          </section>
        </aside>
      </div>
    </div>
  );
}

/* ══════════════ UNIFIED SEARCH ══════════════ */

export function SearchOverlay({ onClose, onNavigate, onOpenProfile, onOpenCommunity, onOpenConversation }: {
  onClose: () => void; onNavigate: (s: string) => void; onOpenProfile: (id: string) => void;
  onOpenCommunity: (id: string) => void; onOpenConversation: (id: string) => void;
}) {
  const hub = useHub();
  const [q, setQ] = useState("");
  const [recent, setRecent] = useState<string[]>([]);
  const query = q.trim().toLowerCase();

  const results = useMemo(() => {
    if (!query) return null;
    const match = (s: string) => s.toLowerCase().includes(query);
    return {
      students: students.filter((s) => s.id !== ME && !hub.state.blocked.includes(s.id) && (match(s.name) || match(s.handle) || match(s.school))),
      posts: hub.state.posts.filter((p) => match(p.text) && p.audience !== "draft" && !hub.state.hiddenPosts.includes(p.id)).slice(0, 5),
      communities: hub.state.communities.filter((c) => c.visibility !== "private" && (match(c.name) || match(c.description))),
      groups: hub.state.conversations.filter((c) => c.type === "group" && match(c.name)),
      battles: hub.state.battles.filter((b) => b.access !== "invite" && match(b.title)),
    };
  }, [query, hub.state]);

  const go = (fn: () => void) => { if (q.trim()) setRecent((r) => [q.trim(), ...r.filter((x) => x !== q.trim())].slice(0, 4)); fn(); onClose(); };

  const Group = ({ label, count, children }: { label: string; count: number; children: React.ReactNode }) => (
    <div className="border-b border-[var(--border)] py-3 last:border-0">
      <p className="mono-label mb-2 text-[9px]">{label} · {count}</p>
      {count === 0 ? <p className="font-mono text-[10.5px] text-[var(--text-3)]">No matches</p> : <div className="space-y-1.5">{children}</div>}
    </div>
  );

  return <div className="fixed inset-0 z-[92] flex items-start justify-center bg-black/70 p-4 pt-16 backdrop-blur-sm" onMouseDown={onClose}>
    <div className="panel-in w-full max-w-2xl border border-[var(--border-strong)] bg-[var(--surface-solid)]" onMouseDown={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label="Search the Hub">
      <div className="flex items-center gap-3 border-b border-[var(--border)] px-4 py-3"><Search className="h-4 w-4 text-[var(--blue)]" />
        <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search students, posts, communities, groups, battles…" className="flex-1 bg-transparent text-[13px] outline-none" />
        <button onClick={onClose} aria-label="Close search"><X className="h-4 w-4" /></button></div>
      <div className="hub-scroll max-h-[65vh] overflow-y-auto px-4 py-2">
        {!results ? <><p className="mono-label mt-3 text-[9px]">Recent searches</p>
          {recent.length ? <div className="mt-2 flex flex-wrap gap-1.5">{recent.map((r) => <button key={r} onClick={() => setQ(r)} className="hub-pill text-[10px]">{r}</button>)}</div> : <p className="mt-2 font-mono text-[11px] text-[var(--text-3)]">Try "graph", "Python", "Sarah", or "sprint".</p>}
          <p className="mt-4 border-t border-[var(--border)] pt-3 font-mono text-[10px] leading-relaxed text-[var(--text-3)]">Private conversations, private communities and invite-only battles are never returned by search.</p></>
          : <>
            <Group label="Students" count={results.students.length}>{results.students.map((s) => <button key={s.id} onClick={() => go(() => onOpenProfile(s.id))} className="flex w-full items-center gap-2.5 p-2 text-left hover:bg-[var(--surface-2)]"><Avatar student={s} size={26} /><span className="text-[12.5px]">{s.name}</span><span className="font-mono text-[10px] text-[var(--text-3)]">{s.handle} · {s.school}</span></button>)}</Group>
            <Group label="Posts" count={results.posts.length}>{results.posts.map((p) => <button key={p.id} onClick={() => go(() => onNavigate("posts"))} className="block w-full p-2 text-left text-[12px] hover:bg-[var(--surface-2)]"><span className="line-clamp-1">{p.text}</span><span className="font-mono text-[10px] text-[var(--text-3)]">{studentById(p.authorId)?.name} · {p.category}</span></button>)}</Group>
            <Group label="Communities" count={results.communities.length}>{results.communities.map((c) => <button key={c.id} onClick={() => go(() => onOpenCommunity(c.id))} className="flex w-full items-center gap-2.5 p-2 text-left hover:bg-[var(--surface-2)]"><span className="hub-avatar flex h-6 w-6 text-[9px]" style={{ background: c.color }}>{c.initials}</span><span className="text-[12.5px]">{c.name}</span><span className="font-mono text-[10px] text-[var(--text-3)]">{c.members.length} members</span></button>)}</Group>
            <Group label="Group chats you belong to" count={results.groups.length}>{results.groups.map((c) => <button key={c.id} onClick={() => go(() => onOpenConversation(c.id))} className="flex w-full items-center gap-2.5 p-2 text-left hover:bg-[var(--surface-2)]"><span className="hub-avatar flex h-6 w-6 text-[9px]" style={{ background: c.color }}>{c.initials}</span><span className="text-[12.5px]">{c.name}</span><span className="font-mono text-[10px] text-[var(--text-3)]">{c.memberIds.length} members</span></button>)}</Group>
            <Group label="Public battles" count={results.battles.length}>{results.battles.map((b) => <button key={b.id} onClick={() => go(() => onNavigate("battles"))} className="flex w-full items-center gap-2.5 p-2 text-left hover:bg-[var(--surface-2)]"><Swords className="h-4 w-4 text-[#FF9F6B]" /><span className="text-[12.5px]">{b.title}</span><span className="font-mono text-[10px] text-[var(--text-3)]">{b.status}</span></button>)}</Group>
          </>}
      </div>
    </div>
  </div>;
}

/* ══════════════ NOTIFICATIONS ══════════════ */

export function NotificationsView({ onNavigate }: { onNavigate: (s: string) => void }) {
  const hub = useHub();
  const [filter, setFilter] = useState("All");
  const list = hub.state.notifications.filter((n) => filter === "All" || (filter === "Unread" ? n.unread : n.icon === filter.toLowerCase()));
  const icons = { message: <MessageCircle className="h-3.5 w-3.5" />, request: <Lock className="h-3.5 w-3.5" />, post: <Heart className="h-3.5 w-3.5" />, community: <UsersRound className="h-3.5 w-3.5" />, battle: <Swords className="h-3.5 w-3.5" />, mention: <Newspaper className="h-3.5 w-3.5" /> };

  return <div className="mx-auto max-w-3xl space-y-4">
    <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--border)] pb-3"><div><p className="mono-label mb-1.5 text-[9px] text-[var(--blue)]">HUB ACTIVITY</p><h1 className="display text-2xl font-bold uppercase tracking-tight">Notifications</h1></div>
      <button className="hub-btn" onClick={() => hub.markAllNotificationsRead()}>Mark all as read</button></div>
    <div className="flex flex-wrap gap-1.5">{["All", "Unread", "message", "request", "post", "community", "battle", "mention"].map((f) => <button key={f} aria-pressed={filter === f} onClick={() => setFilter(f)} className={cn("hub-pill px-2.5 py-1 text-[10px]", filter === f && "is-active")}>{f === "All" || f === "Unread" ? f : f[0].toUpperCase() + f.slice(1)}</button>)}</div>
    {list.length === 0 ? <Empty icon={<Bell className="h-7 w-7" />} title="Nothing here" text="Hub activity appears here when something needs your attention." />
      : <div className="hub-surface divide-y divide-[var(--border)]">{list.map((n) => <button key={n.id} onClick={() => { hub.markNotificationRead(n.id); onNavigate(n.target === "chats" ? "chats" : n.target === "requests" ? "requests" : n.target); }} className={cn("flex w-full items-start gap-3 p-3.5 text-left transition-colors hover:bg-[var(--surface-2)]", n.unread && "bg-[var(--blue-soft)]/40")}>
        <span className="clip-oct-sm mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center border border-[var(--border)] bg-[var(--surface-2)] text-[var(--blue)]">{icons[n.icon]}</span>
        <span className="min-w-0 flex-1"><span className={cn("block text-[12.5px]", n.unread && "font-bold")}>{n.title}</span><span className="mt-0.5 block text-[11.5px] text-[var(--text-2)]">{n.message}</span><span className="mt-1 block font-mono text-[10px] text-[var(--text-3)]">{dateShort(n.at)} · {n.type}</span></span>
        {n.unread && <span className="mt-2 h-1.5 w-1.5 shrink-0 rotate-45 bg-[var(--blue)]" />}</button>)}</div>}
    <p className="font-mono text-[10px] text-[var(--text-3)]">Related minor actions are grouped into a single notification where possible. Hub events also appear in your main dashboard inbox.</p>
  </div>;
}

/* ══════════════ STUDENT PROFILE ══════════════ */

function MessageRequestModal({ student, onClose }: { student: Student; onClose: () => void }) {
  const hub = useHub();
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  return <Modal title={`Message ${student.name}`} onClose={onClose}>
    <div className="flex items-center gap-3"><Avatar student={student} size={40} presence /><div><p className="text-[13px] font-semibold">{student.name}</p><p className="font-mono text-[10px] text-[var(--text-3)]">{student.school}</p></div></div>
    <p className="mt-4 border border-[var(--blue)]/40 bg-[var(--blue-soft)] p-3 text-[12px] leading-relaxed text-[var(--text-2)]">A private conversation only opens after this student accepts your request. Until then, your message stays in the request area.</p>
    <label className="mt-4 block"><span className="mono-label mb-1.5 block">Introduction *</span><textarea rows={3} className="hub-input resize-none" value={text} onChange={(e) => setText(e.target.value)} /></label>
    {error && <p role="alert" className="mt-2 text-[12px] text-[#FF6B6B]">{error}</p>}
    <div className="mt-4 flex justify-end gap-2"><button className="hub-btn" onClick={onClose}>Cancel</button><button className="hub-btn hub-btn-primary" onClick={() => { const r = hub.sendRequest(student.id, text); if (!r.ok) return setError(r.error); onClose(); }}>Send request</button></div>
  </Modal>;
}

export function StudentProfileView({ studentId, onNavigate, onOpenCommunity, onBack }: {
  studentId: string; onNavigate: (s: string) => void; onOpenCommunity: (id: string) => void; onBack: () => void;
}) {
  const hub = useHub();
  const { toast, show } = useToast();
  const s = studentById(studentId);
  const [requestOpen, setRequestOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  if (!s) return <Empty title="Profile unavailable" text="This student could not be found." />;
  const isMe = s.id === ME;
  const following = hub.state.following.includes(s.id);
  const blocked = hub.state.blocked.includes(s.id);
  const hasConversation = canDirectMessage(hub.state, s.id);
  const pending = hub.state.requests.find((r) => r.fromId === ME && r.toId === s.id && r.status === "pending");
  const posts = hub.state.posts.filter((p) => p.authorId === s.id && p.audience === "public");
  const communities = hub.state.communities.filter((c) => c.members.includes(s.id) && c.visibility !== "private");

  return <div className="mx-auto max-w-3xl space-y-5">
    <button onClick={onBack} className="mono-label inline-flex items-center gap-2 hover:text-[var(--blue)]"><ArrowLeft className="h-3 w-3 rotate-180" />Back</button>
    <header className="hub-surface relative overflow-hidden">
      <div className="hub-art h-24" style={{ background: `linear-gradient(110deg, ${s.color}33, transparent 70%)` }} />
      <div className="flex flex-wrap items-end gap-4 p-5"><Avatar student={s} size={72} presence className="-mt-12 border-4 border-[var(--surface-solid)]" />
        <div className="min-w-0 flex-1"><h1 className="display text-2xl font-bold">{s.name}</h1><p className="font-mono text-[11px] text-[var(--text-3)]">{s.handle} · {s.school}</p>
          <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-[var(--text-2)]">{s.bio}</p></div>
        {!isMe && <div className="flex flex-wrap gap-2">
          <button className="hub-btn hub-btn-primary" onClick={() => hub.toggleFollow(s.id)}>{following ? "Unfollow" : "Follow"}</button>
          {hasConversation ? <button className="hub-btn" onClick={() => onNavigate("chats")}>Open chat</button>
            : pending ? <button className="hub-btn" onClick={() => { hub.cancelRequest(pending.id); show("Request cancelled."); }}>Cancel request</button>
            : <button className="hub-btn" onClick={() => setRequestOpen(true)}>Send Message</button>}
          <button className="hub-btn" onClick={() => setReportOpen(true)}>Report</button>
          <button className={cn("hub-btn", blocked && "border-[#FF6B6B] text-[#FF6B6B]")} onClick={() => { hub.toggleBlock(s.id); show(blocked ? "Student unblocked." : "Student blocked. They cannot send another request."); }}>{blocked ? "Unblock" : "Block"}</button>
        </div>}
      </div>
      {pending && <p className="border-t border-[var(--border)] px-5 py-2 font-mono text-[10.5px] text-[#F2C94C]">Request sent · waiting for a response. No private conversation is active yet.</p>}
    </header>

    <div className="grid gap-4 sm:grid-cols-2">
      <div className="hub-surface p-4"><p className="mono-label mb-2 text-[var(--text)]">Interests & languages</p>
        <div className="flex flex-wrap gap-1.5">{[...s.interests, ...s.languages].map((i) => <span key={i} className="hub-pill px-2.5 py-1 text-[10px]">{i}</span>)}</div></div>
      <div className="hub-surface p-4"><p className="mono-label mb-2 text-[var(--text)]">Public achievements</p>
        <ul className="space-y-1.5">{s.achievements.map((a) => <li key={a} className="flex items-center gap-2 text-[12px] text-[var(--text-2)]"><SlidersHorizontal className="h-3.5 w-3.5 text-[var(--blue)]" />{a}</li>)}</ul></div>
      <div className="hub-surface p-4"><p className="mono-label mb-2 text-[var(--text)]">Projects</p>{s.projects.length ? <ul className="space-y-1.5">{s.projects.map((p) => <li key={p} className="text-[12px] text-[var(--text-2)]">· {p}</li>)}</ul> : <p className="font-mono text-[10.5px] text-[var(--text-3)]">No public projects.</p>}</div>
      <div className="hub-surface p-4"><p className="mono-label mb-2 text-[var(--text)]">Communities (visible)</p>
        <div className="flex flex-wrap gap-1.5">{communities.map((c) => <button key={c.id} onClick={() => onOpenCommunity(c.id)} className="hub-pill px-2.5 py-1 text-[10px]">{c.name}</button>)}</div>
        <p className="mt-2 font-mono text-[9.5px] text-[var(--text-3)]">Private communities are never shown on a profile.</p></div>
    </div>

    <section><SectionTitle title="Public posts" right={<span className="font-mono text-[10px] text-[var(--text-3)]">{posts.length}</span>} />
      {posts.length === 0 ? <p className="border border-dashed border-[var(--border)] p-5 text-center text-[12.5px] text-[var(--text-3)]">No public posts yet.</p>
        : <div className="space-y-2">{posts.map((p) => <button key={p.id} onClick={() => onNavigate("posts")} className="hub-surface block w-full p-3.5 text-left hover:border-[var(--blue)]"><p className="font-mono text-[10px] text-[var(--text-3)]">{p.category} · {timeAgo(p.at)}</p><p className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed">{p.text}</p><p className="mt-2 font-mono text-[10px] text-[var(--text-3)]">♥ {p.likes.length} · 💬 {p.comments.length}</p></button>)}</div>}</section>

    {requestOpen && <MessageRequestModal student={s} onClose={() => setRequestOpen(false)} />}
    {reportOpen && <Modal title="Report student" onClose={() => setReportOpen(false)}><p className="text-[12.5px] text-[var(--text-2)]">Reports are private and reviewed by platform moderators.</p><div className="mt-4 flex justify-end gap-2"><button className="hub-btn" onClick={() => setReportOpen(false)}>Cancel</button><button className="hub-btn hub-btn-primary" onClick={() => { hub.submitReport("user", s.id, "Reported from profile"); setReportOpen(false); show("Report submitted. Thank you."); }}>Submit report</button></div></Modal>}
    <ToastView toast={toast} />
  </div>;
}

/* ══════════════ HUB SETTINGS / PRIVACY ══════════════ */

export function HubSettingsView({ onNavigate }: { onNavigate: (s: string) => void }) {
  const hub = useHub();
  const { toast, show } = useToast();
  const [confirmReset, setConfirmReset] = useState(false);
  return <div className="mx-auto max-w-3xl space-y-5">
    <div className="border-b border-[var(--border)] pb-3"><p className="mono-label mb-1.5 text-[9px] text-[var(--blue)]">HUB / PREFERENCES</p><h1 className="display text-2xl font-bold uppercase tracking-tight">Hub settings & privacy</h1></div>

    <div className="hub-surface p-5"><SectionTitle title="Private messaging" />
      <label className="block"><span className="mono-label mb-1.5 block">Who can send you message requests</span>
        <select className="hub-input" value={hub.state.settings.whoCanRequest} onChange={(e) => hub.setSettings({ whoCanRequest: e.target.value as HubState["settings"]["whoCanRequest"] })}>
          <option value="everyone">Everyone on CodeQuest</option><option value="following">Students I follow</option><option value="none">Nobody (block outgoing requests too)</option></select></label>
      <p className="mt-2 font-mono text-[10px] leading-relaxed text-[var(--text-3)]">Accepted requests become active private conversations. Declined and blocked users cannot use the same request again.</p>
    </div>

    <div className="hub-surface p-5"><SectionTitle title="Hub activity" />
      {([
        ["battleInvites", "Allow battle invitations"],
        ["showPresence", "Show my online presence"],
        ["allowCommunityInvites", "Allow community invitations"],
      ] as [keyof HubState["settings"], string][]).map(([key, label]) => <label key={key} className="flex cursor-pointer items-center justify-between border-b border-[var(--border)] py-2.5 text-[12.5px] last:border-0">
        <span>{label}</span><input type="checkbox" className="accent-[var(--blue)]" checked={Boolean(hub.state.settings[key])} onChange={(e) => hub.setSettings({ [key]: e.target.checked })} /></label>)}
    </div>

    <div className="hub-surface p-5"><SectionTitle title={`Blocked users · ${hub.state.blocked.length}`} />
      {hub.state.blocked.length === 0 ? <p className="font-mono text-[11px] text-[var(--text-3)]">You have not blocked anyone.</p>
        : <div className="space-y-2">{hub.state.blocked.map((id) => <div key={id} className="flex items-center gap-2.5 border border-[var(--border)] p-2.5"><Avatar id={id} size={28} /><span className="flex-1 text-[12.5px]">{studentById(id)?.name}</span><button className="hub-btn px-2 py-1 text-[10px]" onClick={() => { hub.toggleBlock(id); show("Student unblocked."); }}>Unblock</button></div>)}</div>}
      <p className="mt-3 font-mono text-[10px] text-[var(--text-3)]">Blocking applies across message requests and other relevant social interactions.</p>
    </div>

    <div className="hub-surface p-5"><SectionTitle title={`Moderation records · ${hub.state.reports.length}`} />
      {hub.state.reports.length === 0 ? <p className="font-mono text-[11px] text-[var(--text-3)]">No reports submitted.</p>
        : <div className="space-y-1.5">{hub.state.reports.slice(0, 6).map((r) => <div key={r.id} className="flex items-center justify-between border-b border-[var(--border)] pb-1.5 text-[11.5px]"><span>{r.kind} report · {r.reason}</span><span className="font-mono text-[10px] text-[var(--text-3)]">{timeAgo(r.at)}</span></div>)}</div>}
      <button className="hub-btn mt-3" onClick={() => onNavigate("announcements")}>Notification preferences →</button>
    </div>

    <div className="border border-dashed border-[var(--border-strong)] p-4"><p className="mono-label text-[#F2C94C]">Prototype data</p>
      <p className="mt-1.5 text-[12px] leading-relaxed text-[var(--text-2)]">All Hub records are stored in this browser. Reset restores the sample data set.</p>
      <button className="hub-btn mt-3 border-[#FF6B6B]/50 text-[#FF6B6B]" onClick={() => setConfirmReset(true)}>Reset Hub demo data</button></div>

    {confirmReset && <Modal title="Reset Hub data?" onClose={() => setConfirmReset(false)}><p className="text-[12.5px] text-[var(--text-2)]">This replaces your local posts, messages, communities and battles with the original sample set.</p><div className="mt-4 flex justify-end gap-2"><button className="hub-btn" onClick={() => setConfirmReset(false)}>Cancel</button><button className="hub-btn border-[#FF6B6B] text-[#FF6B6B]" onClick={() => { hub.reset(); setConfirmReset(false); show("Hub demo data restored."); }}>Reset</button></div></Modal>}
    <ToastView toast={toast} />
  </div>;
}

void CircleUserRound; void Ellipsis;
