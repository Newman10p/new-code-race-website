import { useEffect, useRef, useState } from "react";
import { cn } from "../../../../utils/cn";
import {
  ME, clockTime, dateShort, studentById, students, timeAgo,
  type Attachment, type Conversation, type Message,
} from "../../../../data/hubData";
import { useHub, type ActionResult } from "../../../../lib/hubStore";
import {
  ArrowLeft, ArrowRight, Code2, Ellipsis, FileText, Hash,
  MessageCircle, Paperclip, Pin, Search, Send, Settings2,
  UsersRound, X,
} from "lucide-react";
import { Avatar, CodeBlock, Confirm, Empty, Modal, ToastView, useToast } from "./HubUI";

type Variant = "all" | "group" | "direct";

const EMOJIS = ["⬡", "🔥", "💡", "🙌", "🚀", "✓"];
const GROUP_COLORS = ["#4D9CFF", "#5DD39E", "#AA8CFF", "#F2C94C", "#5DD3C5", "#FF9F6B"];

/* ══════════════ GROUP CREATION WIZARD ══════════════ */

function GroupWizard({ onClose, onCreated }: { onClose: () => void; onCreated: (id: string) => void }) {
  const hub = useHub();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [members, setMembers] = useState<string[]>([]);
  const [color, setColor] = useState(GROUP_COLORS[0]);
  const [error, setError] = useState("");
  const { toast, show } = useToast();

  const steps = ["Name", "Description", "Members", "Identity", "Review"];
  const next = () => {
    if (step === 0 && !name.trim()) return setError("Give the group a name.");
    if (step === 2 && members.length === 0) return setError("Invite at least one student.");
    setError("");
    if (step === 4) {
      const r = hub.createGroup({ name, description, memberIds: members, color });
      if (!r.ok) return setError(r.error);
      const created = hub.state.conversations[0];
      show(`${name} created — you are the owner.`);
      window.setTimeout(() => { onCreated(created?.id ?? ""); onClose(); }, 500);
      return;
    }
    setStep((s) => s + 1);
  };

  return (
    <Modal title="Create a group chat" onClose={onClose} wide>
      <div className="mb-5 flex gap-1.5">{steps.map((s, i) => <span key={s} className={cn("h-1 flex-1 transition-colors", i <= step ? "bg-[var(--blue)]" : "bg-[var(--border)]")} />)}</div>
      <p className="mono-label text-[9px] text-[var(--blue)]">STEP {step + 1} / 5 · {steps[step].toUpperCase()}</p>

      <div className="mt-4 min-h-[190px]">
        {step === 0 && <label className="block"><span className="mono-label mb-2 block">Group name *</span><input autoFocus className="hub-input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. python-mastery" /></label>}
        {step === 1 && <label className="block"><span className="mono-label mb-2 block">Short description</span><textarea rows={4} className="hub-input resize-none" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What is this group for?" /></label>}
        {step === 2 && (
          <div><span className="mono-label mb-2 block">Invite students *</span>
            <div className="hub-scroll max-h-48 space-y-1.5 overflow-y-auto">
              {students.filter((s) => s.id !== ME).map((s) => (
                <label key={s.id} className={cn("flex cursor-pointer items-center gap-3 border p-2.5 transition-colors", members.includes(s.id) ? "border-[var(--blue)] bg-[var(--blue-soft)]" : "border-[var(--border)] hover:border-[var(--blue)]")}>
                  <input type="checkbox" className="accent-[var(--blue)]" checked={members.includes(s.id)} onChange={() => setMembers((m) => m.includes(s.id) ? m.filter((x) => x !== s.id) : [...m, s.id])} />
                  <Avatar student={s} size={26} /><span className="text-[12.5px] font-medium">{s.name}</span>
                  <span className="ml-auto font-mono text-[10px] text-[var(--text-3)]">{s.school}</span>
                </label>
              ))}
            </div>
          </div>
        )}
        {step === 3 && <div><span className="mono-label mb-2 block">Generated colour identity</span>
          <div className="flex flex-wrap gap-2">{GROUP_COLORS.map((c) => <button key={c} onClick={() => setColor(c)} aria-label={`Choose ${c}`} className={cn("hub-avatar h-10 w-10 border-2", color === c ? "border-[var(--text)]" : "border-transparent")} style={{ background: c }}>{name.trim().slice(0, 2).toUpperCase() || "CG"}</button>)}</div>
          <p className="mt-3 font-mono text-[10.5px] text-[var(--text-3)]">Groups use generated colour identities. Image upload is not connected in this prototype.</p>
        </div>}
        {step === 4 && <dl className="space-y-2 border border-[var(--border)] bg-[var(--surface-2)] p-4 text-[12.5px]">
          {[["Name", name.startsWith("#") ? name : `#${name}`], ["Description", description || "—"], ["Members", `${members.length + 1} including you`], ["Role", "Owner (you)"], ["Invite link", "Generated on creation, expires in 7 days"]].map(([k, v]) => (
            <div key={k} className="flex justify-between gap-4"><dt className="font-mono text-[11px] text-[var(--text-3)]">{k}</dt><dd className="text-right">{v}</dd></div>))}
        </dl>}
      </div>

      {error && <p role="alert" className="mt-3 text-[12px] text-[#FF6B6B]">{error}</p>}
      <div className="mt-5 flex justify-between border-t border-[var(--border)] pt-4">
        <button className="hub-btn" onClick={() => step === 0 ? onClose() : setStep((s) => s - 1)}>{step === 0 ? "Cancel" : "← Back"}</button>
        <button className="hub-btn hub-btn-primary" onClick={next}>{step === 4 ? "Create group" : "Continue →"}</button>
      </div>
      <ToastView toast={toast} />
    </Modal>
  );
}

/* ══════════════ REQUEST FLOW ══════════════ */

function NewRequestModal({ onClose }: { onClose: () => void }) {
  const hub = useHub();
  const [toId, setToId] = useState(students.find((s) => s.id !== ME)!.id);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  return (
    <Modal title="New message request" onClose={onClose}>
      <p className="border border-[var(--blue)]/40 bg-[var(--blue-soft)] p-3 text-[12px] leading-relaxed text-[var(--text-2)]">
        Private conversations only begin after the other student accepts your request. Until then, your message stays in the request area.
      </p>
      <label className="mt-4 block"><span className="mono-label mb-2 block">Recipient</span>
        <select className="hub-input" value={toId} onChange={(e) => setToId(e.target.value)}>
          {students.filter((s) => s.id !== ME).map((s) => <option key={s.id} value={s.id}>{s.name} · {s.school}</option>)}
        </select></label>
      <label className="mt-4 block"><span className="mono-label mb-2 block">Introduction *</span>
        <textarea rows={4} className="hub-input resize-none" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Say why you'd like to connect…" /></label>
      <p className="mt-2 font-mono text-[10px] text-[var(--text-3)]">Rate limit: 5 pending outgoing requests. Who can message you is controlled in Hub settings.</p>
      {error && <p role="alert" className="mt-3 text-[12px] text-[#FF6B6B]">{error}</p>}
      <div className="mt-5 flex justify-end gap-2">
        <button className="hub-btn" onClick={onClose}>Cancel</button>
        <button className="hub-btn hub-btn-primary" onClick={() => {
          const r = hub.sendRequest(toId, message);
          if (!r.ok) return setError(r.error);
          onClose();
        }}>Send request</button>
      </div>
    </Modal>
  );
}

function RequestsPanel({ onOpenProfile }: { onOpenProfile: (id: string) => void }) {
  const hub = useHub();
  const { toast, show } = useToast();
  const [newOpen, setNewOpen] = useState(false);
  const incoming = hub.pendingIncomingRequests;
  const outgoing = hub.pendingOutgoingRequests;
  const declined = hub.state.requests.filter((r) => r.status !== "pending" && r.status !== "accepted");

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--border)] pb-3">
        <div><p className="mono-label mb-1.5 text-[9px] text-[var(--blue)]">PRIVATE MESSAGING · PERMISSION MODEL</p><h2 className="display text-xl font-bold uppercase tracking-tight">Message requests</h2>
          <p className="mt-1 text-[12.5px] text-[var(--text-2)]">A direct conversation becomes active only after the recipient accepts.</p></div>
        <button className="hub-btn hub-btn-primary" onClick={() => setNewOpen(true)}>New message</button>
      </div>

      <section>
        <h3 className="mono-label mb-3 text-[var(--text)]">Incoming · {incoming.length}</h3>
        {incoming.length === 0 ? <Empty icon={<Pin className="h-7 w-7" />} title="No pending requests" text="New private message requests will appear here, separate from your active conversations." />
          : <div className="space-y-2.5">{incoming.map((r) => {
            const s = studentById(r.fromId)!;
            return (
              <div key={r.id} className="hub-surface p-4">
                <div className="flex items-start gap-3">
                  <Avatar student={s} size={40} presence onClick={() => onOpenProfile(s.id)} />
                  <div className="min-w-0 flex-1">
                    <button onClick={() => onOpenProfile(s.id)} className="text-[13px] font-semibold hover:text-[var(--blue)]">{s.name}</button>
                    <p className="font-mono text-[10px] text-[var(--text-3)]">{s.school} · {dateShort(r.at)}</p>
                    <p className="mt-2 border-l-2 border-[var(--blue)] pl-3 text-[13px] leading-relaxed text-[var(--text-2)]">{r.initialMessage}</p>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button className="hub-btn hub-btn-primary" onClick={() => { const res = hub.acceptRequest(r.id); show(res.ok ? "Request accepted — conversation is now active." : res.error, res.ok); }}>Accept</button>
                  <button className="hub-btn" onClick={() => { hub.declineRequest(r.id); show("Request declined."); }}>Decline</button>
                  <button className="hub-btn" onClick={() => { hub.blockFromRequest(r.id); show("Student blocked. They cannot send another request."); }}>Block</button>
                  <button className="hub-btn ml-auto" onClick={() => { const res = hub.submitReport("request", r.id, "Inappropriate request"); show(res.ok ? "Reported to moderators." : res.error, res.ok); }}>Report</button>
                </div>
              </div>
            );
          })}</div>}
      </section>

      <section>
        <h3 className="mono-label mb-3 text-[var(--text)]">Sent · waiting for response</h3>
        {outgoing.length === 0 ? <p className="border border-dashed border-[var(--border-strong)] p-5 text-center text-[12.5px] text-[var(--text-3)]">No outgoing requests pending.</p>
          : <div className="space-y-2">{outgoing.map((r) => (
            <div key={r.id} className="hub-surface flex flex-wrap items-center gap-3 p-3">
              <Avatar id={r.toId} size={32} />
              <div className="min-w-0 flex-1"><p className="text-[12.5px] font-semibold">{studentById(r.toId)?.name}</p><p className="truncate font-mono text-[10px] text-[var(--text-3)]">{r.initialMessage}</p></div>
              <span className="clip-oct-sm border border-[#F2C94C]/50 px-2 py-0.5 font-mono text-[9.5px] text-[#F2C94C]">REQUEST SENT · WAITING</span>
              <button className="hub-btn" onClick={() => { hub.cancelRequest(r.id); show("Request cancelled."); }}>Cancel</button>
            </div>
          ))}</div>}
      </section>

      {declined.length > 0 && <section>
        <h3 className="mono-label mb-3 text-[var(--text)]">Closed requests</h3>
        <div className="space-y-2">{declined.map((r) => (
          <div key={r.id} className="flex items-center gap-3 border border-dashed border-[var(--border)] p-3 text-[12px] text-[var(--text-3)]">
            <span>{r.fromId === ME ? `To ${studentById(r.toId)?.name}` : `From ${studentById(r.fromId)?.name}`}</span>
            <span className="ml-auto font-mono text-[10px] uppercase">{r.status}</span>
          </div>
        ))}</div>
      </section>}

      {newOpen && <NewRequestModal onClose={() => setNewOpen(false)} />}
      <ToastView toast={toast} />
    </div>
  );
}

/* ══════════════ MESSAGE ROW ══════════════ */

function MessageRow({ message, conv, grouped, onReply, onProfile, onOpenPractice }: {
  message: Message; conv: Conversation; grouped: boolean; onReply: () => void; onProfile: (id: string) => void; onOpenPractice: () => void;
}) {
  const hub = useHub();
  const [menu, setMenu] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(message.text);
  const [reportOpen, setReportOpen] = useState(false);
  const s = studentById(message.fromId);
  const mine = message.fromId === ME;
  const pinned = conv.pinnedMessages.includes(message.id);

  if (message.deleted) return <div className="py-1.5 pl-[46px] font-mono text-[11px] italic text-[var(--text-3)]">Message deleted</div>;

  return (
    <div className={cn("hub-arrive group relative flex gap-3 py-1.5", grouped && "py-0.5")}>
      <div className="w-8 shrink-0">{!grouped && s && <Avatar student={s} size={32} presence onClick={() => onProfile(s.id)} />}</div>
      <div className="min-w-0 flex-1">
        {!grouped && (
          <div className="flex flex-wrap items-baseline gap-2">
            <button onClick={() => s && onProfile(s.id)} className="text-[12.5px] font-semibold hover:text-[var(--blue)]">{s?.name ?? "Unknown"}</button>
            <span className="font-mono text-[10px] text-[var(--text-3)]">{clockTime(message.at)}</span>
            {pinned && <span className="font-mono text-[9px] text-[var(--blue)]">📌 PINNED</span>}
            {message.edited && <span className="font-mono text-[9px] text-[var(--text-3)]">edited</span>}
          </div>
        )}

        {message.replyTo && (() => {
          const parent = conv.messages.find((m) => m.id === message.replyTo);
          return parent ? <p className="mt-1 border-l-2 border-[var(--border-strong)] pl-2 font-mono text-[10.5px] text-[var(--text-3)]">↳ {studentById(parent.fromId)?.name}: {parent.text.slice(0, 70)}</p> : null;
        })()}

        {editing ? (
          <div className="mt-1 flex gap-2">
            <input autoFocus className="hub-input" value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { hub.editMessage(conv.id, message.id, draft); setEditing(false); } }} />
            <button className="hub-btn" onClick={() => { hub.editMessage(conv.id, message.id, draft); setEditing(false); }}>Save</button>
            <button className="hub-btn" onClick={() => setEditing(false)}>Cancel</button>
          </div>
        ) : <p className="mt-0.5 whitespace-pre-wrap text-[13.5px] leading-relaxed text-[var(--text)]">{message.text}</p>}

        {message.attachment?.kind === "code" && (
          <div className="mt-2"><CodeBlock language={message.attachment.language} title={message.attachment.title} code={message.attachment.code} onOpenPractice={onOpenPractice} /></div>
        )}
        {message.attachment?.kind === "file" && (
          <div className="mt-2 flex w-fit items-center gap-3 border border-[var(--border)] bg-[var(--surface-2)] p-3">
            <FileText className="h-4 w-4 text-[var(--blue)]" /><span className="text-[12px]">{message.attachment.name}</span>
            <span className="font-mono text-[10px] text-[var(--text-3)]">{(message.attachment.size / 1000).toFixed(0)} KB</span>
          </div>
        )}
        {message.attachment?.kind === "link" && (
          <a href={message.attachment.url} className="mt-2 flex w-fit items-center gap-2 border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-[12px] text-[var(--blue)] hover:border-[var(--blue)]">{message.attachment.title} ↗</a>
        )}
        {message.attachment?.kind === "image" && <PostArtLike attachment={message.attachment} />}

        <div className="mt-1 flex flex-wrap items-center gap-1.5">
          {message.reactions.map((r) => (
            <button key={r.emoji} onClick={() => hub.reactToMessage(conv.id, message.id, r.emoji)}
              className={cn("hub-pill px-2 py-0.5 text-[11px]", r.by.includes(ME) && "border-[var(--blue)] text-[var(--blue)]")} title={r.by.map((b) => studentById(b)?.name).join(", ")}>
              {r.emoji} {r.by.length}
            </button>
          ))}
          {mine && message.status === "sending" && <span className="font-mono text-[9.5px] text-[#F2C94C]">Sending…</span>}
          {mine && message.status === "failed" && <button className="font-mono text-[9.5px] text-[#FF6B6B] underline" onClick={() => hub.retryMessage(conv.id, message.id)}>Failed — retry</button>}
          {mine && message.status === "sent" && <span className="font-mono text-[9.5px] text-[var(--text-3)]">Recorded locally</span>}
        </div>
      </div>

      {/* hover actions */}
      <div className="absolute right-0 top-0 hidden items-center gap-0.5 border border-[var(--border)] bg-[var(--surface-solid)] p-0.5 group-hover:flex">
        <button onClick={() => hub.reactToMessage(conv.id, message.id, "⬡")} aria-label="React" className="p-1 text-[var(--text-3)] hover:text-[var(--blue)]">⬡</button>
        <button onClick={onReply} aria-label="Reply" className="p-1 text-[var(--text-3)] hover:text-[var(--blue)]"><ArrowLeft className="h-3.5 w-3.5" /></button>
        <button onClick={() => hub.togglePinMessage(conv.id, message.id)} aria-label="Pin message" className="p-1 text-[var(--text-3)] hover:text-[var(--blue)]"><Paperclip className="h-3.5 w-3.5" /></button>
        <button onClick={() => setMenu((v) => !v)} aria-label="More actions" className="p-1 text-[var(--text-3)] hover:text-[var(--blue)]"><Ellipsis className="h-3.5 w-3.5" /></button>
        {menu && (
          <div className="absolute right-0 top-8 z-20 w-40 border border-[var(--border-strong)] bg-[var(--surface-solid)] p-1 shadow-xl">
            {[
              { label: "Copy text", fn: () => navigator.clipboard?.writeText(message.text) },
              { label: "React 🔥", fn: () => hub.reactToMessage(conv.id, message.id, "🔥") },
              ...(mine ? [{ label: "Edit", fn: () => { setEditing(true); setMenu(false); } }, { label: "Delete", fn: () => hub.deleteMessage(conv.id, message.id) }] : []),
              { label: "Report", fn: () => { setReportOpen(true); setMenu(false); } },
            ].map((a) => <button key={a.label} onClick={() => { a.fn(); setMenu(false); }} className="block w-full px-2 py-1.5 text-left text-[11.5px] text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--blue)]">{a.label}</button>)}
          </div>
        )}
      </div>

      {reportOpen && (
        <Modal title="Report message" onClose={() => setReportOpen(false)}>
          <p className="text-[12.5px] text-[var(--text-2)]">Reports go to Hub moderators. Private messages are never exposed to ordinary community moderators.</p>
          <div className="mt-4 flex justify-end gap-2"><button className="hub-btn" onClick={() => setReportOpen(false)}>Cancel</button>
            <button className="hub-btn hub-btn-primary" onClick={() => { hub.submitReport("message", message.id, "Reported from conversation"); setReportOpen(false); }}>Submit report</button></div>
        </Modal>
      )}
    </div>
  );
}

function PostArtLike({ attachment }: { attachment: Extract<Attachment, { kind: "image" }> }) {
  return <div className="hub-art mt-2" style={{ height: 110 }}><span className="absolute bottom-3 left-4 font-mono text-[10px]" style={{ color: attachment.tone }}>{attachment.label}</span></div>;
}

/* ══════════════ COMPOSER ══════════════ */

function Composer({ conv, replyTo, onClearReply, onOpenPractice }: {
  conv: Conversation; replyTo: string | null; onClearReply: () => void; onOpenPractice: () => void;
}) {
  const hub = useHub();
  const [text, setText] = useState("");
  const [attachMenu, setAttachMenu] = useState(false);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [snippetOpen, setSnippetOpen] = useState(false);
  const [linkOpen, setLinkOpen] = useState(false);
  const [snippet, setSnippet] = useState({ language: "python", title: "Snippet", code: "" });
  const [link, setLink] = useState({ url: "", title: "" });
  const [upload, setUpload] = useState<{ name: string; pct: number } | null>(null);
  const [error, setError] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const blocked = conv.type === "direct" && conv.participantIds?.some((p) => hub.state.blocked.includes(p));

  const send = (attachment?: Attachment) => {
    const r: ActionResult = hub.sendMessage(conv.id, text, attachment, replyTo ?? undefined);
    if (!r.ok) return setError(r.error);
    setText(""); setAttachMenu(false); onClearReply(); setError("");
  };

  const onFile = (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    const v = hub.validateFile({ name: file.name, size: file.size });
    if (!v.ok) return setError(v.error);
    setUpload({ name: file.name, pct: 0 });
    let pct = 0;
    const t = window.setInterval(() => {
      pct = Math.min(100, pct + 25);
      setUpload({ name: file.name, pct });
      if (pct >= 100) {
        window.clearInterval(t);
        setUpload(null);
        send({ kind: "file", name: file.name, size: file.size });
      }
    }, 180);
  };

  if (blocked) return <div className="border-t border-[var(--border)] p-4 text-center font-mono text-[11.5px] text-[#FF6B6B]">This conversation is blocked. Unblock the student in Hub settings to continue.</div>;

  return (
    <div className="shrink-0 border-t border-[var(--border)] bg-[var(--surface-solid)] p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] md:pb-3">
      {replyTo && (() => {
        const parent = conv.messages.find((m) => m.id === replyTo);
        return parent ? <div className="mb-2 flex items-center gap-2 border-l-2 border-[var(--blue)] bg-[var(--blue-soft)] px-3 py-1.5 text-[11.5px] text-[var(--text-2)]">
          <span className="truncate">Replying to {studentById(parent.fromId)?.name}: {parent.text.slice(0, 60)}</span>
          <button onClick={onClearReply} className="ml-auto"><X className="h-3 w-3" /></button>
        </div> : null;
      })()}

      {upload && <div className="mb-2 border border-[var(--border)] p-2.5 font-mono text-[10.5px]"><div className="flex justify-between"><span>{upload.name}</span><span>{upload.pct}%</span></div><div className="mt-1 h-1 bg-[var(--border)]"><div className="h-full bg-[var(--blue)]" style={{ width: `${upload.pct}%` }} /></div></div>}
      {error && <p role="alert" className="mb-2 text-[11.5px] text-[#FF6B6B]">{error}</p>}

      <div className="flex items-end gap-2">
        <div className="relative">
          <button onClick={() => setAttachMenu((v) => !v)} aria-label="Attach" className="hub-btn px-2.5"><Paperclip className="h-4 w-4" /></button>
          {attachMenu && <div className="absolute bottom-11 left-0 z-20 w-48 border border-[var(--border-strong)] bg-[var(--surface-solid)] p-1 shadow-xl">
            {[
              { label: "Code snippet", icon: <Code2 className="h-3.5 w-3.5" />, fn: () => setSnippetOpen(true) },
              { label: "File (max 20 MB)", icon: <FileText className="h-3.5 w-3.5" />, fn: () => inputRef.current?.click() },
              { label: "Link", icon: <ArrowRight className="h-3.5 w-3.5" />, fn: () => setLinkOpen(true) },
              { label: "Visual tile", icon: <Hash className="h-3.5 w-3.5" />, fn: () => send({ kind: "image", label: "SHARED PROJECT PREVIEW", tone: "#4D9CFF" }) },
            ].map((a) => <button key={a.label} onClick={() => { a.fn(); setAttachMenu(false); }} className="flex w-full items-center gap-2 px-2 py-2 text-left text-[12px] text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--blue)]">{a.icon}{a.label}</button>)}
          </div>}
          <input ref={inputRef} type="file" className="sr-only" onChange={(e) => { onFile(e.target.files); e.target.value = ""; }} />
        </div>

        <div className="relative">
          <button onClick={() => setEmojiOpen((v) => !v)} aria-label="Reactions" className="hub-btn px-2.5">⬡</button>
          {emojiOpen && <div className="absolute bottom-11 left-0 z-20 flex gap-1 border border-[var(--border-strong)] bg-[var(--surface-solid)] p-2 shadow-xl">
            {EMOJIS.map((e) => <button key={e} onClick={() => { setText((t) => t + e); setEmojiOpen(false); }} className="p-1 text-base hover:scale-125">{e}</button>)}
          </div>}
        </div>

        <textarea value={text} rows={1} onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder={text.includes("@") ? "Mention a member with @…" : `Message ${conv.name}…`}
          className="hub-input max-h-28 min-h-[38px] flex-1 resize-y leading-relaxed" />

        <button onClick={() => send()} aria-label="Send message" className="hub-btn hub-btn-primary px-3"><Send className="h-4 w-4" /></button>
      </div>
      <div className="mt-1.5 flex flex-wrap items-center justify-between gap-2 font-mono text-[9.5px] text-[var(--text-3)]">
        <span>Enter to send · Shift+Enter for a new line · {text.length}/2000</span>
        <button onClick={() => hub.simulateIncoming(conv.id)} className="underline decoration-dotted hover:text-[var(--blue)]">prototype: simulate reply</button>
      </div>

      {snippetOpen && <Modal title="Attach a code snippet" onClose={() => setSnippetOpen(false)}>
        <div className="grid gap-3 sm:grid-cols-2">
          <label><span className="mono-label mb-1.5 block">Language</span><select className="hub-input" value={snippet.language} onChange={(e) => setSnippet({ ...snippet, language: e.target.value })}>{["python", "javascript", "css", "typescript"].map((l) => <option key={l}>{l}</option>)}</select></label>
          <label><span className="mono-label mb-1.5 block">Title</span><input className="hub-input" value={snippet.title} onChange={(e) => setSnippet({ ...snippet, title: e.target.value })} /></label>
        </div>
        <label className="mt-3 block"><span className="mono-label mb-1.5 block">Code</span><textarea rows={7} className="hub-input resize-none font-mono text-[12px]" value={snippet.code} onChange={(e) => setSnippet({ ...snippet, code: e.target.value })} placeholder="def solve(): ..." /></label>
        <div className="mt-4 flex justify-end gap-2"><button className="hub-btn" onClick={() => setSnippetOpen(false)}>Cancel</button>
          <button className="hub-btn hub-btn-primary" onClick={() => { if (!snippet.code.trim()) return; send({ kind: "code", language: snippet.language, title: snippet.title, code: snippet.code }); setSnippetOpen(false); }}>Attach & send</button></div>
      </Modal>}

      {linkOpen && <Modal title="Attach a link" onClose={() => setLinkOpen(false)}>
        <label className="block"><span className="mono-label mb-1.5 block">Title</span><input className="hub-input" value={link.title} onChange={(e) => setLink({ ...link, title: e.target.value })} placeholder="Practice problem" /></label>
        <label className="mt-3 block"><span className="mono-label mb-1.5 block">URL</span><input className="hub-input" value={link.url} onChange={(e) => setLink({ ...link, url: e.target.value })} placeholder="https://" /></label>
        <div className="mt-4 flex justify-end gap-2"><button className="hub-btn" onClick={() => setLinkOpen(false)}>Cancel</button>
          <button className="hub-btn hub-btn-primary" onClick={() => { if (!/^https?:\/\//.test(link.url)) return; send({ kind: "link", url: link.url, title: link.title || "Link" }); setLinkOpen(false); }}>Attach & send</button></div>
        <button onClick={onOpenPractice} className="mt-3 font-mono text-[10.5px] text-[var(--blue)]">Open CodeQuest Practice instead →</button>
      </Modal>}
    </div>
  );
}

/* ══════════════ MAIN CONVERSATIONS VIEW ══════════════ */

export default function ConversationsView({ variant, requestsMode, onOpenProfile, onOpenPractice, focusId, wizardSignal, requestSignal }: {
  variant: Variant; requestsMode?: boolean; onOpenProfile: (id: string) => void; onOpenPractice: () => void;
  focusId?: string | null; wizardSignal?: number; requestSignal?: number;
}) {
  const hub = useHub();
  const { toast, show } = useToast();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [tab, setTab] = useState<Variant>(variant);
  const [listQuery, setListQuery] = useState("");
  const [msgQuery, setMsgQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(true);
  const [wizardOpen, setWizardOpen] = useState(false);
  const [newRequestOpen, setNewRequestOpen] = useState(false);
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [leaveConfirm, setLeaveConfirm] = useState(false);
  const [mobileChat, setMobileChat] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { setTab(variant); }, [variant]);
  useEffect(() => { if (wizardSignal) setWizardOpen(true); }, [wizardSignal]);
  useEffect(() => { if (requestSignal) setNewRequestOpen(true); }, [requestSignal]);
  useEffect(() => { if (focusId && hub.state.conversations.some((c) => c.id === focusId)) { setActiveId(focusId); setMobileChat(true); } }, [focusId, hub.state.conversations]);

  const convs = hub.state.conversations
    .filter((c) => tab === "all" ? true : c.type === tab)
    .filter((c) => `${c.name} ${c.description ?? ""}`.toLowerCase().includes(listQuery.toLowerCase()))
    .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || new Date(b.messages[b.messages.length - 1]?.at ?? b.createdAt).getTime() - new Date(a.messages[a.messages.length - 1]?.at ?? a.createdAt).getTime());

  const active = hub.state.conversations.find((c) => c.id === activeId) ?? null;
  const visibleMessages = active ? active.messages.filter((m) => !msgQuery || m.text.toLowerCase().includes(msgQuery.toLowerCase()) || (m.attachment?.kind === "code" && m.attachment.code.toLowerCase().includes(msgQuery.toLowerCase()))) : [];

  useEffect(() => { if (active && !msgQuery && scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [active?.messages.length, msgQuery]);

  if (requestsMode) return <RequestsPanel onOpenProfile={onOpenProfile} />;

  const select = (id: string) => { setActiveId(id); setMobileChat(true); setReplyTo(null); setMsgQuery(""); setSearchOpen(false); hub.markConversationRead(id); };

  const InfoPanel = active && (
    <div className="hub-scroll flex h-full flex-col overflow-y-auto bg-[var(--sidebar)] p-4">
      <div className="flex items-center justify-between"><p className="mono-label text-[9px]">Conversation info</p><button onClick={() => setInfoOpen(false)} aria-label="Collapse info"><X className="h-3.5 w-3.5" /></button></div>
      <div className="mt-4 text-center">
        <span className="hub-avatar mx-auto flex h-14 w-14 text-lg" style={{ background: active.color }}>{active.initials}</span>
        <h3 className="display mt-2 text-[14px] font-bold">{active.name}</h3>
        <p className="font-mono text-[10px] text-[var(--text-3)]">{active.type === "group" ? `${active.memberIds.length} members` : "Private conversation"}</p>
        {active.description && <p className="mt-2 text-[12px] leading-relaxed text-[var(--text-2)]">{active.description}</p>}
      </div>

      {active.type === "group" && <>
        <p className="mono-label mb-2 mt-5 text-[9px]">Members · {active.memberIds.filter((id) => studentById(id)?.online).length} online</p>
        <div className="space-y-1.5">{active.memberIds.map((id) => {
          const s = studentById(id); if (!s) return null;
          const role = id === active.ownerId ? "Owner" : active.adminIds?.includes(id) ? "Admin" : "Member";
          return <button key={id} onClick={() => onOpenProfile(id)} className="flex w-full items-center gap-2.5 p-1.5 text-left hover:bg-[var(--surface-2)]">
            <Avatar student={s} size={28} presence /><span className="min-w-0 flex-1 truncate text-[12px]">{s.name}</span>
            <span className="font-mono text-[9.5px] text-[var(--text-3)]">{role}</span></button>;
        })}</div>

        <p className="mono-label mb-2 mt-5 text-[9px]">Invite link</p>
        {active.invite && <div className="border border-[var(--border)] bg-[var(--surface-2)] p-2.5">
          <p className={cn("font-mono text-[11px]", active.invite.revoked ? "text-[#FF6B6B] line-through" : "text-[var(--blue)]")}>{active.invite.code}</p>
          <p className="mt-1 font-mono text-[9.5px] text-[var(--text-3)]">{active.invite.revoked ? "Revoked" : `Expires ${dateShort(active.invite.expiresAt)}`}</p>
          <div className="mt-2 flex gap-1.5"><button className="hub-btn px-2 py-1 text-[10px]" onClick={() => navigator.clipboard?.writeText(active.invite!.code)}>Copy</button>
            <button className="hub-btn px-2 py-1 text-[10px]" onClick={() => { hub.regenerateInvite(active.id); show("Invite regenerated — old link no longer works."); }}>Regenerate</button>
            <button className="hub-btn px-2 py-1 text-[10px]" onClick={() => { hub.revokeInvite(active.id); show("Invite link revoked."); }}>Revoke</button></div>
        </div>}
      </>}

      <p className="mono-label mb-2 mt-5 text-[9px]">Pinned messages · {active.pinnedMessages.length}</p>
      {active.pinnedMessages.length === 0 ? <p className="font-mono text-[10.5px] text-[var(--text-3)]">Nothing pinned yet.</p>
        : active.pinnedMessages.map((mid) => { const m = active.messages.find((x) => x.id === mid); return m ? <p key={mid} className="mb-1.5 border-l-2 border-[var(--blue)] pl-2 text-[11.5px] text-[var(--text-2)]">{m.text.slice(0, 80)}</p> : null; })}

      <p className="mono-label mb-2 mt-5 text-[9px]">Shared files & code</p>
      <div className="space-y-1">{active.messages.filter((m) => m.attachment).map((m) => <p key={m.id} className="truncate font-mono text-[10.5px] text-[var(--text-2)]">· {m.attachment?.kind === "code" ? m.attachment.title : m.attachment?.kind === "file" ? m.attachment.name : m.attachment?.kind === "link" ? m.attachment.title : m.attachment?.label}</p>)}</div>

      <div className="mt-auto space-y-1.5 border-t border-[var(--border)] pt-4">
        <button className="hub-btn w-full justify-between" onClick={() => { hub.toggleMuteConversation(active.id); show(active.muted ? "Conversation unmuted." : "Conversation muted."); }}>Mute <span>{active.muted ? "ON" : "OFF"}</span></button>
        <button className="hub-btn w-full justify-between" onClick={() => { hub.togglePinConversation(active.id); show(active.pinned ? "Conversation unpinned." : "Conversation pinned."); }}>Pin <span>{active.pinned ? "ON" : "OFF"}</span></button>
        {active.type === "group" && <button className="hub-btn w-full border-[#FF6B6B]/50 text-[#FF6B6B]" onClick={() => setLeaveConfirm(true)}>Leave group</button>}
      </div>
    </div>
  );

  return (
    <div className="flex h-[calc(100vh-var(--hub-header-h))] min-h-[520px] gap-0">
      {/* ── conversation list ── */}
      <aside className={cn("hub-surface hub-scroll flex w-full shrink-0 flex-col overflow-y-auto lg:w-[300px]", mobileChat && "hidden lg:flex")}>
        <div className="border-b border-[var(--border)] p-3">
          <div className="flex items-center justify-between"><h2 className="display text-[14px] font-bold">Conversations</h2>
            <button onClick={() => setWizardOpen(true)} className="hub-btn px-2 py-1 text-[10px]" title="Create group">+ Group</button></div>
          <label className="relative mt-2 block"><Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[var(--text-3)]" /><input className="hub-input pl-8" placeholder="Search conversations…" value={listQuery} onChange={(e) => setListQuery(e.target.value)} /></label>
          <div className="mt-2.5 flex gap-1.5">
            {([["all", "All"], ["group", "Groups"], ["direct", "Direct"]] as [Variant, string][]).map(([id, label]) => <button key={id} onClick={() => setTab(id)} aria-pressed={tab === id} className={cn("hub-pill px-2.5 py-1 text-[10px]", tab === id && "is-active")}>{label}</button>)}
            <button onClick={() => setNewRequestOpen(true)} className="hub-btn ml-auto px-2 py-1 text-[10px]">New message</button>
          </div>
          <button onClick={() => setTab("all")} className="mt-2 block w-full text-left font-mono text-[10px] text-[var(--blue)] hover:underline">
            Message requests ({hub.pendingIncomingRequests.length}) → open dedicated area via Hub rail
          </button>
        </div>

        <div className="flex-1">
          {convs.length === 0 ? <div className="p-4"><Empty title="No conversations" text="Start a group or send a message request to connect." /></div>
            : convs.map((c) => {
              const last = c.messages[c.messages.length - 1];
              return (
                <button key={c.id} onClick={() => select(c.id)} className={cn("flex w-full gap-2.5 border-b border-[var(--border)] p-3 text-left transition-colors", activeId === c.id ? "bg-[var(--blue-soft)]" : "hover:bg-[var(--surface-2)]")}>
                  <span className="hub-avatar flex h-9 w-9 shrink-0 text-[11px]" style={{ background: c.color }}>{c.initials}</span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5"><span className={cn("truncate text-[12.5px]", c.unread ? "font-bold" : "font-medium")}>{c.name}</span>
                      {c.pinned && <span className="text-[9px] text-[var(--blue)]">📌</span>}{c.muted && <span className="text-[9px] text-[var(--text-3)]">🔇</span>}
                      <span className="ml-auto shrink-0 font-mono text-[9.5px] text-[var(--text-3)]">{last ? timeAgo(last.at) : ""}</span></div>
                    <p className="mt-0.5 truncate text-[11.5px] text-[var(--text-2)]">{last ? `${last.fromId === ME ? "You: " : ""}${last.text || (last.attachment ? "attachment" : "")}` : "No messages yet"}</p>
                  </div>
                  {c.unread > 0 && <span className="clip-oct-sm mt-1 flex h-5 w-5 shrink-0 items-center justify-center bg-[var(--blue)] font-mono text-[9px] font-bold text-white">{c.unread}</span>}
                </button>
              );
            })}
        </div>
        <p className="border-t border-[var(--border)] p-2.5 font-mono text-[9.5px] text-[var(--text-3)]">Discord-style channel list · unread · pinned · muted</p>
      </aside>

      {/* ── active conversation ── */}
      <section className={cn("hub-surface flex min-w-0 flex-1 flex-col", !mobileChat && "hidden lg:flex")}>
        {!active ? (
          <div className="flex flex-1 flex-col items-center justify-center p-8 text-center">
            <MessageCircle className="h-9 w-9 text-[var(--blue)]" />
            <h2 className="display mt-4 text-xl font-bold">Connect. Share. Collaborate.</h2>
            <p className="mt-2 max-w-md text-[13px] text-[var(--text-2)]">Select a conversation to start. Private chats only open after a request is accepted.</p>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              <button className="hub-btn hub-btn-primary" onClick={() => setWizardOpen(true)}>Create group</button>
              <button className="hub-btn" onClick={() => setNewRequestOpen(true)}>New message request</button>
            </div>
            <div className="mt-8 w-full max-w-sm"><p className="mono-label mb-2 text-[9px]">Recent</p>
              {convs.slice(0, 3).map((c) => <button key={c.id} onClick={() => select(c.id)} className="flex w-full items-center gap-2 border-b border-[var(--border)] p-2 text-left text-[12px] hover:text-[var(--blue)]"><span className="hub-avatar flex h-6 w-6 text-[9px]" style={{ background: c.color }}>{c.initials}</span>{c.name}<ArrowRight className="ml-auto h-3 w-3" /></button>)}</div>
          </div>
        ) : (
          <>
            <header className="flex shrink-0 flex-wrap items-center gap-3 border-b border-[var(--border)] bg-[var(--sidebar)] px-3 py-2.5">
              <button onClick={() => setMobileChat(false)} className="lg:hidden"><ArrowLeft className="h-4 w-4" /></button>
              <span className="hub-avatar flex h-9 w-9 text-[11px]" style={{ background: active.color }}>{active.initials}</span>
              <div className="min-w-0"><h2 className="display truncate text-[14px] font-bold">{active.name}</h2>
                <p className="font-mono text-[10px] text-[var(--text-3)]">{active.type === "group" ? `${active.memberIds.length} members · ${active.memberIds.filter((id) => studentById(id)?.online).length} online` : `${studentById(active.participantIds?.find((p) => p !== ME) ?? "")?.online ? "Online" : "Offline"}`}</p></div>
              <div className="ml-auto flex items-center gap-1.5">
                <button onClick={() => setSearchOpen((v) => !v)} aria-label="Search messages" className="hub-btn px-2 py-1"><Search className="h-3.5 w-3.5" /></button>
                <button onClick={() => setInfoOpen((v) => !v)} aria-label="Toggle info" className="hub-btn px-2 py-1"><UsersRound className="h-3.5 w-3.5" /></button>
                <button onClick={() => { hub.simulateIncoming(active.id); }} className="hub-btn px-2 py-1 text-[10px]" title="Prototype: simulate an incoming message">Simulate reply</button>
              </div>
              {searchOpen && <div className="w-full"><input autoFocus className="hub-input" placeholder="Search this conversation…" value={msgQuery} onChange={(e) => setMsgQuery(e.target.value)} /></div>}
            </header>

            <div ref={scrollRef} className="hub-scroll min-h-0 flex-1 overflow-y-auto px-3 py-4">
              <div className="hub-divider my-2">Today</div>
              {visibleMessages.length === 0 ? <Empty title="No messages found" text={msgQuery ? "Try another search term." : "Send the first message."} />
                : visibleMessages.map((m, i) => {
                  const prev = visibleMessages[i - 1];
                  const grouped = Boolean(prev && prev.fromId === m.fromId && new Date(m.at).getTime() - new Date(prev.at).getTime() < 5 * 60_000);
                  return <MessageRow key={m.id} message={m} conv={active} grouped={grouped} onReply={() => setReplyTo(m.id)} onProfile={onOpenProfile} onOpenPractice={onOpenPractice} />;
                })}
              {hub.typingIn.includes(active.id) && <div className="flex items-center gap-2 py-2 pl-11 font-mono text-[11px] text-[var(--text-3)]"><span className="pulse-dot h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />someone is typing…</div>}
            </div>

            <Composer conv={active} replyTo={replyTo} onClearReply={() => setReplyTo(null)} onOpenPractice={onOpenPractice} />
          </>
        )}
      </section>

      {infoOpen && active && <aside className="hidden w-[280px] shrink-0 border-l border-[var(--border)] xl:block">{InfoPanel}</aside>}
      {!infoOpen && <button onClick={() => setInfoOpen(true)} aria-label="Expand info" className="hidden w-8 shrink-0 items-center justify-center border-l border-[var(--border)] bg-[var(--sidebar)] text-[var(--text-3)] hover:text-[var(--blue)] xl:flex"><Settings2 className="h-3.5 w-3.5" /></button>}

      {wizardOpen && <GroupWizard onClose={() => setWizardOpen(false)} onCreated={(id) => { if (id) select(id); }} />}
      {newRequestOpen && <NewRequestModal onClose={() => setNewRequestOpen(false)} />}
      {leaveConfirm && active && <Confirm title="Leave group?" text={`You will lose access to ${active.name}'s messages. Rejoining needs a new invite.`} confirmLabel="Leave group" danger onConfirm={() => { hub.leaveGroup(active.id); setActiveId(null); setMobileChat(false); show("You left the group."); }} onClose={() => setLeaveConfirm(false)} />}
      <ToastView toast={toast} />
    </div>
  );
}

/* silence unused helpers in this module's shared imports */
