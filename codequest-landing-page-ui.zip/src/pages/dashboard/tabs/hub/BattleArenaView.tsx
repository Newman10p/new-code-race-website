import { useEffect, useMemo, useState } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { oneDark } from "@codemirror/theme-one-dark";
import { EditorView } from "@codemirror/view";
import { cn } from "../../../../utils/cn";
import { ME, dateShort, studentById, students, type Battle } from "../../../../data/hubData";
import { useHub } from "../../../../lib/hubStore";
import { useTheme } from "../../../../lib/theme";
import { prefersReducedMotion } from "../../../../lib/grid";
import {
  ArrowLeft, Check, Code2, Ellipsis, Medal, PlusCircle, ScrollText, Search,
  Send, Swords, Timer, Trophy, UsersRound, X,
} from "lucide-react";
import { Avatar, Confirm, Empty, Modal, SectionTitle, ToastView, useToast } from "./HubUI";

const STATUS_TONE: Record<Battle["status"], string> = {
  open: "var(--blue)", waiting: "#F2C94C", "starting-soon": "#F2C94C", live: "#FF6B6B",
  completed: "#5DD39E", cancelled: "var(--text-3)",
};

const BATTLE_QUESTION = {
  title: "Peak Attendance Window",
  statement: "Given a list of minute-by-minute attendance counts and a window size k, return the maximum total across any contiguous window of length k.",
  input: "peak(counts, k) — counts is an array of integers, k <= counts.length.",
  output: "An integer: the largest window sum.",
  constraints: ["1 <= k <= counts.length <= 10^5", "0 <= counts[i] <= 1000"],
  languages: ["javascript", "python"],
  runnable: ["javascript"],
  starter: `function peak(counts, k) {
  // Return the largest sum of any window of length k
  let current = 0;
  // TODO: finish the sliding window
  return 0;
}`,
  visibleTests: [
    { name: "Sample 1", args: [[2, 5, 1, 3, 4], 3], expected: 9 },
    { name: "Sample 2", args: [[1, 1, 1], 3], expected: 3 },
    { name: "Sample 3", args: [[7], 1], expected: 7 },
  ],
  hiddenCount: 4,
};

const clone = <T,>(v: T): T => (v !== null && typeof v === "object" ? JSON.parse(JSON.stringify(v)) : v);
const fmt = (v: unknown) => JSON.stringify(v);

function countdown(iso: string, now: number) {
  const ms = Math.max(0, new Date(iso).getTime() - now);
  return { d: Math.floor(ms / 86400_000), h: Math.floor((ms % 86400_000) / 3600_000), m: Math.floor((ms % 3600_000) / 60_000), s: Math.floor((ms % 60_000) / 1000), done: ms <= 0 };
}
const pad = (n: number) => String(n).padStart(2, "0");

/* ══════════════ CREATE WIZARD ══════════════ */

function CreateBattleWizard({ onClose, onCreated }: { onClose: () => void; onCreated: (id: string) => void }) {
  const hub = useHub();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    title: "", description: "", language: "Python", difficulty: "Medium" as Battle["difficulty"],
    durationMinutes: 30, maxPlayers: 8, questionCount: 3, startsAt: new Date(Date.now() + 30 * 60_000).toISOString().slice(0, 16),
    access: "open" as Battle["access"], source: "Approved question pack: Fundamentals", scoring: "Correctness + time tie-break",
  });
  const [error, setError] = useState("");
  const steps = ["Basics", "Settings", "Questions", "Scoring & access", "Review"];

  return <Modal title="Create a battle" onClose={onClose} wide>
    <div className="mb-5 flex gap-1.5">{steps.map((s, i) => <span key={s} className={cn("h-1 flex-1", i <= step ? "bg-[var(--blue)]" : "bg-[var(--border)]")} />)}</div>
    <p className="mono-label text-[9px] text-[#FF9F6B]">STEP {step + 1} / 5 · {steps[step].toUpperCase()}</p>
    <div className="mt-4 min-h-[220px] space-y-3">
      {step === 0 && <><label className="block"><span className="mono-label mb-1.5 block">Battle name *</span><input autoFocus className="hub-input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Friday Graph Sprint" /></label>
        <label className="block"><span className="mono-label mb-1.5 block">Description</span><textarea rows={3} className="hub-input resize-none" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
        <p className="font-mono text-[10px] text-[var(--text-3)]">Banner upload is not connected — battles use a generated colour identity.</p></>}
      {step === 1 && <div className="grid gap-3 sm:grid-cols-2">
        <label><span className="mono-label mb-1.5 block">Language</span><select className="hub-input" value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })}>{["Python", "JavaScript", "C++", "Any"].map((l) => <option key={l}>{l}</option>)}</select></label>
        <label><span className="mono-label mb-1.5 block">Difficulty</span><select className="hub-input" value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value as Battle["difficulty"] })}>{["Easy", "Medium", "Hard"].map((d) => <option key={d}>{d}</option>)}</select></label>
        <label><span className="mono-label mb-1.5 block">Questions</span><input type="number" min={1} max={10} className="hub-input" value={form.questionCount} onChange={(e) => setForm({ ...form, questionCount: Number(e.target.value) })} /></label>
        <label><span className="mono-label mb-1.5 block">Duration (min)</span><input type="number" min={5} max={180} className="hub-input" value={form.durationMinutes} onChange={(e) => setForm({ ...form, durationMinutes: Number(e.target.value) })} /></label>
        <label><span className="mono-label mb-1.5 block">Max participants</span><input type="number" min={2} max={32} className="hub-input" value={form.maxPlayers} onChange={(e) => setForm({ ...form, maxPlayers: Number(e.target.value) })} /></label>
        <label><span className="mono-label mb-1.5 block">Start time</span><input type="datetime-local" className="hub-input" value={form.startsAt} onChange={(e) => setForm({ ...form, startsAt: e.target.value })} /></label>
      </div>}
      {step === 2 && <div><p className="mono-label mb-2">Question source</p>
        <div className="space-y-2">{["Approved question pack: Fundamentals", "Approved question pack: Graph Basics", " setter-authored question (permission required)"].map((s) => <label key={s} className={cn("flex cursor-pointer items-center gap-2.5 border p-3 text-[12.5px]", form.source === s ? "border-[var(--blue)] bg-[var(--blue-soft)]" : "border-[var(--border)]")}>
          <input type="radio" className="accent-[var(--blue)]" checked={form.source === s} onChange={() => setForm({ ...form, source: s })} />{s}</label>)}</div>
        <p className="mt-3 font-mono text-[10px] text-[#F2C94C]">Creating custom questions requires setter permission. Hidden tests are never sent to the browser.</p></div>}
      {step === 3 && <div className="grid gap-3 sm:grid-cols-2">
        <label><span className="mono-label mb-1.5 block">Scoring</span><select className="hub-input" value={form.scoring} onChange={(e) => setForm({ ...form, scoring: e.target.value })}><option>Correctness + time tie-break</option><option>Test-case completion</option><option>Correctness with per-run penalty</option></select></label>
        <label><span className="mono-label mb-1.5 block">Access</span><select className="hub-input" value={form.access} onChange={(e) => setForm({ ...form, access: e.target.value as Battle["access"] })}><option value="open">Open to all eligible students</option><option value="friends">Friends only</option><option value="invite">Invite-only</option></select></label>
      </div>}
      {step === 4 && <dl className="space-y-2 border border-[var(--border)] bg-[var(--surface-2)] p-4 text-[12.5px]">
        {[["Title", form.title], ["Description", form.description || "—"], ["Language", form.language], ["Difficulty", form.difficulty], ["Questions", String(form.questionCount)], ["Duration", `${form.durationMinutes} min`], ["Players", `max ${form.maxPlayers}`], ["Starts", dateShort(new Date(form.startsAt).toISOString())], ["Source", form.source], ["Scoring", form.scoring], ["Access", form.access]].map(([k, v]) => <div key={k} className="flex justify-between gap-4"><dt className="font-mono text-[11px] text-[var(--text-3)]">{k}</dt><dd className="text-right">{v}</dd></div>)}
      </dl>}
    </div>
    {error && <p role="alert" className="mt-3 text-[12px] text-[#FF6B6B]">{error}</p>}
    <div className="mt-5 flex justify-between border-t border-[var(--border)] pt-4">
      <button className="hub-btn" onClick={() => step === 0 ? onClose() : setStep((s) => s - 1)}>{step === 0 ? "Cancel" : "← Back"}</button>
      <button className="hub-btn hub-btn-primary" onClick={() => {
        if (step === 0 && !form.title.trim()) return setError("Give the battle a name.");
        if (step === 1 && (form.durationMinutes < 5 || form.maxPlayers < 2)) return setError("Check duration and participant limits.");
        setError("");
        if (step === 4) {
          const r = hub.createBattle({ ...form, startsAt: new Date(form.startsAt).toISOString(), scoring: [form.scoring, "Test-case completion", "Completion time as tie-breaker"] });
          if (!r.ok) return setError(r.error);
          onCreated(hub.state.battles[0].id); onClose(); return;
        }
        setStep((s) => s + 1);
      }}>{step === 4 ? "Publish battle" : "Continue →"}</button>
    </div>
  </Modal>;
}

/* ══════════════ WAITING ROOM ══════════════ */

function WaitingRoom({ battle, onExit }: { battle: Battle; onExit: () => void }) {
  const hub = useHub();
  const { toast, show } = useToast();
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(t); }, []);
  const t = countdown(battle.startsAt, now);
  const meIn = battle.participants.find((p) => p.studentId === ME);
  const isCreator = battle.creatorId === ME;
  const allReady = battle.participants.length > 1 && battle.participants.every((p) => p.ready);

  return <div className="arena-shell accent-blue fixed inset-0 z-[78] flex flex-col overflow-y-auto bg-[var(--bg)]">
    <header className="flex shrink-0 items-center gap-3 border-b border-[var(--border)] bg-[var(--sidebar)] px-4 py-3">
      <button onClick={onExit} className="hub-btn"><ArrowLeft className="h-3.5 w-3.5" />Leave room</button>
      <div className="min-w-0"><p className="mono-label text-[9px] text-[#FF9F6B]">BATTLE WAITING ROOM · {battle.status.toUpperCase()}</p><h1 className="display truncate text-[15px] font-bold">{battle.title}</h1></div>
      <span className="ml-auto font-mono text-[10.5px] text-[var(--text-3)]">{battle.participants.length}/{battle.maxPlayers} players</span>
    </header>

    <div className="mx-auto grid w-full max-w-5xl gap-6 px-4 py-8 lg:grid-cols-[minmax(0,1fr)_290px]">
      <div className="space-y-5">
        <p className="mono-label text-[#FF9F6B]">CHALLENGE A FRIEND. PROVE YOUR LOGIC.</p>
        <h2 className="display text-3xl font-bold uppercase leading-tight">Your battle is <span className="text-[var(--blue)]">almost ready.</span></h2>
        <div className="arena-texture border border-[var(--border)] bg-[var(--surface-solid)] p-6 text-center">
          <div className="flex justify-center gap-2 sm:gap-4">
            {[["D", t.d], ["H", t.h], ["M", t.m], ["S", t.s]].map(([l, v]) => <div key={l}><span className="countdown-digit display text-4xl font-bold sm:text-6xl">{pad(Number(v))}</span><span className="mono-label mt-2 block text-[9px]">{l === "D" ? "DAYS" : l === "H" ? "HOURS" : l === "M" ? "MINUTES" : "SECONDS"}</span></div>)}
          </div>
          <p className="mt-5 border-t border-[var(--border)] pt-3 font-mono text-[10.5px] text-[var(--text-3)]">Starts {dateShort(battle.startsAt)} · local time · countdown is a browser rehearsal, production uses server time</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {meIn && <button className="hub-btn hub-btn-primary" onClick={() => { hub.toggleReady(battle.id); show(meIn.ready ? "Ready state withdrawn." : "You are marked ready."); }}>{meIn.ready ? "✓ Ready" : "Mark ready"}</button>}
          {isCreator && <button className="hub-btn" disabled={!allReady} onClick={() => { const r = hub.startBattle(battle.id); show(r.ok ? "Battle started (local rehearsal)." : r.error, r.ok); }}>Start battle now</button>}
          <button className="hub-btn" onClick={() => { hub.leaveBattle(battle.id); show("You left the battle."); onExit(); }}>Leave battle</button>
          {isCreator && !allReady && <span className="self-center font-mono text-[10px] text-[#F2C94C]">Waiting for all participants to mark ready.</span>}
        </div>
        <p className="border border-dashed border-[var(--border-strong)] p-3 font-mono text-[10.5px] leading-relaxed text-[var(--text-3)]">Only the creator can start a manually controlled battle. Live scoring, timestamps and countdowns require the server-authoritative battle service; this room is a frontend rehearsal.</p>
      </div>

      <aside className="space-y-4">
        <div className="hub-surface p-4"><p className="mono-label mb-3 text-[var(--text)]">Participants</p>
          <div className="space-y-2">{battle.participants.map((p) => <div key={p.studentId} className="flex items-center gap-2.5"><Avatar id={p.studentId} size={28} presence /><span className="text-[12px]">{studentById(p.studentId)?.name}</span>{p.studentId === battle.creatorId && <span className="font-mono text-[9px] text-[#FF9F6B]">HOST</span>}<span className={cn("ml-auto font-mono text-[10px]", p.ready ? "text-[#5DD39E]" : "text-[var(--text-3)]")}>{p.ready ? "Ready" : "Waiting"}</span></div>)}</div>
        </div>
        <div className="hub-surface p-4"><p className="mono-label mb-2 text-[var(--text)]">Battle rules</p><ul className="space-y-1.5">{battle.scoring.map((s) => <li key={s} className="text-[11.5px] text-[var(--text-2)]">· {s}</li>)}<li className="text-[11.5px] text-[var(--text-2)]">· {battle.questionCount} questions · {battle.durationMinutes} min · {battle.language}</li></ul></div>
        <div className="hub-surface p-4"><p className="mono-label mb-2 text-[#FF9F6B]">Creator announcement</p><p className="text-[12px] leading-relaxed text-[var(--text-2)]">{battle.description || "Good luck — no announcements yet."}</p></div>
      </aside>
    </div>
    <ToastView toast={toast} />
  </div>;
}

/* ══════════════ LIVE BATTLE ══════════════ */

function LiveBattle({ battle, onExit }: { battle: Battle; onExit: () => void }) {
  const { theme } = useTheme();
  const { toast, show } = useToast();
  const [code, setCode] = useState(BATTLE_QUESTION.starter);
  const [rows, setRows] = useState<{ name: string; pass: boolean; error?: string }[]>([]);
  const [seconds, setSeconds] = useState(battle.durationMinutes * 60);
  const [tab, setTab] = useState<"output" | "standings">("output");
  const [submitted, setSubmitted] = useState(false);
  const [localScore, setLocalScore] = useState(0);
  const [confirmExit, setConfirmExit] = useState(false);

  useEffect(() => { const t = window.setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000); return () => window.clearInterval(t); }, []);
  const extensions = useMemo(() => [javascript(), EditorView.lineWrapping, EditorView.theme({ "&": { fontSize: "12.5px" }, ".cm-scroller": { fontFamily: "var(--font-mono)" } })], []);

  const run = () => {
    let solve: ((...a: unknown[]) => unknown) | null = null;
    try { solve = new Function(`"use strict";\n${code}\n;return typeof peak === "function" ? peak : null;`)() as ((...a: unknown[]) => unknown) | null; }
    catch (e) { setRows([{ name: "Compile", pass: false, error: e instanceof Error ? e.message : String(e) }]); return; }
    if (!solve) return setRows([{ name: "Compile", pass: false, error: "No function `peak` found." }]);
    setRows(BATTLE_QUESTION.visibleTests.map((t) => {
      try { return { name: t.name, pass: fmt(solve!(...t.args.map(clone))) === fmt(t.expected) }; }
      catch (e) { return { name: t.name, pass: false, error: e instanceof Error ? e.message : String(e) }; }
    }));
    setTab("output");
  };

  const submit = () => {
    run();
    const passed = BATTLE_QUESTION.visibleTests.filter((t) => {
      try {
        const solve = new Function(`"use strict";\n${code}\n;return peak;`)() as (...a: unknown[]) => unknown;
        return fmt(solve(...t.args.map(clone))) === fmt(t.expected);
      } catch { return false; }
    }).length;
    const estimate = Math.round((passed / (BATTLE_QUESTION.visibleTests.length + BATTLE_QUESTION.hiddenCount)) * 100);
    setLocalScore(estimate);
    setSubmitted(true);
    show("Local rehearsal submitted. No official score was awarded.");
  };

  return <div className="fixed inset-0 z-[78] flex flex-col bg-[var(--bg)]">
    <header className="flex shrink-0 flex-wrap items-center gap-3 border-b border-[var(--border)] bg-[var(--sidebar)] px-3 py-2">
      <Swords className="h-4 w-4 text-[#FF9F6B]" />
      <div className="min-w-0"><p className="mono-label text-[9px] text-[#FF9F6B]">LIVE BATTLE · QUESTION 1 OF {battle.questionCount}</p><h1 className="display truncate text-[13.5px] font-bold">{battle.title}</h1></div>
      <div className="ml-auto flex items-center gap-3">
        <span className="font-mono text-[10px] text-[#5DD39E]">● connected (local)</span>
        <span className={cn("countdown-digit display text-lg font-bold", seconds < 300 ? "text-[#FF6B6B]" : "text-[var(--text)]")}>{pad(Math.floor(seconds / 60))}:{pad(seconds % 60)}</span>
        <button className="hub-btn" onClick={() => setConfirmExit(true)}>Exit</button>
      </div>
    </header>

    <div className="grid min-h-0 flex-1 lg:grid-cols-[300px_minmax(0,1fr)_300px]">
      <aside className="hub-scroll hidden overflow-y-auto border-r border-[var(--border)] bg-[var(--surface-solid)] p-4 lg:block">
        <p className="mono-label text-[9px]">Question 1 · 100 pts</p>
        <h2 className="display mt-1.5 text-base font-bold">{BATTLE_QUESTION.title}</h2>
        <p className="mt-3 text-[12.5px] leading-relaxed text-[var(--text-2)]">{BATTLE_QUESTION.statement}</p>
        <div className="mt-4 space-y-2 font-mono text-[11px] text-[var(--text-3)]"><p><span className="text-[var(--text-2)]">Input:</span> {BATTLE_QUESTION.input}</p><p><span className="text-[var(--text-2)]">Output:</span> {BATTLE_QUESTION.output}</p></div>
        <p className="mono-label mt-4 mb-1.5 text-[9px]">Constraints</p><ul className="space-y-1">{BATTLE_QUESTION.constraints.map((c) => <li key={c} className="font-mono text-[10.5px] text-[var(--text-2)]">· {c}</li>)}</ul>
        <p className="mono-label mt-4 mb-1.5 text-[9px]">Samples</p>{BATTLE_QUESTION.visibleTests.map((t) => <div key={t.name} className="mb-1.5 border border-[var(--border)] bg-[var(--surface-2)] p-2 font-mono text-[10.5px]"><span className="text-[var(--text-3)]">{t.name}</span><p>in: {JSON.stringify(t.args)}</p><p className="text-[#5DD39E]">out: {JSON.stringify(t.expected)}</p></div>)}
        <p className="mt-3 font-mono text-[10px] text-[#F2C94C]">{BATTLE_QUESTION.hiddenCount} hidden tests remain server-side. You cannot see another participant's code.</p>
      </aside>

      <section className="flex min-w-0 flex-col">
        <div className="flex shrink-0 items-center gap-2 border-b border-[var(--border)] bg-[var(--sidebar)] px-3 py-1.5">
          <Code2 className="h-3.5 w-3.5 text-[var(--blue)]" /><span className="font-mono text-[10.5px]">JavaScript · runs locally</span>
          <button className="hub-btn ml-auto px-2 py-1 text-[10px]" onClick={() => { setCode(BATTLE_QUESTION.starter); setRows([]); }}>Reset</button>
        </div>
        <div className="min-h-0 flex-1 overflow-hidden">
          <CodeMirror value={code} onChange={setCode} extensions={extensions} theme={theme === "dark" ? oneDark : "light"} height="100%"
            basicSetup={{ lineNumbers: true, foldGutter: true, highlightActiveLine: true, bracketMatching: true, closeBrackets: true, indentOnInput: true }} />
        </div>
        <div className="flex shrink-0 flex-wrap items-center gap-2 border-t border-[var(--border)] bg-[var(--sidebar)] p-2.5">
          <button className="hub-btn" onClick={run}><Send className="h-3 w-3" />Run samples</button>
          <button className="hub-btn hub-btn-primary" onClick={submit}><Check className="h-3 w-3" />Submit solution</button>
          {submitted && <span className="font-mono text-[10.5px] text-[#F2C94C]">Local rehearsal estimate: {localScore} pts — not an official score</span>}
        </div>
      </section>

      <aside className="hidden flex-col border-l border-[var(--border)] bg-[var(--sidebar)] lg:flex">
        <div className="flex gap-1 border-b border-[var(--border)] p-2">{(["output", "standings"] as const).map((t) => <button key={t} onClick={() => setTab(t)} aria-pressed={tab === t} className={cn("hub-pill px-2.5 py-1 text-[10px]", tab === t && "is-active")}>{t}</button>)}</div>
        <div className="hub-scroll flex-1 overflow-y-auto p-3">
          {tab === "output" ? rows.length === 0 ? <p className="font-mono text-[11px] text-[var(--text-3)]">No run yet. Sample tests execute in your browser.</p>
            : <div className="space-y-1.5">{rows.map((r) => <div key={r.name} className={cn("border p-2 font-mono text-[11px]", r.pass ? "border-[#5DD39E]/40 text-[#5DD39E]" : "border-[#FF6B6B]/40 text-[#FF6B6B]")}>{r.pass ? "✓" : "✕"} {r.name}{r.error && <span className="block truncate">{r.error}</span>}</div>)}
              {Array.from({ length: BATTLE_QUESTION.hiddenCount }).map((_, i) => <div key={i} className="border border-dashed border-[var(--border)] p-2 font-mono text-[11px] text-[var(--text-3)]">Hidden test {i + 1} · server-side</div>)}</div>
            : <div className="space-y-2">{battle.participants.map((p, i) => <div key={p.studentId} className="flex items-center gap-2"><span className="font-mono text-[10px] text-[var(--text-3)]">{pad(i + 1)}</span><Avatar id={p.studentId} size={24} /><span className="text-[11.5px]">{studentById(p.studentId)?.name}</span><span className="ml-auto font-mono text-[10px] text-[var(--text-3)]">pending</span></div>)}<p className="mt-3 font-mono text-[10px] text-[#F2C94C]">Live standings require server-side scoring.</p></div>}
        </div>
      </aside>
    </div>

    {confirmExit && <Confirm title="Exit the live battle?" text="Your editor state is kept locally, but no server-side submission exists in this prototype." confirmLabel="Exit battle" danger onConfirm={onExit} onClose={() => setConfirmExit(false)} />}
    <ToastView toast={toast} />
  </div>;
}

/* ══════════════ RESULTS ══════════════ */

function BattleResults({ battle, onExit, onNewBattle }: { battle: Battle; onExit: () => void; onNewBattle: () => void }) {
  const hub = useHub();
  const { toast, show } = useToast();
  const rows = battle.results ?? battle.participants.map((p, i) => ({ rank: i + 1, studentId: p.studentId, score: p.score ?? 0, time: p.time ?? "—" }));
  return <div className="mx-auto max-w-3xl space-y-5">
    <button onClick={onExit} className="mono-label inline-flex items-center gap-2 hover:text-[var(--blue)]"><ArrowLeft className="h-3 w-3" />Battle Arena</button>
    <div className="hub-surface p-6">
      <div className="flex gap-1.5">{Array.from({ length: 7 }).map((_, i) => <span key={i} className="clip-oct-sm h-5 w-5 bg-[var(--blue)]" style={{ animation: prefersReducedMotion() ? "none" : `cq-ignite 700ms ${i * 80}ms ease-out both` }} />)}</div>
      <p className="mono-label mt-5 text-[#5DD39E]">BATTLE COMPLETE · FRIENDLY SESSION</p>
      <h1 className="display mt-1.5 text-3xl font-bold uppercase tracking-tight">{battle.title}</h1>
      <div className="mt-5 overflow-x-auto border border-[var(--border)]"><table className="w-full min-w-[400px] text-left text-[12.5px]"><thead><tr className="border-b border-[var(--border)] font-mono text-[10px] uppercase text-[var(--text-3)]"><th className="px-3 py-2.5 font-normal">Rank</th><th className="px-3 py-2.5 font-normal">Student</th><th className="px-3 py-2.5 text-right font-normal">Score</th><th className="px-3 py-2.5 text-right font-normal">Time</th></tr></thead>
        <tbody>{rows.map((r) => <tr key={r.studentId} className={cn("border-b border-[var(--border)] last:border-0", r.studentId === ME && "bg-[var(--blue-soft)]")}><td className="px-3 py-2.5 font-mono">{pad(r.rank)}</td><td className="px-3 py-2.5 font-semibold">{studentById(r.studentId)?.name}{r.rank === 1 && <span className="ml-2">🏆</span>}{r.studentId === ME && <span className="ml-2 font-mono text-[9px] text-[var(--blue)]">YOU</span>}</td><td className="px-3 py-2.5 text-right font-mono">{r.score}</td><td className="px-3 py-2.5 text-right font-mono text-[var(--text-3)]">{r.time}</td></tr>)}</tbody></table></div>
      <p className="mt-3 font-mono text-[10px] text-[var(--text-3)]">Informal Hub battle only — results never enter official competition rankings or CodeQuest scores.</p>
      <div className="mt-5 flex flex-wrap gap-2">
        <button className="hub-btn hub-btn-primary" onClick={() => { hub.createPost({ text: `Friendly battle complete: ${battle.title} — finished #${rows.find((r) => r.studentId === ME)?.rank ?? "—"} with ${rows.find((r) => r.studentId === ME)?.score ?? 0} pts. Great problems, great company.`, category: "Competitions" }); show("Result shared to the Community Feed."); }}>Share result to feed</button>
        <button className="hub-btn" onClick={onNewBattle}>Start another battle</button>
        <button className="hub-btn" onClick={onExit}>Return to Arena</button>
      </div>
    </div>
    <ToastView toast={toast} />
  </div>;
}

/* ══════════════ ARENA HOME ══════════════ */

export default function BattleArenaView({ focusId, createSignal }: { focusId?: string | null; createSignal?: number }) {
  const hub = useHub();
  const { toast, show } = useToast();
  const [filter, setFilter] = useState({ status: "All", language: "All", difficulty: "All", friends: false });
  const [query, setQuery] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [waitingId, setWaitingId] = useState<string | null>(focusId ?? null);
  const [liveId, setLiveId] = useState<string | null>(null);
  const [resultsId, setResultsId] = useState<string | null>(null);
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(t); }, []);
  useEffect(() => { if (createSignal) setCreateOpen(true); }, [createSignal]);

  const battles = hub.state.battles;
  const waiting = waitingId && battles.find((b) => b.id === waitingId);
  const live = liveId && battles.find((b) => b.id === liveId);
  const results = resultsId && battles.find((b) => b.id === resultsId);
  if (waiting) return <WaitingRoom battle={waiting} onExit={() => setWaitingId(null)} />;
  if (live) return <LiveBattle battle={live} onExit={() => setLiveId(null)} />;
  if (results) return <BattleResults battle={results} onExit={() => setResultsId(null)} onNewBattle={() => { setResultsId(null); setCreateOpen(true); }} />;

  const visible = battles.filter((b) => {
    if (filter.status !== "All" && b.status !== filter.status) return false;
    if (filter.language !== "All" && b.language !== filter.language) return false;
    if (filter.difficulty !== "All" && b.difficulty !== filter.difficulty) return false;
    if (filter.friends && !hub.state.following.includes(b.creatorId)) return false;
    if (query && !`${b.title} ${b.description}`.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });
  const active = battles.filter((b) => b.status === "live" || b.status === "waiting" || b.status === "starting-soon");
  const open = battles.filter((b) => b.status === "open");
  const done = battles.filter((b) => b.status === "completed");

  const BattleCard = ({ b }: { b: Battle }) => {
    const t = countdown(b.startsAt, now);
    const joined = b.participants.some((p) => p.studentId === ME);
    return <div className="hub-surface flex flex-col p-4 transition-all hover:-translate-y-0.5 hover:border-[#FF9F6B]">
      <div className="flex items-start justify-between gap-2"><span className="mono-label text-[9px] text-[#FF9F6B]">{b.language} · {b.difficulty}</span>
        <span className="clip-oct-sm border px-2 py-0.5 font-mono text-[9px] font-bold" style={{ borderColor: STATUS_TONE[b.status], color: STATUS_TONE[b.status] }}>{b.status.toUpperCase()}</span></div>
      <h3 className="display mt-2 text-[15px] font-bold">{b.title}</h3>
      <p className="mt-1 line-clamp-2 flex-1 text-[12.5px] leading-relaxed text-[var(--text-2)]">{b.description}</p>
      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 font-mono text-[10px] text-[var(--text-3)]"><span className="flex items-center gap-1"><UsersRound className="h-3 w-3" />{b.participants.length}/{b.maxPlayers}</span><span>{b.questionCount} questions</span><span className="flex items-center gap-1"><Timer className="h-3 w-3" />{b.durationMinutes} min</span><span>{b.access}</span></div>
      <p className="mt-2 font-mono text-[10px] text-[var(--text-2)]">{b.status === "completed" ? `Completed · winner ${studentById(b.results?.[0]?.studentId ?? "")?.name ?? "—"}` : `Starts ${dateShort(b.startsAt)} · T−${t.d > 0 ? `${t.d}d ` : ""}${pad(t.h)}:${pad(t.m)}:${pad(t.s)}`}</p>
      <div className="mt-3 flex gap-1.5 border-t border-[var(--border)] pt-3">
        {b.status === "completed" ? <button className="hub-btn hub-btn-primary flex-1 justify-center" onClick={() => setResultsId(b.id)}>View results</button>
          : b.status === "live" ? <button className="hub-btn hub-btn-primary flex-1 justify-center" onClick={() => setLiveId(b.id)}>Enter live battle</button>
          : joined ? <button className="hub-btn hub-btn-primary flex-1 justify-center" onClick={() => setWaitingId(b.id)}>Waiting room</button>
          : <button className="hub-btn hub-btn-primary flex-1 justify-center" onClick={() => { const r = hub.joinBattle(b.id); show(r.ok ? "Joined the battle. You are in the waiting room." : r.error, r.ok); if (r.ok) setWaitingId(b.id); }}>{b.access === "invite" ? "Request invite" : "Join battle"}</button>}
        <button className="hub-btn" onClick={() => setWaitingId(b.id)}>View</button>
      </div>
    </div>;
  };

  return <div className="mx-auto max-w-[1080px] space-y-8">
    <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--border)] pb-4">
      <div><p className="mono-label mb-1.5 text-[9px] text-[#FF9F6B]">EXPERIENCE THREE / THE BATTLE ARENA</p><h1 className="display text-2xl font-bold uppercase tracking-tight">Challenge a friend. <span className="text-[#FF9F6B]">Prove your logic.</span></h1>
        <p className="mt-1 text-[12.5px] text-[var(--text-2)]">Student-organised mini battles. Friendly competition — separate from official CodeQuest rankings.</p></div>
      <button className="hub-btn hub-btn-primary" onClick={() => setCreateOpen(true)}><Swords className="h-4 w-4" />Create battle</button>
    </div>

    {/* stats */}
    <dl className="grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-4">{[["Active", String(active.length)], ["Open challenges", String(open.length)], ["Friends competing", String(active.filter((b) => hub.state.following.includes(b.creatorId)).length)], ["Completed", String(done.length)]].map(([k, v]) => <div key={k} className="border-l border-[var(--border-strong)] pl-3"><dt className="mono-label text-[9px]">{k}</dt><dd className="display mt-1 text-xl font-bold">{v}</dd></div>)}</dl>

    <div className="flex flex-wrap items-center gap-2">
      <Ellipsis className="h-3.5 w-3.5 text-[var(--text-3)]" />
      {["All", "open", "waiting", "live", "completed"].map((s) => <button key={s} aria-pressed={filter.status === s} onClick={() => setFilter({ ...filter, status: s })} className={cn("hub-pill px-2.5 py-1 text-[10.5px]", filter.status === s && "is-active")}>{s === "All" ? "All statuses" : s}</button>)}
      <select className="hub-input w-auto" value={filter.language} onChange={(e) => setFilter({ ...filter, language: e.target.value })}><option value="All">All languages</option>{["Python", "JavaScript", "C++", "Any"].map((l) => <option key={l}>{l}</option>)}</select>
      <select className="hub-input w-auto" value={filter.difficulty} onChange={(e) => setFilter({ ...filter, difficulty: e.target.value })}><option value="All">All difficulties</option>{["Easy", "Medium", "Hard"].map((d) => <option key={d}>{d}</option>)}</select>
      <button aria-pressed={filter.friends} onClick={() => setFilter({ ...filter, friends: !filter.friends })} className={cn("hub-pill px-2.5 py-1 text-[10.5px]", filter.friends && "is-active")}>Friend-created</button>
      <label className="relative ml-auto"><Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[var(--text-3)]" /><input className="hub-input w-40 pl-8" placeholder="Search battles…" value={query} onChange={(e) => setQuery(e.target.value)} /></label>
    </div>

    {active.length > 0 && <section><SectionTitle eyebrow="FEATURED" title="Active & starting soon" /><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{active.map((b) => <BattleCard key={b.id} b={b} />)}</div></section>}
    <section><SectionTitle eyebrow="DISCOVERY" title="Open challenges" right={<span className="font-mono text-[10px] text-[var(--text-3)]">{visible.length} matching</span>} />
      {visible.length === 0 ? <Empty title="No battles match" text="Clear a filter or create your own session." action={<button className="hub-btn hub-btn-primary" onClick={() => setCreateOpen(true)}>Create battle</button>} />
        : <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{visible.map((b) => <BattleCard key={b.id} b={b} />)}</div>}</section>
    {done.length > 0 && <section><SectionTitle title="Battle history" /><div className="space-y-2">{done.map((b) => <button key={b.id} onClick={() => setResultsId(b.id)} className="hub-surface flex w-full flex-wrap items-center gap-3 p-3 text-left hover:border-[var(--blue)]"><Trophy className="h-4 w-4 text-[#FF9F6B]" /><span className="flex-1 text-[13px] font-semibold">{b.title}</span><span className="font-mono text-[10.5px] text-[var(--text-3)]">{b.participants.length} players · {b.language}</span><span className="font-mono text-[10.5px] text-[#5DD39E]">Completed</span><Send className="h-3.5 w-3.5" /></button>)}</div></section>}

    <p className="border-t border-[var(--border)] pt-4 font-mono text-[10px] leading-relaxed text-[var(--text-3)]">Battle start/end times, submissions, scoring and participant permissions are server-authoritative in production. This prototype executes JavaScript samples locally and never awards official scores.</p>
    {createOpen && <CreateBattleWizard onClose={() => setCreateOpen(false)} onCreated={(id) => { setWaitingId(id); show("Battle created — you are the host."); }} />}
    <ToastView toast={toast} />
  </div>;
}

void Medal; void PlusCircle; void ScrollText; void X; void students; void Modal;
