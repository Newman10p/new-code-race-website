import { useEffect, useState, type ReactNode } from "react";
import { cn } from "../../../../utils/cn";
import { navigate } from "../../../../lib/router";
import { ME, students } from "../../../../data/hubData";
import { useHub } from "../../../../lib/hubStore";
import {
  ArrowLeft, ArrowRight, Bell, Bookmark, ChartNoAxesColumnIncreasing, CircleUserRound,
  Code2, Compass, Ellipsis, Flag, FolderOpen, Globe, Hash, Heart, LogOut, Medal,
  MessageCircle, MessageSquare, MessagesSquare, Newspaper, Pin, PlusCircle, Repeat2,
  Reply, ScrollText, Search, Send, ShieldCheck, SlidersHorizontal, Smile, SquarePen,
  Swords, Timer, Trophy, UserRoundPlus, UsersRound,
} from "lucide-react";
import { Avatar } from "./HubUI";
import ConversationsView from "./ConversationsView";
import PostsView from "./PostsView";
import CommunitiesView from "./CommunitiesView";
import BattleArenaView from "./BattleArenaView";
import { HubHome, HubSettingsView, NotificationsView, SearchOverlay, StudentProfileView } from "./HubExtras";

/* ═══════════ NAVIGATION MODEL ═══════════ */

type NavEntry = { id: string; label: string; icon: ReactNode; badge?: number };
type NavGroup = { label: string; items: NavEntry[] };

const SECTION_COPY: Record<string, string> = {
  home: "Your social campus for code",
  chats: "Group chats and private conversations",
  groups: "Topic channels with your peers",
  directs: "One-to-one conversations",
  requests: "Permission-based private messaging",
  posts: "Share ideas, projects and results",
  saved: "Posts you kept for later",
  communities: "Topic spaces for every interest",
  battles: "Friendly student coding battles",
  "my-battles": "Battles you created or joined",
  settings: "Privacy and Hub preferences",
  help: "Safety, guidelines and reporting",
  notifications: "Hub activity",
  profile: "Student profile",
};

/** Rail groups — CONNECT / DISCOVER / COMPETE, plus footer utilities. */
function navGroups(hub: ReturnType<typeof useHub>): NavGroup[] {
  return [
    {
      label: "Connect",
      items: [
        { id: "chats", label: "Group Chats", icon: <MessagesSquare />, badge: hub.unreadChats },
        { id: "directs", label: "Direct Messages", icon: <MessageCircle /> },
        { id: "requests", label: "Message Requests", icon: <UserRoundPlus />, badge: hub.pendingIncomingRequests.length },
      ],
    },
    {
      label: "Discover",
      items: [
        { id: "posts", label: "Feed", icon: <Newspaper /> },
        { id: "communities", label: "Communities", icon: <UsersRound /> },
        { id: "saved", label: "Saved Posts", icon: <Bookmark /> },
      ],
    },
    {
      label: "Compete",
      items: [
        { id: "battles", label: "Battle Arena", icon: <Swords /> },
        { id: "my-battles", label: "My Battles", icon: <Trophy /> },
      ],
    },
  ];
}

const FOOTER_NAV: NavEntry[] = [
  { id: "settings", label: "Hub Settings", icon: <SlidersHorizontal /> },
  { id: "help", label: "Help & Safety", icon: <ShieldCheck /> },
];

const VALID = new Set([
  "home", "chats", "groups", "directs", "requests", "posts", "saved",
  "communities", "battles", "my-battles", "settings", "help",
  "notifications", "profile",
]);

/** Destinations that need the full viewport — no context panel, no gutters. */
const FULLSCREEN = new Set(["battles", "my-battles", "help"]);

/** Destinations that keep a contextual right panel on desktop. */
const CONTEXT_ALLOWED = new Set(["home", "posts", "saved", "communities"]);

export default function HubShell({ param }: { param?: string | null }) {
  const hub = useHub();
  const [section, setSection] = useState("home");
  const [railOpen, setRailOpen] = useState(true);
  const [contextOpen, setContextOpen] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const [focusProfileId, setFocusProfileId] = useState<string | null>(null);
  const [focusCommunityId, setFocusCommunityId] = useState<string | null>(null);
  const [focusConversationId, setFocusConversationId] = useState<string | null>(null);
  const [postSignal, setPostSignal] = useState(0);
  const [groupSignal, setGroupSignal] = useState(0);
  const [requestSignal, setRequestSignal] = useState(0);
  const [battleSignal, setBattleSignal] = useState(0);
  const [communitySignal, setCommunitySignal] = useState(0);
  const [createMenuOpen, setCreateMenuOpen] = useState(false);
  const [returnPath, setReturnPath] = useState("/dashboard/user");

  /* The URL is the source of truth for the active Hub destination. */
  useEffect(() => {
    if (!param || param === "hub") { setSection("home"); return; }
    if (VALID.has(param)) { setSection(param); return; }
    const direct = hub.state.conversations.find((c) => c.id === param);
    if (direct) { setSection(direct.type === "group" ? "groups" : "directs"); setFocusConversationId(param); return; }
    if (hub.state.communities.some((c) => c.id === param)) { setSection("communities"); setFocusCommunityId(param); return; }
    if (hub.state.battles.some((b) => b.id === param)) { setSection("battles"); return; }
    if (students.some((s) => s.id === param)) { setSection("profile"); setFocusProfileId(param); return; }
    setSection("home");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [param]);

  const go = (s: string) => {
    setSection(s);
    setCreateMenuOpen(false);
    navigate(s === "home" ? "/dashboard/user/hub" : `/dashboard/user/hub/${s}`);
  };

  const openProfile = (id: string) => { setFocusProfileId(id); go("profile"); };
  const openCommunity = (id: string) => { setFocusCommunityId(id); setSection("communities"); navigate("/dashboard/user/hub/communities"); };
  const openConversation = (id: string) => { setFocusConversationId(id); go("chats"); };
  const openPractice = () => navigate("/dashboard/user/practice");
  const openBattle = () => go("battles");

  /* Remember where the student came from so Back returns them there. */
  useEffect(() => {
    if (section === "home") setReturnPath("/dashboard/user");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const createActions = [
    { label: "New post", hint: "Publish to the community feed", icon: <SquarePen className="h-4 w-4" />, fn: () => { go("posts"); setPostSignal((n) => n + 1); } },
    { label: "New group chat", hint: "Invite students to a channel", icon: <Hash className="h-4 w-4" />, fn: () => { go("groups"); setGroupSignal((n) => n + 1); } },
    { label: "Message request", hint: "Requires recipient acceptance", icon: <UserRoundPlus className="h-4 w-4" />, fn: () => { go("requests"); setRequestSignal((n) => n + 1); } },
    { label: "New community", hint: "Create a topic space", icon: <Compass className="h-4 w-4" />, fn: () => { go("communities"); setCommunitySignal((n) => n + 1); } },
    { label: "Create battle", hint: "Friendly mini coding session", icon: <PlusCircle className="h-4 w-4" />, fn: () => { go("battles"); setBattleSignal((n) => n + 1); } },
  ];

  /* ── context panel content ── */
  const contextPanel = (
    <>
      <p className="mono-label mb-4 text-[9px]">Context</p>

      <div>
        <p className="mono-label mb-3 text-[var(--text)]">Online friends</p>
        <div className="space-y-2.5">
          {students.filter((s) => s.online && s.id !== ME && hub.state.following.includes(s.id)).slice(0, 5).map((s) => (
            <button key={s.id} onClick={() => openProfile(s.id)} className="flex w-full items-center gap-2.5 text-left hover:text-[var(--blue)]">
              <Avatar student={s} size={26} presence />
              <span className="truncate text-[12px]">{s.name}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <p className="mono-label mb-3 text-[var(--text)]">Trending communities</p>
        <div className="space-y-2">
          {hub.state.communities.filter((c) => c.visibility !== "private").slice(0, 3).map((c) => (
            <button key={c.id} onClick={() => openCommunity(c.id)} className="flex w-full items-center gap-2.5 text-left hover:text-[var(--blue)]">
              <span className="hub-avatar flex h-7 w-7 text-[9px]" style={{ background: c.color }}>{c.initials}</span>
              <span className="min-w-0 flex-1 truncate text-[12px]">{c.name}</span>
              <span className="font-mono text-[9px] text-[var(--text-3)]">{c.members.length}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <p className="mono-label mb-3 text-[var(--text)]">Suggested students</p>
        <div className="space-y-2">
          {students.filter((s) => s.id !== ME && !hub.state.following.includes(s.id)).slice(0, 3).map((s) => (
            <div key={s.id} className="flex items-center gap-2.5">
              <Avatar student={s} size={26} onClick={() => openProfile(s.id)} />
              <button onClick={() => openProfile(s.id)} className="min-w-0 flex-1 truncate text-left text-[12px] hover:text-[var(--blue)]">{s.name}</button>
              <button className="hub-btn px-1.5 py-0.5 text-[9px]" onClick={() => hub.toggleFollow(s.id)}>Follow</button>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <p className="mono-label mb-3 text-[#FF9F6B]">Upcoming battles</p>
        {hub.state.battles.filter((b) => b.status === "open" || b.status === "waiting").slice(0, 2).map((b) => (
          <button key={b.id} onClick={openBattle} className="mb-2 block w-full border border-[var(--border)] p-2.5 text-left hover:border-[#FF9F6B]">
            <span className="block text-[11.5px] font-semibold">{b.title}</span>
            <span className="font-mono text-[9.5px] text-[var(--text-3)]">{b.participants.length}/{b.maxPlayers} players · {b.status}</span>
          </button>
        ))}
      </div>

      <p className="mt-6 border-t border-[var(--border)] pt-3 font-mono text-[9.5px] leading-relaxed text-[var(--text-3)]">
        Local prototype — no realtime delivery, presence or server scoring.
      </p>
    </>
  );

  /* ── main content ── */
  const content = (() => {
    switch (section) {
      case "chats":
      case "groups":
      case "directs":
      case "requests":
        return <ConversationsView
          variant={section === "groups" ? "group" : section === "directs" ? "direct" : "all"}
          requestsMode={section === "requests"}
          onOpenProfile={openProfile} onOpenPractice={openPractice}
          focusId={focusConversationId}
          wizardSignal={groupSignal} requestSignal={requestSignal}
        />;
      case "posts":
        return <PostsView mode="feed" onOpenProfile={openProfile} onOpenCommunity={openCommunity} onOpenBattle={openBattle} openComposerSignal={postSignal} />;
      case "saved":
        return <PostsView mode="saved" onOpenProfile={openProfile} onOpenCommunity={openCommunity} onOpenBattle={openBattle} />;
      case "communities":
        return <CommunitiesView focusId={focusCommunityId} onOpenProfile={openProfile} onOpenBattle={openBattle} createSignal={communitySignal} />;
      case "battles":
        return <BattleArenaView createSignal={battleSignal} />;
      case "my-battles":
        return <BattleArenaView createSignal={battleSignal} />;
      case "settings":
        return <HubSettingsView onNavigate={(s) => (s === "announcements" ? navigate("/dashboard/user/announcements") : go(s))} />;
      case "help":
        return <HelpSafety onNavigate={go} />;
      case "notifications":
        return <NotificationsView onNavigate={go} />;
      case "profile":
        return <StudentProfileView studentId={focusProfileId ?? ME} onNavigate={go} onOpenCommunity={openCommunity} onBack={() => go("home")} />;
      default:
        return <HubHome onNavigate={go} onOpenProfile={openProfile} onOpenCommunity={openCommunity} onOpenBattle={openBattle} onOpenConversation={openConversation} />;
    }
  })();

  const showContext = contextOpen && CONTEXT_ALLOWED.has(section);
  const isFullscreen = FULLSCREEN.has(section) || section === "chats" || section === "groups" || section === "directs" || section === "requests";

  return (
    <div className="hub-root text-[var(--text)]">
      {/* ═══ HUB HEADER — replaces the global dashboard chrome ═══ */}
      <header className="hub-header">
        <button
          onClick={() => navigate(returnPath)}
          className="group flex shrink-0 items-center gap-2.5 rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3.5 py-2 text-[12.5px] font-medium text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
        >
          <ArrowLeft className="h-4 w-4 stroke-[1.9] transition-transform group-hover:-translate-x-0.5" />
          <span className="hidden sm:inline">Back to CodeQuest</span>
        </button>

        <span className="mx-1 hidden h-6 w-px bg-[var(--border)] sm:block" />

        <div className="min-w-0 flex-1">
          <h1 className="display truncate text-[17px] font-bold leading-tight">Student Hub</h1>
          <p className="hidden truncate font-mono text-[10.5px] text-[var(--text-3)] sm:block">{SECTION_COPY[section] ?? "Your social campus"}</p>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => setSearchOpen(true)}
            aria-label="Search the Hub"
            className="hidden h-10 w-[300px] items-center gap-2.5 rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3.5 text-left text-[12.5px] text-[var(--text-3)] transition-colors hover:border-[var(--blue)] md:flex xl:w-[320px]"
          >
            <Search className="h-4 w-4 stroke-[1.9] text-[var(--blue)]" />
            Search students, posts, communities…
          </button>
          <button onClick={() => setSearchOpen(true)} aria-label="Search" className="hub-icon-btn border border-[var(--border)] md:hidden"><Search /></button>

          <div className="relative">
            <button onClick={() => setCreateMenuOpen((v) => !v)} aria-label="Create" className="hub-btn hub-btn-primary h-10 px-3.5">
              <SquarePen className="h-4 w-4 stroke-[1.9]" /><span className="hidden sm:inline">Create</span>
            </button>
            {createMenuOpen && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setCreateMenuOpen(false)} />
                <div className="absolute right-0 top-12 z-40 w-64 border border-[var(--border-strong)] bg-[var(--surface-solid)] p-1.5 shadow-2xl">
                  <p className="mono-label px-2 py-1.5 text-[9px]">Create in the Hub</p>
                  {createActions.map((a) => (
                    <button key={a.label} onClick={a.fn} className="flex w-full items-start gap-2.5 rounded-[8px] px-2 py-2 text-left hover:bg-[var(--surface-2)]">
                      <span className="mt-0.5 text-[var(--blue)]">{a.icon}</span>
                      <span>
                        <span className="block text-[12.5px] font-semibold">{a.label}</span>
                        <span className="block font-mono text-[9.5px] text-[var(--text-3)]">{a.hint}</span>
                      </span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          <button onClick={() => go("notifications")} aria-label="Notifications" className="hub-icon-btn relative border border-[var(--border)]">
            <Bell />
            {hub.unreadNotifications > 0 && <span className="hub-badge hub-badge--alert">{hub.unreadNotifications}</span>}
          </button>
          <button onClick={() => go("requests")} aria-label="Message requests" className="hub-icon-btn relative hidden border border-[var(--border)] sm:inline-flex">
            <UserRoundPlus />
            {hub.pendingIncomingRequests.length > 0 && <span className="hub-badge">{hub.pendingIncomingRequests.length}</span>}
          </button>
          <button onClick={() => { setFocusProfileId(ME); go("profile"); }} aria-label="Your profile" className="ml-1 shrink-0">
            <Avatar id={ME} size={34} presence />
          </button>
          <button onClick={() => setContextOpen((v) => !v)} aria-label="Toggle context panel" className="hub-icon-btn hidden xl:inline-flex">
            <Ellipsis />
          </button>
        </div>
      </header>

      {/* ═══ THREE-ZONE BODY ═══ */}
      <div className="hub-body">
        {/* left rail */}
        {railOpen ? (
          <aside className="hub-rail hidden lg:block" aria-label="Hub navigation">
            <div className="px-2 pb-5">
              <p className="font-display text-[13px] font-bold leading-tight">CODE<span className="text-[var(--blue)]">QUEST</span></p>
              <p className="font-mono text-[9px] tracking-[0.14em] text-[var(--text-3)]">STUDENT HUB</p>
            </div>

            <nav aria-label="Hub sections">
              <button onClick={() => go("home")} className={cn("hub-nav mb-2", section === "home" && "is-active")}>
                <Globe /><span className="flex-1">Hub Home</span>
              </button>

              {navGroups(hub).map((group, gi) => (
                <div key={group.label} className={gi > 0 ? "mt-7" : "mt-4"}>
                  <p className="hub-nav-label px-4 font-mono text-[9px] uppercase tracking-[0.16em] text-[var(--text-3)]">{group.label}</p>
                  <div className="space-y-1.5">
                    {group.items.map((item) => {
                      const active = section === item.id;
                      return (
                        <button key={item.id} onClick={() => go(item.id)} aria-current={active ? "page" : undefined} className={cn("hub-nav", active && "is-active")}>
                          {item.icon}<span className="flex-1">{item.label}</span>
                          {item.badge ? <span className="hub-badge static relative top-0 right-0">{item.badge}</span> : null}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              <div className="mt-7 border-t border-[var(--border)] pt-4">
                <div className="space-y-1.5">
                  {FOOTER_NAV.map((item) => (
                    <button key={item.id} onClick={() => go(item.id)} className={cn("hub-nav", section === item.id && "is-active")}>
                      {item.icon}<span className="flex-1">{item.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </nav>

            <p className="mt-6 px-4 font-mono text-[9px] leading-relaxed text-[var(--text-3)]">Connect. Share.<br />Collaborate. Compete.</p>
          </aside>
        ) : (
          <button onClick={() => setRailOpen(true)} aria-label="Expand navigation" className="hidden w-10 shrink-0 items-center justify-center border-r border-[var(--border)] bg-[var(--sidebar)] text-[var(--text-3)] hover:text-[var(--blue)] lg:flex">
            <Ellipsis className="h-4 w-4 rotate-90" />
          </button>
        )}

        {/* centre */}
        <main
          className={cn(
            "hub-center",
            isFullscreen && "hub-center--wide",
            !isFullscreen && "hub-content-padded lg:pb-16"
          )}
        >
          {content}
        </main>

        {/* contextual panel — only where it genuinely helps */}
        {showContext && <aside className="hub-context hidden xl:block">{contextPanel}</aside>}
      </div>

      {/* ═══ MOBILE BOTTOM NAV ═══ */}
      <nav className="hub-bottomnav" aria-label="Hub mobile navigation">
        {[
          { id: "posts", label: "Feed", icon: <Newspaper /> },
          { id: "chats", label: "Chats", icon: <MessagesSquare />, badge: hub.unreadChats + hub.pendingIncomingRequests.length },
          { id: "communities", label: "Spaces", icon: <UsersRound /> },
          { id: "battles", label: "Battles", icon: <Swords /> },
          { id: "profile", label: "Profile", icon: <CircleUserRound /> },
        ].map((n) => (
          <button
            key={n.id}
            onClick={() => { setFocusProfileId(n.id === "profile" ? ME : null); go(n.id); }}
            className={cn("hub-bottomnav-item", ["posts", "chats", "groups", "directs", "requests", "saved"].includes(section) && n.id === "posts" && "is-active", ["chats", "groups", "directs", "requests"].includes(section) && n.id === "chats" && "is-active", section === "communities" && n.id === "communities" && "is-active", ["battles", "my-battles"].includes(section) && n.id === "battles" && "is-active", section === "profile" && n.id === "profile" && "is-active")}
          >
            {n.icon}<span>{n.label}</span>
            {n.badge ? <span className="hub-badge">{n.badge}</span> : null}
          </button>
        ))}
      </nav>

      {searchOpen && (
        <SearchOverlay onClose={() => setSearchOpen(false)} onNavigate={go} onOpenProfile={openProfile} onOpenCommunity={openCommunity} onOpenConversation={openConversation} />
      )}
    </div>
  );
}

/* ═══════════ HELP & SAFETY ═══════════ */

function HelpSafety({ onNavigate }: { onNavigate: (s: string) => void }) {
  const hub = useHub();
  const cards = [
    { icon: <ShieldCheck className="h-5 w-5" />, title: "Community guidelines", body: "Be constructive, credit sources, and never share live-round solutions. Community moderators enforce these rules." },
    { icon: <Flag className="h-5 w-5" />, title: "Reporting content", body: "Every post, comment, message and community has a Report action. Reports go to platform moderators, and you get confirmation once submitted." },
    { icon: <MessageCircle className="h-5 w-5" />, title: "Private messaging", body: "Direct conversations only begin after the recipient accepts a request. Blocked students cannot send another request to bypass a block." },
    { icon: <Trophy className="h-5 w-5" />, title: "Battles vs official competitions", body: "Hub battles are friendly sessions. They never contribute to official CodeQuest rankings or competition scores." },
  ];
  return (
    <div className="hub-narrow">
      <p className="mono-label mb-3 text-[9px] text-[var(--blue)]">HELP & SAFETY</p>
      <h1 className="display text-3xl font-bold tracking-tight">Staying safe in the Hub</h1>
      <p className="mt-3 max-w-xl text-[14px] leading-relaxed text-[var(--text-2)]">
        How the Hub handles privacy, moderation and competition integrity.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {cards.map((c) => (
          <div key={c.title} className="hub-card">
            <span className="text-[var(--blue)]">{c.icon}</span>
            <h2 className="display mt-4 text-[15px] font-bold">{c.title}</h2>
            <p className="mt-2 text-[13px] leading-relaxed text-[var(--text-2)]">{c.body}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 hub-card">
        <h2 className="display text-[15px] font-bold">Your moderation records</h2>
        <p className="mt-2 text-[13px] text-[var(--text-2)]">{hub.state.reports.length} report{hub.state.reports.length === 1 ? "" : "s"} submitted from this account.</p>
        <div className="mt-4 flex flex-wrap gap-2.5">
          <button className="hub-btn" onClick={() => onNavigate("settings")}>Privacy settings</button>
          <button className="hub-btn" onClick={() => onNavigate("notifications")}>Notification settings</button>
        </div>
      </div>
    </div>
  );
}

/* Lucide re-exports used across Hub views (semantic mapping kept in one place). */
export const HubIcons = {
  Feed: Newspaper, GroupChats: MessagesSquare, DirectMessages: MessageCircle,
  MessageRequests: UserRoundPlus, Communities: UsersRound, Saved: Bookmark,
  BattleArena: Swords, MyBattles: Trophy, Settings: SlidersHorizontal, Help: ShieldCheck,
  Search, Bell, Profile: CircleUserRound, CreatePost: SquarePen, Like: Heart, Comment: MessageCircle,
  Share: Send, Repost: Repeat2, More: Ellipsis, Image: ChartNoAxesColumnIncreasing, File: FolderOpen,
  Code: Code2, Report: Flag, Pin, Smile, Reply, Mute: Bell, Block: UserRoundPlus, Leave: LogOut,
  Discover: Compass, Join: UserRoundPlus, Guidelines: FolderOpen, Resources: FolderOpen,
  Events: Timer, CreateBattle: PlusCircle, Timer, Ready: CheckCircle2Placeholder, Results: Medal,
  Leaderboard: Trophy, Rules: ScrollText,
};
function CheckCircle2Placeholder() { return null; }
void ArrowRight; void Globe; void Hash; void MessageSquare; void Pin; void PlusCircle; void Reply;
void Repeat2; void ScrollText; void Send; void Smile; void SquarePen; void Timer; void UserRoundPlus;
