import { useEffect, useMemo, useState } from "react";
import { cn } from "../../../../utils/cn";
import {
  HUB_CATEGORIES, ME, studentById, students, timeAgo,
  type Comment, type Post,
} from "../../../../data/hubData";
import { useHub } from "../../../../lib/hubStore";
import {
  Bookmark, ChartNoAxesColumnIncreasing, Code2, Ellipsis, Heart,
  MessageCircle, Repeat2, Search, Send, SquarePen, X,
} from "lucide-react";
import { Avatar, CodeBlock, Confirm, Empty, Modal, PostArt, SectionTitle, ToastView, useToast } from "./HubUI";

type FeedTab = "for-you" | "following" | "latest" | "popular" | "explore" | "saved";
const TABS: [FeedTab, string][] = [["for-you", "For You"], ["following", "Following"], ["latest", "Latest"], ["popular", "Popular"], ["explore", "Explore"], ["saved", "Saved"]];

/* ══════════════ COMPOSER ══════════════ */

function ComposerModal({ onClose }: { onClose: () => void }) {
  const hub = useHub();
  const { toast, show } = useToast();
  const [text, setText] = useState("");
  const [category, setCategory] = useState<Post["category"]>("General Discussion");
  const [audience, setAudience] = useState<Post["audience"]>("public");
  const [communityId, setCommunityId] = useState("");
  const [snippet, setSnippet] = useState<{ language: string; title: string; code: string } | null>(null);
  const [snippetOpen, setSnippetOpen] = useState(false);
  const [snippetDraft, setSnippetDraft] = useState({ language: "python", title: "Example", code: "" });
  const [link, setLink] = useState<{ url: string; title: string } | null>(null);
  const [linkOpen, setLinkOpen] = useState(false);
  const [linkDraft, setLinkDraft] = useState({ url: "", title: "" });
  const [poll, setPoll] = useState<{ question: string; options: string[] } | null>(null);
  const [pollOpen, setPollOpen] = useState(false);
  const [artLabel, setArtLabel] = useState("");
  const [preview, setPreview] = useState(false);
  const [error, setError] = useState("");

  const publish = (draft = false) => {
    const r = hub.createPost({
      text, category, audience: draft ? "draft" : audience,
      communityId: audience === "community" && communityId ? communityId : undefined,
      snippet: snippet ?? undefined, link: link ?? undefined,
      poll: poll ? { question: poll.question, options: poll.options.filter(Boolean).map((label) => ({ label, votes: [] })) } : undefined,
      art: artLabel ? { label: artLabel, tone: "#4D9CFF", kind: "grid" } : undefined,
    });
    if (!r.ok) return setError(r.error);
    show(draft ? "Draft published to your private view." : "Post published to the Hub.");
    window.setTimeout(onClose, 400);
  };

  return (
    <Modal title="Create a post" onClose={onClose} wide>
      <div className="flex items-start gap-3"><Avatar id={ME} size={36} />
        <textarea autoFocus rows={4} value={text} onChange={(e) => setText(e.target.value)} placeholder="Share an idea, a project, a result, or ask a question…"
          className="hub-input min-h-[100px] flex-1 resize-y leading-relaxed" /></div>
      <div className="mt-2 flex items-center justify-between font-mono text-[10px] text-[var(--text-3)]"><span>CodeQuest-only audience · never published outside the platform</span><span>{text.length}/1200</span></div>

      {(snippet || link || poll || artLabel) && <div className="mt-3 space-y-2">
        {snippet && <div className="relative"><CodeBlock language={snippet.language} title={snippet.title} code={snippet.code} /><button onClick={() => setSnippet(null)} className="absolute right-2 top-2 text-[var(--text-3)] hover:text-[#FF6B6B]"><X className="h-3.5 w-3.5" /></button></div>}
        {link && <div className="flex items-center gap-2 border border-[var(--border)] p-2 text-[12px] text-[var(--blue)]"><Send className="h-3 w-3" />{link.title}<button onClick={() => setLink(null)} className="ml-auto"><X className="h-3.5 w-3.5" /></button></div>}
        {poll && <div className="border border-[var(--border)] p-3 text-[12.5px]">📊 {poll.question} · {poll.options.filter(Boolean).length} options <button onClick={() => setPoll(null)} className="ml-2 text-[var(--text-3)]"><X className="h-3 w-3" /></button></div>}
        {artLabel && <div className="flex items-center gap-2 border border-[var(--border)] p-2 text-[12px]">Generated visual tile: {artLabel}<button onClick={() => setArtLabel("")} className="ml-auto"><X className="h-3 w-3" /></button></div>}
      </div>}

      <div className="mt-3 flex flex-wrap gap-1.5">
        <button className="hub-btn px-2 py-1.5 text-[10.5px]" onClick={() => setSnippetOpen(true)}><Code2 className="h-3.5 w-3.5" />Code</button>
        <button className="hub-btn px-2 py-1.5 text-[10.5px]" onClick={() => setLinkOpen(true)}><Send className="h-3.5 w-3.5" />Link</button>
        <button className="hub-btn px-2 py-1.5 text-[10.5px]" onClick={() => setPollOpen(true)}><ChartNoAxesColumnIncreasing className="h-3.5 w-3.5" />Poll</button>
        <button className="hub-btn px-2 py-1.5 text-[10.5px]" onClick={() => setArtLabel(text.trim().slice(0, 40).toUpperCase() || "PROJECT PREVIEW")}><SquarePen className="h-3.5 w-3.5" />Visual</button>
        <button className="hub-btn px-2 py-1.5 text-[10.5px]" onClick={() => setPreview((v) => !v)}>Preview</button>
      </div>

      {preview && <div className="mt-3 border border-[var(--border)] bg-[var(--surface-2)] p-3"><p className="mono-label text-[9px]">PREVIEW — what students will see</p>
        <p className="mt-1.5 whitespace-pre-wrap text-[13px] leading-relaxed">{text || "Your post text appears here."}</p></div>}

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <label><span className="mono-label mb-1.5 block">Category</span><select className="hub-input" value={category} onChange={(e) => setCategory(e.target.value as Post["category"])}>{HUB_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></label>
        <label><span className="mono-label mb-1.5 block">Audience</span><select className="hub-input" value={audience} onChange={(e) => setAudience(e.target.value as Post["audience"])}><option value="public">Public within CodeQuest</option><option value="community">Selected community</option><option value="draft">Private draft</option></select></label>
        {audience === "community" && <label><span className="mono-label mb-1.5 block">Community</span><select className="hub-input" value={communityId} onChange={(e) => setCommunityId(e.target.value)}><option value="">Choose…</option>{hub.state.communities.filter((c) => c.membership === "joined").map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>}
      </div>
      {error && <p role="alert" className="mt-3 text-[12px] text-[#FF6B6B]">{error}</p>}

      <div className="mt-5 flex flex-wrap justify-end gap-2 border-t border-[var(--border)] pt-4">
        <button className="hub-btn" onClick={() => publish(true)}>Save draft</button>
        <button className="hub-btn hub-btn-primary" onClick={() => publish(false)}>Publish post</button>
      </div>

      {snippetOpen && <Modal title="Attach code" onClose={() => setSnippetOpen(false)}>
        <div className="grid gap-3 sm:grid-cols-2"><label><span className="mono-label mb-1.5 block">Language</span><select className="hub-input" value={snippetDraft.language} onChange={(e) => setSnippetDraft({ ...snippetDraft, language: e.target.value })}>{["python", "javascript", "css", "typescript"].map((l) => <option key={l}>{l}</option>)}</select></label>
          <label><span className="mono-label mb-1.5 block">Title</span><input className="hub-input" value={snippetDraft.title} onChange={(e) => setSnippetDraft({ ...snippetDraft, title: e.target.value })} /></label></div>
        <textarea rows={6} className="hub-input mt-3 resize-none font-mono text-[12px]" value={snippetDraft.code} onChange={(e) => setSnippetDraft({ ...snippetDraft, code: e.target.value })} placeholder="def solve(): ..." />
        <div className="mt-4 flex justify-end"><button className="hub-btn hub-btn-primary" onClick={() => { if (!snippetDraft.code.trim()) return; setSnippet(snippetDraft); setSnippetOpen(false); }}>Attach</button></div>
      </Modal>}

      {linkOpen && <Modal title="Attach a link" onClose={() => setLinkOpen(false)}>
        <label className="block"><span className="mono-label mb-1.5 block">Title</span><input className="hub-input" value={linkDraft.title} onChange={(e) => setLinkDraft({ ...linkDraft, title: e.target.value })} /></label>
        <label className="mt-3 block"><span className="mono-label mb-1.5 block">URL</span><input className="hub-input" value={linkDraft.url} onChange={(e) => setLinkDraft({ ...linkDraft, url: e.target.value })} placeholder="https://" /></label>
        <div className="mt-4 flex justify-end"><button className="hub-btn hub-btn-primary" onClick={() => { if (!/^https?:\/\//.test(linkDraft.url) && !linkDraft.url.startsWith("#")) return; setLink({ url: linkDraft.url, title: linkDraft.title || "Link" }); setLinkOpen(false); }}>Attach</button></div>
      </Modal>}

      {pollOpen && <PollEditor onSave={(p) => { setPoll(p); setPollOpen(false); }} onClose={() => setPollOpen(false)} />}
      <ToastView toast={toast} />
    </Modal>
  );
}

function PollEditor({ onSave, onClose }: { onSave: (p: { question: string; options: string[] }) => void; onClose: () => void }) {
  const [q, setQ] = useState(""); const [opts, setOpts] = useState(["", ""]);
  return <Modal title="Create a poll" onClose={onClose}>
    <label className="block"><span className="mono-label mb-1.5 block">Question</span><input className="hub-input" value={q} onChange={(e) => setQ(e.target.value)} /></label>
    <div className="mt-3 space-y-2">{opts.map((o, i) => <input key={i} className="hub-input" placeholder={`Option ${i + 1}`} value={o} onChange={(e) => setOpts(opts.map((x, j) => j === i ? e.target.value : x))} />)}</div>
    <button className="hub-btn mt-2" onClick={() => setOpts([...opts, ""])}>+ Add option</button>
    <div className="mt-4 flex justify-end gap-2"><button className="hub-btn" onClick={onClose}>Cancel</button><button className="hub-btn hub-btn-primary" onClick={() => { if (!q.trim() || opts.filter(Boolean).length < 2) return; onSave({ question: q, options: opts }); }}>Add poll</button></div>
  </Modal>;
}

/* ══════════════ COMMENTS ══════════════ */

function CommentView({ comment, postId, depth, onReply }: { comment: Comment; postId: string; depth: number; onReply: (id: string) => void }) {
  const hub = useHub();
  const [collapsed, setCollapsed] = useState(false);
  const s = studentById(comment.authorId);
  return (
    <div className={cn(depth > 0 && "ml-5 border-l border-[var(--border)] pl-3")}>
      <div className="py-2">
        <div className="flex flex-wrap items-center gap-2"><Avatar id={comment.authorId} size={22} />
          <span className="text-[12px] font-semibold">{s?.name}</span><span className="font-mono text-[9.5px] text-[var(--text-3)]">{timeAgo(comment.at)}</span>
          {comment.reported && <span className="font-mono text-[9px] text-[#FF6B6B]">reported · hidden</span>}
        </div>
        <p className="mt-1 text-[12.5px] leading-relaxed text-[var(--text-2)]">{comment.reported ? "This comment is hidden pending review." : comment.text}</p>
        <div className="mt-1 flex gap-3 font-mono text-[10px] text-[var(--text-3)]">
          <button onClick={() => hub.likeComment(postId, comment.id)} className={cn("hover:text-[var(--blue)]", comment.likes.includes(ME) && "text-[var(--blue)]")}>Helpful · {comment.likes.length}</button>
          {depth < 2 && <button onClick={() => onReply(comment.id)} className="hover:text-[var(--blue)]">Reply</button>}
          {!comment.reported && <button onClick={() => hub.reportComment(postId, comment.id)} className="hover:text-[#FF6B6B]">Report</button>}
          {comment.replies.length > 0 && <button onClick={() => setCollapsed((v) => !v)} className="hover:text-[var(--blue)]">{collapsed ? `Show ${comment.replies.length} replies` : "Collapse thread"}</button>}
        </div>
      </div>
      {!collapsed && comment.replies.map((r) => <CommentView key={r.id} comment={r} postId={postId} depth={depth + 1} onReply={onReply} />)}
    </div>
  );
}

/* ══════════════ POST CARD ══════════════ */

function PostCard({ post, onOpenProfile, onOpenCommunity, compact = false }: {
  post: Post; onOpenProfile: (id: string) => void; onOpenCommunity: (id: string) => void; compact?: boolean;
}) {
  const hub = useHub();
  const { toast, show } = useToast();
  const [expanded, setExpanded] = useState(false);
  const [sort, setSort] = useState<"newest" | "relevant">("newest");
  const [comment, setComment] = useState("");
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(post.text);
  const [reportOpen, setReportOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const author = studentById(post.authorId);
  const mine = post.authorId === ME;
  const community = hub.state.communities.find((c) => c.id === post.communityId);
  const liked = post.likes.includes(ME);
  const saved = post.bookmarks.includes(ME);
  const isDraft = post.audience === "draft";
  const comments = [...post.comments].sort((a, b) => sort === "newest" ? new Date(b.at).getTime() - new Date(a.at).getTime() : b.likes.length - a.likes.length);

  if (compact) return (
    <button onClick={() => setExpanded(true)} className="hub-surface mb-3 block w-full break-inside-avoid p-3 text-left transition-colors hover:border-[var(--blue)]">
      {post.art && <PostArt art={post.art} className="mb-3" />}
      {post.snippet && <div className="mb-2"><CodeBlock language={post.snippet.language} title={post.snippet.title} code={post.snippet.code.slice(0, 220)} /></div>}
      <p className="line-clamp-3 text-[12.5px] leading-relaxed">{post.text}</p>
      <div className="mt-2 flex items-center gap-2 font-mono text-[10px] text-[var(--text-3)]"><Avatar id={post.authorId} size={18} />{author?.name}<span className="ml-auto">{post.likes.length} ♥</span></div>
    </button>
  );

  return (
    <article className="hub-post hub-arrive">
      <div className="flex items-start gap-3">
        <Avatar id={post.authorId} size={38} presence onClick={() => onOpenProfile(post.authorId)} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
            <button onClick={() => onOpenProfile(post.authorId)} className="text-[13.5px] font-bold hover:text-[var(--blue)]">{author?.name}</button>
            <span className="font-mono text-[11px] text-[var(--text-3)]">{author?.handle} · {author?.school}</span>
            <span className="font-mono text-[10.5px] text-[var(--text-3)]">· {timeAgo(post.at)}</span>
            {post.edited && <span className="font-mono text-[9.5px] text-[var(--text-3)]">edited</span>}
            {isDraft && <span className="clip-oct-sm border border-[#F2C94C] px-1.5 py-0.5 font-mono text-[9px] text-[#F2C94C]">PRIVATE DRAFT</span>}
          </div>
          {community && <button onClick={() => onOpenCommunity(community.id)} className="mt-1 font-mono text-[10.5px] text-[var(--blue)] hover:underline">{community.name}</button>}
        </div>
        <div className="relative">
          <button onClick={() => setMenu((v) => !v)} aria-label="More options" className="p-1 text-[var(--text-3)] hover:text-[var(--blue)]"><Ellipsis className="h-4 w-4" /></button>
          {menu && <div className="absolute right-0 top-7 z-20 w-40 border border-[var(--border-strong)] bg-[var(--surface-solid)] p-1 shadow-xl">
            {[
              ...(mine ? [{ label: "Edit post", fn: () => { setEditing(true); setMenu(false); } }, { label: "Delete post", fn: () => { setConfirmDelete(true); setMenu(false); } }] : []),
              { label: "Copy link", fn: () => navigator.clipboard?.writeText(`#/dashboard/user/hub/post/${post.id}`) },
              { label: "Report", fn: () => { setReportOpen(true); setMenu(false); } },
              { label: hub.state.mutedUsers.includes(post.authorId) ? "Unmute author" : "Mute author", fn: () => hub.toggleMuteUser(post.authorId) },
              { label: "Hide post", fn: () => hub.hidePost(post.id) },
            ].map((a) => <button key={a.label} onClick={() => { a.fn(); setMenu(false); }} className="block w-full px-2 py-1.5 text-left text-[11.5px] text-[var(--text-2)] hover:bg-[var(--surface-2)] hover:text-[var(--blue)]">{a.label}</button>)}
          </div>}
        </div>
      </div>

      <div className="mt-2.5 pl-[50px]">
        <span className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-2)] px-2 py-0.5 font-mono text-[9.5px] text-[var(--text-2)]">{post.category}</span>
        {editing ? <div className="mt-2 flex gap-2"><textarea className="hub-input resize-none" rows={3} value={draft} onChange={(e) => setDraft(e.target.value)} /><button className="hub-btn" onClick={() => { hub.editPost(post.id, draft); setEditing(false); show("Post updated."); }}>Save</button><button className="hub-btn" onClick={() => setEditing(false)}>Cancel</button></div>
          : <p className="mt-2 whitespace-pre-wrap text-[14px] leading-relaxed text-[var(--text)]">{post.text}</p>}

        {post.snippet && <div className="mt-3"><CodeBlock language={post.snippet.language} title={post.snippet.title} code={post.snippet.code} /></div>}
        {post.art && <div className="mt-3"><PostArt art={post.art} /></div>}
        {post.link && <a href={post.link.url} className="mt-3 flex items-center gap-2 border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 text-[12.5px] text-[var(--blue)] hover:border-[var(--blue)]">{post.link.title}<Send className="ml-auto h-3.5 w-3.5" /></a>}
        {post.poll && <div className="mt-3 space-y-1.5"><p className="text-[12.5px] font-semibold">📊 {post.poll.question}</p>
          {post.poll.options.map((o, i) => {
            const total = post.poll!.options.reduce((s, x) => s + x.votes.length, 0) || 1;
            const voted = o.votes.includes(ME);
            return <button key={o.label} onClick={() => hub.votePoll(post.id, i)} className={cn("relative block w-full overflow-hidden border px-3 py-2 text-left text-[12px]", voted ? "border-[var(--blue)] text-[var(--blue)]" : "border-[var(--border)] hover:border-[var(--blue)]")}>
              <span className="absolute inset-y-0 left-0 bg-[var(--blue-soft)]" style={{ width: `${(o.votes.length / total) * 100}%` }} />
              <span className="relative flex justify-between">{o.label}<span className="font-mono">{o.votes.length}</span></span>
            </button>;
          })}
          <p className="font-mono text-[10px] text-[var(--text-3)]">{post.poll.options.reduce((s, o) => s + o.votes.length, 0)} votes · click to change</p>
        </div>}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 pl-[50px] font-mono text-[11px] text-[var(--text-3)]">
        <button onClick={() => hub.toggleLike(post.id)} className={cn("flex items-center gap-1.5 transition-colors hover:text-[#FF6B6B]", liked && "text-[#FF6B6B]")}><Heart className="h-3.5 w-3.5" />{post.likes.length}</button>
        <button onClick={() => setExpanded((v) => !v)} className="flex items-center gap-1.5 hover:text-[var(--blue)]"><MessageCircle className="h-3.5 w-3.5" />{post.comments.length}</button>
        <button onClick={() => hub.toggleRepost(post.id)} className={cn("flex items-center gap-1.5 hover:text-[#5DD39E]", post.reposts.includes(ME) && "text-[#5DD39E]")}><Repeat2 className="h-3.5 w-3.5" />{post.reposts.length}</button>
        <button onClick={() => hub.toggleBookmark(post.id)} className={cn("flex items-center gap-1.5 hover:text-[var(--blue)]", saved && "text-[var(--blue)]")}><Bookmark className="h-3.5 w-3.5" />{saved ? "Saved" : "Save"}</button>
        <span className="ml-auto">{post.audience === "community" ? "Community only" : post.audience === "draft" ? "Only you" : "CodeQuest public"}</span>
      </div>

      {expanded && <div className="mt-3 border-t border-[var(--border)] pl-[50px] pt-3">
        <div className="flex flex-wrap items-center justify-between gap-2"><p className="mono-label text-[9px]">Discussion</p>
          <button onClick={() => setSort(sort === "newest" ? "relevant" : "newest")} className="font-mono text-[10px] text-[var(--blue)]">Sort: {sort}</button></div>
        <div className="mt-2 divide-y divide-[var(--border)]">{comments.map((c) => <CommentView key={c.id} comment={c} postId={post.id} depth={0} onReply={(id) => setReplyTo(id)} />)}</div>
        {comments.length === 0 && <p className="py-3 text-[12px] text-[var(--text-3)]">No comments yet — start the discussion.</p>}
        {replyTo && <p className="mt-2 font-mono text-[10px] text-[var(--blue)]">Replying to a comment <button onClick={() => setReplyTo(null)} className="ml-2 underline">cancel</button></p>}
        <form className="mt-2 flex gap-2" onSubmit={(e) => { e.preventDefault(); const r = hub.addComment(post.id, comment, replyTo ?? undefined); if (!r.ok) return show(r.error, false); setComment(""); setReplyTo(null); }}>
          <input className="hub-input flex-1" value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Add a constructive comment…" />
          <button className="hub-btn hub-btn-primary" type="submit"><Send className="h-3.5 w-3.5" /></button>
        </form>
      </div>}

      {reportOpen && <Modal title="Report post" onClose={() => setReportOpen(false)}>
        <p className="text-[12.5px] leading-relaxed text-[var(--text-2)]">Reports are reviewed by Hub moderators. You can also mute or hide this author's posts.</p>
        <div className="mt-4 flex justify-end gap-2"><button className="hub-btn" onClick={() => setReportOpen(false)}>Cancel</button>
          <button className="hub-btn hub-btn-primary" onClick={() => { hub.submitReport("post", post.id, "Reported from feed"); setReportOpen(false); show("Report submitted. Thank you."); }}>Submit report</button></div>
      </Modal>}
      {confirmDelete && <Confirm title="Delete post?" text="This removes the post from your feed. Comments attached to it are removed too." confirmLabel="Delete" danger onConfirm={() => { hub.deletePost(post.id); show("Post deleted."); }} onClose={() => setConfirmDelete(false)} />}
      <ToastView toast={toast} />
    </article>
  );
}

/* ══════════════ FEED ══════════════ */

export default function PostsView({ mode, onOpenProfile, onOpenCommunity, onOpenBattle, openComposerSignal }: {
  mode?: "feed" | "saved"; onOpenProfile: (id: string) => void; onOpenCommunity: (id: string) => void;
  onOpenBattle: () => void; openComposerSignal?: number;
}) {
  const hub = useHub();
  const [tab, setTab] = useState<FeedTab>(mode === "saved" ? "saved" : "for-you");
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [composerOpen, setComposerOpen] = useState(false);
  const [expandedCompact, setExpandedCompact] = useState<string | null>(null);

  useEffect(() => { if (openComposerSignal) setComposerOpen(true); }, [openComposerSignal]);

  const feed = useMemo(() => {
    let list = hub.state.posts.filter((p) => !hub.state.hiddenPosts.includes(p.id));
    if (tab === "saved") list = list.filter((p) => p.bookmarks.includes(ME));
    else if (tab === "following") list = list.filter((p) => hub.state.following.includes(p.authorId) || p.communityId && hub.state.communities.find((c) => c.id === p.communityId)?.membership === "joined");
    else if (tab === "popular") list = [...list].sort((a, b) => (b.likes.length + b.comments.length * 2) - (a.likes.length + a.comments.length * 2));
    else if (tab === "latest") list = [...list].sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime());
    else if (tab === "for-you") list = list.filter((p) => p.audience !== "draft" || p.authorId === ME);
    if (tab !== "popular" && tab !== "latest") list = [...list].sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime());
    if (category !== "All") list = list.filter((p) => p.category === category);
    if (query) list = list.filter((p) => p.text.toLowerCase().includes(query.toLowerCase()));
    return list.filter((p) => !hub.state.mutedUsers.includes(p.authorId));
  }, [hub.state, tab, category, query]);

  const visual = feed.filter((p) => p.art || p.snippet);

  return (
    <div className="grid gap-8 xl:grid-cols-[minmax(0,1fr)_276px]">
      <div className="mx-auto max-w-[780px] min-w-0">
        <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[var(--border)] pb-3">
          <div><p className="mono-label mb-1.5 text-[9px] text-[var(--blue)]">COMMUNITY / THE FEED</p><h1 className="display text-2xl font-bold uppercase tracking-tight">Connect. Share. Collaborate.</h1></div>
          <button className="hub-btn hub-btn-primary" onClick={() => setComposerOpen(true)}>+ Create post</button>
        </div>

        <div className="mt-3 flex flex-wrap gap-1.5">
          {TABS.map(([id, label]) => <button key={id} aria-pressed={tab === id} onClick={() => setTab(id)} className={cn("hub-pill", tab === id && "is-active")}>{label}</button>)}
          <label className="relative ml-auto"><Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[var(--text-3)]" /><input className="hub-input w-40 pl-8" placeholder="Search posts…" value={query} onChange={(e) => setQuery(e.target.value)} /></label>
        </div>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {["All", ...HUB_CATEGORIES].map((c) => <button key={c} aria-pressed={category === c} onClick={() => setCategory(c)} className={cn("hub-pill px-2.5 py-1 text-[10px]", category === c && "is-active")}>{c}</button>)}
        </div>

        {tab === "explore" ? (
          <div className="mt-5">
            <SectionTitle eyebrow="DISCOVERY" title="Project showcases & visual resources" right={<span className="font-mono text-[10px] text-[var(--text-3)]">Masonry · {visual.length} tiles</span>} />
            <div className="columns-1 gap-3 sm:columns-2 xl:columns-3">
              {visual.map((p) => <div key={p.id} onClick={() => setExpandedCompact(p.id)}><PostCard post={p} compact onOpenProfile={onOpenProfile} onOpenCommunity={onOpenCommunity} /></div>)}
            </div>
            {expandedCompact && (() => { const p = hub.state.posts.find((x) => x.id === expandedCompact); return p ? <Modal title="Post" onClose={() => setExpandedCompact(null)} wide><PostCard post={p} onOpenProfile={onOpenProfile} onOpenCommunity={onOpenCommunity} /></Modal> : null; })()}
            <p className="mt-4 font-mono text-[10px] text-[var(--text-3)]">Only visual resources and project showcases use masonry. Ordinary discussions stay in the vertical stream.</p>
          </div>
        ) : (
          <div className="mt-4">
            {feed.length === 0 ? <Empty icon={<MessageCircle className="h-7 w-7" />} title={tab === "saved" ? "Nothing saved yet" : "No posts match"} text={tab === "saved" ? "Bookmark a post with the Save action to keep it here." : "Try a different tab or clear your filters."} action={<button className="hub-btn hub-btn-primary" onClick={() => setComposerOpen(true)}>Create the first post</button>} />
              : feed.map((p) => <PostCard key={p.id} post={p} onOpenProfile={onOpenProfile} onOpenCommunity={onOpenCommunity} />)}
          </div>
        )}
      </div>

      {/* contextual panel */}
      <aside className="hidden space-y-4 lg:block">
        <div className="hub-surface p-4"><p className="mono-label mb-3 text-[var(--text)]">Trending discussions</p>
          <div className="space-y-2.5">{[...hub.state.posts].sort((a, b) => b.comments.length - a.comments.length).slice(0, 3).map((p) => <button key={p.id} onClick={() => { setQuery(p.text.slice(0, 18)); setTab("latest"); }} className="block w-full border-l-2 border-[var(--blue)] pl-2.5 text-left text-[11.5px] leading-snug hover:text-[var(--blue)]">{p.text.slice(0, 70)}…<span className="mt-0.5 block font-mono text-[9.5px] text-[var(--text-3)]">{p.comments.length} comments</span></button>)}</div>
        </div>
        <div className="hub-surface p-4"><p className="mono-label mb-3 text-[var(--text)]">Suggested communities</p>
          <div className="space-y-2">{hub.state.communities.filter((c) => c.membership !== "joined" && c.visibility !== "private").slice(0, 3).map((c) => <button key={c.id} onClick={() => onOpenCommunity(c.id)} className="flex w-full items-center gap-2.5 text-left hover:text-[var(--blue)]"><span className="hub-avatar flex h-8 w-8 text-[10px]" style={{ background: c.color }}>{c.initials}</span><span className="min-w-0"><span className="block truncate text-[12px] font-medium">{c.name}</span><span className="block font-mono text-[9.5px] text-[var(--text-3)]">{c.members.length} members</span></span></button>)}</div>
        </div>
        <div className="hub-surface p-4"><p className="mono-label mb-3 text-[var(--text)]">Students to follow</p>
          <div className="space-y-2">{students.filter((s) => s.id !== ME && !hub.state.following.includes(s.id)).slice(0, 3).map((s) => <div key={s.id} className="flex items-center gap-2.5"><Avatar student={s} size={28} presence onClick={() => onOpenProfile(s.id)} /><span className="min-w-0 flex-1 truncate text-[12px]">{s.name}</span><button className="hub-btn px-2 py-1 text-[10px]" onClick={() => hub.toggleFollow(s.id)}>Follow</button></div>)}</div>
        </div>
        <button onClick={onOpenBattle} className="hub-surface block w-full p-4 text-left transition-colors hover:border-[#FF9F6B]"><p className="mono-label text-[#FF9F6B]">Upcoming student battles</p>
          <p className="mt-2 text-[12.5px] font-semibold">{hub.state.battles.filter((b) => b.status === "open" || b.status === "waiting").length} sessions open</p>
          <span className="mt-2 inline-flex items-center gap-1 font-mono text-[10.5px] text-[var(--blue)]">Open Battle Arena <Send className="h-3 w-3" /></span></button>
      </aside>

      {composerOpen && <ComposerModal onClose={() => setComposerOpen(false)} />}
    </div>
  );
}


