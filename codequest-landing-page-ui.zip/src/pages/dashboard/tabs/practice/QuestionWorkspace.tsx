import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { javascript } from "@codemirror/lang-javascript";
import { python } from "@codemirror/lang-python";
import { oneDark } from "@codemirror/theme-one-dark";
import { EditorView } from "@codemirror/view";
import { cn } from "../../../../utils/cn";
import type { Question } from "../../../../data/practiceData";
import { usePractice, type GradeReport, type OfflineReport } from "../../../../lib/practiceStore";
import { useTheme } from "../../../../lib/theme";
import { prefersReducedMotion } from "../../../../lib/grid";
import {
  ArrowLeft,
  CheckIcon,
  CloseIcon,
  CodeIcon,
  PlayIcon,
  SparklesIcon,
  UploadCloudIcon,
  ClockIcon,
  TrophyIcon,
  ChevronRight,
} from "../../../../components/icons";

type Lang = "python" | "javascript" | "java" | "cpp";

type LogLine = { t: "info" | "ok" | "err" | "warn"; text: string };

/* ────────────── success celebration ────────────── */

function SuccessOverlay({
  q,
  report,
  newTotalXp,
  rankPosition,
  gapToNext,
  durationLabel,
  onClose,
}: {
  q: Question;
  report: GradeReport;
  newTotalXp: number;
  rankPosition: number;
  gapToNext: number | null;
  durationLabel: string;
  onClose: () => void;
}) {
  const reduced = prefersReducedMotion();

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/78 p-4 backdrop-blur-[3px]" onClick={onClose}>
      <div
        className="clip-oct w-full max-w-lg border border-[#5DD39E]/45 bg-[var(--surface-solid)] p-6 sm:p-8"
        style={{ animation: reduced ? "none" : "cq-rise 0.45s cubic-bezier(0.22,1,0.36,1) both" }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* illuminating octagon sequence */}
        <div className="flex items-center gap-1.5" aria-hidden="true">
          {Array.from({ length: 9 }).map((_, i) => (
            <span
              key={i}
              className="clip-oct-sm h-3.5 flex-1 bg-[var(--border-strong)]"
              style={{
                animation: reduced ? "none" : `cq-illuminate 900ms ${120 + i * 90}ms ease-out both`,
              }}
            />
          ))}
        </div>

        <div className="mt-6 flex items-start justify-between gap-4">
          <div>
            <p className="mono-label text-[#5DD39E]">Accepted · all tests passing</p>
            <h2 className="display mt-1.5 text-3xl font-bold uppercase leading-none tracking-tight sm:text-4xl">
              Problem solved
            </h2>
            <p className="mt-2 text-[13px] text-[var(--text-2)]">
              Excellent work. Another challenge conquered — {q.title.toLowerCase()} is archived.
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="clip-oct-sm flex h-8 w-8 shrink-0 items-center justify-center border border-[var(--border)] text-[var(--text-2)] hover:border-[var(--blue)] hover:text-[var(--text)]"
          >
            <CloseIcon className="h-4 w-4" />
          </button>
        </div>

        <div className="clip-oct-sm mt-5 border border-[#5DD39E]/40 bg-[#5DD39E]/[0.08] px-4 py-3 text-center">
          <p className="display text-3xl font-bold leading-none tracking-tight text-[#5DD39E]">
            +{report.awardedXp} XP <span className="text-sm font-normal">EARNED</span>
          </p>
        </div>

        <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-3 text-[11.5px] sm:grid-cols-4">
          {[
            { l: "Tests passed", v: `${report.passed} / ${report.total}` },
            { l: "Solve time", v: durationLabel },
            { l: "Runtime", v: `${report.durationMs.toFixed(0)} ms` },
            { l: "Score", v: `${Math.round(report.fraction * 100)}%` },
          ].map((m) => (
            <div key={m.l}>
              <dt className="mono-label text-[9px]">{m.l}</dt>
              <dd className="display mt-1 font-bold text-[var(--text)]">{m.v}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-[var(--border)] pt-4">
          <p className="font-mono text-[10.5px] leading-relaxed text-[var(--text-2)]">
            new total <span className="font-bold text-[var(--text)]">{newTotalXp.toLocaleString()} XP</span>
            <br />
            school rank <span className="font-bold text-[var(--blue)]">#{String(rankPosition).padStart(2, "0")}</span>
            {gapToNext !== null && <span className="text-[var(--text-3)]"> · {gapToNext} XP from {rankPosition - 1}</span>}
            {gapToNext === null && <span className="text-[#F2C94C]"> · first in school</span>}
          </p>
          <button onClick={onClose} className="btn-shell btn-primary-shell btn-shell-sm">
            <span className="btn-core">Back to archive</span>
          </button>
        </div>
      </div>
    </div>
  );
}

/* ────────────── workspace ────────────── */

export default function QuestionWorkspace({
  question,
  onBack,
}: {
  question: Question;
  onBack: () => void;
}) {
  const { grade, recordSubmission, statuses, attempts, best, totalXp, rank } = usePractice();
  const { theme } = useTheme();

  const runnable: Lang[] = question.localRunner as Lang[];
  const [language, setLanguage] = useState<Lang>(
    runnable.includes("javascript") ? ("javascript" as Lang) : (question.languages[0] as Lang)
  );
  const [code, setCode] = useState<string>(() => question.starter[language] ?? question.starter.javascript);
  const [busy, setBusy] = useState<null | "run" | "submit">(null);
  const [report, setReport] = useState<GradeReport | null>(null);
  const [offline, setOffline] = useState<OfflineReport | null>(null);
  const [logs, setLogs] = useState<LogLine[]>([
    { t: "info", text: `judge: sandbox ready · ${question.id}` },
    { t: "info", text: `language: ${language} · ${question.tests.length} test cases loaded` },
  ]);
  const [tab, setTab] = useState<"tests" | "output" | "console" | "results">("tests");
  const [activeTest, setActiveTest] = useState(0);
  const [narrow, setNarrow] = useState(
    () => typeof window !== "undefined" && window.innerWidth < 768
  );
  const [leftOpen, setLeftOpen] = useState(
    () => typeof window === "undefined" || window.innerWidth >= 768
  );
  const [focusMode, setFocusMode] = useState(false);
  const [showHints, setShowHints] = useState(false);
  const [showSolution, setShowSolution] = useState(false);
  const [editorTheme, setEditorTheme] = useState<"auto" | "dark" | "light">("auto");
  const [celebrate, setCelebrate] = useState<GradeReport | null>(null);
  const [startedAt] = useState(() => Date.now());
  const [elapsed, setElapsed] = useState(0);

  const [leftWidth, setLeftWidth] = useState(380);
  const [consoleHeight, setConsoleHeight] = useState(230);
  const dragRef = useRef<null | "x" | "y">(null);

  const status = statuses[question.id] ?? question.status;
  const attemptCount = attempts[question.id] ?? 0;
  const bestPercent = best[question.id];

  useEffect(() => {
    const t = window.setInterval(() => setElapsed(Math.floor((Date.now() - startedAt) / 1000)), 1000);
    return () => window.clearInterval(t);
  }, [startedAt]);

  /* phones stack the three panes instead of dragging them */
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px)");
    const sync = () => setNarrow(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);

  /* keep language switches coherent */
  const changeLanguage = (next: Lang) => {
    setLanguage(next);
    const starter = question.starter[next];
    if (starter) setCode(starter);
    setReport(null);
    setOffline(null);
    setLogs((l) => [...l, { t: "info", text: `switched template → ${next}` }]);
  };

  /* panel dragging */
  useEffect(() => {
    const move = (e: PointerEvent) => {
      if (!dragRef.current) return;
      if (dragRef.current === "x") {
        setLeftWidth(Math.min(640, Math.max(280, e.clientX - 24)));
      } else {
        setConsoleHeight(Math.min(520, Math.max(120, window.innerHeight - e.clientY - 8)));
      }
    };
    const up = () => {
      dragRef.current = null;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
  }, []);

  const run = useCallback(
    (mode: "run" | "submit") => {
      setBusy(mode);
      setOffline(null);
      setLogs((l) => [
        ...l,
        { t: "info", text: `${mode === "run" ? "running visible tests" : "submitting for grading"}…` },
      ]);

      // brief, honest async gap so loading states are real work, not theatre
      window.setTimeout(() => {
        const outcome = grade(question, code, language, mode);
        setBusy(null);

        if (outcome.kind === "offline") {
          setOffline(outcome);
          setReport(null);
          setLogs((l) => [
            ...l,
            {
              t: "warn",
              text: `${outcome.language} judge is server-side and not connected in this prototype — no verdict was produced and no points were awarded.`,
            },
            { t: "info", text: `runnable here: ${outcome.runnable.join(", ") || "none"}` },
          ]);
          return;
        }

        setReport(outcome);
        const r = outcome;
        setLogs((l) => [
          ...l,
          ...(r.compileError
            ? [{ t: "err" as const, text: `compile error — ${r.compileError}` }]
            : r.outcomes.map((o) => ({
                t: (o.status === "pass" ? "ok" : "err") as "ok" | "err",
                text: `${o.status === "pass" ? "PASS" : "FAIL"} · ${o.name}${o.hidden ? " (hidden)" : ""} · ${o.ms.toFixed(1)} ms${
                  o.error ? ` · ${o.error}` : ""
                }`,
              }))),
          {
            t: r.accepted ? ("ok" as const) : ("warn" as const),
            text:
              mode === "submit"
                ? `verdict: ${r.accepted ? "ACCEPTED" : "PARTIAL"} · ${r.passed}/${r.total} tests · ${Math.round(r.fraction * 100)}% weight · +${r.awardedXp} XP`
                : `local run: ${r.passed}/${r.total} visible tests passed`,
          },
        ]);

        if (mode === "submit") {
          setTab("results");
          if (r.accepted || r.awardedXp > 0) {
            recordSubmission(question, r);
            if (r.accepted) setCelebrate(r);
          }
        } else if (!r.accepted && r.outcomes.length) {
          setTab("tests");
        }
      }, 520);
    },
    [code, grade, language, question, recordSubmission]
  );

  /* keyboard shortcuts: Mod-Enter run, Mod-Shift-Enter submit */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.metaKey || e.ctrlKey)) return;
      if (e.key === "Enter") {
        e.preventDefault();
        run(e.shiftKey ? "submit" : "run");
      }
      if (e.key.toLowerCase() === "b") {
        e.preventDefault();
        setLeftOpen((v) => !v);
      }
      if (e.key.toLowerCase() === "f" && e.shiftKey) {
        e.preventDefault();
        setFocusMode((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [run]);

  const formatCode = () => {
    const normalized = code
      .replace(/\t/g, "  ")
      .split("\n")
      .map((l) => l.replace(/\s+$/, ""))
      .join("\n");
    setCode(normalized);
    setLogs((l) => [...l, { t: "info", text: "format: tabs expanded, trailing whitespace removed" }]);
  };

  const extensions = useMemo(() => {
    const lang = language === "python" ? python() : javascript();
    return [
      lang,
      EditorView.lineWrapping,
      EditorView.contentAttributes.of({ "aria-label": `Solution editor (${language})`, spellcheck: "false" }),
      EditorView.theme({
        "&": { fontSize: "12.5px", height: "100%" },
        ".cm-scroller": { fontFamily: "var(--font-mono)", lineHeight: "1.65" },
        ".cm-gutters": { backgroundColor: "transparent", borderRight: "1px solid var(--border)" },
        ".cm-activeLine": { backgroundColor: "rgba(77,156,255,0.07)" },
        ".cm-activeLineGutter": { backgroundColor: "transparent" },
      }),
    ];
  }, [language]);

  const elapsedLabel = useMemo(() => {
    const m = Math.floor(elapsed / 60);
    const s = elapsed % 60;
    return `${m}m ${String(s).padStart(2, "0")}s`;
  }, [elapsed]);

  const activeOutcome = report?.outcomes[activeTest];
  const local = runnable.includes(language);
  const darkEditor = editorTheme === "auto" ? theme === "dark" : editorTheme === "dark";
  const isDark = darkEditor;

  const toneColor =
    question.difficulty === "Beginner"
      ? "#5DD39E"
      : question.difficulty === "Intermediate"
      ? "var(--blue)"
      : question.difficulty === "Advanced"
      ? "#F2C94C"
      : "#FF6B6B";

  return (
    <div className="fixed inset-0 z-[70] flex flex-col bg-[var(--bg)]">
      {/* ══ WORKSPACE HEADER ══ */}
      <header className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-2 border-b border-[var(--border)] bg-[var(--sidebar)] px-3 py-2.5 sm:px-5">
        <button
          onClick={onBack}
          className="clip-oct-sm flex items-center gap-2 border border-[var(--border)] bg-[var(--surface-2)] px-2.5 py-1.5 font-mono text-[11px] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
        >
          <ArrowLeft className="h-3 w-3" /> Back to Practice
        </button>

        {!focusMode && (narrow || !leftOpen) && (
          <button
            onClick={() => setLeftOpen((v) => !v)}
            className="clip-oct-sm border border-[var(--border)] bg-[var(--surface-2)] px-2.5 py-1.5 font-mono text-[11px] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
          >
            {leftOpen ? "Hide problem" : "View problem"}
          </button>
        )}

        <div className="flex min-w-0 flex-1 items-center gap-2.5">
          <CodeIcon className="hidden h-4 w-4 shrink-0 text-[var(--blue)] sm:block" />
          <h1 className="display truncate text-[13.5px] font-bold uppercase tracking-tight sm:text-[15px]">
            {question.title}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 font-mono text-[10px] tracking-wider">
          <span className="clip-oct-sm border px-2 py-0.5" style={{ borderColor: toneColor, color: toneColor }}>
            {question.difficulty.toUpperCase()}
          </span>
          <span className="clip-oct-sm border border-[var(--border-strong)] px-2 py-0.5 text-[var(--text-2)]">
            {language.toUpperCase()}
          </span>
          <span className="clip-oct-sm border border-[var(--blue)]/50 bg-[var(--blue-soft)] px-2 py-0.5 text-[var(--blue)]">
            +{question.points} XP
          </span>
          <span
            className={cn(
              "clip-oct-sm border px-2 py-0.5",
              status === "COMPLETED"
                ? "border-[#5DD39E] text-[#5DD39E]"
                : "border-[var(--border-strong)] text-[var(--text-3)]"
            )}
          >
            {status}
            {attemptCount > 0 && ` · #${attemptCount + 1}`}
          </span>
          <span className="hidden items-center gap-1 text-[var(--text-3)] md:flex">
            <ClockIcon className="h-3 w-3" /> {elapsedLabel}
          </span>
        </div>
      </header>

      {/* ══ BODY ══ */}
      <div
        className={cn("min-h-0 flex-1", narrow ? "flex flex-col" : "grid")}
        style={
          narrow
            ? undefined
            : {
                gridTemplateColumns: focusMode
                  ? "1fr"
                  : leftOpen
                  ? `${leftWidth}px 5px minmax(0,1fr)`
                  : "5px minmax(0,1fr)",
              }
        }
      >
        {/* LEFT — problem statement */}
        {leftOpen && !focusMode && (
          <aside
            className={cn(
              "min-h-0 overflow-y-auto bg-[var(--surface-solid)] p-4 sm:p-5",
              narrow ? "max-h-[46%] border-b border-[var(--border)]" : "border-r-0"
            )}
          >
            <div className="flex items-center justify-between">
              <p className="mono-label flex items-center gap-2 text-[var(--blue)]">
                <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" /> Problem
              </p>
              <button
                onClick={() => setLeftOpen(false)}
                title="Collapse panel (Ctrl/⌘ + B)"
                className="font-mono text-[10px] text-[var(--text-3)] transition-colors hover:text-[var(--blue)]"
              >
                {narrow ? "close" : "collapse →"}
              </button>
            </div>

            <h2 className="display mt-3 text-lg font-bold leading-tight tracking-tight">{question.title}</h2>

            <div className="mt-3 border border-[var(--border)] bg-[var(--surface-2)] p-3">
              <p className="mono-label mb-1 text-[9px]">Scenario</p>
              <p className="text-[12px] leading-relaxed text-[var(--text-2)]">{question.scenario}</p>
            </div>

            <p className="mt-3 whitespace-pre-line text-[12.5px] leading-relaxed text-[var(--text)]">
              {question.statement}
            </p>

            <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
              <div>
                <p className="mono-label text-[9px]">Input format</p>
                <p className="mt-1 font-mono text-[11px] leading-relaxed text-[var(--text-2)]">{question.inputFormat}</p>
              </div>
              <div>
                <p className="mono-label text-[9px]">Output format</p>
                <p className="mt-1 font-mono text-[11px] leading-relaxed text-[var(--text-2)]">{question.outputFormat}</p>
              </div>
            </div>

            <div className="mt-4">
              <p className="mono-label text-[9px]">Constraints</p>
              <ul className="mt-1.5 space-y-1">
                {question.constraints.map((c) => (
                  <li key={c} className="flex gap-2 font-mono text-[11px] text-[var(--text-2)]">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rotate-45 bg-[var(--blue)]" />
                    {c}
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-4 space-y-2.5">
              <p className="mono-label text-[9px]">Examples</p>
              {question.examples.map((ex, i) => (
                <div key={i} className="border border-[var(--border)] bg-[var(--surface-2)] p-2.5 font-mono text-[10.5px]">
                  <p className="text-[var(--text-3)]">input</p>
                  <p className="text-[var(--text)]">{ex.input}</p>
                  <p className="mt-1.5 text-[var(--text-3)]">output</p>
                  <p className="text-[#5DD39E]">{ex.output}</p>
                  <p className="mt-1.5 border-t border-[var(--border)] pt-1.5 leading-relaxed text-[var(--text-2)]">
                    {ex.explanation}
                  </p>
                </div>
              ))}
            </div>

            <button
              onClick={() => setShowHints((v) => !v)}
              className="mt-4 flex w-full items-center justify-between border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 font-mono text-[11px] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
            >
              <span className="flex items-center gap-2">
                <SparklesIcon className="h-3.5 w-3.5" /> Hints ({question.hints.length})
              </span>
              <ChevronRight className={cn("h-3.5 w-3.5 transition-transform", showHints && "rotate-90")} />
            </button>
            {showHints && (
              <div className="panel-in mt-2 space-y-2">
                {question.hints.map((h, i) => (
                  <p key={i} className="border-l-2 border-[var(--blue)] bg-[var(--blue-soft)] px-3 py-2 text-[11.5px] leading-relaxed text-[var(--text-2)]">
                    {h}
                  </p>
                ))}
              </div>
            )}

            <div className="mt-4 border-t border-[var(--border)] pt-3">
              <p className="mono-label text-[9px]">Submission requirements</p>
              <ul className="mt-1.5 space-y-1">
                {question.requirements.map((r) => (
                  <li key={r} className="flex gap-2 text-[11.5px] leading-relaxed text-[var(--text-2)]">
                    <CheckIcon className="mt-0.5 h-3 w-3 shrink-0 text-[#5DD39E]" />
                    {r}
                  </li>
                ))}
              </ul>
            </div>

            {(status === "COMPLETED" || (bestPercent ?? 0) >= 100) && (
              <button
                onClick={() => setShowSolution((v) => !v)}
                className="mt-4 w-full border border-[var(--blue)] bg-[var(--blue-soft)] px-3 py-2 font-mono text-[11px] text-[var(--blue)] transition-colors hover:bg-[var(--blue)] hover:text-white"
              >
                {showSolution ? "Hide reference solution" : "View reference solution"}
              </button>
            )}
            {showSolution && (
              <pre className="panel-in mt-2 overflow-x-auto border border-[var(--border)] bg-[var(--surface-2)] p-3 font-mono text-[10.5px] leading-relaxed text-[var(--text-2)]">
                <code>{question.canonical}</code>
              </pre>
            )}
          </aside>
        )}

        {/* collapse handle */}
        {!focusMode && !narrow && (
          <div
            role="separator"
            aria-orientation="vertical"
            onPointerDown={() => {
              if (!leftOpen) {
                setLeftOpen(true);
                return;
              }
              dragRef.current = "x";
              document.body.style.cursor = "col-resize";
              document.body.style.userSelect = "none";
            }}
            className={cn(
              "group relative hidden cursor-col-resize bg-[var(--border)] transition-colors hover:bg-[var(--blue)] md:block",
              !leftOpen && "md:cursor-pointer"
            )}
          >
            <span className="absolute left-1/2 top-1/2 h-8 w-[3px] -translate-x-1/2 -translate-y-1/2 bg-[var(--text-3)] opacity-0 transition-opacity group-hover:opacity-100" />
          </div>
        )}

        {/* CENTER + BOTTOM */}
        <div className="flex min-h-0 min-w-0 flex-col">
          {/* editor toolbar */}
          <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-[var(--border)] bg-[var(--surface-solid)] px-3 py-2">
            <span className="mono-label flex items-center gap-2 text-[9.5px]">
              <span className="h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" /> Editor
            </span>

            <select
              value={language}
              onChange={(e) => changeLanguage(e.target.value as Lang)}
              className="clip-oct-sm cursor-pointer border border-[var(--border)] bg-[var(--surface-2)] px-2 py-1 font-mono text-[10.5px] text-[var(--text)] focus:border-[var(--blue)] focus:outline-none"
            >
              {question.languages.map((l) => (
                <option key={l} value={l}>
                  {l === "python" ? "Python 3.12" : l === "javascript" ? "JavaScript (ES2023)" : l === "java" ? "Java 17" : "C++ 20"}
                  {runnable.includes(l as Lang) ? " · runs locally" : " · judge offline"}
                </option>
              ))}
            </select>

            <div className="flex items-center gap-1">
              {[
                { label: "Format", fn: formatCode, hint: "expand tabs, trim trailing space" },
                { label: "Reset", fn: () => { setCode(question.starter[language] ?? question.starter.javascript); setReport(null); }, hint: "restore starter code" },
                {
                  label: "Focus",
                  fn: () => setFocusMode((v) => !v),
                  hint: "Ctrl/⌘ + Shift + F",
                },
                ...(status === "COMPLETED"
                  ? [{ label: "Solution", fn: () => setShowSolution((v) => !v), hint: "reference implementation" }]
                  : []),
              ].map((b) => (
                <button
                  key={b.label}
                  onClick={b.fn}
                  title={b.hint}
                  className="clip-oct-sm border border-[var(--border)] px-2 py-1 font-mono text-[10px] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
                >
                  {b.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1" role="group" aria-label="Editor theme">
              {(["auto", "dark", "light"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setEditorTheme(t)}
                  title={`editor theme: ${t}`}
                  className={cn(
                    "clip-oct-sm border px-2 py-1 font-mono text-[10px] transition-colors",
                    editorTheme === t
                      ? "border-[var(--blue)] bg-[var(--blue-soft)] text-[var(--blue)]"
                      : "border-[var(--border)] text-[var(--text-3)] hover:text-[var(--text)]"
                  )}
                >
                  {t}
                </button>
              ))}
            </div>

            <span className="ml-auto hidden items-center gap-2.5 font-mono text-[9.5px] text-[var(--text-3)] lg:flex">
              <span>⌘/Ctrl+↵ run</span>
              <span>⇧⌘/Ctrl+↵ submit</span>
              <span>⌘/Ctrl+F find & replace</span>
              <span>⌘/Ctrl+/ comment</span>
            </span>
          </div>

          {/* editor */}
          <div className="min-h-0 flex-1 overflow-hidden bg-[var(--surface-solid)]">
            <CodeMirror
              value={code}
              onChange={(v) => setCode(v)}
              extensions={extensions}
              theme={isDark ? oneDark : "light"}
              height="100%"
              basicSetup={{
                lineNumbers: true,
                foldGutter: true,
                highlightActiveLine: true,
                bracketMatching: true,
                closeBrackets: true,
                autocompletion: false,
                indentOnInput: true,
                tabSize: 2,
              }}
              style={{ height: "100%", fontSize: "12.5px" }}
            />
          </div>

          {/* console resize handle */}
          {!focusMode && !narrow && (
            <div
              role="separator"
              aria-orientation="horizontal"
              onPointerDown={() => {
                dragRef.current = "y";
                document.body.style.cursor = "row-resize";
                document.body.style.userSelect = "none";
              }}
              className="group h-[5px] shrink-0 cursor-row-resize bg-[var(--border)] transition-colors hover:bg-[var(--blue)]"
            />
          )}

          {/* bottom panel */}
          {!focusMode && (
            <div
              className={cn("flex shrink-0 flex-col border-t border-[var(--border)] bg-[var(--surface-solid)]", narrow && "h-[44%]")}
              style={narrow ? undefined : { height: consoleHeight }}
            >
              <div className="flex shrink-0 items-center gap-1 border-b border-[var(--border)] px-2 py-1.5">
                {(
                  [
                    { id: "tests", label: "Test Cases", count: question.tests.length },
                    { id: "output", label: "Output", count: undefined },
                    { id: "console", label: "Console", count: logs.length },
                    { id: "results", label: "Submission Results", count: undefined },
                  ] as { id: "tests" | "output" | "console" | "results"; label: string; count?: number }[]
                ).map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTab(t.id)}
                    className={cn(
                      "clip-oct-sm flex items-center gap-1.5 px-2.5 py-1 font-mono text-[10px] tracking-wider transition-colors",
                      tab === t.id ? "bg-[var(--blue)] text-white" : "text-[var(--text-3)] hover:text-[var(--text)]"
                    )}
                  >
                    {t.label}
                    {typeof t.count === "number" && <span className="opacity-70">({t.count})</span>}
                  </button>
                ))}

                <div className="ml-auto flex items-center gap-2">
                  <button
                    onClick={() => run("run")}
                    disabled={busy !== null}
                    className="btn-shell btn-ghost-shell btn-shell-sm disabled:opacity-50"
                  >
                    <span className="btn-core">
                      <PlayIcon className="h-3 w-3" /> {busy === "run" ? "Running…" : "Run Code"}
                    </span>
                  </button>
                  <button
                    onClick={() => run("submit")}
                    disabled={busy !== null}
                    className="btn-shell btn-primary-shell btn-shell-sm disabled:opacity-50"
                  >
                    <span className="btn-core">
                      <UploadCloudIcon className="h-3 w-3" />
                      {busy === "submit" ? "Grading…" : "Submit Solution"}
                    </span>
                  </button>
                </div>
              </div>

              <div className="min-h-0 flex-1 overflow-y-auto p-3">
                {busy !== null ? (
                  <div className="flex h-full flex-col items-center justify-center gap-3 text-[var(--text-3)]">
                    <div className="flex gap-1.5" aria-hidden="true">
                      {[0, 1, 2, 3, 4].map((i) => (
                        <span
                          key={i}
                          className="clip-oct-sm h-3.5 w-8 bg-[var(--border-strong)]"
                          style={
                            prefersReducedMotion()
                              ? { backgroundColor: "var(--blue)" }
                              : { animation: `cq-illuminate 900ms ${i * 110}ms ease-out infinite` }
                          }
                        />
                      ))}
                    </div>
                    <p className="font-mono text-[11px]">
                      {busy === "run" ? "executing against visible tests…" : "grading submission against the full suite…"}
                    </p>
                  </div>
                ) : offline ? (
                  <div className="clip-oct border border-[#F2C94C]/45 bg-[#F2C94C]/[0.07] p-4">
                    <p className="mono-label text-[#F2C94C]">Judge offline</p>
                    <p className="mt-2 text-[12.5px] leading-relaxed text-[var(--text)]">
                      {offline.language} is executed by the server-side sandbox, which is not connected in this
                      frontend prototype. No verdict was produced and no XP was awarded — the page never guesses.
                    </p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {offline.runnable.map((l) => (
                        <button
                          key={l}
                          onClick={() => changeLanguage(l as Lang)}
                          className="clip-oct-sm border border-[var(--blue)] bg-[var(--blue-soft)] px-2.5 py-1 font-mono text-[10.5px] text-[var(--blue)] transition-colors hover:bg-[var(--blue)] hover:text-white"
                        >
                          run in {l} instead →
                        </button>
                      ))}
                    </div>
                  </div>
                ) : tab === "tests" ? (
                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-1.5">
                      {question.tests.map((t, i) => {
                        const o = report?.outcomes[i];
                        return (
                          <button
                            key={t.name}
                            onClick={() => setActiveTest(i)}
                            className={cn(
                              "clip-oct-sm flex items-center gap-1.5 border px-2 py-1 font-mono text-[10px] transition-colors",
                              activeTest === i && "border-[var(--blue)]",
                              o?.status === "pass"
                                ? "border-[#5DD39E] text-[#5DD39E]"
                                : o
                                ? "border-[#FF6B6B] text-[#FF6B6B]"
                                : "border-[var(--border)] text-[var(--text-3)]"
                            )}
                          >
                            {o ? (o.status === "pass" ? "✓" : "✕") : "○"} T{i + 1}
                            {t.hidden && <span className="opacity-60">·hidden</span>}
                          </button>
                        );
                      })}
                    </div>

                    {activeOutcome ? (
                      <div className="grid gap-2 sm:grid-cols-3">
                        {[
                          { l: "Input", v: activeOutcome.input, c: "var(--text)" },
                          { l: "Expected", v: activeOutcome.expected, c: "#5DD39E" },
                          { l: "Your output", v: activeOutcome.actual, c: activeOutcome.status === "pass" ? "#5DD39E" : "#FF6B6B" },
                        ].map((box) => (
                          <div key={box.l} className="border border-[var(--border)] bg-[var(--surface-2)] p-2.5">
                            <p className="mono-label text-[9px]">{box.l}</p>
                            <p className="mt-1 break-words font-mono text-[11px] leading-relaxed" style={{ color: box.c }}>
                              {box.v}
                            </p>
                          </div>
                        ))}
                        {activeOutcome.error && (
                          <div className="sm:col-span-3 border border-[#FF6B6B]/50 bg-[#FF6B6B]/10 p-2.5 font-mono text-[11px] text-[#FF6B6B]">
                            runtime error → {activeOutcome.error}
                          </div>
                        )}
                        <p className="font-mono text-[10px] text-[var(--text-3)] sm:col-span-3">
                          {activeOutcome.status.toUpperCase()} · {activeOutcome.ms.toFixed(2)} ms · weight {activeOutcome.weight}
                          {activeOutcome.hidden ? " · hidden test (graded on submit only)" : ""}
                        </p>
                      </div>
                    ) : (
                      <p className="py-6 text-center text-[11.5px] text-[var(--text-3)]">
                        {report
                          ? "That run did not include this test. Submit to grade the hidden cases."
                          : "No run yet — press Run Code (⌘/Ctrl + ↵) to execute against the visible tests."}
                      </p>
                    )}
                  </div>
                ) : tab === "output" ? (
                  <pre className="whitespace-pre-wrap font-mono text-[11.5px] leading-relaxed text-[var(--text-2)]">
{report
  ? [
      `--- CodeQuest sandbox (${language}) ---`,
      `verdict        ${report.accepted ? "ACCEPTED" : "PARTIAL / REJECTED"}`,
      `tests passed   ${report.passed} of ${report.total}`,
      `score weight   ${Math.round(report.fraction * 100)}%`,
      `elapsed        ${report.durationMs.toFixed(1)} ms`,
      ``,
      ...report.outcomes.map(
        (o) =>
          `${o.status === "pass" ? "  ok  " : " FAIL "} ${o.name}${o.hidden ? " [hidden]" : ""}  in=${o.input}  got=${o.actual}  want=${o.expected}`
      ),
    ].join("\n")
  : "No output yet. Running code executes it against the question's sample cases in your browser."}
                  </pre>
                ) : tab === "console" ? (
                  <div className="space-y-1 font-mono text-[11px] leading-relaxed">
                    {logs.map((l, i) => (
                      <p
                        key={i}
                        className={cn(
                          l.t === "ok" && "text-[#5DD39E]",
                          l.t === "err" && "text-[#FF6B6B]",
                          l.t === "warn" && "text-[#F2C94C]",
                          l.t === "info" && "text-[var(--text-3)]"
                        )}
                      >
                        <span className="mr-2 opacity-50">{">"}</span>
                        {l.text}
                      </p>
                    ))}
                  </div>
                ) : report ? (
                  <div className="space-y-3">
                    {/* marking breakdown */}
                    <div className="overflow-hidden border border-[var(--border)]">
                      <div className="grid grid-cols-[minmax(0,1fr)_4rem_4.5rem_4rem] gap-2 border-b border-[var(--border)] bg-[var(--surface-2)] px-2.5 py-1.5 font-mono text-[9.5px] uppercase tracking-wider text-[var(--text-3)]">
                        <span>Test</span><span>Weight</span><span>Result</span><span className="text-right">Points</span>
                      </div>
                      {report.outcomes.map((o, i) => {
                        const totalW = report.outcomes.reduce((s, x) => s + x.weight, 0) || 1;
                        const pts = o.status === "pass" ? Math.round((o.weight / totalW) * question.points) : 0;
                        return (
                          <div key={i} className="grid grid-cols-[minmax(0,1fr)_4rem_4.5rem_4rem] gap-2 border-b border-[var(--border)] px-2.5 py-1.5 font-mono text-[11px] last:border-b-0">
                            <span className="truncate text-[var(--text-2)]">
                              {o.name}
                              {o.hidden && <span className="ml-1.5 text-[9px] text-[var(--text-3)]">hidden</span>}
                            </span>
                            <span className="text-[var(--text-3)]">{o.weight}</span>
                            <span className={o.status === "pass" ? "text-[#5DD39E]" : "text-[#FF6B6B]"}>
                              {o.status === "pass" ? "pass" : o.status}
                            </span>
                            <span className="text-right text-[var(--text)]">{pts}</span>
                          </div>
                        );
                      })}
                    </div>

                    <div className={cn("clip-oct-sm border p-3", report.accepted ? "border-[#5DD39E]/50 bg-[#5DD39E]/[0.07]" : "border-[#F2C94C]/50 bg-[#F2C94C]/[0.07]")}>
                      <p className="display text-sm font-bold" style={{ color: report.accepted ? "#5DD39E" : "#F2C94C" }}>
                        {report.accepted ? `ACCEPTED — +${report.awardedXp} XP` : `PARTIAL — +${report.awardedXp} XP`}
                      </p>
                      <ul className="mt-2 space-y-1">
                        {question.marking.map((m) => (
                          <li key={m} className="flex gap-2 text-[11.5px] leading-relaxed text-[var(--text-2)]">
                            <span className="mt-1.5 h-1 w-1 shrink-0 rotate-45 bg-[var(--blue)]" />
                            {m}
                          </li>
                        ))}
                        <li className="flex gap-2 text-[11.5px] leading-relaxed text-[var(--text-2)]">
                          <span className="mt-1.5 h-1 w-1 shrink-0 rotate-45 bg-[var(--blue)]" />
                          Awarded {report.awardedXp} of {report.potentialXp} possible points
                          {report.accepted ? "" : " — partial credit is weighted at 80% of the passing tests."}
                        </li>
                      </ul>
                    </div>
                  </div>
                ) : (
                  <p className="py-6 text-center text-[11.5px] text-[var(--text-3)]">
                    Submit your solution to see the marking breakdown. Points come from the graded result — never
                    from pressing the button.
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ══ STATUS RAIL ══ */}
      <footer className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-1 border-t border-[var(--border)] bg-[var(--sidebar)] px-3 py-1.5 font-mono text-[10px] text-[var(--text-3)] sm:px-5">
        <span className="flex items-center gap-1.5">
          <span className={cn("h-1.5 w-1.5 rounded-full", local ? "bg-[#5DD39E]" : "bg-[#F2C94C]")} />
          {local ? "client sandbox: live" : "server judge: offline"}
        </span>
        <span>{question.category}</span>
        <span>est {question.estMinutes} min · target {elapsedLabel}</span>
        {bestPercent !== undefined && <span>best {bestPercent}%</span>}
        <span className="ml-auto flex items-center gap-1.5">
          <TrophyIcon className="h-3 w-3 text-[var(--blue)]" />
          {totalXp.toLocaleString()} XP · school #{String(rank.position).padStart(2, "0")}
        </span>
      </footer>

      {celebrate && report && (
        <SuccessOverlay
          q={question}
          report={celebrate}
          newTotalXp={totalXp}
          rankPosition={rank.position}
          gapToNext={rank.gapToNext}
          durationLabel={elapsedLabel}
          onClose={() => {
            setCelebrate(null);
            onBack();
          }}
        />
      )}
    </div>
  );
}
