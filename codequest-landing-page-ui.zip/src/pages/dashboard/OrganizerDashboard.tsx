import DashboardPlaceholder from "./DashboardPlaceholder";

/** Dashboard 02 — placeholder until the design spec arrives. */
export default function OrganizerDashboard() {
  return <DashboardPlaceholder id="organizer" />;
}
