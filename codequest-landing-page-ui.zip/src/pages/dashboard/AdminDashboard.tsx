import DashboardPlaceholder from "./DashboardPlaceholder";

/** Dashboard 03 — placeholder until the design spec arrives. */
export default function AdminDashboard() {
  return <DashboardPlaceholder id="admin" />;
}
