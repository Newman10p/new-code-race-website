import { Link } from "../../lib/router";
import { dashboards, type DashboardId } from "../../lib/dashboards";
import { ThemeToggle, Wordmark } from "../../components/Navbar";
import { ArrowLeft, OctagonFrame } from "../../components/icons";

/**
 * Empty dashboard frame. Each dashboard page renders this until its
 * real design spec is implemented — then the page simply stops using it.
 */
export default function DashboardPlaceholder({ id }: { id: DashboardId }) {
  const meta = dashboards.find((d) => d.id === id)!;

  return (
    <div className="flex min-h-[100svh] flex-col">
      {/* Top bar (temporary — final dashboard chrome comes with the spec) */}
      <header className="sticky top-0 z-40 border-b border-[var(--border)] bg-[var(--nav-bg)] backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-5 sm:px-8">
          <div className="flex items-center gap-4">
            <Wordmark />
            <span className="hidden h-5 w-px bg-[var(--border-strong)] sm:block" aria-hidden="true" />
            <span className="clip-oct-sm hidden border border-[var(--blue)]/50 bg-[var(--blue-soft)] px-2.5 py-1 font-mono text-[10px] font-semibold tracking-[0.18em] text-[var(--blue)] sm:inline-block">
              {meta.label.toUpperCase()}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/"
              className="mono-label hidden items-center gap-2 transition-colors hover:text-[var(--blue)] sm:inline-flex"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Exit to site
            </Link>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Body */}
      <div className="mx-auto flex w-full max-w-7xl flex-1 items-center px-5 py-16 sm:px-8">
        <div className="panel clip-oct relative w-full overflow-hidden px-6 py-16 text-center sm:px-12 sm:py-24">
          <OctagonFrame className="pointer-events-none absolute -left-14 -top-14 h-52 w-52 text-[var(--border)]" />
          <OctagonFrame className="pointer-events-none absolute -bottom-16 -right-10 h-60 w-60 text-[var(--border)]" />
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[var(--blue)] to-transparent"
          />

          <div className="relative">
            <p className="mono-label mb-5 flex items-center justify-center gap-3">
              <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
              Dashboard {meta.num} / {String(dashboards.length).padStart(2, "0")}
              <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
            </p>

            <h1 className="display text-4xl font-bold uppercase leading-[1.02] tracking-tight sm:text-6xl">
              {meta.label} <span className="text-[var(--blue)]">dashboard</span>
            </h1>

            <p className="mx-auto mt-5 max-w-md text-[14.5px] leading-relaxed text-[var(--text-2)]">
              {meta.blurb}. This page is wired up and waiting for its design
              spec.
            </p>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-2.5">
              <span className="clip-oct-sm border border-[var(--border-strong)] bg-[var(--surface-2)] px-3 py-1.5 font-mono text-[11px] tracking-wider text-[var(--text-2)]">
                #{meta.path}
              </span>
              <span className="clip-oct-sm flex items-center gap-2 border border-[var(--border-strong)] bg-[var(--surface-2)] px-3 py-1.5 font-mono text-[11px] tracking-wider text-[var(--text-2)]">
                <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />
                AWAITING SPEC
              </span>
            </div>

            <Link
              to="/"
              className="mono-label mt-10 inline-flex items-center gap-2 transition-colors hover:text-[var(--blue)] sm:hidden"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Exit to site
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
