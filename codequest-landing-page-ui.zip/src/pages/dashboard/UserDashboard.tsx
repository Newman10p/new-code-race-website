import { useEffect, useState } from "react";
import { navigate, parseRoute, useRoute } from "../../lib/router";
import { setGridEnergy } from "../../lib/grid";
import DashboardShell from "../../components/dashboard/DashboardShell";
import { PracticeProvider } from "../../lib/practiceStore";
import { CommunicationsProvider } from "../../lib/communicationsStore";
import { CompetitionProvider } from "../../lib/competitionStore";
import { SubmissionProvider } from "../../lib/submissionStore";
import { AcademyProvider } from "../../lib/academyStore";
import LearningPathTab from "./tabs/LearningPathTab";
import { getQuestion } from "../../lib/practiceStore";
import QuestionWorkspace from "./tabs/practice/QuestionWorkspace";
import OverviewTab from "./tabs/OverviewTab";
import CoursesTab from "./tabs/CoursesTab";
import DailyPracticeTab from "./tabs/DailyPracticeTab";
import PracticeTab from "./tabs/PracticeTab";
import AiTutorTab from "./tabs/AiTutorTab";
import CompetitionsTab from "./tabs/CompetitionsTab";
import SubmissionsTab from "./tabs/SubmissionsTab";
import StudentHubTab from "./tabs/StudentHubTab";
import AnnouncementsTab from "./tabs/AnnouncementsTab";
import ProfileTab from "./tabs/ProfileTab";
import SettingsTab from "./tabs/SettingsTab";

/** "/dashboard/user[/tab[/param]]" -> { tab, param } */
function parseDashboardRoute(path: string): { tab: string; param: string | null } {
  const rest = path.replace(/^\/dashboard\/(?:user\/?)?/, "").replace(/\/+$/, "");
  if (!rest) return { tab: "overview", param: null };
  const [tab, param] = rest.split("/");
  return { tab: tab || "overview", param: param ?? null };
}

export default function UserDashboard() {
  const route = useRoute();
  const { path } = parseRoute(route);
  const { tab, param } = parseDashboardRoute(path);

  const [activeTab, setActiveTab] = useState<string>(tab);
  const [openQuestionId, setOpenQuestionId] = useState<string | null>(param);

  useEffect(() => {
    setActiveTab(tab);
    setOpenQuestionId(param);
  }, [tab, param]);

  // The environmental grid stays quiet inside the product.
  useEffect(() => {
    setGridEnergy(0.06);
    return () => setGridEnergy(0.14);
  }, []);

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    setOpenQuestionId(null);
    navigate(tabId === "overview" ? "/dashboard/user" : `/dashboard/user/${tabId}`);
  };

  const openQuestion = (questionId: string) => {
    setOpenQuestionId(questionId);
    navigate(`/dashboard/user/daily-practice/${questionId}`);
  };

  const closeQuestion = () => {
    setOpenQuestionId(null);
    navigate("/dashboard/user/daily-practice");
  };

  const question = openQuestionId ? getQuestion(openQuestionId) : undefined;

  return (
    <PracticeProvider>
      <CommunicationsProvider>
        <CompetitionProvider>
        <SubmissionProvider>
          {/* Dedicated full-screen workspace: its own route, so the browser
              back button returns to the archive. */}
          {openQuestionId && question ? (
            <QuestionWorkspace key={question.id} question={question} onBack={closeQuestion} />
          ) : (
            <AcademyProvider>
            <DashboardShell activeTab={activeTab} onTabChange={handleTabChange}>
              <div key={activeTab} className="page-in">
            {activeTab === "courses" ? (
              <CoursesTab param={param} onNavigate={handleTabChange} />
            ) : activeTab === "continue" ? (
              <CoursesTab param="continue" onNavigate={handleTabChange} />
            ) : activeTab === "path" ? (
              <LearningPathTab onOpenCourse={(id) => navigate(`/dashboard/user/courses/${id}`)} />
            ) : activeTab === "daily-practice" ? (
              <DailyPracticeTab onOpenQuestion={openQuestion} onNavigate={handleTabChange} />
            ) : activeTab === "practice" ? (
              <PracticeTab onNavigate={handleTabChange} />
            ) : activeTab === "ai-tutor" ? (
              <AiTutorTab onNavigate={handleTabChange} />
            ) : activeTab === "competitions" ? (
              <CompetitionsTab onNavigate={handleTabChange} />
            ) : activeTab === "submissions" ? (
              <SubmissionsTab />
            ) : activeTab === "hub" ? (
              <StudentHubTab />
            ) : activeTab === "announcements" ? (
              <AnnouncementsTab onNavigate={handleTabChange} />
            ) : activeTab === "profile" ? (
              <ProfileTab />
            ) : activeTab === "settings" ? (
              <SettingsTab />
            ) : (
              <OverviewTab onNavigate={handleTabChange} onOpenQuestion={openQuestion} />
            )}
              </div>
            </DashboardShell>
            </AcademyProvider>
          )}
        </SubmissionProvider>
        </CompetitionProvider>
      </CommunicationsProvider>
    </PracticeProvider>
  );
}
