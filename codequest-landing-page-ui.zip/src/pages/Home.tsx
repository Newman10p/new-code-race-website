import { useEffect, useRef, useState } from "react";
import { cn } from "../utils/cn";
import { Link, parseRoute, useRoute } from "../lib/router";
import { prefersReducedMotion, setGridEnergy } from "../lib/grid";
import {
  features,
  initialLeaderboard,
  processSteps,
  stages,
  timelinePreview,
  type RankRow,
} from "../data";
import {
  Button,
  ButtonLink,
  OctagonNode,
  Reveal,
  SectionHead,
  Stat,
  useAnimatedNumber,
} from "../components/ui";
import { ArrowRight, FeatureIcon } from "../components/icons";

/* ---------------- Hero ---------------- */

function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (prefersReducedMotion()) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const el = heroRef.current;
        if (!el) return;
        const y = window.scrollY;
        if (y < 1000) {
          el.style.transform = `translateY(${y * 0.14}px)`;
          el.style.opacity = `${Math.max(0, 1 - y / 720)}`;
        }
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  const scrollToSeason = () =>
    document.getElementById("season")?.scrollIntoView({ behavior: prefersReducedMotion() ? "auto" : "smooth" });

  return (
    <section className="relative flex min-h-[100svh] items-center justify-center overflow-hidden">
      <div ref={heroRef} className="relative z-10 mx-auto max-w-5xl px-5 pb-24 pt-32 text-center sm:px-8">
        <Reveal>
          <p className="mono-label mb-7 flex items-center justify-center gap-3">
            <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
            Inter-school coding competition
            <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[var(--blue)]" />
          </p>
        </Reveal>

        <Reveal delay={80}>
          <h1 className="display text-[clamp(3.4rem,13vw,9rem)] font-bold leading-[0.95] tracking-[-0.045em]">
            <span className="text-[var(--text)]">CODE</span>
            <span className="text-[var(--blue)]">QUEST</span>
          </h1>
        </Reveal>

        <div className="relative mx-auto mt-6 h-[3px] w-44 overflow-hidden sm:w-64" aria-hidden="true">
          <div
            className="h-full w-full origin-left bg-[var(--blue)] shadow-[0_0_14px_var(--glow)]"
            style={{
              transform: prefersReducedMotion() ? "scaleX(1)" : "scaleX(0)",
              animation: prefersReducedMotion() ? "none" : "cq-sweep 0.9s 0.5s cubic-bezier(0.65,0,0.35,1) both",
            }}
          />
        </div>

        <Reveal delay={160}>
          <p className="display mt-7 text-xl font-semibold tracking-wide text-[var(--text)] sm:text-2xl">
            Think<span className="text-[var(--blue)]">.</span> Build
            <span className="text-[var(--blue)]">.</span> Compete
            <span className="text-[var(--blue)]">.</span>
          </p>
        </Reveal>

        <Reveal delay={240}>
          <p className="mx-auto mt-5 max-w-xl text-[15px] leading-relaxed text-[var(--text-2)]">
            A competitive coding platform where students solve real problems,
            sharpen their skills, and compete against the best young
            developers in the region.
          </p>
        </Reveal>

        <Reveal delay={320}>
          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <ButtonLink to="/login?mode=join" size="lg" className="w-full sm:w-auto">
              Join the Competition
            </ButtonLink>
            <Button variant="ghost" size="lg" onClick={scrollToSeason} className="w-full sm:w-auto">
              Explore Timeline
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </Reveal>

        <Reveal delay={420}>
          <p className="mono-label mt-12 flex flex-wrap items-center justify-center gap-x-4 gap-y-2">
            <span>20+ Schools</span>
            <span className="text-[var(--blue)]">/</span>
            <span>100+ Challenges</span>
            <span className="text-[var(--blue)]">/</span>
            <span>6 Rounds</span>
            <span className="caret text-[var(--blue)]">▍</span>
          </p>
        </Reveal>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-7 left-1/2 z-10 -translate-x-1/2" aria-hidden="true">
        <div className="flex flex-col items-center gap-2">
          <span className="mono-label opacity-60">Scroll</span>
          <span className="scroll-cue-line block h-12 w-px bg-[var(--border-strong)]" />
        </div>
      </div>
    </section>
  );
}

/* ---------------- What is CodeQuest ---------------- */

const whatList = [
  "Solve real problems, not toy puzzles",
  "Improve programming skills under pressure",
  "Think logically and structure your approach",
  "Compete against students from other schools",
  "Learn through every challenge you face",
  "Measure your progress across the season",
];

function WhatSection() {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-5 py-24 sm:px-8 md:py-32">
      <SectionHead index="01" label="What is CodeQuest" title="More than a coding contest." />
      <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
        <Reveal>
          <p className="text-[15px] leading-relaxed text-[var(--text-2)]">
            CodeQuest is a season-long, ranked competition built for school
            students. Every round is engineered to make you solve harder
            problems, write cleaner code, and measure exactly how far you've
            come — against yourself first, and everyone else second.
          </p>
          <p className="mt-5 text-[15px] leading-relaxed text-[var(--text-2)]">
            From the first qualifier to the final stage, your progress is
            recorded, ranked, and visible. No hidden brackets, no opaque
            judging. Just problems, time, and a leaderboard that doesn't lie.
          </p>
        </Reveal>
        <div className="grid gap-x-8 gap-y-4 sm:grid-cols-2">
          {whatList.map((item, i) => (
            <Reveal key={item} delay={i * 70}>
              <div className="flex items-start gap-3">
                <span className="clip-oct-sm mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border border-[var(--border-strong)] bg-[var(--surface-2)]">
                  <span className="h-1.5 w-1.5 bg-[var(--blue)]" />
                </span>
                <span className="text-sm leading-relaxed text-[var(--text)]">{item}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- How it works ---------------- */

function ProcessSection() {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-5 py-24 sm:px-8 md:py-32">
      <SectionHead index="02" label="How CodeQuest works" title="From registration to the final stage." />
      <div className="relative">
        {/* Connecting line (desktop) */}
        <div className="absolute left-8 right-8 top-[22px] hidden h-px bg-[var(--border)] md:block" aria-hidden="true" />
        <div className="flex flex-col gap-2 md:grid md:grid-cols-5 md:gap-5">
          {processSteps.map((s, i) => (
            <Reveal key={s.id} delay={i * 110}>
              <div className="relative flex gap-5 md:block">
                <div className="flex flex-col items-center">
                  <OctagonNode active={i === 2} size={44}>
                    <span className="font-mono text-[11px] font-semibold">{s.num}</span>
                  </OctagonNode>
                  {i < processSteps.length - 1 && (
                    <span className="mt-2 w-px flex-1 bg-[var(--border)] md:hidden" aria-hidden="true" />
                  )}
                </div>
                <div className="pb-10 md:mt-6 md:pb-0">
                  <h3 className="display text-base font-bold tracking-wide">{s.title}</h3>
                  <p className="mt-2 max-w-[220px] text-[13px] leading-relaxed text-[var(--text-2)]">{s.copy}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Competition system ---------------- */

function SystemSection() {
  const [selected, setSelected] = useState(1);
  const stage = stages[selected];

  return (
    <section className="relative z-10 mx-auto max-w-7xl px-5 py-24 sm:px-8 md:py-32">
      <SectionHead index="03" label="Competition system" title="A season built in stages." />

      {/* Stage rail */}
      <Reveal>
        <div className="relative">
          <div className="absolute left-4 right-4 top-[20px] h-px bg-[var(--border)]" aria-hidden="true" />
          <div
            className="absolute left-4 top-[20px] h-px bg-[var(--blue)] transition-all duration-700"
            style={{ width: `calc((100% - 2rem) * ${selected / (stages.length - 1)})` }}
            aria-hidden="true"
          />
          <div className="relative flex gap-2 overflow-x-auto pb-3 md:justify-between md:overflow-visible">
            {stages.map((s, i) => (
              <button
                key={s.id}
                onClick={() => setSelected(i)}
                aria-pressed={i === selected}
                className="group flex min-w-[92px] flex-col items-center gap-3 focus-visible:outline-none"
              >
                <OctagonNode active={i === selected} size={40}>
                  <span className={cn("font-mono text-[10px] font-semibold", i === selected && "text-white")}>
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </OctagonNode>
                <span
                  className={cn(
                    "mono-label transition-colors duration-300",
                    i === selected ? "text-[var(--blue)]" : "group-hover:text-[var(--text)]"
                  )}
                >
                  {s.short}
                </span>
              </button>
            ))}
          </div>
        </div>
      </Reveal>

      {/* Detail panel */}
      <Reveal delay={140}>
        <div key={stage.id} className="panel clip-oct panel-in mt-8 p-7 sm:p-10">
          <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
            <div className="max-w-xl">
              <p className="mono-label mb-3 text-[var(--blue)]">
                Stage {String(selected + 1).padStart(2, "0")} / {String(stages.length).padStart(2, "0")}
              </p>
              <h3 className="display text-2xl font-bold uppercase tracking-tight sm:text-3xl">{stage.name}</h3>
              <p className="mt-4 text-sm leading-relaxed text-[var(--text-2)]">{stage.copy}</p>
            </div>
            <div className="flex shrink-0 flex-wrap gap-2 md:max-w-[240px] md:justify-end">
              {stage.chips.map((c) => (
                <span
                  key={c}
                  className="clip-oct-sm border border-[var(--border-strong)] bg-[var(--surface-2)] px-3 py-1.5 font-mono text-[11px] tracking-wider text-[var(--text-2)]"
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

/* ---------------- Features ---------------- */

function FeaturesSection() {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-5 py-24 sm:px-8 md:py-32">
      <SectionHead index="04" label="Competitive features" title="Built for competition." />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((f, i) => (
          <Reveal key={f.id} delay={(i % 3) * 90}>
            <div className="panel card-hover clip-oct group h-full p-6">
              <div className="flex items-start justify-between">
                <span className="clip-oct-sm flex h-12 w-12 items-center justify-center border border-[var(--border-strong)] text-[var(--text-2)] transition-all duration-300 group-hover:border-[var(--blue)] group-hover:bg-[var(--blue)] group-hover:text-white group-hover:[filter:drop-shadow(0_0_14px_var(--glow))]">
                  <FeatureIcon name={f.icon} className="h-6 w-6" />
                </span>
                <span className="mono-label opacity-50">F.0{i + 1}</span>
              </div>
              <h3 className="display mt-5 text-[15px] font-bold tracking-wide">{f.title}</h3>
              <p className="mt-2 text-[13px] leading-relaxed text-[var(--text-2)]">{f.copy}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ---------------- Leaderboard ---------------- */

function RankRowView({ row, rank, flash }: { row: RankRow; rank: number; flash: boolean }) {
  const pts = useAnimatedNumber(row.points, 800);
  return (
    <div
      className={cn(
        "grid grid-cols-[2.4rem_1fr_4.8rem_3rem] items-center gap-2 border-b border-[var(--border)] px-4 py-3.5 transition-colors last:border-b-0 sm:grid-cols-[2.4rem_1fr_7.5rem_5rem_3rem] sm:gap-3 sm:px-6",
        flash && "row-flash"
      )}
    >
      <span className={cn("font-mono text-xs", rank <= 3 ? "font-bold text-[var(--blue)]" : "text-[var(--text-3)]")}>
        {String(rank).padStart(2, "0")}
      </span>
      <div className="min-w-0">
        <p className="truncate font-display text-sm font-semibold">{row.name}</p>
        <p className="truncate font-mono text-[10.5px] tracking-wide text-[var(--text-3)]">{row.school}</p>
      </div>
      <span className="hidden text-right font-mono text-xs text-[var(--text-3)] sm:block">{row.lastRound} pts</span>
      <span className="text-right font-mono text-sm font-semibold tabular-nums text-[var(--text)]">
        {pts} <span className="text-[10px] font-normal text-[var(--text-3)]">pts</span>
      </span>
      <span
        className={cn(
          "text-right font-mono text-[11px] tabular-nums",
          row.delta > 0 ? "font-bold text-[var(--blue)]" : row.delta < 0 ? "text-[var(--down)]" : "text-[var(--text-3)]"
        )}
      >
        {row.delta > 0 ? `▲ ${row.delta}` : row.delta < 0 ? `▼ ${Math.abs(row.delta)}` : "—"}
      </span>
    </div>
  );
}

function LeaderboardSection() {
  const [rows, setRows] = useState<RankRow[]>(initialLeaderboard);
  const [flash, setFlash] = useState<Set<number>>(new Set());
  const rowsRef = useRef(rows);
  rowsRef.current = rows;

  useEffect(() => {
    const tick = () => {
      const prev = rowsRef.current;
      const next = prev.map((r) => ({ ...r }));
      const i = Math.floor(Math.random() * next.length);
      next[i].points += 4 + Math.floor(Math.random() * 12);
      next.sort((a, b) => b.points - a.points);
      next.forEach((r, idx) => {
        const oldRank = prev.findIndex((p) => p.id === r.id) + 1;
        r.delta = oldRank - (idx + 1);
      });
      setRows(next);
      setFlash(new Set([next[i].id]));
    };
    const id = window.setInterval(tick, 3800);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (flash.size === 0) return;
    const t = window.setTimeout(() => setFlash(new Set()), 1300);
    return () => window.clearTimeout(t);
  }, [flash]);

  return (
    <section id="rankings" className="relative z-10 mx-auto max-w-7xl px-5 py-24 sm:px-8 md:py-32">
      <SectionHead index="05" label="Live leaderboard" title="The field, ranked." />
      <Reveal>
        <div className="panel clip-oct overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--border)] px-4 py-4 sm:px-6">
            <h3 className="mono-label text-[var(--text)]">CodeQuest Rankings</h3>
            <span className="flex items-center gap-2 font-mono text-[11px] tracking-[0.2em] text-[var(--blue)]">
              <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-[var(--blue)]" />
              LIVE
            </span>
          </div>
          <div className="hidden grid-cols-[2.4rem_1fr_7.5rem_5rem_3rem] gap-3 border-b border-[var(--border)] px-6 py-2.5 sm:grid">
            {["Rank", "Student", "Last round", "Points", "Δ"].map((h) => (
              <span key={h} className="mono-label text-[10px] opacity-70">
                {h}
              </span>
            ))}
          </div>
          <div>
            {rows.map((r, i) => (
              <RankRowView key={r.id} row={r} rank={i + 1} flash={flash.has(r.id)} />
            ))}
          </div>
          <p className="border-t border-[var(--border)] px-6 py-3 font-mono text-[10.5px] tracking-wider text-[var(--text-3)]">
            Frontend preview — mock data. Live scoring arrives with Season 01.
          </p>
        </div>
      </Reveal>
    </section>
  );
}

/* ---------------- Season timeline preview ---------------- */

function SeasonSection() {
  return (
    <section id="season" className="relative z-10 mx-auto max-w-7xl px-5 py-24 sm:px-8 md:py-32">
      <SectionHead index="06" label="Season 01" title="Upcoming on the timeline." />
      <div className="relative">
        <div className="absolute left-[20px] top-2 h-[calc(100%-16px)] w-px bg-[var(--border)] md:left-0 md:top-[20px] md:h-px md:w-full" aria-hidden="true" />
        <div className="flex flex-col gap-8 md:grid md:grid-cols-4 md:gap-4">
          {timelinePreview.map((t, i) => (
            <Reveal key={t.id} delay={i * 110}>
              <div className="relative flex gap-5 md:block">
                <div className="flex flex-col items-center">
                  <OctagonNode active={t.status === "active"} size={40}>
                    {t.status === "active" ? (
                      <span className="pulse-dot h-2 w-2 rounded-full bg-white" />
                    ) : (
                      <span className="h-2 w-2 bg-[var(--text-3)]" />
                    )}
                  </OctagonNode>
                  {i < timelinePreview.length - 1 && (
                    <span className="mt-2 hidden w-px flex-1 md:block" aria-hidden="true" />
                  )}
                </div>
                <div className="pb-2 md:mt-5">
                  <p className="mono-label mb-1.5">{t.date}</p>
                  <h3 className="display text-base font-bold uppercase tracking-wide">{t.title}</h3>
                  <p className="mt-1.5 max-w-[200px] text-[12.5px] leading-relaxed text-[var(--text-2)]">{t.copy}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
      <Reveal delay={200}>
        <div className="mt-12">
          <ButtonLink to="/timeline" variant="ghost" size="lg">
            View Full Timeline
            <ArrowRight className="h-4 w-4" />
          </ButtonLink>
        </div>
      </Reveal>
    </section>
  );
}

/* ---------------- About preview ---------------- */

function AboutSection() {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-5 py-24 sm:px-8 md:py-32">
      <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
        <div>
          <SectionHead index="07" label="About CodeQuest" title="Built by students, for students." className="mb-0" />
          <Reveal delay={120}>
            <p className="mt-6 max-w-md text-[15px] leading-relaxed text-[var(--text-2)]">
              CodeQuest was started by student developers who wanted a
              competition that felt like a real product — rigorous problems,
              honest scoring, and a community that keeps competing after the
              final whistle.
            </p>
            <div className="mt-8">
              <ButtonLink to="/about" variant="ghost">
                Learn more about CodeQuest
                <ArrowRight className="h-4 w-4" />
              </ButtonLink>
            </div>
          </Reveal>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <Stat value={500} suffix="+" label="Students" />
          <Stat value={20} suffix="+" label="Schools" delay={120} />
          <Stat value={100} suffix="+" label="Challenges" delay={240} />
        </div>
      </div>

      {/* Field archive strip → gallery */}
      <Reveal delay={160}>
        <Link to="/gallery" className="group mt-14 block border-t border-[var(--border)] pt-8">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <p className="mono-label">Field archive — 06 plates</p>
            <span className="mono-label flex items-center gap-2 transition-colors group-hover:text-[var(--blue)]">
              Open gallery
              <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
            </span>
          </div>
          <div className="grid grid-cols-3 gap-3 sm:gap-4">
            {[
              { src: "images/gallery/arena.jpg", cap: "The Field" },
              { src: "images/gallery/medallion.jpg", cap: "Medallion" },
              { src: "images/gallery/blueprint.jpg", cap: "Geometry" },
            ].map((t) => (
              <div
                key={t.src}
                className="clip-oct-sm relative aspect-[4/3] overflow-hidden border border-[var(--border)] bg-[var(--surface)] transition-colors duration-300 group-hover:border-[var(--blue)]"
              >
                <img
                  src={t.src}
                  alt={t.cap}
                  loading="lazy"
                  className="h-full w-full object-cover opacity-75 transition-all duration-700 group-hover:scale-[1.06] group-hover:opacity-100"
                />
                <span className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent px-3 pb-2 pt-6 font-mono text-[10px] tracking-[0.16em] text-white/85">
                  {t.cap.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        </Link>
      </Reveal>
    </section>
  );
}

/* ---------------- Final CTA ---------------- */

function FinalCta() {
  const ctaRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = ctaRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => setGridEnergy(entry.isIntersecting ? 0.6 : 0.14),
      { threshold: 0.25 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <section ref={ctaRef} className="relative z-10 mx-auto max-w-7xl px-5 pb-28 pt-8 sm:px-8 md:pb-36">
      <Reveal>
        <div className="panel clip-oct relative overflow-hidden px-6 py-16 text-center sm:px-12 md:py-24">
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[var(--blue)] to-transparent"
          />
          <p className="mono-label mb-6">Season 01 — Registration open</p>
          <h2 className="display mx-auto max-w-3xl text-4xl font-bold uppercase leading-[1.02] tracking-tight sm:text-5xl md:text-6xl">
            Ready to enter <span className="text-[var(--blue)]">the quest?</span>
          </h2>
          <div className="display mt-8 space-y-1 text-base font-medium text-[var(--text-2)] sm:text-lg">
            <p>Build your skills.</p>
            <p>Challenge yourself.</p>
            <p className="text-[var(--text)]">Compete with the best.</p>
          </div>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <ButtonLink to="/login?mode=join" size="lg" className="w-full sm:w-auto">
              Join CodeQuest
            </ButtonLink>
            <ButtonLink to="/timeline" variant="ghost" size="lg" className="w-full sm:w-auto">
              View Timeline
            </ButtonLink>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

/* ---------------- Home ---------------- */

export default function Home() {
  const route = useRoute();
  const { query } = parseRoute(route);

  useEffect(() => {
    const s = query.get("s");
    if (s) {
      window.requestAnimationFrame(() => {
        document.getElementById(s)?.scrollIntoView({ behavior: prefersReducedMotion() ? "auto" : "smooth" });
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [route]);

  useEffect(() => {
    setGridEnergy(0.2);
    return () => setGridEnergy(0.14);
  }, []);

  return (
    <>
      <Hero />
      <WhatSection />
      <ProcessSection />
      <SystemSection />
      <FeaturesSection />
      <LeaderboardSection />
      <SeasonSection />
      <AboutSection />
      <FinalCta />
    </>
  );
}
