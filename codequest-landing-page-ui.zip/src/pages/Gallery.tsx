import { useEffect, useMemo, useState } from "react";
import { cn } from "../utils/cn";
import { Reveal, SectionHead } from "../components/ui";
import { CloseIcon } from "../components/icons";

type Plate = {
  id: string;
  src: string;
  alt: string;
  title: string;
  cat: "ARENA" | "GEOMETRY" | "ARTIFACTS" | "LIGHT";
  meta: string;
  wide?: boolean;
};

const plates: Plate[] = [
  {
    id: "p1",
    src: "images/gallery/arena.jpg",
    alt: "Tessellated field of charcoal octagonal tiles with a cluster glowing blue beneath",
    title: "The Field, Hall B",
    cat: "ARENA",
    meta: "Set build · Round 02 · 2026",
    wide: true,
  },
  {
    id: "p2",
    src: "images/gallery/tiles.jpg",
    alt: "Top-down view of charcoal octagonal tiles with one single blue tile",
    title: "One Blue Tile",
    cat: "GEOMETRY",
    meta: "Grid study · Plate 02",
  },
  {
    id: "p3",
    src: "images/gallery/lightboard.jpg",
    alt: "Dark indicator wall of square lamps with a diagonal wave of blue lights",
    title: "Result Board",
    cat: "LIGHT",
    meta: "Live scoring · Regional heat",
  },
  {
    id: "p4",
    src: "images/gallery/medallion.jpg",
    alt: "Macro photograph of a brushed gunmetal octagonal medallion with blue rim light",
    title: "Season 01 Medallion",
    cat: "ARTIFACTS",
    meta: "Awards · Cast gunmetal",
  },
  {
    id: "p5",
    src: "images/gallery/blueprint.jpg",
    alt: "Technical blueprint plate of octagonal tessellation geometry drawn in blue ink",
    title: "Grid Geometry Plate",
    cat: "GEOMETRY",
    meta: "Design system · Rev. C",
  },
  {
    id: "p6",
    src: "images/gallery/print.jpg",
    alt: "Fanned risograph print sheets showing blue octagon patterns on dark paper",
    title: "Campaign Prints",
    cat: "ARTIFACTS",
    meta: "Risograph · Two-colour run",
  },
];

const cats = ["ALL", "ARENA", "GEOMETRY", "ARTIFACTS", "LIGHT"] as const;

export default function Gallery() {
  const [cat, setCat] = useState<(typeof cats)[number]>("ALL");
  const [openId, setOpenId] = useState<string | null>(null);

  const visible = useMemo(
    () => (cat === "ALL" ? plates : plates.filter((p) => p.cat === cat)),
    [cat]
  );

  const openIndex = openId ? visible.findIndex((p) => p.id === openId) : -1;
  const openPlate = openIndex >= 0 ? visible[openIndex] : null;

  useEffect(() => {
    if (!openPlate) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpenId(null);
      if (e.key === "ArrowRight")
        setOpenId(visible[(openIndex + 1) % visible.length].id);
      if (e.key === "ArrowLeft")
        setOpenId(visible[(openIndex - 1 + visible.length) % visible.length].id);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [openPlate, openIndex, visible]);

  return (
    <div className="relative z-10 mx-auto max-w-7xl px-5 pb-28 pt-32 sm:px-8 md:pt-40">
      <SectionHead
        index="G1"
        label={`Field archive — ${String(plates.length).padStart(2, "0")} plates`}
        title={
          <>
            The field <span className="text-[var(--blue)]">archive.</span>
          </>
        }
      />

      <Reveal>
        <div className="mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <p className="max-w-xl text-[14.5px] leading-relaxed text-[var(--text-2)]">
            The environment behind CodeQuest — the field, the geometry, the
            artefacts of Season 01. Documented as a set of plates: each one a
            piece of the competition's visual identity.
          </p>
          {/* Filters */}
          <div className="flex flex-wrap gap-2" role="group" aria-label="Filter plates">
            {cats.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                aria-pressed={cat === c}
                className={cn(
                  "clip-oct-sm border px-3 py-1.5 font-mono text-[10.5px] tracking-[0.16em] transition-all duration-250",
                  cat === c
                    ? "border-[var(--blue)] bg-[var(--blue-strong)] text-white [filter:drop-shadow(0_0_10px_var(--glow))]"
                    : "border-[var(--border-strong)] text-[var(--text-3)] hover:border-[var(--blue)] hover:text-[var(--blue)]"
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </Reveal>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {visible.map((p, i) => (
          <Reveal key={p.id} delay={(i % 3) * 90} className={cn(p.wide && "sm:col-span-2")}>
            <button
              onClick={() => setOpenId(p.id)}
              aria-label={`Open plate: ${p.title}`}
              className="group block w-full text-left"
            >
              <div
                className={cn(
                  "clip-oct bg-[var(--border-strong)] p-px transition-colors duration-300 group-hover:bg-[var(--blue)] group-hover:[filter:drop-shadow(0_0_18px_var(--glow))]"
                )}
              >
                <div className="clip-oct overflow-hidden bg-[var(--surface)]">
                  <div className={cn("relative w-full overflow-hidden", p.wide ? "aspect-[16/9]" : "aspect-[4/3]")}>
                    <img
                      src={p.src}
                      alt={p.alt}
                      loading={i < 3 ? "eager" : "lazy"}
                      className="h-full w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.05]"
                    />
                    <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent opacity-80" />
                    <span
                      className="pointer-events-none absolute inset-0 bg-[var(--blue)] opacity-0 mix-blend-color transition-opacity duration-500 group-hover:opacity-25"
                      aria-hidden="true"
                    />
                    <span className="absolute left-4 top-4 clip-oct-sm bg-[var(--blue-strong)] px-2 py-1 font-mono text-[10px] font-bold tracking-widest text-white">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="absolute bottom-4 left-4 right-4">
                      <span className="mono-label block text-[10px] text-white/70">{p.meta}</span>
                      <span className="display mt-1 block text-base font-bold uppercase tracking-wide text-white transition-colors duration-300 group-hover:text-[#9fc9ff]">
                        {p.title}
                      </span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between px-4 py-3">
                    <span className="font-mono text-[10.5px] tracking-[0.18em] text-[var(--text-3)]">
                      {p.cat}
                    </span>
                    <span className="font-mono text-[10.5px] tracking-[0.18em] text-[var(--text-3)] transition-colors group-hover:text-[var(--blue)]">
                      View ↗
                    </span>
                  </div>
                </div>
              </div>
            </button>
          </Reveal>
        ))}
      </div>

      <Reveal delay={120}>
        <div className="mt-14 flex flex-col items-start gap-5 border-t border-[var(--border)] pt-8 sm:flex-row sm:items-center sm:justify-between">
          <p className="max-w-md text-[13.5px] leading-relaxed text-[var(--text-2)]">
            The grid behind every page reacts to you — return home and run
            your cursor across the octagons.
          </p>
          <a
            href="#/"
            className="btn-shell btn-ghost-shell btn-shell-md"
          >
            <span className="btn-core">Back to the arena</span>
          </a>
        </div>
      </Reveal>

      {/* Lightbox */}
      {openPlate && (
        <div
          className="fixed inset-0 z-[90] flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm sm:p-8"
          onClick={() => setOpenId(null)}
          role="dialog"
          aria-modal="true"
          aria-label={openPlate.title}
        >
          <div
            className="panel-in w-full max-w-5xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between gap-4">
              <div className="min-w-0">
                <p className="mono-label text-[10px] text-[var(--blue)]">
                  {openPlate.cat} — {openPlate.meta}
                </p>
                <h2 className="display mt-1 truncate text-lg font-bold uppercase tracking-tight sm:text-xl">
                  {openPlate.title}
                </h2>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <button
                  onClick={() =>
                    setOpenId(visible[(openIndex - 1 + visible.length) % visible.length].id)
                  }
                  aria-label="Previous plate"
                  className="clip-oct-sm flex h-9 w-9 items-center justify-center border border-[var(--border-strong)] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
                >
                  ←
                </button>
                <button
                  onClick={() => setOpenId(visible[(openIndex + 1) % visible.length].id)}
                  aria-label="Next plate"
                  className="clip-oct-sm flex h-9 w-9 items-center justify-center border border-[var(--border-strong)] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
                >
                  →
                </button>
                <button
                  onClick={() => setOpenId(null)}
                  aria-label="Close plate"
                  className="clip-oct-sm flex h-9 w-9 items-center justify-center border border-[var(--border-strong)] text-[var(--text-2)] transition-colors hover:border-[var(--blue)] hover:text-[var(--blue)]"
                >
                  <CloseIcon className="h-4 w-4" />
                </button>
              </div>
            </div>
            <div className="clip-oct bg-[var(--border-strong)] p-px">
              <img
                src={openPlate.src}
                alt={openPlate.alt}
                className="clip-oct max-h-[62vh] w-full bg-black object-contain"
              />
            </div>
            <div className="mt-3 flex items-center justify-between">
              <span className="font-mono text-[10.5px] tracking-wider text-[var(--text-3)]">
                {String(openIndex + 1).padStart(2, "0")} / {String(visible.length).padStart(2, "0")}
              </span>
              <span className="hidden font-mono text-[10.5px] tracking-wider text-[var(--text-3)] sm:block">
                ← / → to browse · esc to close
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
