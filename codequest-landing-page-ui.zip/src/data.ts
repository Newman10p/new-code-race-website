export type ProcessStep = { id: string; num: string; title: string; copy: string };

export const processSteps: ProcessStep[] = [
  {
    id: "register",
    num: "01",
    title: "REGISTER",
    copy: "Create your profile, link your school, and claim your seat for Season 01.",
  },
  {
    id: "prepare",
    num: "02",
    title: "PREPARE",
    copy: "Train on practice sets and sharpen the skills the rounds demand.",
  },
  {
    id: "compete",
    num: "03",
    title: "COMPETE",
    copy: "Timed rounds, real problems, ranked against the whole field.",
  },
  {
    id: "climb",
    num: "04",
    title: "CLIMB",
    copy: "Top scorers advance through qualification and regional heats.",
  },
  {
    id: "win",
    num: "05",
    title: "WIN",
    copy: "Season champions are crowned on the CodeQuest leaderboard.",
  },
];

export type Stage = {
  id: string;
  name: string;
  short: string;
  copy: string;
  chips: string[];
};

export const stages: Stage[] = [
  {
    id: "student",
    name: "Student",
    short: "STUDENT",
    copy: "Every journey starts here — a verified student profile linked to your school. One profile, every round, one clean record of your progress.",
    chips: ["Verified profile", "School linked", "Free entry"],
  },
  {
    id: "qualification",
    name: "Qualification",
    short: "QUALIFICATION",
    copy: "A timed qualifier open to every registrant. Solve under pressure — the top half lock in a spot for Round 1.",
    chips: ["90 min", "5 problems", "Top 50% advance"],
  },
  {
    id: "round1",
    name: "Round 1",
    short: "ROUND 1",
    copy: "The first ranked round of the season. A standard problem set, individual scoring, and your first real position on the leaderboard.",
    chips: ["120 min", "4 problems", "Ranked"],
  },
  {
    id: "round2",
    name: "Round 2",
    short: "ROUND 2",
    copy: "Harder problems, tighter time. Team formation opens after results — pair up and start thinking in foursomes.",
    chips: ["150 min", "3 problems", "Teams open"],
  },
  {
    id: "regionals",
    name: "Regionals",
    short: "REGIONALS",
    copy: "Regional heats between the top 25% of the field, played school against school with live regional scoreboards.",
    chips: ["Top 25%", "By region", "Live scoring"],
  },
  {
    id: "finals",
    name: "Finals",
    short: "FINALS",
    copy: "The final stage. Season champions crowned. Prizes, certificates, and a place in the CodeQuest record.",
    chips: ["Live event", "Awards", "Ceremony"],
  },
];

export type Feature = { id: string; icon: string; title: string; copy: string };

export const features: Feature[] = [
  {
    id: "live",
    icon: "timer",
    title: "Live Challenges",
    copy: "Solve coding problems under strict time constraints, live.",
  },
  {
    id: "leaderboard",
    icon: "ranks",
    title: "Leaderboards",
    copy: "Track performance and ranking as scores update in real time.",
  },
  {
    id: "languages",
    icon: "code",
    title: "Multiple Languages",
    copy: "Compete in C++, Python, Java, JavaScript and more.",
  },
  {
    id: "realtime",
    icon: "signal",
    title: "Real-Time Results",
    copy: "Watch rounds unfold as results stream in minute by minute.",
  },
  {
    id: "skill",
    icon: "growth",
    title: "Skill Development",
    copy: "Practice sets and round reviews to level up between events.",
  },
  {
    id: "fair",
    icon: "shield",
    title: "Fair Competition",
    copy: "Standardized scoring, verified participants, clear rules.",
  },
];

export type RankRow = {
  id: number;
  name: string;
  school: string;
  lastRound: number;
  points: number;
  delta: number;
};

export const initialLeaderboard: RankRow[] = [
  { id: 1, name: "Alex M.", school: "Northview Academy", lastRound: 312, points: 982, delta: 2 },
  { id: 2, name: "Sarah K.", school: "St. Xavier's School", lastRound: 301, points: 951, delta: 0 },
  { id: 3, name: "Daniel O.", school: "Horizon Public", lastRound: 288, points: 927, delta: -1 },
  { id: 4, name: "Farid B.", school: "Greenfield High", lastRound: 279, points: 904, delta: 1 },
  { id: 5, name: "Imran K.", school: "Lake City School", lastRound: 272, points: 891, delta: -2 },
  { id: 6, name: "Meera D.", school: "Northview Academy", lastRound: 265, points: 874, delta: 3 },
];

export type TimelineItem = {
  id: string;
  title: string;
  date: string;
  status: "active" | "upcoming";
  copy: string;
  chips: string[];
};

export const timelinePreview: TimelineItem[] = [
  {
    id: "reg",
    title: "Registration",
    date: "Jan 12 – Feb 02",
    status: "active",
    copy: "Open to students from all partner schools.",
    chips: ["Free entry"],
  },
  {
    id: "qual",
    title: "Qualifiers",
    date: "Feb 14",
    status: "upcoming",
    copy: "Timed online qualifier for all registrants.",
    chips: ["90 min"],
  },
  {
    id: "regional",
    title: "Regionals",
    date: "Apr 18",
    status: "upcoming",
    copy: "Regional heats, school against school.",
    chips: ["Top 25%"],
  },
  {
    id: "finals",
    title: "Finale",
    date: "May 09",
    status: "upcoming",
    copy: "The final stage and awards ceremony.",
    chips: ["Live"],
  },
];

export type FullPhase = {
  id: string;
  title: string;
  date: string;
  status: "active" | "upcoming";
  copy: string;
  chips: string[];
};

export const fullTimeline: FullPhase[] = [
  {
    id: "reg",
    title: "Registration",
    date: "Jan 12 → Feb 02, 2026",
    status: "active",
    copy: "Open to students from all partner schools. Register your profile, link your school, and claim your seat for Season 01. No entry fee, no age gate beyond school enrollment.",
    chips: ["Free entry", "Individual", "Online"],
  },
  {
    id: "qual",
    title: "Qualifiers",
    date: "Feb 14, 2026 · 15:00",
    status: "upcoming",
    copy: "A 90-minute timed qualifier open to every registrant. Five problems across difficulty bands. The top 50% of scores advance to Round 1.",
    chips: ["90 min", "5 problems", "Top 50% advance"],
  },
  {
    id: "r1",
    title: "Round 1",
    date: "Mar 07, 2026 · 15:00",
    status: "upcoming",
    copy: "The first ranked round of the season. A standard problem set with individual scoring — your first real position on the season leaderboard.",
    chips: ["120 min", "4 problems", "Ranked"],
  },
  {
    id: "r2",
    title: "Round 2",
    date: "Mar 28, 2026 · 15:00",
    status: "upcoming",
    copy: "An advanced problem set with tighter time limits. Team formation opens once results publish — top soloists start assembling foursomes.",
    chips: ["150 min", "3 problems", "Teams open"],
  },
  {
    id: "regional",
    title: "Regionals",
    date: "Apr 18, 2026 · 14:00",
    status: "upcoming",
    copy: "Regional heats between the top 25% of the qualifying field, played school against school. Live regional scoreboards run for the full duration of the round.",
    chips: ["Top 25%", "By region", "Live scoring"],
  },
  {
    id: "finals",
    title: "Finale",
    date: "May 09, 2026 · 10:00",
    status: "upcoming",
    copy: "The final stage. Season champions, team champions, and fastest-solver awards. Certificates, prizes, and the CodeQuest Season 01 record.",
    chips: ["Live event", "Awards", "Ceremony"],
  },
];

export const team = [
  { initials: "AK", name: "Ayaan K.", role: "Founder · Lead Organizer" },
  { initials: "SP", name: "Sana P.", role: "Problem Design Lead" },
  { initials: "DR", name: "Dev R.", role: "Platform & Tooling" },
  { initials: "FN", name: "Fahad N.", role: "Community & Schools" },
];

export const values = [
  {
    title: "Fairness",
    copy: "Standardized scoring, verified participants, and rules that apply to every school equally.",
  },
  {
    title: "Rigor",
    copy: "Problems written to be solved under real constraints — not memorized patterns.",
  },
  {
    title: "Community",
    copy: "Built by student developers for student developers, across every partner school.",
  },
];

export const navLinks = [
  { label: "Home", to: "/" },
  { label: "Timeline", to: "/timeline" },
  { label: "Gallery", to: "/gallery" },
  { label: "About Us", to: "/about" },
  { label: "Contact", to: "/contact" },
];
