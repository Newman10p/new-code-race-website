/**
 * THE CHALLENGE ARCHIVE — prototype content layer.
 *
 * In production this shape comes from the publishing workflow
 * (setter authors a question -> patron reviews -> published) and the student
 * page simply reads whatever is published. Nothing here is baked into the UI:
 * cards, filters, packs, missions and the workspace all render from this
 * module, so wiring a real API later means replacing this file only.
 *
 * Test expectations below were computed from the reference solutions, so the
 * client-side runner really does grade submissions rather than faking verdicts.
 */

export type Difficulty = "Beginner" | "Intermediate" | "Advanced" | "Expert";

export type QuestionStatus =
  | "NEW"
  | "NOT STARTED"
  | "IN PROGRESS"
  | "COMPLETED"
  | "ATTEMPT AGAIN";

export type QuestionTest = {
  name: string;
  args: unknown[];
  expected: unknown;
  weight: number;
  hidden?: boolean;
};

export type Question = {
  id: string;
  title: string;
  blurb: string;
  category: string;
  difficulty: Difficulty;
  languages: string[];
  points: number;
  estMinutes: number;
  publishedAt: string;
  packId: string;
  /** Languages the in-browser prototype runner can actually execute. */
  localRunner: string[];
  status: QuestionStatus;
  attempts: number;
  bestPercent?: number;
  scenario: string;
  statement: string;
  inputFormat: string;
  outputFormat: string;
  constraints: string[];
  examples: { input: string; output: string; explanation: string }[];
  hints: string[];
  requirements: string[];
  marking: string[];
  starter: Record<string, string>;
  tests: QuestionTest[];
  /** Reference solution revealed by "View Solution" once completed. */
  canonical: string;
};

export type Pack = {
  id: string;
  title: string;
  tagline: string;
  description: string;
  questionIds: string[];
  publishedBy: string;
  curatedBy: string;
  accent: string;
};

export const CATEGORIES = [
  "Algorithms",
  "Data Structures",
  "Python",
  "JavaScript",
  "Mathematics & Logic",
  "Debugging",
  "Problem Solving",
  "System Design",
];

export const DIFFICULTIES: Difficulty[] = [
  "Beginner",
  "Intermediate",
  "Advanced",
  "Expert",
];

export const difficultyXp: Record<Difficulty, string> = {
  Beginner: "10 – 15 XP",
  Intermediate: "20 – 30 XP",
  Advanced: "40 – 60 XP",
  Expert: "70 – 100 XP",
};

/* ══════════════════════ PACKS ══════════════════════ */

export const packs: Pack[] = [
  {
    id: "logic-lab",
    title: "THE LOGIC LAB",
    tagline: "Problems that challenge the way you think.",
    description:
      "A collection of algorithmic puzzles, logical reasoning tasks and practical programming challenges designed to test your ability to think beyond the obvious.",
    questionIds: [
      "missing-number",
      "perfect-match",
      "last-file-standing",
      "staircase-gambit",
      "decode-message",
    ],
    publishedBy: "Northview Academy · Patron Circle",
    curatedBy: "Setters: A. Khan, S. Pillai",
    accent: "var(--blue)",
  },
  {
    id: "structures",
    title: "STRUCTURES IN MOTION",
    tagline: "Queues, buffers and the things that never empty.",
    description:
      "Hands-on data structure work: circular buffers, eviction policies and the careful bookkeeping that keeps a system honest under load.",
    questionIds: ["infinite-queue", "library-never-sleeps", "traffic-junction"],
    publishedBy: "St. Xavier's School · Patron Circle",
    curatedBy: "Setters: D. Rahman",
    accent: "#5DD39E",
  },
  {
    id: "shortpaths",
    title: "PATHS & PRICES",
    tagline: "Find the cheapest way through a connected world.",
    description:
      "Shortest paths, spanning networks and cost models — the graph thinking that separates a working solution from an efficient one.",
    questionIds: ["delivery-route", "water-grid"],
    publishedBy: "Horizon Public · Patron Circle",
    curatedBy: "Setters: F. Nsubuga",
    accent: "#F2C94C",
  },
  {
    id: "debuggers",
    title: "THE DEBUGGER'S BENCH",
    tagline: "The code runs. The answer is wrong.",
    description:
      "Reading, reasoning and repair. Each task hands you code that looks fine and quietly isn't.",
    questionIds: ["disappearing-transactions", "event-loop-order"],
    publishedBy: "Greenfield High · Patron Circle",
    curatedBy: "Setters: community bench",
    accent: "#FF6B6B",
  },
];

/* ══════════════════════ QUESTIONS ══════════════════════ */

export const questions: Question[] = [
  {
    id: "first-duplicate",
    title: "The First Duplicate",
    blurb:
      "One array, repeated values, and no permission to allocate anything else. Find the first repeat in five minutes.",
    category: "Algorithms",
    difficulty: "Beginner",
    languages: ["python", "javascript"],
    points: 10,
    estMinutes: 5,
    publishedAt: "2026-03-01",
    packId: "logic-lab",
    localRunner: ["javascript"],
    status: "NOT STARTED",
    attempts: 0,
    scenario:
      "Today's timed opener on the main dashboard. A sensor log stream holds values already bounded by the length of the log; you must spot the first repeat while streaming past it exactly once.",
    statement:
      "Given an array `nums` of length n where every value satisfies 0 <= nums[i] < n, return the value whose second occurrence appears earliest — that is, the first duplicate you would meet while scanning left to right. Return -1 when every value is unique. You may not use a hash set, a frequency array or any other auxiliary container: solve it in-place in O(n) time and O(1) extra space by encoding visit counts inside `nums` itself.",
    inputFormat: "solve(nums) — nums is an array of integers with 0 <= nums[i] < nums.length.",
    outputFormat: "An integer: the first duplicated value, or -1.",
    constraints: [
      "1 <= nums.length <= 10^5",
      "0 <= nums[i] < nums.length",
      "At most one answer is required; ties do not occur in the test data",
    ],
    examples: [
      {
        input: "nums = [2, 1, 3, 2, 4]",
        output: "2",
        explanation: "Value 2 is seen again at index 3, before value 4 would repeat.",
      },
      { input: "nums = [1, 2, 3, 0]", output: "-1", explanation: "Every value is distinct." },
    ],
    hints: [
      "Because every value is smaller than n, you can store extra information in a slot by adding n to it.",
      "Read a slot's original value with nums[i] % n, and test how many times it was visited with nums[i] >= 2 * n.",
    ],
    requirements: [
      "Implement exactly one top-level function named solve.",
      "No Set, Map, sort or second array — the memory guard rejects them.",
      "Returning the index instead of the value fails every test.",
    ],
    marking: [
      "Visible tests 60%, hidden 40%.",
      "A hash-set solution passes the logic but fails the constraints review, so aim for the in-place encoding.",
    ],
    starter: {
      python: `def solve(nums):
    # TODO: return the first duplicated value, or -1
    pass
`,
      javascript: `function solve(nums) {
  // TODO: return the first duplicated value, or -1
}
`,
    },
    tests: [
      { name: "sample 1", args: [[2, 1, 3, 2, 4]], expected: 2, weight: 1 },
      { name: "all unique", args: [[1, 2, 3, 0]], expected: -1, weight: 1 },
      { name: "duplicate at zero", args: [[0, 0]], expected: 0, weight: 1 },
      { name: "later tie", args: [[3, 4, 3, 2, 4, 1]], expected: 3, weight: 1, hidden: true },
      { name: "long stream", args: [Array.from({ length: 50000 }, (_, i) => i % 25000)], expected: 0, weight: 2, hidden: true },
    ],
    canonical: `function solve(nums) {
  const n = nums.length;
  for (let i = 0; i < n; i++) {
    const idx = nums[i] % n;
    nums[idx] += n;
    if (nums[idx] >= 2 * n) return idx;
  }
  return -1;
}`,
  },
  {
    id: "missing-number",
    title: "The Missing Number Mystery",
    blurb:
      "A ledger lists every register from 1 to n except one. Find the gap without storing the whole list.",
    category: "Mathematics & Logic",
    difficulty: "Beginner",
    languages: ["python", "javascript"],
    points: 15,
    estMinutes: 8,
    publishedAt: "2026-02-24",
    packId: "logic-lab",
    localRunner: ["javascript"],
    status: "COMPLETED",
    attempts: 2,
    bestPercent: 100,
    scenario:
      "A register printer jammed halfway through printing roll numbers 1…n. One number is missing from the stack, and the papers arrive shuffled.",
    statement:
      "Given an array nums containing n - 1 distinct integers drawn from the range 1…n, return the single missing number. Your solution must run in O(n) time and O(1) extra space — sorting the array or keeping a set of seen values will not pass the memory limit.",
    inputFormat:
      "solve(nums, n) — nums is the array of printed roll numbers, n is the expected highest roll number.",
    outputFormat: "A single integer: the missing roll number.",
    constraints: [
      "1 <= n <= 2 * 10^5",
      "nums.length === n - 1",
      "All values are distinct and within 1…n",
    ],
    examples: [
      {
        input: "nums = [3, 7, 1, 2, 8, 4, 5], n = 8",
        output: "6",
        explanation: "The full range 1…8 is expected; 6 never got printed.",
      },
      {
        input: "nums = [1], n = 2",
        output: "2",
        explanation: "Only one number survived the jam.",
      },
    ],
    hints: [
      "The sum of 1…n is n * (n + 1) / 2 — subtract what you were given.",
      "If the total worries you, XOR every index with every value instead.",
    ],
    requirements: [
      "Implement exactly one top-level function named solve.",
      "Do not read stdin or print — return the value.",
      "The function must be pure: no globals, no mutation of nums.",
    ],
    marking: [
      "Visible tests carry 60% of the score.",
      "Hidden tests carry 40% and include the maximum-size input.",
      "Partial credit is awarded per passing test; full 15 XP requires 100%.",
    ],
    starter: {
      python: `def solve(nums, n):
    # TODO: return the missing roll number
    pass
`,
      javascript: `function solve(nums, n) {
  // TODO: return the missing roll number
}
`,
    },
    tests: [
      { name: "sample 1", args: [[3, 7, 1, 2, 8, 4, 5], 8], expected: 6, weight: 1 },
      { name: "single element", args: [[1], 2], expected: 2, weight: 1 },
      { name: "gap at the end", args: [[1, 2, 3, 4], 5], expected: 5, weight: 1 },
      {
        name: "large range",
        args: [Array.from({ length: 9999 }, (_, i) => i + 1), 10000],
        expected: 10000,
        weight: 2,
        hidden: true,
      },
    ],
    canonical: `function solve(nums, n) {
  const expected = (n * (n + 1)) / 2;
  const actual = nums.reduce((a, v) => a + v, 0);
  return expected - actual;
}`,
  },
  {
    id: "decode-message",
    title: "Decode the Hidden Message",
    blurb:
      "A club slides every letter forward before passing notes. Write the decoder before the next meeting.",
    category: "Problem Solving",
    difficulty: "Beginner",
    languages: ["python", "javascript"],
    points: 10,
    estMinutes: 6,
    publishedAt: "2026-02-20",
    packId: "logic-lab",
    localRunner: ["javascript"],
    status: "IN PROGRESS",
    attempts: 1,
    bestPercent: 55,
    scenario:
      "Your club encrypts notes by shifting every letter forward by a fixed amount. A note arrived, and only the sender knows the key — but the greeting at the start is always the same.",
    statement:
      "Given a ciphertext produced by a Caesar shift of forward positions, return the decoded plaintext. Letters wrap around the alphabet, case is preserved, and digits, punctuation and spaces pass through untouched.",
    inputFormat: "solve(cipher, shift) — cipher is a string, shift is an integer 0…25.",
    outputFormat: "The decoded string.",
    constraints: [
      "0 <= shift <= 25",
      "1 <= cipher.length <= 10^4",
      "cipher may contain upper and lower ASCII letters, digits and punctuation",
    ],
    examples: [
      {
        input: 'cipher = "Khoor", shift = 3',
        output: '"Hello"',
        explanation: "Every letter moves back three places.",
      },
      {
        input: 'cipher = "Az", shift = 1',
        output: '"Zy"',
        explanation: "Uppercase A wraps backwards to Z; lowercase z becomes y.",
      },
    ],
    hints: [
      "Work with char codes: a is 97 and A is 65.",
      "Use modulo 26 to wrap — and remember that subtracting the shift can go negative.",
    ],
    requirements: [
      "Implement exactly one top-level function named solve.",
      "Return a string; do not log anything.",
    ],
    marking: [
      "Visible tests carry 60% of the score, hidden tests 40%.",
      "Mixed-case and wrap-around cases are weighted double.",
    ],
    starter: {
      python: `def solve(cipher, shift):
    # TODO: return the decoded plaintext
    pass
`,
      javascript: `function solve(cipher, shift) {
  // TODO: return the decoded plaintext
}
`,
    },
    tests: [
      { name: "sample 1", args: ["Khoor", 3], expected: "Hello", weight: 1 },
      { name: "wrap both ends", args: ["Az", 1], expected: "Zy", weight: 2 },
      { name: "punctuation passes through", args: ["Xy, z!", 3], expected: "Uv, w!", weight: 1, hidden: true },
      { name: "zero shift", args: ["CodeQuest", 0], expected: "CodeQuest", weight: 1, hidden: true },
    ],
    canonical: `function solve(cipher, shift) {
  let out = "";
  for (const ch of cipher) {
    const code = ch.charCodeAt(0);
    if (code >= 97 && code <= 122) {
      out += String.fromCharCode(((code - 97 - shift + 26) % 26) + 97);
    } else if (code >= 65 && code <= 90) {
      out += String.fromCharCode(((code - 65 - shift + 26) % 26) + 65);
    } else {
      out += ch;
    }
  }
  return out;
}`,
  },
  {
    id: "perfect-match",
    title: "The Perfect Match Problem",
    blurb:
      "Pair every applicant with the one partner whose score completes the target. Count the perfect pairs.",
    category: "Algorithms",
    difficulty: "Intermediate",
    languages: ["python", "javascript"],
    points: 20,
    estMinutes: 12,
    publishedAt: "2026-02-26",
    packId: "logic-lab",
    localRunner: ["javascript"],
    status: "NOT STARTED",
    attempts: 0,
    scenario:
      "The mentor programme only accepts a pairing when both scores sum to exactly the compatibility target. Organisers need the number of valid pairings before sign-ups open.",
    statement:
      "Given an array of distinct integers and a target, return the number of unordered pairs (i < j) whose sum equals the target. Return -1 if no such pair exists. Aim for O(n log n) or better; a nested loop will not survive the large test.",
    inputFormat: "solve(arr, target) — arr holds distinct integers, target is an integer.",
    outputFormat: "An integer count of pairs, or -1 when there are none.",
    constraints: [
      "2 <= arr.length <= 10^5",
      "-10^9 <= arr[i], target <= 10^9",
      "All values in arr are distinct",
    ],
    examples: [
      {
        input: "arr = [1, 5, 3, 7, 9, 2], target = 10",
        output: "2",
        explanation: "Pairs: (1, 9) and (3, 7).",
      },
      {
        input: "arr = [1, 2, 3], target = 100",
        output: "-1",
        explanation: "No pair reaches the target, so return -1 rather than 0.",
      },
    ],
    hints: [
      "Sort first, then walk two pointers inward — that collapses a nested loop into one pass.",
      "When the sum is too large, only the right pointer should move.",
    ],
    requirements: [
      "Implement exactly one top-level function named solve.",
      "Return a number. Counting the same pair twice fails the hidden tests.",
    ],
    marking: [
      "Score is the weighted fraction of passing tests.",
      "The large-input test is worth 3 of 6 weight.",
    ],
    starter: {
      python: `def solve(arr, target):
    # TODO: count unordered pairs summing to target, or -1
    pass
`,
      javascript: `function solve(arr, target) {
  // TODO: count unordered pairs summing to target, or -1
}
`,
    },
    tests: [
      { name: "sample 1", args: [[1, 5, 3, 7, 9, 2], 10], expected: 2, weight: 1 },
      { name: "no pairs", args: [[1, 2, 3], 100], expected: -1, weight: 1 },
      { name: "negatives", args: [[-4, -1, 3, 7, 11], 6], expected: 1, weight: 1, hidden: true },
      {
        name: "large input",
        args: [Array.from({ length: 100000 }, (_, i) => i + 1), 100001],
        expected: 50000,
        weight: 3,
        hidden: true,
      },
    ],
    canonical: `function solve(arr, target) {
  const a = [...arr].sort((x, y) => x - y);
  let left = 0, right = a.length - 1, count = 0;
  while (left < right) {
    const sum = a[left] + a[right];
    if (sum === target) { count++; left++; right--; }
    else if (sum < target) left++;
    else right--;
  }
  return count === 0 ? -1 : count;
}`,
  },
  {
    id: "last-file-standing",
    title: "The Last File Standing",
    blurb:
      "A circle of files is deleted every k-th step until one survives. Name the survivor without simulating it.",
    category: "Data Structures",
    difficulty: "Intermediate",
    languages: ["python", "javascript"],
    points: 30,
    estMinutes: 15,
    publishedAt: "2026-02-27",
    packId: "logic-lab",
    localRunner: ["javascript"],
    status: "ATTEMPT AGAIN",
    attempts: 3,
    bestPercent: 62,
    scenario:
      "A cleanup script walks a circular folder list, deleting every k-th folder and closing the circle behind it. You must predict the survivor before running it on production data.",
    statement:
      "Files are numbered 1…n and arranged in a circle. Starting from file 1, count k files (wrapping around) and delete the k-th; continue counting from the next file. Repeat until one file remains and return its number. Because n can be large, an O(n) recurrence is expected — removing items from an array will not finish in time.",
    inputFormat: "solve(n, k) — n files numbered 1…n, eliminate every k-th.",
    outputFormat: "A single integer: the surviving file number (1-indexed).",
    constraints: [
      "1 <= n <= 10^5",
      "1 <= k <= 10^3",
      "Counting restarts from the file after each deletion",
    ],
    examples: [
      {
        input: "n = 7, k = 2",
        output: "7",
        explanation: "Deletion order 2, 4, 6, 1, 5, 3 — file 7 remains.",
      },
      {
        input: "n = 5, k = 3",
        output: "4",
        explanation: "Deletion order 3, 1, 5, 2 — file 4 remains.",
      },
    ],
    hints: [
      "This is the Josephus problem. Ask: if I know the survivor for n - 1 files, how do I map it back to n files?",
      "The recurrence is J(1) = 0 and J(n) = (J(n-1) + k) % n, then add 1 for a 1-indexed answer.",
      "Iterate upward instead of recursing to avoid blowing the call stack.",
    ],
    requirements: [
      "Implement exactly one top-level function named solve.",
      "No array mutation or linked-list simulation — the timing test rejects them.",
    ],
    marking: [
      "Recurrence tests: 50% of score.",
      "Timing test with n = 100000: 50% of score.",
    ],
    starter: {
      python: `def solve(n, k):
    # TODO: return the surviving file number (1-indexed)
    pass
`,
      javascript: `function solve(n, k) {
  // TODO: return the surviving file number (1-indexed)
}
`,
    },
    tests: [
      { name: "sample 1", args: [7, 2], expected: 7, weight: 1 },
      { name: "sample 2", args: [5, 3], expected: 4, weight: 1 },
      { name: "single file", args: [1, 5], expected: 1, weight: 1 },
      { name: "k of one", args: [9, 1], expected: 9, weight: 1, hidden: true },
      { name: "large n", args: [100000, 7], expected: 27152, weight: 2, hidden: true },
    ],
    canonical: `function solve(n, k) {
  let survivor = 0;
  for (let size = 2; size <= n; size++) {
    survivor = (survivor + k) % size;
  }
  return survivor + 1;
}`,
  },
  {
    id: "staircase-gambit",
    title: "The Staircase Gambit",
    blurb:
      "One, two or three blocks at a time — how many distinct routes reach the top of the podium?",
    category: "Python",
    difficulty: "Intermediate",
    languages: ["python", "javascript"],
    points: 25,
    estMinutes: 10,
    publishedAt: "2026-02-22",
    packId: "logic-lab",
    localRunner: ["javascript"],
    status: "NEW",
    attempts: 0,
    scenario:
      "The awards podium is stacked from n blocks. A climber may take one, two or three blocks per stride, and every distinct route counts.",
    statement:
      "Given a non-negative integer n, return the number of distinct ways to climb exactly n blocks using steps of size 1, 2 or 3. A naive recursive brute force will time out; use dynamic programming.",
    inputFormat: "solve(n) — n is the number of blocks.",
    outputFormat: "An integer count of distinct climbing routes.",
    constraints: [
      "0 <= n <= 60",
      "solve(0) is defined as 1 route (do nothing)",
      "The answer fits inside a 64-bit integer",
    ],
    examples: [
      { input: "n = 3", output: "4", explanation: "1+1+1, 1+2, 2+1, 3." },
      { input: "n = 4", output: "7", explanation: "Follows f(n) = f(n-1) + f(n-2) + f(n-3)." },
    ],
    hints: [
      "The final stride is 1, 2 or 3 blocks, so the answer is the sum of the three previous answers.",
      "You only need three rolling values; a full table is wasted memory.",
    ],
    requirements: [
      "Implement solve(n) returning a number.",
      "Iterative solutions preferred; recursion depth may exceed limits.",
    ],
    marking: [
      "Small cases 40%, the n = 0 boundary 20%, n = 60 40%.",
    ],
    starter: {
      python: `def solve(n):
    # TODO: count distinct ways to climb n blocks
    pass
`,
      javascript: `function solve(n) {
  // TODO: count distinct ways to climb n blocks
}
`,
    },
    tests: [
      { name: "n = 3", args: [3], expected: 4, weight: 1 },
      { name: "n = 4", args: [4], expected: 7, weight: 1 },
      { name: "n = 0", args: [0], expected: 1, weight: 1, hidden: true },
      { name: "n = 60", args: [60], expected: 4680045560037375, weight: 2, hidden: true },
    ],
    canonical: `function solve(n) {
  if (n <= 1) return 1;
  let a = 1, b = 1, c = 2; // f(0), f(1), f(2)
  for (let i = 3; i <= n; i++) {
    const next = a + b + c;
    a = b; b = c; c = next;
  }
  return c;
}`,
  },
  {
    id: "traffic-junction",
    title: "Traffic at the Digital Junction",
    blurb:
      "Cars queue from two roads under one light. How many green phases until the junction clears?",
    category: "Data Structures",
    difficulty: "Intermediate",
    languages: ["python", "javascript"],
    points: 25,
    estMinutes: 14,
    publishedAt: "2026-02-25",
    packId: "structures",
    localRunner: ["javascript"],
    status: "IN PROGRESS",
    attempts: 1,
    bestPercent: 40,
    scenario:
      "A smart controller serves a single junction. Each green phase serves at most capacity cars from one direction, and cars keep their arrival order.",
    statement:
      "You are given the arrival sequence of cars as an array of 0 (north road) and 1 (east road), processed strictly in order. Each phase takes up to capacity consecutive cars from the front of the queue, all from the same road. Return the minimum number of green phases needed to clear every car.",
    inputFormat: "solve(cars, capacity) — cars is an array of 0/1, capacity >= 1.",
    outputFormat: "An integer: the number of green phases.",
    constraints: [
      "0 <= cars.length <= 10^5",
      "1 <= capacity <= 100",
      "Cars cannot be reordered — the queue is FIFO",
    ],
    examples: [
      {
        input: "cars = [0, 0, 1, 1, 1, 0], capacity = 2",
        output: "4",
        explanation: "Runs of length 2, 3 and 1 give ceil(2/2) + ceil(3/2) + ceil(1/2) = 4.",
      },
      {
        input: "cars = [1, 1, 1], capacity = 3",
        output: "1",
        explanation: "A single phase clears the whole queue.",
      },
    ],
    hints: [
      "A phase never mixes directions, so each maximal run of equal values is independent.",
      "For a run of length L the cost is ceil(L / capacity).",
    ],
    requirements: [
      "Implement solve returning a number.",
      "An empty array must return 0 rather than throwing.",
    ],
    marking: ["Run-splitting tests 60%, empty and single-run edge cases 40%."],
    starter: {
      python: `def solve(cars, capacity):
    # TODO: minimum number of green phases
    pass
`,
      javascript: `function solve(cars, capacity) {
  // TODO: minimum number of green phases
}
`,
    },
    tests: [
      { name: "sample 1", args: [[0, 0, 1, 1, 1, 0], 2], expected: 4, weight: 1 },
      { name: "one phase", args: [[1, 1, 1], 3], expected: 1, weight: 1 },
      { name: "empty junction", args: [[], 2], expected: 0, weight: 1, hidden: true },
      { name: "alternating", args: [[0, 1, 0, 1, 0], 4], expected: 5, weight: 2, hidden: true },
    ],
    canonical: `function solve(cars, capacity) {
  let phases = 0, i = 0;
  while (i < cars.length) {
    let j = i;
    while (j < cars.length && cars[j] === cars[i]) j++;
    phases += Math.ceil((j - i) / capacity);
    i = j;
  }
  return phases;
}`,
  },
  {
    id: "infinite-queue",
    title: "The Infinite Queue",
    blurb:
      "A buffer that never blocks: when it fills, the oldest entry is silently dropped. Rebuild its transcript.",
    category: "Data Structures",
    difficulty: "Advanced",
    languages: ["python", "javascript", "java"],
    points: 40,
    estMinutes: 20,
    publishedAt: "2026-02-28",
    packId: "structures",
    localRunner: ["javascript"],
    status: "COMPLETED",
    attempts: 1,
    bestPercent: 100,
    scenario:
      "A telemetry ring buffer keeps only the last capacity readings. When it is full, a new push evicts the oldest value instead of failing. Auditors need the exact reply transcript for a recorded session.",
    statement:
      'Simulate the buffer over a list of operations. A ["push", v] inserts v, evicting the oldest value when full, and contributes nothing to the output. ["pop"] removes and returns the oldest value, or null when empty. ["peek"] returns the oldest value without removing it, or null when empty. Return an array of every value returned by pop and peek, in order.',
    inputFormat: 'solve(capacity, ops) — ops entries are ["push", v], ["pop"] or ["peek"].',
    outputFormat:
      "An array holding the results of pop and peek in order, using null for reads on an empty buffer.",
    constraints: [
      "1 <= capacity <= 10^3",
      "1 <= ops.length <= 10^4",
      "push values are integers",
    ],
    examples: [
      {
        input: 'capacity = 2, ops = [["push",1],["push",2],["push",3],["peek"],["pop"],["pop"],["pop"]]',
        output: "[2, 2, 3, null]",
        explanation:
          "Pushing 3 evicts 1. Peek sees 2, pop returns 2, pop returns 3, and pop on an empty buffer returns null.",
      },
    ],
    hints: [
      "Keep a head index and a size rather than shifting an array — shift() is O(n) and will time out.",
      "When pushing into a full buffer, write at the tail index and move head past the evicted slot.",
    ],
    requirements: [
      "Implement solve(capacity, ops).",
      "Use null (Python: None) for reads on an empty buffer.",
      "Pushes contribute nothing to the output array.",
    ],
    marking: [
      "Eviction order is the hard part: two hidden tests target it specifically.",
      "Full credit needs all five tests; a correct but O(n) shift solution may time out on the last.",
    ],
    starter: {
      python: `def solve(capacity, ops):
    # TODO: simulate the drop-oldest ring buffer
    pass
`,
      javascript: `function solve(capacity, ops) {
  // TODO: simulate the drop-oldest ring buffer
}
`,
      java: `class Solution {
    java.util.List<Object> solve(int capacity, java.util.List<Object[]> ops) {
        // TODO
        return null;
    }
}`,
    },
    tests: [
      {
        name: "sample 1",
        args: [2, [["push", 1], ["push", 2], ["push", 3], ["peek"], ["pop"], ["pop"], ["pop"]]],
        expected: [2, 2, 3, null],
        weight: 1,
      },
      { name: "no eviction", args: [3, [["push", 5], ["pop"], ["peek"]]], expected: [5, null], weight: 1 },
      {
        name: "overwrite in place",
        args: [2, [["push", 1], ["push", 2], ["pop"], ["push", 3], ["push", 4], ["pop"], ["pop"]]],
        expected: [1, 3, 4],
        weight: 2,
        hidden: true,
      },
      { name: "peek only", args: [1, [["peek"], ["push", 9], ["peek"], ["peek"]]], expected: [null, 9, 9], weight: 1, hidden: true },
      {
        name: "stress",
        args: [3, Array.from({ length: 9 }, (_, i) => ["push", i]).concat([["pop"], ["pop"], ["pop"], ["pop"]])],
        expected: [6, 7, 8, null],
        weight: 2,
        hidden: true,
      },
    ],
    canonical: `function solve(capacity, ops) {
  const buf = new Array(capacity);
  let head = 0, size = 0;
  const out = [];
  for (const op of ops) {
    if (op[0] === "push") {
      const tail = (head + size) % capacity;
      if (size === capacity) head = (head + 1) % capacity;
      else size++;
      buf[tail] = op[1];
    } else if (op[0] === "pop") {
      if (size === 0) { out.push(null); continue; }
      out.push(buf[head]);
      head = (head + 1) % capacity;
      size--;
    } else {
      out.push(size === 0 ? null : buf[head]);
    }
  }
  return out;
}`,
  },
  {
    id: "library-never-sleeps",
    title: "The Library That Never Sleeps",
    blurb:
      "One reading room, a fixed number of desks, and a strict rule for who gets released. Model it exactly.",
    category: "System Design",
    difficulty: "Expert",
    languages: ["python", "javascript"],
    points: 70,
    estMinutes: 35,
    publishedAt: "2026-02-28",
    packId: "structures",
    localRunner: ["javascript"],
    status: "NOT STARTED",
    attempts: 0,
    scenario:
      "A 24-hour library has k study desks. A borrower who uses a reserved desk keeps it; when a newcomer arrives and every desk is taken, the desk nobody has used for the longest time is released.",
    statement:
      'This is an LRU policy exercise in library clothing. Process operations against capacity k. ["seat", id] seats borrower id — a repeat seat only marks them most recently used and evicts nobody. ["free", id] removes a borrower when present. ["count"] returns nothing. When capacity is reached and a genuinely new borrower arrives, the least recently used borrower is evicted. Return { count, evicted } after all operations, where count is how many borrowers remain seated and evicted lists every forcibly released id in order.',
    inputFormat: 'solve(k, ops) — k is desk capacity, ops is an array of operations.',
    outputFormat: "An object { count, evicted }.",
    constraints: [
      "1 <= k <= 10^2",
      "1 <= ops.length <= 10^4",
      "borrower ids are positive integers",
      "A seat for an already-seated borrower updates recency only",
    ],
    examples: [
      {
        input: 'k = 2, ops = [["seat",1],["seat",2],["seat",1],["seat",3],["count"]]',
        output: "{ count: 2, evicted: [2] }",
        explanation: "Re-seating 1 makes 2 the least recently used, so 3 evicts 2.",
      },
    ],
    hints: [
      "A JS Map and a Python dict both preserve insertion order — deleting then re-inserting a key moves it to the back.",
      "Only evict when the key is genuinely new and capacity is already reached.",
    ],
    requirements: [
      "Implement solve(k, ops).",
      "free on an absent borrower is a no-op and must not shift recency.",
      "Return exactly the described shape — the harness compares structure, not formatting.",
    ],
    marking: [
      "Recency updates after a repeat seat: 30%.",
      "Eviction ordering across a long run: 40%.",
      "Capacity-1 and no-eviction edge cases: 30%.",
    ],
    starter: {
      python: `def solve(k, ops):
    # TODO: model the desk policy; return {"count": ..., "evicted": [...]}
    pass
`,
      javascript: `function solve(k, ops) {
  // TODO: model the desk policy; return { count, evicted }
}
`,
    },
    tests: [
      {
        name: "sample 1",
        args: [2, [["seat", 1], ["seat", 2], ["seat", 1], ["seat", 3], ["count"]]],
        expected: { count: 2, evicted: [2] },
        weight: 1,
      },
      {
        name: "free then seat",
        args: [2, [["seat", 4], ["seat", 5], ["free", 4], ["seat", 6], ["count"]]],
        expected: { count: 2, evicted: [] },
        weight: 1,
      },
      {
        name: "capacity one",
        args: [1, [["seat", 1], ["seat", 2], ["seat", 3]]],
        expected: { count: 1, evicted: [1, 2] },
        weight: 2,
        hidden: true,
      },
      {
        name: "free missing is a no-op",
        args: [2, [["seat", 1], ["free", 99], ["seat", 2], ["seat", 3]]],
        expected: { count: 2, evicted: [1] },
        weight: 1,
        hidden: true,
      },
    ],
    canonical: `function solve(k, ops) {
  const seats = new Map();
  const evicted = [];
  for (const op of ops) {
    if (op[0] === "seat") {
      const id = op[1];
      if (seats.has(id)) { seats.delete(id); seats.set(id, true); continue; }
      if (seats.size >= k) {
        const oldest = seats.keys().next().value;
        seats.delete(oldest);
        evicted.push(oldest);
      }
      seats.set(id, true);
    } else if (op[0] === "free") {
      seats.delete(op[1]);
    }
  }
  return { count: seats.size, evicted };
}`,
  },
  {
    id: "delivery-route",
    title: "The Efficient Delivery Route",
    blurb:
      "Many routes cross the city; only one is shortest. Find its cost before the drivers leave the depot.",
    category: "Algorithms",
    difficulty: "Advanced",
    languages: ["python", "javascript", "cpp"],
    points: 45,
    estMinutes: 22,
    publishedAt: "2026-02-21",
    packId: "shortpaths",
    localRunner: ["javascript"],
    status: "NOT STARTED",
    attempts: 0,
    scenario:
      "A courier depot must reach a customer across a weighted one-way road network. Fuel is billed per kilometre, so only the cheapest total distance matters.",
    statement:
      "Given a directed weighted graph as an adjacency list and two nodes, return the length of the shortest path from start to end. Return -1 when the destination is unreachable. Edge weights are non-negative, so Dijkstra applies.",
    inputFormat: "solve(adj, start, end) — adj[i] is an array of [neighbour, weight] pairs; nodes are 0-indexed.",
    outputFormat: "An integer total weight, or -1.",
    constraints: [
      "1 <= number of nodes <= 10^3",
      "0 <= weight <= 10^4",
      "The graph may be disconnected and may contain self loops",
    ],
    examples: [
      {
        input: "adj = [[[1,4],[2,1]], [[3,1]], [[1,2],[3,5]], []], start = 0, end = 3",
        output: "4",
        explanation: "0 → 2 (1), 2 → 1 (2), 1 → 3 (1) totals 4 — cheaper than the direct 0 → 1 → 3 which costs 5.",
      },
      {
        input: "adj = [[], []], start = 0, end = 1",
        output: "-1",
        explanation: "No route exists, so return -1.",
      },
    ],
    hints: [
      "Always relax edges through the unvisited node with the smallest tentative distance.",
      "A heap is not strictly required at n = 1000 — a linear scan passes, but practise the heap version for the finals.",
    ],
    requirements: [
      "Implement solve(adj, start, end).",
      "Do not mutate adj.",
      "Return -1 for unreachable targets, never Infinity or null.",
    ],
    marking: [
      "Basic shortest path 40%, unreachable case 20%, zero-weight edges 20%, self loops 20%.",
    ],
    starter: {
      python: `def solve(adj, start, end):
    # TODO: shortest distance from start to end, or -1
    pass
`,
      javascript: `function solve(adj, start, end) {
  // TODO: shortest distance from start to end, or -1
}
`,
      cpp: `#include <vector>
long solve(std::vector<std::vector<std::pair<int,int>>>& adj, int start, int end) {
    // TODO
    return -1;
}`,
    },
    tests: [
      { name: "sample", args: [[[[1, 4], [2, 1]], [[3, 1]], [[1, 2], [3, 5]], []], 0, 3], expected: 4, weight: 1 },
      { name: "unreachable", args: [[[], []], 0, 1], expected: -1, weight: 1 },
      {
        name: "self loop ignored",
        args: [[[[0, 7], [1, 3]], []], 0, 1],
        expected: 3,
        weight: 1,
        hidden: true,
      },
      {
        name: "zero weight edges",
        args: [[[[1, 0], [2, 5]], [[2, 0]], []], 0, 2],
        expected: 0,
        weight: 2,
        hidden: true,
      },
    ],
    canonical: `function solve(adj, start, end) {
  const n = adj.length;
  const dist = new Array(n).fill(Infinity);
  const seen = new Array(n).fill(false);
  dist[start] = 0;
  for (let iter = 0; iter < n; iter++) {
    let u = -1, best = Infinity;
    for (let i = 0; i < n; i++) {
      if (!seen[i] && dist[i] < best) { best = dist[i]; u = i; }
    }
    if (u === -1) break;
    seen[u] = true;
    for (const [v, w] of adj[u]) {
      if (dist[u] + w < dist[v]) dist[v] = dist[u] + w;
    }
  }
  return dist[end] === Infinity ? -1 : dist[end];
}`,
  },
  {
    id: "water-grid",
    title: "The Smart Water Distribution Problem",
    blurb:
      "Every plot must receive water and pipe is expensive. Lay the cheapest network that still connects them.",
    category: "System Design",
    difficulty: "Expert",
    languages: ["python", "javascript"],
    points: 80,
    estMinutes: 30,
    publishedAt: "2026-02-19",
    packId: "shortpaths",
    localRunner: ["javascript"],
    status: "NEW",
    attempts: 0,
    scenario:
      "A housing cooperative must pipe water from one reservoir to every plot. The budget is fixed, so the total length of laid pipe must be minimal while keeping every plot connected.",
    statement:
      "Given a list of undirected weighted edges over n plots, return the total weight of a minimum spanning tree. If the plots cannot all be connected, return -1. Use Kruskal with union-find, or Prim.",
    inputFormat: "solve(n, edges) — edges is an array of [u, v, weight].",
    outputFormat: "An integer total weight, or -1 if the graph is disconnected.",
    constraints: [
      "1 <= n <= 10^3",
      "0 <= weight <= 10^4",
      "Parallel edges and self loops are allowed",
    ],
    examples: [
      {
        input: "n = 4, edges = [[0,1,5],[1,2,3],[0,2,4],[2,3,6],[1,3,7]]",
        output: "13",
        explanation: "Take 1-2 (3), 0-2 (4) and 2-3 (6). Edge 0-1 (5) would close a cycle.",
      },
      { input: "n = 1, edges = []", output: "0", explanation: "A single plot needs no pipe at all.", },
    ],
    hints: [
      "Sort edges by weight and union plots that are not yet connected; stop after n - 1 accepted edges.",
      "If you accepted fewer than n - 1 edges, the network was disconnected.",
      "Path compression keeps find() near constant time.",
    ],
    requirements: [
      "Implement solve(n, edges).",
      "n = 1 needs zero pipes and must return 0.",
    ],
    marking: [
      "MST correctness 60%, disconnected detection 20%, n = 1 and parallel edges 20%.",
    ],
    starter: {
      python: `def solve(n, edges):
    # TODO: minimum spanning tree weight, or -1
    pass
`,
      javascript: `function solve(n, edges) {
  // TODO: minimum spanning tree weight, or -1
}
`,
    },
    tests: [
      { name: "sample", args: [4, [[0, 1, 5], [1, 2, 3], [0, 2, 4], [2, 3, 6], [1, 3, 7]]], expected: 13, weight: 1 },
      { name: "single plot", args: [1, []], expected: 0, weight: 1 },
      { name: "disconnected", args: [4, [[0, 1, 2], [2, 3, 3]]], expected: -1, weight: 1, hidden: true },
      { name: "parallel edges", args: [3, [[0, 1, 9], [0, 1, 2], [1, 2, 4], [0, 2, 20]]], expected: 6, weight: 2, hidden: true },
    ],
    canonical: `function solve(n, edges) {
  const parent = Array.from({ length: n }, (_, i) => i);
  const rank = new Array(n).fill(0);
  const find = (x) => {
    while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; }
    return x;
  };
  let total = 0, used = 0;
  for (const [u, v, w] of [...edges].sort((a, b) => a[2] - b[2])) {
    const ru = find(u), rv = find(v);
    if (ru === rv) continue;
    if (rank[ru] < rank[rv]) parent[ru] = rv;
    else if (rank[ru] > rank[rv]) parent[rv] = ru;
    else { parent[rv] = ru; rank[ru]++; }
    total += w;
    if (++used === n - 1) break;
  }
  return used === n - 1 ? total : -1;
}`,
  },
  {
    id: "disappearing-transactions",
    title: "The Disappearing Transactions",
    blurb:
      "The reconciler balances on paper and loses cents in production. Find the leak.",
    category: "Debugging",
    difficulty: "Intermediate",
    languages: ["python", "javascript"],
    points: 20,
    estMinutes: 12,
    publishedAt: "2026-02-23",
    packId: "debuggers",
    localRunner: ["javascript"],
    status: "ATTEMPT AGAIN",
    attempts: 2,
    bestPercent: 75,
    scenario:
      "A finance club shipped a reconciler that sums deposits and refunds. On demo data it printed 0.00. Overnight it printed 0.00000000000000004 and an auditor asked questions.",
    statement:
      "The starter code below is already written for you — and it is buggy. Fix solve(entries) so it returns the correct final balance of a list of signed amounts, as a number equal to the exact 2-decimal result. The bug is not in the arithmetic you would expect; it is in how the amounts are represented.",
    inputFormat: "solve(entries) — an array of signed numbers, each with at most 2 decimal places.",
    outputFormat: "A number: the exact balance to 2 decimal places.",
    constraints: [
      "0 <= entries.length <= 10^5",
      "-10^6 <= entries[i] <= 10^6",
      "Every entry has at most 2 decimal places",
    ],
    examples: [
      {
        input: "[100.10, 200.20, -300.30]",
        output: "0",
        explanation: "Perfectly balanced — the shipped version returns 5.68e-14.",
      },
      {
        input: "[0.1, 0.2]",
        output: "0.3",
        explanation: "The classic binary float drift: a naive sum gives 0.30000000000000004.",
      },
    ],
    hints: [
      "Binary floating point cannot represent 0.1 exactly.",
      "Accumulate in integer cents with Math.round(amount * 100), then divide once at the very end.",
    ],
    requirements: [
      "Keep the function name solve and its signature.",
      "Return a number, not a string.",
      "No decimal or exact-arithmetic library — the point is the reasoning.",
    ],
    marking: [
      "Every hidden test checks exact equality, so the rounding strategy matters more than speed.",
      "The shipped starter passes nothing: one balanced-looking sum happens to be exact, so the suite deliberately includes a drift case.",
    ],
    starter: {
      javascript: `// This reconciler shipped last week and it is losing cents.
function solve(entries) {
  let balance = 0;
  for (const amount of entries) {
    balance = balance + amount;
  }
  return balance;
}
`,
      python: `# This reconciler shipped last week and it is losing cents.
def solve(entries):
    balance = 0
    for amount in entries:
        balance = balance + amount
    return round(balance, 6)
`,
    },
    tests: [
      { name: "cents drift", args: [[100.1, 200.2, -300.31]], expected: -0.01, weight: 1 },
      { name: "classic drift", args: [[0.1, 0.2]], expected: 0.3, weight: 1 },
      { name: "empty day", args: [[]], expected: 0, weight: 1, hidden: true },
      {
        name: "many refunds",
        args: [Array.from({ length: 3000 }, () => 0.01).concat([-29.99])],
        expected: 0.01,
        weight: 2,
        hidden: true,
      },
    ],
    canonical: `function solve(entries) {
  const cents = entries.reduce(
    (total, amount) => total + Math.round(amount * 100), 0);
  return cents / 100;
}`,
  },
  {
    id: "event-loop-order",
    title: "The Order Things Actually Happen",
    blurb: "Five log calls, three queues. Return the exact order the runtime prints them.",
    category: "JavaScript",
    difficulty: "Advanced",
    languages: ["javascript"],
    points: 50,
    estMinutes: 15,
    publishedAt: "2026-02-26",
    packId: "debuggers",
    localRunner: ["javascript"],
    status: "NOT STARTED",
    attempts: 0,
    scenario:
      "Interviewers love this diagram and half the room gets it wrong. The event loop does not care what the room believes.",
    statement:
      "Return the exact print order produced by the snippet below, as an array of labels. Think in terms of the call stack, then the microtask queue, then the macrotask queue.\n\n  console.log('A');\n  setTimeout(() => console.log('B'), 0);\n  Promise.resolve().then(() => console.log('C'));\n  queueMicrotask(() => console.log('D'));\n  console.log('E');\n\nReturn only the labels for the queued work — B, C and D — in execution order.",
    inputFormat: "solve() — takes no arguments.",
    outputFormat: "An array of three strings: the labels of the queued callbacks in runtime order.",
    constraints: [
      "Microtasks drain completely before the next macrotask.",
      "Promise callbacks and queueMicrotask share one queue, FIFO.",
    ],
    examples: [
      {
        input: "solve()",
        output: '["C", "D", "B"]',
        explanation:
          "C and D are microtasks queued during the same tick in registration order; B is a timer, a macrotask, so it runs after the microtask queue empties.",
      },
    ],
    hints: [
      "Synchronous code first, then drain every microtask, then take exactly one macrotask.",
      "Both the promise callback and queueMicrotask land in the microtask queue, registered first running first.",
    ],
    requirements: [
      "Implement solve() with no parameters.",
      "Return an array of strings, not a joined string.",
    ],
    marking: ["One deterministic test at full weight — this is a precision question, not a search."],
    starter: {
      javascript: `function solve() {
  // TODO: return the three queued labels in execution order
}
`,
    },
    tests: [{ name: "exact order", args: [], expected: ["C", "D", "B"], weight: 1 }],
    canonical: `function solve() {
  return ["C", "D", "B"];
}`,
  },
];

/* ══════════════════ PATRON-CONFIGURED GOALS ══════════════════ */

export type MissionConfig = {
  id: string;
  label: string;
  target: number;
  progress: number;
  bonusXp: number;
  source: string;
  window: string;
};

/** Fetched from patron goal configuration — not hardcoded in the UI. */
export const missionConfig: MissionConfig = {
  id: "season-01-weekly",
  label: "Complete 10 practice challenges this week",
  target: 10,
  progress: 6,
  bonusXp: 50,
  source: "Patron goal set · Season 01",
  window: "Resets Monday 00:00 UTC",
};

export type Achievement = {
  id: string;
  name: string;
  detail: string;
  state: "earned" | "progress" | "locked";
  percent?: number;
};

export const achievements: Achievement[] = [
  { id: "streak", name: "7 DAY STREAK", detail: "Practised every day this week", state: "earned" },
  { id: "century", name: "100 PROBLEMS", detail: "One hundred accepted solutions", state: "earned" },
  { id: "top10", name: "TOP 10 SCHOOL", detail: "Held inside Northview's top 10", state: "earned" },
  { id: "polyglot", name: "PYTHON BUILDER", detail: "Fifteen accepted Python solutions", state: "earned" },
  { id: "hard", name: "HARD MODE", detail: "Accept three Advanced questions", state: "progress", percent: 66 },
  { id: "finalist", name: "FINALIST", detail: "Reach the Season 01 finals", state: "locked" },
];

export const archiveStats = {
  solved: 126,
  practiceXp: 2480,
  successRate: 84,
  streakDays: 7,
};

export const packById = (id: string) => packs.find((p) => p.id === id);

export const questionById = (id: string) => questions.find((q) => q.id === id);
