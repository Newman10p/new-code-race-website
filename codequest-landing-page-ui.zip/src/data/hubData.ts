/**
 * STUDENT HUB — prototype content layer.
 *
 * Mirrors the core entities the real backend will own: profiles, follows,
 * groups, conversations, DM requests, messages, posts, comments, communities,
 * battles and notifications.
 *
 * PROTOTYPE LIMIT: everything is local state. No realtime delivery, presence,
 * server scoring or uploads leave the browser. The Hub UI labels this.
 */

export type Student = {
  id: string;
  name: string;
  handle: string;
  school: string;
  initials: string;
  color: string;
  bio: string;
  interests: string[];
  languages: string[];
  online: boolean;
  achievements: string[];
  projects: string[];
  communityIds: string[];
};

export type Attachment =
  | { kind: "code"; language: string; code: string; title: string }
  | { kind: "file"; name: string; size: number }
  | { kind: "link"; url: string; title: string }
  | { kind: "image"; label: string; tone: string };

export type Message = {
  id: string;
  fromId: string;
  text: string;
  at: string;
  reactions: { emoji: string; by: string[] }[];
  replyTo?: string;
  attachment?: Attachment;
  edited?: boolean;
  deleted?: boolean;
  status?: "sending" | "sent" | "failed";
};

export type Conversation = {
  id: string;
  type: "group" | "direct";
  name: string;
  description?: string;
  color: string;
  initials: string;
  memberIds: string[];
  ownerId?: string;
  adminIds?: string[];
  participantIds?: string[]; // direct
  pinned: boolean;
  muted: boolean;
  unread: number;
  messages: Message[];
  pinnedMessages: string[];
  createdAt: string;
  invite?: { code: string; expiresAt: string; revoked: boolean };
};

export type DMRequest = {
  id: string;
  fromId: string;
  toId: string;
  initialMessage: string;
  at: string;
  status: "pending" | "accepted" | "declined" | "blocked";
};

export type Comment = {
  id: string;
  authorId: string;
  text: string;
  at: string;
  likes: string[];
  reported?: boolean;
  deleted?: boolean;
  replies: Comment[];
};

export type Post = {
  id: string;
  authorId: string;
  text: string;
  at: string;
  communityId?: string;
  category: "Programming" | "Projects" | "Competitions" | "Questions" | "Tutorials" | "Achievements" | "General Discussion" | "Resources";
  audience: "public" | "community" | "draft";
  snippet?: { language: string; code: string; title: string };
  link?: { url: string; title: string };
  poll?: { question: string; options: { label: string; votes: string[] }[] };
  art?: { label: string; tone: string; kind: "code" | "grid" | "chart" };
  likes: string[];
  reposts: string[];
  bookmarks: string[];
  comments: Comment[];
  hidden?: boolean;
  edited?: boolean;
};

export type Community = {
  id: string;
  name: string;
  description: string;
  category: string;
  initials: string;
  color: string;
  members: string[];
  moderators: string[];
  ownerId: string;
  visibility: "open" | "approval" | "private";
  membership: "none" | "pending" | "joined" | "invited" | "banned";
  rules: string[];
  announcements: { id: string; text: string; at: string; authorId: string }[];
  resources: { id: string; title: string; kind: string }[];
  activity: string;
  pinnedPostIds: string[];
};

export type Battle = {
  id: string;
  title: string;
  description: string;
  creatorId: string;
  language: string;
  difficulty: "Easy" | "Medium" | "Hard";
  durationMinutes: number;
  maxPlayers: number;
  questionCount: number;
  startsAt: string;
  status: "open" | "waiting" | "starting-soon" | "live" | "completed" | "cancelled";
  access: "open" | "friends" | "invite";
  participants: { studentId: string; ready: boolean; score?: number; time?: string }[];
  scoring: string[];
  results?: { rank: number; studentId: string; score: number; time: string }[];
};

export type HubNotification = {
  id: string;
  type: string;
  title: string;
  message: string;
  at: string;
  unread: boolean;
  icon: "message" | "request" | "post" | "community" | "battle" | "mention";
  target: string;
};

export const ME = "stu-farid";
const ago = (h: number) => new Date(Date.now() - h * 3600_000).toISOString();
const ahead = (m: number) => new Date(Date.now() + m * 60_000).toISOString();

export const students: Student[] = [
  { id: ME, name: "Farid Bulega", handle: "@faridb", school: "Northview Academy", initials: "FB", color: "#4D9CFF", bio: "Grade 11 · Python, graphs, and system design. Building things that survive the 07:45 traffic spike.", interests: ["Competitive programming", "System design", "Open source"], languages: ["Python", "JavaScript", "C++"], online: true, achievements: ["7 Day Flame Streak", "100 Problems", "Top 10 School"], projects: ["School Management Platform", "Ticket Locker"], communityIds: ["com-python", "com-competitive", "com-sysdesign"] },
  { id: "stu-sarah", name: "Sarah K.", handle: "@sarahk", school: "St. Xavier's School", initials: "SK", color: "#AA8CFF", bio: "Rank #2 · I like proving why an algorithm works, not just that it does.", interests: ["Algorithms", "Math"], languages: ["Python", "C++"], online: true, achievements: ["Season 01 Finalist"], projects: ["Graph Visualiser"], communityIds: ["com-python", "com-competitive"] },
  { id: "stu-daniel", name: "Daniel O.", handle: "@danielo", school: "Horizon Public", initials: "DO", color: "#5DD39E", bio: "Debugging is just detective work with better tooling.", interests: ["Web development", "DevOps"], languages: ["JavaScript", "TypeScript", "Go"], online: true, achievements: ["Bug Hunter"], projects: ["Event Loop Explorer"], communityIds: ["com-js", "com-web"] },
  { id: "stu-meera", name: "Meera D.", handle: "@meerad", school: "Northview Academy", initials: "MD", color: "#F2C94C", bio: "Frontend, accessibility, and making interfaces that feel obvious.", interests: ["UI engineering", "Accessibility"], languages: ["JavaScript", "TypeScript"], online: false, achievements: ["Design Sprint Winner"], projects: ["Responsive Nav Kit"], communityIds: ["com-web", "com-beginners"] },
  { id: "stu-imran", name: "Imran K.", handle: "@imrank", school: "Lake City School", initials: "IK", color: "#FF9F6B", bio: "AI prompting and automation experiments. Currently teaching a bot to write better questions.", interests: ["AI", "Automation"], languages: ["Python"], online: true, achievements: ["Prompt Engineer"], projects: ["Study Plan Generator"], communityIds: ["com-ai", "com-python"] },
  { id: "stu-alex", name: "Alex M.", handle: "@alexm", school: "Greenfield High", initials: "AM", color: "#5DD3C5", bio: "Rank #1 · Data structures, slow explanations, fast code.", interests: ["DSA", "Teaching"], languages: ["C++", "Python"], online: false, achievements: ["Season 01 Champion"], projects: ["Heap Lab"], communityIds: ["com-competitive"] },
  { id: "stu-aisha", name: "Ms. Aisha Nakato", handle: "@patron.aisha", school: "Northview Academy", initials: "AN", color: "#AA8CFF", bio: "ICT Patron · Northview Academy. Here for course questions and competition logistics.", interests: ["Teaching", "Curriculum"], languages: ["Python"], online: true, achievements: ["Verified Patron"], projects: [], communityIds: ["com-beginners", "com-python"] },
];

export const studentById = (id: string) => students.find((s) => s.id === id);

export const seedConversations: Conversation[] = [
  {
    id: "conv-python", type: "group", name: "#python-mastery", description: "Python tips, recursion patterns and complexity tricks", color: "#5DD39E", initials: "PY",
    memberIds: [ME, "stu-sarah", "stu-daniel", "stu-imran", "stu-aisha"], ownerId: "stu-aisha", adminIds: ["stu-sarah"], pinned: true, muted: false, unread: 3,
    createdAt: ago(720), pinnedMessages: ["msg-p1"],
    invite: { code: "PY-7K2Q", expiresAt: ahead(60 * 24 * 3), revoked: false },
    messages: [
      { id: "msg-p1", fromId: "stu-aisha", text: "Welcome! Keep questions specific and share what you already tried. Code snippets are encouraged.", at: ago(50), reactions: [{ emoji: "⬡", by: [ME, "stu-sarah"] }] },
      { id: "msg-p2", fromId: "stu-sarah", text: "Anyone have a clean way to explain 0-1 BFS? I keep losing people at the deque.", at: ago(3.2), reactions: [] },
      { id: "msg-p3", fromId: "stu-daniel", text: "Use a deque and push to the front for zero-weight edges, back for weight-1. The deque stays sorted by distance.", at: ago(3), reactions: [{ emoji: "🔥", by: [ME, "stu-sarah", "stu-imran"] }],
        attachment: { kind: "code", language: "python", title: "0-1 BFS skeleton", code: "from collections import deque\n\ndef zero_one_bfs(adj, src):\n    dist = [float('inf')] * len(adj)\n    dist[src] = 0\n    dq = deque([src])\n    while dq:\n        u = dq.popleft()\n        for v, w in adj[u]:\n            if dist[u] + w < dist[v]:\n                dist[v] = dist[u] + w\n                (dq.appendleft if w == 0 else dq.append)(v)\n    return dist" } },
      { id: "msg-p4", fromId: "stu-imran", text: "^ this. The invariant is that the deque is ordered by tentative distance — that's the whole proof.", at: ago(2.6), reactions: [] },
      { id: "msg-p5", fromId: "stu-sarah", text: "That phrasing helps. @faridb does the archive have a good problem for this?", at: ago(1.1), reactions: [], replyTo: "msg-p4" },
    ],
  },
  {
    id: "conv-season", type: "group", name: "#season-01-prep", description: "Official Season 01 preparation & scrimmage teams", color: "#4D9CFF", initials: "S1",
    memberIds: [ME, "stu-sarah", "stu-alex", "stu-meera", "stu-aisha"], ownerId: "stu-aisha", adminIds: [], pinned: true, muted: false, unread: 2,
    createdAt: ago(500), pinnedMessages: [], invite: { code: "S1-9B4X", expiresAt: ahead(60 * 24 * 7), revoked: false },
    messages: [
      { id: "msg-s1", fromId: "stu-alex", text: "Round 1 has a graph problem — worth revising Dijkstra and DSU this week.", at: ago(6), reactions: [{ emoji: "⬡", by: [ME] }] },
      { id: "msg-s2", fromId: "stu-meera", text: "I made a checklist of the four scoring rules. Sharing it here.", at: ago(5), reactions: [], attachment: { kind: "file", name: "round1-checklist.pdf", size: 420_000 } },
      { id: "msg-s3", fromId: "stu-sarah", text: "Scrimmage Saturday 15:00? We can do a 3-problem set.", at: ago(1.5), reactions: [{ emoji: "🔥", by: [ME, "stu-alex"] }] },
    ],
  },
  {
    id: "conv-sysdesign", type: "group", name: "#system-design", description: "Architecture diagrams, API contracts, database design", color: "#AA8CFF", initials: "SD",
    memberIds: [ME, "stu-daniel", "stu-aisha", "stu-alex"], ownerId: "stu-daniel", adminIds: [], pinned: false, muted: true, unread: 0,
    createdAt: ago(900), pinnedMessages: [], messages: [
      { id: "msg-sd1", fromId: "stu-daniel", text: "For the attendance spike, acknowledge fast and process steady. A queue is the whole answer.", at: ago(20), reactions: [] },
      { id: "msg-sd2", fromId: ME, text: "I added a cache for the parent read path — review in Submissions when you have a minute.", at: ago(18), reactions: [] },
    ],
  },
  {
    id: "conv-dm-sarah", type: "direct", name: "Sarah K.", color: "#AA8CFF", initials: "SK", memberIds: [ME, "stu-sarah"], participantIds: [ME, "stu-sarah"], pinned: false, muted: false, unread: 1,
    createdAt: ago(200), pinnedMessages: [], messages: [
      { id: "msg-d1", fromId: "stu-sarah", text: "Hey! Your BFS explanation in the group was really clear.", at: ago(30), reactions: [] },
      { id: "msg-d2", fromId: ME, text: "Thanks — I'm writing it up as a practice pack next week.", at: ago(29), reactions: [] },
      { id: "msg-d3", fromId: "stu-sarah", text: "Want to pair on a graph problem before the sprint?", at: ago(0.6), reactions: [] },
    ],
  },
  {
    id: "conv-dm-daniel", type: "direct", name: "Daniel O.", color: "#5DD39E", initials: "DO", memberIds: [ME, "stu-daniel"], participantIds: [ME, "stu-daniel"], pinned: false, muted: false, unread: 0,
    createdAt: ago(400), pinnedMessages: [], messages: [
      { id: "msg-dd1", fromId: "stu-daniel", text: "Sent you the event-loop notes.", at: ago(72), reactions: [] },
      { id: "msg-dd2", fromId: ME, text: "Got them, cheers.", at: ago(70), reactions: [] },
    ],
  },
];

export const seedRequests: DMRequest[] = [
  { id: "req-1", fromId: "stu-imran", toId: ME, initialMessage: "Hey Farid, can I ask about your prompt evaluation exercise?", at: ago(4), status: "pending" },
  { id: "req-2", fromId: "stu-meera", toId: ME, initialMessage: "Would love your feedback on the responsive nav repo!", at: ago(26), status: "pending" },
  { id: "req-3", fromId: ME, toId: "stu-alex", initialMessage: "Hi Alex — could you review my DSA revision plan?", at: ago(50), status: "pending" },
];

export const seedPosts: Post[] = [
  {
    id: "post-1", authorId: "stu-sarah", at: ago(2), category: "Programming", audience: "public", communityId: "com-python",
    text: "A small realisation that made Dijkstra click: the priority queue isn't sorting the graph, it's repeatedly answering 'which unsettled node is closest right now?'. Everything else is bookkeeping.",
    snippet: { language: "python", title: "The relaxation step", code: "for v, w in adj[u]:\n    if dist[u] + w < dist[v]:\n        dist[v] = dist[u] + w\n        heapq.heappush(pq, (dist[v], v))" },
    likes: ["stu-daniel", "stu-imran", "stu-meera", "stu-alex", ME], reposts: ["stu-imran"], bookmarks: ["stu-meera"],
    comments: [
      { id: "c1", authorId: ME, text: "This framing is going straight into my revision notes. The invariant is the part people skip.", at: ago(1.5), likes: ["stu-sarah"], replies: [{ id: "c1r1", authorId: "stu-sarah", text: "Exactly — invariants make the proof short.", at: ago(1.2), likes: [], replies: [] }] },
      { id: "c2", authorId: "stu-imran", text: "Does the same intuition carry to A*?", at: ago(0.8), likes: [], replies: [] },
    ],
  },
  {
    id: "post-2", authorId: ME, at: ago(8), category: "Projects", audience: "public", communityId: "com-sysdesign",
    text: "Shipped v2 of my School Management Platform design: attendance writes are queued, results reads are cached, and data is partitioned per school. Patron feedback directly shaped it.",
    art: { label: "SCHOOL PORTAL · ARCHITECTURE V2", tone: "#4D9CFF", kind: "grid" },
    link: { url: "#/dashboard/user/submissions", title: "View project in Submissions" },
    likes: ["stu-aisha", "stu-daniel", "stu-sarah"], reposts: [], bookmarks: ["stu-imran"],
    comments: [{ id: "c3", authorId: "stu-daniel", text: "What happens when the queue consumer goes down mid-spike?", at: ago(6), likes: [ME], replies: [{ id: "c3r1", authorId: ME, text: "That's the next revision — adding a dead-letter path with backoff.", at: ago(5.5), likes: [], replies: [] }] }],
  },
  {
    id: "post-3", authorId: "stu-alex", at: ago(12), category: "Competitions", audience: "public",
    text: "Season 01 Round 1 prep: if you can explain why a greedy choice is safe, you can usually solve the problem. If you can't, you're guessing. Here's the three-question checklist I use before committing to greedy.",
    art: { label: "GREEDY CHECKLIST · 3 QUESTIONS", tone: "#F2C94C", kind: "chart" },
    likes: ["stu-sarah", ME, "stu-meera", "stu-imran", "stu-daniel"], reposts: ["ME", "stu-sarah"], bookmarks: [ME],
    comments: [{ id: "c4", authorId: "stu-meera", text: "Saving this for Saturday's scrimmage.", at: ago(10), likes: [], replies: [] }],
  },
  {
    id: "post-4", authorId: "stu-imran", at: ago(20), category: "Questions", audience: "public", communityId: "com-ai",
    text: "Is it better to put constraints at the start of a prompt or the end? I keep getting long intros even when I say 'be concise'.",
    poll: { question: "Where do you put your strongest constraint?", options: [{ label: "First line", votes: ["stu-sarah", "stu-daniel"] }, { label: "Last line", votes: [ME] }, { label: "Both", votes: ["stu-aisha", "stu-meera"] }] },
    likes: ["stu-aisha", "stu-meera"], reposts: [], bookmarks: [],
    comments: [{ id: "c5", authorId: "stu-aisha", text: "Try both: state it up front and end with the exact output shape. Models follow the most recent instruction too.", at: ago(18), likes: [ME, "stu-imran"], replies: [] }],
  },
  {
    id: "post-5", authorId: "stu-meera", at: ago(30), category: "Tutorials", audience: "public", communityId: "com-web",
    text: "A responsive nav without a single media query: flex wrap plus one container query. Six lines of CSS, works down to 320px.",
    snippet: { language: "css", title: "Container-query nav", code: ".nav {\n  display: flex;\n  flex-wrap: wrap;\n  gap: .75rem;\n}\n@container (max-width: 30rem) {\n  .nav { justify-content: center; }\n}" },
    art: { label: "RESPONSIVE NAV · 320PX → DESKTOP", tone: "#AA8CFF", kind: "code" },
    likes: ["stu-daniel", ME, "stu-sarah"], reposts: ["stu-daniel"], bookmarks: [ME], comments: [],
  },
  {
    id: "post-6", authorId: "stu-aisha", at: ago(48), category: "Achievements", audience: "public", communityId: "com-beginners",
    text: "Congratulations to everyone who completed the Computer Fundamentals course this week. Certificates are in the Academy — well earned.",
    likes: [ME, "stu-meera", "stu-imran", "stu-daniel", "stu-sarah", "stu-alex"], reposts: [], bookmarks: [], comments: [],
  },
];

export const seedCommunities: Community[] = [
  { id: "com-python", name: "Python Developers", description: "Idiomatic Python, standard library deep dives and clean competition solutions.", category: "Programming", initials: "PY", color: "#5DD39E", members: [ME, "stu-sarah", "stu-imran", "stu-aisha", "stu-alex"], moderators: ["stu-sarah"], ownerId: "stu-aisha", visibility: "open", membership: "joined", rules: ["Share working code, not screenshots", "Explain your approach", "No spoilers for live rounds"], announcements: [{ id: "ann1", text: "Weekly problem review: Friday 16:00 in #python-mastery.", at: ago(20), authorId: "stu-aisha" }], resources: [{ id: "r1", title: "Python cheat sheet", kind: "pdf" }, { id: "r2", title: "Sliding window templates", kind: "snippet" }], activity: "Very active", pinnedPostIds: ["post-1"] },
  { id: "com-competitive", name: "Competitive Programmers", description: "Season prep, scrimmages, complexity analysis and honest post-round reviews.", category: "Competitions", initials: "CP", color: "#F2C94C", members: [ME, "stu-sarah", "stu-alex", "stu-meera"], moderators: ["stu-alex"], ownerId: "stu-alex", visibility: "open", membership: "joined", rules: ["Never share live-round solutions", "Respect all schools", "Post problem sources"], announcements: [{ id: "ann2", text: "Scrimmage Saturday 15:00 — 3 problems, 90 minutes.", at: ago(4), authorId: "stu-alex" }], resources: [{ id: "r3", title: "Graph algorithm map", kind: "diagram" }], activity: "Very active", pinnedPostIds: ["post-3"] },
  { id: "com-sysdesign", name: "System Design", description: "Architecture trade-offs, diagram reviews and the Showdown prep channel.", category: "System Design", initials: "SD", color: "#AA8CFF", members: [ME, "stu-daniel", "stu-aisha"], moderators: ["stu-daniel"], ownerId: "stu-daniel", visibility: "approval", membership: "joined", rules: ["State the constraint before the technology", "Both sides of every trade-off"], announcements: [], resources: [{ id: "r4", title: "ADR template", kind: "doc" }], activity: "Active", pinnedPostIds: ["post-2"] },
  { id: "com-web", name: "Web Development", description: "Frontend craft, accessibility and small interfaces that feel obvious.", category: "Web Development", initials: "WD", color: "#5DD3C5", members: ["stu-daniel", "stu-meera"], moderators: ["stu-meera"], ownerId: "stu-meera", visibility: "open", membership: "none", rules: ["Include a live example where possible", "Accessibility is part of the review"], announcements: [], resources: [], activity: "Active", pinnedPostIds: ["post-5"] },
  { id: "com-ai", name: "AI & Machine Learning", description: "Prompt engineering, model literacy and automation experiments.", category: "AI & Automation", initials: "AI", color: "#FF9F6B", members: ["stu-imran", "stu-aisha"], moderators: ["stu-imran"], ownerId: "stu-imran", visibility: "open", membership: "none", rules: ["Label illustrative outputs as illustrative", "No API keys in shared code"], announcements: [{ id: "ann3", text: "Prompt clinic: bring one weak prompt, leave with a template.", at: ago(30), authorId: "stu-imran" }], resources: [], activity: "Growing", pinnedPostIds: ["post-4"] },
  { id: "com-beginners", name: "Beginner Coders", description: "A patient space for first programs, first bugs and first pull requests.", category: "Learning", initials: "BC", color: "#4D9CFF", members: ["stu-aisha", "stu-meera", ME], moderators: ["stu-aisha"], ownerId: "stu-aisha", visibility: "open", membership: "joined", rules: ["No question is too basic", "Explain without jargon first"], announcements: [], resources: [{ id: "r5", title: "First-program checklist", kind: "doc" }], activity: "Active", pinnedPostIds: [] },
  { id: "com-js", name: "JavaScript Builders", description: "Event loops, DOM patterns and modern JavaScript tooling.", category: "Programming", initials: "JS", color: "#F2C94C", members: ["stu-daniel", "stu-meera"], moderators: ["stu-daniel"], ownerId: "stu-daniel", visibility: "private", membership: "none", rules: ["Invite only"], announcements: [], resources: [], activity: "Quiet", pinnedPostIds: [] },
];

export const seedBattles: Battle[] = [
  { id: "battle-1", title: "Friday Graph Sprint", description: "Three graph problems, 45 minutes. Friendly scrimmage before the qualifier.", creatorId: "stu-sarah", language: "Python", difficulty: "Medium", durationMinutes: 45, maxPlayers: 8, questionCount: 3, startsAt: ahead(18), status: "waiting", access: "open", participants: [{ studentId: "stu-sarah", ready: true }, { studentId: ME, ready: true }, { studentId: "stu-imran", ready: false }], scoring: ["Correctness per test", "Test-case completion", "Completion time as tie-breaker"] },
  { id: "battle-2", title: "Arrays & Two Pointers Blitz", description: "A quick 20-minute warm-up. Beginner friendly.", creatorId: "stu-alex", language: "Any", difficulty: "Easy", durationMinutes: 20, maxPlayers: 12, questionCount: 4, startsAt: ahead(95), status: "open", access: "open", participants: [{ studentId: "stu-alex", ready: true }, { studentId: "stu-meera", ready: false }], scoring: ["Correctness", "Time as tie-breaker"] },
  { id: "battle-3", title: "Invocation: Debugging Duel", description: "Invite-only debugging battle for the study group.", creatorId: "stu-daniel", language: "JavaScript", difficulty: "Hard", durationMinutes: 30, maxPlayers: 4, questionCount: 2, startsAt: ahead(240), status: "open", access: "invite", participants: [{ studentId: "stu-daniel", ready: true }], scoring: ["Correctness", "Fewest runs"] },
  { id: "battle-4", title: "DP Ladder: Week 4", description: "Completed ladder with four dynamic programming problems.", creatorId: "stu-imran", language: "Python", difficulty: "Medium", durationMinutes: 40, maxPlayers: 6, questionCount: 4, startsAt: ago(96), status: "completed", access: "open", participants: [{ studentId: "stu-sarah", ready: true, score: 380, time: "31m 12s" }, { studentId: ME, ready: true, score: 365, time: "33m 40s" }, { studentId: "stu-imran", ready: true, score: 340, time: "36m 05s" }], scoring: ["Correctness", "Time as tie-breaker"], results: [{ rank: 1, studentId: "stu-sarah", score: 380, time: "31m 12s" }, { rank: 2, studentId: ME, score: 365, time: "33m 40s" }, { rank: 3, studentId: "stu-imran", score: 340, time: "36m 05s" }] },
];

export const seedNotifications: HubNotification[] = [
  { id: "hn1", type: "group", title: "Sarah K. mentioned you", message: "In #python-mastery — 'does the archive have a good problem for this?'", at: ago(1.1), unread: true, icon: "mention", target: "chats" },
  { id: "hn2", type: "request", title: "New message request", message: "Imran K. wants to start a private conversation.", at: ago(4), unread: true, icon: "request", target: "requests" },
  { id: "hn3", type: "battle", title: "Battle starting soon", message: "Friday Graph Sprint starts in 18 minutes.", at: ago(0.3), unread: true, icon: "battle", target: "battles" },
  { id: "hn4", type: "post", title: "New comment on your project", message: "Daniel O. replied to School Management Platform v2.", at: ago(6), unread: true, icon: "post", target: "posts" },
  { id: "hn5", type: "community", title: "Community announcement", message: "Scrimmage Saturday 15:00 in Competitive Programmers.", at: ago(4), unread: false, icon: "community", target: "communities" },
];

export const initialFollowing = ["stu-sarah", "stu-daniel", "stu-aisha"];

export const HUB_CATEGORIES: Post["category"][] = ["Programming", "Projects", "Competitions", "Questions", "Tutorials", "Achievements", "General Discussion", "Resources"];

export const timeAgo = (iso: string) => {
  const h = (Date.now() - new Date(iso).getTime()) / 3600_000;
  if (h < 1 / 60) return "now";
  if (h < 1) return `${Math.max(1, Math.floor(h * 60))}m`;
  if (h < 24) return `${Math.floor(h)}h`;
  return `${Math.floor(h / 24)}d`;
};

export const clockTime = (iso: string) =>
  new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit" }).format(new Date(iso));

export const dateShort = (iso: string) =>
  new Intl.DateTimeFormat(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(iso));
