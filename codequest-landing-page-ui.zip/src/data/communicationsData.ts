import { competitionsData } from "./dashboardData";

export type Source = "developer" | "patron" | "platform" | "hub" | "competition" | "submission" | "learning" | "practice" | "achievement";
export type Priority = "normal" | "important" | "urgent" | "critical";
export type Entity = { type: string; id: string; tab: string };
export type AnnouncementRecord = {
  id: string; title: string; content: string[]; source_type: "developer" | "patron";
  author_id: string; author_name: string; category: string; priority: Priority;
  published_at: string; updated_at: string; attachments: { label: string; url: string }[];
  related_entity?: Entity; is_pinned: boolean; status: "published";
};
export type NotificationRecord = {
  id: string; student_id: string; type: string; source_type: Source; title: string;
  message: string; created_at: string; is_read: boolean; read_at: string | null;
  is_archived: boolean; is_pinned: boolean; action_url: string; related_entity?: Entity;
  group_id?: string; priority: Priority; deleted?: boolean; sender?: string;
};
export type FeatureRecord = {
  id: string; title: string; kind: "New feature" | "Improvement" | "Bug fix" | "Interface update" | "Coming soon";
  version: string; released_at: string; description: string; changes: string[]; benefit: string;
  targetTab?: string; is_read: boolean; is_pinned: boolean;
};
export type ReminderRecord = {
  id: string; student_id: string; title: string; description: string;
  category: "Competition" | "Submission Deadline" | "Learning" | "Practice" | "Personal" | "Other";
  scheduled_at: string; timezone: string; reminder_offsets: number[];
  recurrence_rule: "none" | "daily" | "weekly"; related_entity?: Entity;
  status: "upcoming" | "completed"; created_at: string; origin: "personal" | "automatic";
  method: "in-app" | "email" | "browser";
};

const ago = (hours: number) => new Date(Date.now() - hours * 3600_000).toISOString();
const ahead = (hours: number) => new Date(Date.now() + hours * 3600_000).toISOString();
export const studentId = "CQ-2026-904";

export const seedAnnouncements: AnnouncementRecord[] = [
  { id: "a1", title: "Round 1 preparation brief is ready", source_type: "patron", author_id: "northview-ict", author_name: "Northview Academy · ICT Club", category: "Competition", priority: "important", published_at: ago(2), updated_at: ago(2), is_pinned: true, status: "published", related_entity: { type: "competition", id: "season-01-r1", tab: "competitions" }, attachments: [{ label: "Preparation guide", url: "#/dashboard/user/competitions" }], content: ["Students registered for Season 01 Round 1 should complete the practice set and verify their coding environment before the event.", "The ICT Club will host a short preparation session in the Student Hub. Review the competition rules and reach out to your patron with any access questions."] },
  { id: "a2", title: "A better Code Lab is now available", source_type: "developer", author_id: "cq-systems", author_name: "CodeQuest Systems", category: "Platform update", priority: "normal", published_at: ago(6), updated_at: ago(6), is_pinned: false, status: "published", related_entity: { type: "feature", id: "f1", tab: "practice" }, attachments: [], content: ["The Code Lab now supports editable project files, a resizable preview and a focused editor experience.", "Start with a Web, React or Python starter project. The lab is a free space to experiment; it is separate from ranked competition submissions."] },
  { id: "a3", title: "Account security maintenance window", source_type: "developer", author_id: "cq-systems", author_name: "CodeQuest Systems", category: "Security", priority: "critical", published_at: ago(22), updated_at: ago(21), is_pinned: true, status: "published", attachments: [], content: ["A scheduled security update will refresh student sessions during the maintenance window. Save work before signing out.", "Critical account notices remain available even when non-essential notification categories are muted. No student work is removed by this update."] },
  { id: "a4", title: "Weekend algorithm study circle", source_type: "patron", author_id: "northview-ict", author_name: "Northview Academy · ICT Club", category: "School activity", priority: "normal", published_at: ago(48), updated_at: ago(48), is_pinned: false, status: "published", related_entity: { type: "hub", id: "season-01-prep", tab: "hub" }, attachments: [], content: ["Join the school study group this weekend for a guided walkthrough of graph traversal and debugging patterns.", "Bring a question you have struggled with. This is an informal study circle, not a graded session."] },
];

export const seedNotifications: NotificationRecord[] = [
  { id: "n1", student_id: studentId, type: "competition", source_type: "competition", title: "Your Round 1 seat is confirmed", message: "You're registered for Season 01 Round 1. Review the rules before the start time.", created_at: ago(0.4), is_read: false, read_at: null, is_archived: false, is_pinned: false, action_url: "#/dashboard/user/competitions", related_entity: { type: "competition", id: "season-01-r1", tab: "competitions" }, priority: "important" },
  { id: "n2", student_id: studentId, type: "submission", source_type: "submission", title: "System design submission received", message: "Your School Management Platform architecture was received. Jury review is pending.", created_at: ago(2), is_read: false, read_at: null, is_archived: false, is_pinned: false, action_url: "#/dashboard/user/submissions", related_entity: { type: "submission", id: "SUB-8492", tab: "submissions" }, priority: "normal" },
  { id: "n3", student_id: studentId, type: "mention", source_type: "hub", sender: "Sarah K.", title: "Sarah K. mentioned you", message: "In your discussion about Python automation: 'Could you share your approach to the queue problem?'", created_at: ago(3), is_read: false, read_at: null, is_archived: false, is_pinned: false, action_url: "#/dashboard/user/hub", related_entity: { type: "discussion", id: "python", tab: "hub" }, priority: "normal" },
  { id: "n4", student_id: studentId, type: "reply", source_type: "hub", sender: "Daniel O.", title: "3 new replies in Python Mastery", message: "Daniel O. and two others replied to your graph traversal thread.", created_at: ago(4), is_read: false, read_at: null, is_archived: false, is_pinned: false, action_url: "#/dashboard/user/hub", related_entity: { type: "discussion", id: "python", tab: "hub" }, group_id: "python-replies", priority: "normal" },
  { id: "n5", student_id: studentId, type: "achievement", source_type: "achievement", title: "7-Day Flame Streak unlocked", message: "You earned a streak achievement and 120 XP. Keep your momentum going.", created_at: ago(6), is_read: false, read_at: null, is_archived: false, is_pinned: false, action_url: "#/dashboard/user/profile", related_entity: { type: "achievement", id: "streak", tab: "profile" }, priority: "normal" },
  { id: "n6", student_id: studentId, type: "practice", source_type: "practice", title: "The Logic Lab is open", message: "A patron has published new logic problems in the Challenge Archive.", created_at: ago(10), is_read: false, read_at: null, is_archived: false, is_pinned: false, action_url: "#/dashboard/user/daily-practice", related_entity: { type: "pack", id: "logic-lab", tab: "daily-practice" }, priority: "normal" },
  { id: "n7", student_id: studentId, type: "learning", source_type: "learning", title: "Your next Python lesson is ready", message: "Continue Functions & Scope in Python Fundamentals.", created_at: ago(26), is_read: true, read_at: ago(23), is_archived: false, is_pinned: false, action_url: "#/dashboard/user/courses", related_entity: { type: "course", id: "py-fundamentals", tab: "courses" }, priority: "normal" },
  { id: "n8", student_id: studentId, type: "competition", source_type: "competition", title: "Weekly sprint results published", message: "Review your placement and compare approaches with your school peers.", created_at: ago(50), is_read: true, read_at: ago(45), is_archived: false, is_pinned: true, action_url: "#/dashboard/user/competitions", related_entity: { type: "competition", id: "weekly-sprint-06", tab: "competitions" }, priority: "normal" },
];

export const seedFeatures: FeatureRecord[] = [
  { id: "f1", title: "Resizable Code Lab workspace", kind: "New feature", version: "v2.4", released_at: ago(6), description: "Adjust your editor, explorer and preview panels to match the way you build.", changes: ["Independent panel resizing", "Project file tabs and autosave", "Responsive preview sizes"], benefit: "More space for the part of your project you're working on.", targetTab: "practice", is_read: false, is_pinned: false },
  { id: "f2", title: "Challenge Archive discovery", kind: "Improvement", version: "v2.3", released_at: ago(36), description: "Find patron-published questions by topic, difficulty, status and points.", changes: ["Pack filters and search", "Weighted test feedback", "Recent attempts timeline"], benefit: "Spend less time searching and more time solving.", targetTab: "daily-practice", is_read: false, is_pinned: false },
  { id: "f3", title: "More reliable round countdowns", kind: "Bug fix", version: "v2.2.1", released_at: ago(84), description: "Countdown displays now use the scheduled round time more consistently.", changes: ["Timezone-aware time labels", "Improved status handling at round start"], benefit: "Know exactly when it's time to enter the arena.", targetTab: "competitions", is_read: true, is_pinned: false },
  { id: "f4", title: "Compact student navigation", kind: "Interface update", version: "v2.2", released_at: ago(160), description: "The student navigation takes less space on smaller screens.", changes: ["Compact rail", "More legible active states", "Mobile bottom navigation"], benefit: "Keep the current task in view on every screen.", is_read: true, is_pinned: false },
  { id: "f5", title: "Visual learning diagrams", kind: "Coming soon", version: "Roadmap", released_at: ago(180), description: "A richer way to explore algorithms in the tutor workspace.", changes: ["Step-by-step visual concepts", "Interactive code walkthroughs"], benefit: "See complex ideas take shape, not just read about them.", targetTab: "ai-tutor", is_read: true, is_pinned: false },
];

export const seedPersonalReminders: ReminderRecord[] = [
  { id: "r1", student_id: studentId, title: "Finish the Logic Lab pack", description: "Solve the remaining two questions before study group.", category: "Practice", scheduled_at: ahead(7), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, reminder_offsets: [30], recurrence_rule: "none", status: "upcoming", created_at: ago(24), origin: "personal", method: "in-app" },
  { id: "r2", student_id: studentId, title: "Revise Python data structures", description: "Queues and heaps before the next sprint.", category: "Learning", scheduled_at: ahead(28), timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, reminder_offsets: [60], recurrence_rule: "weekly", status: "upcoming", created_at: ago(48), origin: "personal", method: "in-app" },
];

/** Derived from enrolled competitions. Changing the source date changes these reminders. */
export function deriveAutomaticReminders(): ReminderRecord[] {
  return competitionsData.filter((c) => c.registered && c.startsInDays > 0).map((c) => ({
    id: `auto-${c.id}`, student_id: studentId, title: c.name,
    description: `Your seat is confirmed. ${c.problemsCount} problems · ${c.duration}.`,
    category: "Competition" as const,
    scheduled_at: ahead(c.startsInDays * 24),
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    reminder_offsets: [1440, 60], recurrence_rule: "none" as const,
    status: "upcoming" as const, created_at: ago(1), origin: "automatic" as const,
    method: "in-app" as const, related_entity: { type: "competition", id: c.id, tab: "competitions" },
  }));
}

export const timeLabel = (iso: string) => {
  const delta = Date.now() - new Date(iso).getTime();
  if (delta < 0) return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(new Date(iso));
  if (delta < 3600_000) return `${Math.max(1, Math.floor(delta / 60_000))}m ago`;
  if (delta < 24 * 3600_000) return `${Math.floor(delta / 3600_000)}h ago`;
  return `${Math.floor(delta / (24 * 3600_000))}d ago`;
};