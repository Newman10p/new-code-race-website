export type EnvironmentType = "web" | "react" | "python";

export type ProjectFile = {
  id: string;
  name: string;
  path: string;
  content: string;
  language: "html" | "css" | "javascript" | "jsx" | "python" | "markdown" | "json";
  isReadonly?: boolean;
};

export type CodeLabProject = {
  id: string;
  name: string;
  environment: EnvironmentType;
  updatedAt: string;
  files: ProjectFile[];
  activeFileId: string;
  openTabs: string[];
};

export const WEB_STARTER_FILES: ProjectFile[] = [
  {
    id: "html-index",
    name: "index.html",
    path: "index.html",
    language: "html",
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My CodeQuest Project</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="app-card">
    <div class="badge">CODEQUEST LAB</div>
    <h1 id="title">Hello, CodeQuest!</h1>
    <p>Your ideas. Your code. Your environment.</p>

    <div class="counter-box">
      <button id="dec-btn" class="btn">-</button>
      <span id="counter">0</span>
      <button id="inc-btn" class="btn">+</button>
    </div>

    <div class="status-box">
      <span class="dot"></span>
      <span id="log-text">Ready to run</span>
    </div>
  </div>

  <script src="script.js"></script>
</body>
</html>`,
  },
  {
    id: "css-style",
    name: "style.css",
    path: "style.css",
    language: "css",
    content: `* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background-color: #080A0D;
  color: #F3F5F7;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: 1.5rem;
}

.app-card {
  background: #12161C;
  border: 1px solid #242B34;
  padding: 2rem;
  max-width: 420px;
  width: 100%;
  text-align: center;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
  clip-path: polygon(
    10px 0, calc(100% - 10px) 0,
    100% 10px, 100% calc(100% - 10px),
    calc(100% - 10px) 100%, 10px 100%,
    0 calc(100% - 10px), 0 10px
  );
}

.badge {
  display: inline-block;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.15em;
  color: #4D9CFF;
  background: rgba(77, 156, 255, 0.1);
  padding: 4px 10px;
  margin-bottom: 1rem;
}

h1 {
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
  color: #F3F5F7;
}

p {
  color: #929BA8;
  font-size: 0.875rem;
  margin-bottom: 1.5rem;
}

.counter-box {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1.25rem;
  margin: 1.5rem 0;
}

.btn {
  background: #181E26;
  color: #F3F5F7;
  border: 1px solid #242B34;
  width: 42px;
  height: 42px;
  font-size: 1.25rem;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn:hover {
  background: #4D9CFF;
  border-color: #4D9CFF;
  color: #080A0D;
}

#counter {
  font-size: 2rem;
  font-weight: 800;
  font-family: monospace;
  color: #4D9CFF;
  min-width: 50px;
}

.status-box {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-size: 12px;
  font-family: monospace;
  color: #929BA8;
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid #242B34;
}

.dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #5DD39E;
  display: inline-block;
}`,
  },
  {
    id: "js-script",
    name: "script.js",
    path: "script.js",
    language: "javascript",
    content: `// CodeQuest Web Playground Runtime
console.log("Welcome to CodeQuest Code Lab!");

let count = 0;
const counterEl = document.getElementById("counter");
const incBtn = document.getElementById("inc-btn");
const decBtn = document.getElementById("dec-btn");
const logText = document.getElementById("log-text");

function updateDisplay() {
  counterEl.textContent = count;
  logText.textContent = \`Counter updated: \${count}\`;
  console.log(\`[State] count = \${count}\`);
}

incBtn.addEventListener("click", () => {
  count++;
  updateDisplay();
});

decBtn.addEventListener("click", () => {
  count--;
  updateDisplay();
});

console.log("Event listeners attached successfully.");`,
  },
  {
    id: "md-readme",
    name: "README.md",
    path: "README.md",
    language: "markdown",
    content: `# Web Playground
A free sandbox to experiment with HTML5, CSS3, and modern JavaScript.

- Edit **index.html** to customize markup.
- Tweak **style.css** for visual styles.
- Write logic in **script.js**.
- Press **Run Code** (Ctrl+Enter) to update the preview!`,
  },
];

export const REACT_STARTER_FILES: ProjectFile[] = [
  {
    id: "react-app",
    name: "App.jsx",
    path: "src/App.jsx",
    language: "jsx",
    content: `import React, { useState } from "react";

export default function App() {
  const [count, setCount] = useState(0);
  const [todos, setTodos] = useState([
    { id: 1, text: "Build something remarkable", done: true },
    { id: 2, text: "Master dynamic programming", done: false },
    { id: 3, text: "Compete in Season 01", done: false },
  ]);
  const [inputVal, setInputVal] = useState("");

  const addTodo = (e) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    setTodos([...todos, { id: Date.now(), text: inputVal.trim(), done: false }]);
    setInputVal("");
    console.log("Added new task:", inputVal.trim());
  };

  const toggleTodo = (id) => {
    setTodos(todos.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  return (
    <div className="react-container">
      <div className="header-badge">CODEQUEST REACT STUDIO</div>
      <h1>Interactive React App</h1>
      <p className="subtitle">Real component rendering with live state.</p>

      <div className="counter-card">
        <p className="metric-label">CLICK COUNTER</p>
        <div className="counter-row">
          <button onClick={() => setCount(c => c - 1)} className="btn">-</button>
          <span className="count-display">{count}</span>
          <button onClick={() => setCount(c => c + 1)} className="btn">+</button>
        </div>
      </div>

      <div className="todo-section">
        <h3>Season 01 Sprint Goals</h3>
        <form onSubmit={addTodo} className="input-row">
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder="Add new goal..."
            className="text-input"
          />
          <button type="submit" className="add-btn">Add</button>
        </form>

        <ul className="todo-list">
          {todos.map(t => (
            <li key={t.id} onClick={() => toggleTodo(t.id)} className={t.done ? "done" : ""}>
              <span className="checkbox">{t.done ? "✓" : "○"}</span>
              <span>{t.text}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}`,
  },
  {
    id: "react-styles",
    name: "styles.css",
    path: "src/styles.css",
    language: "css",
    content: `* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background: #080A0D;
  color: #F3F5F7;
  padding: 1.5rem;
  display: flex;
  justify-content: center;
}

.react-container {
  max-width: 480px;
  width: 100%;
  background: #12161C;
  border: 1px solid #242B34;
  padding: 1.75rem;
}

.header-badge {
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.15em;
  color: #4D9CFF;
  margin-bottom: 0.5rem;
}

h1 {
  font-size: 1.5rem;
  margin-bottom: 0.25rem;
}

.subtitle {
  color: #929BA8;
  font-size: 0.85rem;
  margin-bottom: 1.5rem;
}

.counter-card {
  background: #181E26;
  border: 1px solid #242B34;
  padding: 1rem;
  margin-bottom: 1.5rem;
  text-align: center;
}

.metric-label {
  font-size: 10px;
  color: #929BA8;
  letter-spacing: 0.1em;
  font-weight: 600;
}

.counter-row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-top: 0.5rem;
}

.btn {
  background: #242B34;
  border: 1px solid #374151;
  color: #F3F5F7;
  width: 36px;
  height: 36px;
  font-size: 1.25rem;
  cursor: pointer;
}

.btn:hover {
  background: #4D9CFF;
  color: #080A0D;
}

.count-display {
  font-size: 1.75rem;
  font-weight: 700;
  color: #4D9CFF;
  font-family: monospace;
  min-width: 40px;
}

.todo-section h3 {
  font-size: 0.95rem;
  margin-bottom: 0.75rem;
}

.input-row {
  display: flex;
  gap: 8px;
  margin-bottom: 1rem;
}

.text-input {
  flex: 1;
  background: #181E26;
  border: 1px solid #242B34;
  color: #F3F5F7;
  padding: 8px 12px;
  font-size: 13px;
  outline: none;
}

.text-input:focus {
  border-color: #4D9CFF;
}

.add-btn {
  background: #4D9CFF;
  color: #080A0D;
  border: none;
  padding: 0 16px;
  font-weight: 600;
  cursor: pointer;
}

.todo-list {
  list-style: none;
}

.todo-list li {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px;
  border-bottom: 1px solid #242B34;
  cursor: pointer;
  font-size: 13px;
}

.todo-list li.done {
  color: #68717D;
  text-decoration: line-through;
}

.checkbox {
  color: #4D9CFF;
  font-family: monospace;
}`,
  },
  {
    id: "react-main",
    name: "main.jsx",
    path: "src/main.jsx",
    language: "jsx",
    content: `import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./styles.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`,
  },
  {
    id: "react-readme",
    name: "README.md",
    path: "README.md",
    language: "markdown",
    content: `# React Studio
Create interactive UI components using React and JSX.
State and hooks re-render automatically upon execution.`,
  },
];

export const PYTHON_STARTER_FILES: ProjectFile[] = [
  {
    id: "py-main",
    name: "main.py",
    path: "main.py",
    language: "python",
    content: `# CodeQuest Python Lab
# Explore algorithms, functions, and standard I/O

from utils import calculate_stats, banner

banner("CODEQUEST PYTHON LAB")

def fibonacci_sequence(n):
    """Generate the first n numbers in the Fibonacci sequence."""
    seq = [0, 1]
    for _ in range(2, n):
        seq.append(seq[-1] + seq[-2])
    return seq[:n]

print("Calculating Fibonacci numbers...")
fib_10 = fibonacci_sequence(10)
print(f"Fibonacci (first 10): {fib_10}")

numbers = [42, 17, 88, 93, 25, 64, 31]
stats = calculate_stats(numbers)

print(f"Dataset: {numbers}")
print(f"Min: {stats['min']}, Max: {stats['max']}, Mean: {stats['mean']:.2f}")

# Example interactive check
name = "Developer"
print(f"\\nExecution successful. Ready for testing, {name}!")`,
  },
  {
    id: "py-utils",
    name: "utils.py",
    path: "utils.py",
    language: "python",
    content: `"""Helper utilities for Python Lab."""

def calculate_stats(values):
    """Compute summary statistics for a list of numbers."""
    if not values:
        return {"min": None, "max": None, "mean": 0, "sum": 0}
    return {
        "min": min(values),
        "max": max(values),
        "sum": sum(values),
        "mean": sum(values) / len(values),
        "count": len(values)
    }

def banner(title):
    width = 40
    print("=" * width)
    print(f"  {title}")
    print("=" * width)`,
  },
  {
    id: "py-readme",
    name: "README.md",
    path: "README.md",
    language: "markdown",
    content: `# Python Lab
Write and execute Python programs in-browser with instantaneous stdout and tracebacks.

- Edit **main.py** and helper modules.
- Use \`print()\` for output.
- Press **Run Code** (Ctrl+Enter) to execute!`,
  },
];

/* ══════════════════ SNIPPETS LIBRARY ══════════════════ */

export type CodeSnippet = {
  id: string;
  title: string;
  category: "HTML" | "CSS" | "JavaScript" | "React" | "Python";
  description: string;
  code: string;
};

export const CODE_SNIPPETS: CodeSnippet[] = [
  {
    id: "html-boiler",
    title: "HTML5 Boilerplate",
    category: "HTML",
    description: "Standard document structure with viewport and meta tags",
    code: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <h1>Hello World</h1>
</body>
</html>`,
  },
  {
    id: "css-flex-center",
    title: "CSS Flexbox Centering",
    category: "CSS",
    description: "Perfect horizontal and vertical centering",
    code: `.center-container {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
}`,
  },
  {
    id: "css-grid-auto",
    title: "CSS Responsive Grid",
    category: "CSS",
    description: "Autofit responsive cards grid without media queries",
    code: `.grid-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.5rem;
}`,
  },
  {
    id: "js-fetch-async",
    title: "Async Fetch Request",
    category: "JavaScript",
    description: "Fetch API with try/catch error handling",
    code: `async function fetchData(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(\`HTTP \${res.status}\`);
    const data = await res.json();
    return data;
  } catch (err) {
    console.error("Fetch failed:", err);
  }
}`,
  },
  {
    id: "js-array-methods",
    title: "Array Transform Pipeline",
    category: "JavaScript",
    description: "Chaining filter, map, and reduce",
    code: `const numbers = [1, 2, 3, 4, 5, 6];
const sumOfSquaresOfEvens = numbers
  .filter(n => n % 2 === 0)
  .map(n => n * n)
  .reduce((acc, val) => acc + val, 0);

console.log(sumOfSquaresOfEvens);`,
  },
  {
    id: "react-state-hook",
    title: "React State & Effect Hook",
    category: "React",
    description: "Component with useState and useEffect timers",
    code: `import React, { useState, useEffect } from "react";

export function Timer() {
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setSeconds(s => s + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return <p>Elapsed: {seconds}s</p>;
}`,
  },
  {
    id: "py-comprehension",
    title: "List Comprehension with Filter",
    category: "Python",
    description: "Pythonic filtering and transformation",
    code: `# Square of even numbers
numbers = range(1, 20)
even_squares = [x**2 for x in numbers if x % 2 == 0]
print(even_squares)`,
  },
  {
    id: "py-class-model",
    title: "Python Class with Methods",
    category: "Python",
    description: "Object-oriented class template",
    code: `class Competitor:
    def __init__(self, username, school, xp=0):
        self.username = username
        self.school = school
        self.xp = xp

    def add_points(self, points):
        self.xp += points
        print(f"{self.username} earned +{points} XP! Total: {self.xp}")

    def __repr__(self):
        return f"<Competitor {self.username} ({self.school}) - {self.xp} XP>"`,
  },
];

/* ══════════════════ PLAYGROUND EXPERIMENT IDEAS ══════════════════ */

export type LabChallenge = {
  id: string;
  title: string;
  env: EnvironmentType;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  description: string;
  specs: string[];
};

export const LAB_CHALLENGES: LabChallenge[] = [
  {
    id: "digital-clock",
    title: "Digital Neon Clock",
    env: "web",
    difficulty: "Beginner",
    description: "Build a live ticking clock that shows hours, minutes, seconds and AM/PM format.",
    specs: [
      "Use JavaScript's setInterval to update time every 1000ms",
      "Format single-digit numbers with leading zeros (e.g. 09:05:03)",
      "Style with a dark background and CodeQuest electric blue typography",
    ],
  },
  {
    id: "password-gen",
    title: "Random Password Generator",
    env: "web",
    difficulty: "Intermediate",
    description: "Generate cryptographically secure passwords with customizable length and symbol sets.",
    specs: [
      "Checkboxes for uppercase, lowercase, numbers, and special symbols",
      "Slider for length from 8 to 32 characters",
      "Copy-to-clipboard button with visual feedback",
    ],
  },
  {
    id: "python-guessing",
    title: "Number Guessing Game",
    env: "python",
    difficulty: "Beginner",
    description: "Write an interactive terminal game where the computer picks a random integer 1-100.",
    specs: [
      "Track number of attempts remaining",
      "Give higher/lower hints on each guess",
      "Handle invalid non-integer inputs gracefully",
    ],
  },
  {
    id: "interactive-calc",
    title: "Grid Calculator",
    env: "react",
    difficulty: "Intermediate",
    description: "Build an interactive calculator with button keypad and memory state in React.",
    specs: [
      "Support addition, subtraction, multiplication, and division",
      "Display current operation and running calculation",
      "Handle division by zero and clear functions",
    ],
  },
  {
    id: "responsive-navbar",
    title: "Responsive Octagon Nav",
    env: "web",
    difficulty: "Intermediate",
    description: "Create a modern navigation header with desktop links and mobile slide-out drawer.",
    specs: [
      "CSS flexbox / responsive layout without overflow",
      "Hamburger toggle animation in JavaScript",
      "Sticky blurred backdrop upon scrolling",
    ],
  },
];
