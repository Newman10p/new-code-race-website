/**
 * THE CODEQUEST ACADEMY — course content layer (prototype).
 *
 * Workflow mirrored here: developers supply content → patrons configure & publish
 * → students see only `published` records. Unlocking is derived from completion
 * records in the store, never from a flag a student can set.
 *
 * Lessons carry an explicit content type so one studio renders every subject.
 */

export type StudioType = "theory" | "code" | "prompt" | "design";

export type Quiz = { q: string; options: string[]; correct: number; explain: string };

export type ExploreSpec =
  | { kind: "steps"; label: string; steps: { title: string; detail: string }[]; result: string }
  | { kind: "snippet"; label: string; code: string; inputLabel: string; sample: number; runJs: string }
  | { kind: "labels"; label: string; map: "hardware" | "network" | "layers"; parts: { id: string; name: string; role: string }[] }
  | { kind: "compare"; label: string; before: string; after: string; note: string };

export type PracSpec =
  | { kind: "code"; language: "javascript"; starter: string; tests: { name: string; args: unknown[]; expected: unknown }[]; hint: string }
  | { kind: "order"; label: string; items: string[]; correct: string[]; success: string }
  | { kind: "prompt"; label: string; brief: string; requires: string[]; criteria: string[]; strong: string }
  | { kind: "choice"; label: string; q: string; options: string[]; correct: number; success: string };

export type Lesson = {
  id: string;
  title: string;
  type: StudioType;
  minutes: number;
  points: number;
  objectives: string[];
  intro: string;
  callout?: string;
  definition?: { term: string; text: string };
  explore: ExploreSpec;
  practise: PracSpec;
  quiz: Quiz[];
};

export type SubCourse = {
  id: string;
  title: string;
  summary: string;
  lessons: Lesson[];
};

export type Course = {
  id: string;
  title: string;
  description: string;
  subject: "Computer Fundamentals" | "Programming" | "Web Development" | "AI & Automation" | "System Design";
  pattern: "circuit" | "code" | "neural" | "layout" | "layers";
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  patron: string;
  level: string;
  estimatedHours: number;
  points: number;
  recommended?: boolean;
  updated?: boolean;
  published: boolean;
  prerequisites: string[];
  objectives: string[];
  skills: string[];
  modules: SubCourse[];
};

export const SUBJECTS = ["Computer Fundamentals", "Programming", "Web Development", "AI & Automation", "System Design"];

/* ─────────── shared lesson builders ─────────── */

const theoryLesson = (
  id: string, title: string, minutes: number, points: number,
  objectives: string[], intro: string, definition: { term: string; text: string },
  map: "hardware" | "network" | "layers", parts: { id: string; name: string; role: string }[],
  order: { label: string; items: string[]; correct: string[]; success: string },
  quiz: Quiz[], callout?: string
): Lesson => ({
  id, title, type: "theory", minutes, points, objectives, intro, definition, callout,
  explore: { kind: "labels", label: "Explore — select each component", map, parts },
  practise: { kind: "order", ...order },
  quiz,
});

const promptLesson = (
  id: string, title: string, minutes: number, points: number,
  objectives: string[], intro: string, definition: { term: string; text: string },
  compare: { before: string; after: string; note: string },
  prac: { label: string; brief: string; requires: string[]; criteria: string[]; strong: string },
  quiz: Quiz[]
): Lesson => ({
  id, title, type: "prompt", minutes, points, objectives, intro, definition,
  callout: "No AI model is connected here: outputs shown are illustrative examples written by the course author. Your prompt is checked against the stated criteria, not generated.",
  explore: { kind: "compare", label: "Explore — weak vs strong prompt", ...compare },
  practise: { kind: "prompt", ...prac },
  quiz,
});

/* ─────────── courses ─────────── */

export const academyCourses: Course[] = [
  {
    id: "py-mastery",
    title: "Python Programming Mastery",
    description:
      "From first variable to working functions. A four-stage path that teaches Python the way competitions expect you to write it.",
    subject: "Programming",
    pattern: "code",
    difficulty: "Intermediate",
    patron: "Ms. Aisha Nakato · Northview Academy",
    level: "Grades 9–12",
    estimatedHours: 14,
    points: 640,
    recommended: true,
    published: true,
    prerequisites: [],
    objectives: ["Write and reason about Python programs", "Use control flow and functions confidently", "Debug with output, not guesswork", "Prepare for competition-style problems"],
    skills: ["Variables & types", "Control flow", "Functions", "Testing your own code"],
    modules: [
      {
        id: "py-m1", title: "Introduction to Programming",
        summary: "How a program runs, and where values come from.",
        lessons: [
          {
            id: "py-m1-l1", title: "What a program actually does", type: "theory", minutes: 12, points: 20,
            objectives: ["Describe a program as a sequence of instructions", "Identify input, processing and output"],
            intro: "A program is an ordered list of instructions that a machine executes one after another. Nothing happens out of order, and nothing happens that was not written down. That single fact explains most beginner surprises: if the computer did something unexpected, it followed your instructions exactly.",
            callout: "Read code top to bottom and predict the output before you run it. Prediction is the skill that separates readers from runners.",
            definition: { term: "Interpretation", text: "Python reads your source line by line and executes it immediately — an error stops the program at that exact line." },
            explore: {
              kind: "steps", label: "Explore — step through a three-line program",
              steps: [
                { title: "1 · score = 10", detail: "A name `score` is created and the value 10 is stored under it." },
                { title: "2 · score = score + 5", detail: "The old value is read, 5 is added, and the name now points at 15." },
                { title: "3 · print(score)", detail: "Python looks up `score` and writes 15 to the output." },
              ],
              result: "Output: 15",
            },
            practise: {
              kind: "order", label: "Practise — put the steps of execution in order",
              items: ["Execute the instruction", "Read the next instruction", "Start at the top of the file", "Stop at the end of the file"],
              correct: ["Start at the top of the file", "Read the next instruction", "Execute the instruction", "Stop at the end of the file"],
              success: "Correct — that is the execution model of any sequential program.",
            },
            quiz: [
              { q: "What does Python do first when a file runs?", options: ["Compiles the whole file to machine code", "Executes the first instruction at the top", "Imports every module on the system"], correct: 1, explain: "Python starts at the top and executes instruction by instruction." },
              { q: "If a line is never written in the file, what happens?", options: ["It may run anyway", "It never runs", "It runs at shutdown"], correct: 1, explain: "Only written instructions can execute." },
            ],
          },
          {
            id: "py-m1-l2", title: "Variables and memory", type: "code", minutes: 15, points: 30,
            objectives: ["Bind values to names", "Reassign a name and predict the result"],
            intro: "A variable is a label attached to a value, not a box that holds text. Rebinding moves the label; it does not edit the old value in place.",
            definition: { term: "Binding", text: "The association between a name and an object in memory, created or replaced by an assignment." },
            explore: { kind: "snippet", label: "Explore — run it, then change the input", inputLabel: "n", sample: 5, runJs: `function main(n) {
  let a = n;
  let b = a;
  a = a * 2;
  return [a, b];
}`, code: `function main(n) {
  let a = n;
  let b = a;
  a = a * 2;
  return [a, b];
}` },
            practise: { kind: "code", language: "javascript", starter: `function main(n) {
  // Return [doubled, original]
  let a = n;
  // TODO: store a copy of a before doubling
  // TODO: double a
  return [a, 0];
}`, tests: [
              { name: "n = 5", args: [5], expected: [10, 5] },
              { name: "n = 12", args: [12], expected: [24, 12] },
              { name: "n = 0", args: [0], expected: [0, 0] },
            ], hint: "Capture b BEFORE you double a. Order of instructions matters." },
            quiz: [
              { q: "After `b = a; a = a * 2`, what is b?", options: ["It doubles too", "It keeps the old value", "It becomes undefined"], correct: 1, explain: "b was bound to the old value; rebinding a does not change b." },
              { q: "A variable is best described as…", options: ["A labelled reference to a value", "A fixed-size memory box", "A type of loop"], correct: 0, explain: "Names point at values." },
            ],
          },
        ],
      },
      {
        id: "py-m2", title: "Conditionals & Loops",
        summary: "Making decisions and repeating work.",
        lessons: [
          {
            id: "py-m2-l1", title: "Branching with conditions", type: "theory", minutes: 14, points: 30,
            objectives: ["Write clear if/elif/else chains", "Explain why indentation changes behaviour"],
            intro: "A conditional picks one path through your code. Python uses indentation to decide which lines belong to the branch — the colon opens a block, and the deeper indentation defines it.",
            callout: "Ask 'what happens when the condition is false?' before you write the else. Both paths are part of your design.",
            definition: { term: "Boolean expression", text: "An expression that evaluates to True or False, built from comparisons combined with and, or and not." },
            explore: {
              kind: "steps", label: "Explore — evaluate a grade lookup",
              steps: [
                { title: "score = 74", detail: "A value is stored." },
                { title: "score >= 65?", detail: "Comparison returns True, so the first branch runs." },
                { title: "grade = 'C'", detail: "Later branches are skipped entirely." },
              ],
              result: "grade = 'C'",
            },
            practise: {
              kind: "order", label: "Practise — order an if / elif / else chain",
              items: ["else: handle everything else", "if: check the first condition", "elif: check the fallback condition"],
              correct: ["if: check the first condition", "elif: check the fallback condition", "else: handle everything else"],
              success: "Right — conditions are evaluated top to bottom and the first match wins.",
            },
            quiz: [
              { q: "What happens after a matching branch runs?", options: ["The remaining branches run too", "The block is skipped", "The program restarts"], correct: 1, explain: "Only the first matching branch executes." },
              { q: "Which keyword opens a conditional block?", options: [";", ":", ","], correct: 1, explain: "The colon opens the indented block." },
            ],
          },
          {
            id: "py-m2-l2", title: "Loops and iteration", type: "code", minutes: 18, points: 40,
            objectives: ["Use for loops over ranges", "Accumulate a result while iterating"],
            intro: "A loop repeats a block with a changing value. In competitions, loops almost always build or scan a sequence while keeping a running result.",
            definition: { term: "Accumulator", text: "A variable initialised before a loop that is updated on every iteration to build a final result." },
            explore: { kind: "snippet", label: "Explore — run it, then change the input", inputLabel: "n", sample: 5, runJs: `function main(n) {
  const seen = [];
  for (let i = 1; i <= n; i++) seen.push(i * i);
  return seen;
}`, code: `function main(n) {
  const seen = [];
  for (let i = 1; i <= n; i++) seen.push(i * i);
  return seen;
}` },
            practise: { kind: "code", language: "javascript", starter: `function main(n) {
  // Return the sum of 1..n using a loop
  let total = 0;
  // TODO: loop from 1 to n and add each value to total
  return total;
}`, tests: [
              { name: "sum 1..4", args: [4], expected: 10 },
              { name: "sum 1..1", args: [1], expected: 1 },
              { name: "sum 1..10", args: [10], expected: 55 },
            ], hint: "for (let i = 1; i <= n; i++) { total += i; }" },
            quiz: [
              { q: "In `for i in 1..n`, how many iterations run for n = 4?", options: ["3", "4", "5"], correct: 1, explain: "Four values: 1, 2, 3, 4." },
              { q: "Where should an accumulator be initialised?", options: ["Inside the loop", "Before the loop", "After printing"], correct: 1, explain: "Initialising inside the loop resets it every iteration." },
            ],
          },
        ],
      },
      {
        id: "py-m3", title: "Functions & Scope",
        summary: "Reusable blocks with clear inputs and outputs.",
        lessons: [
          {
            id: "py-m3-l1", title: "Writing functions", type: "theory", minutes: 14, points: 30,
            objectives: ["Decompose a problem into functions", "Choose meaningful names and parameters"],
            intro: "A function names a piece of work. Give it one responsibility, a clear parameter list and one return value, and every other part of your program becomes easier to reason about.",
            callout: "If you cannot summarise a function in one sentence, it is doing too much.",
            definition: { term: "Return value", text: "The result a function hands back to the caller; without a return, the function produces None." },
            explore: {
              kind: "steps", label: "Explore — calling a function twice",
              steps: [
                { title: "def double(x): return x * 2", detail: "The function is defined but not run." },
                { title: "double(3) → 6", detail: "A call creates a fresh binding for x." },
                { title: "double(4) → 8", detail: "Each call is independent — x does not remember the last value." },
              ],
              result: "Two calls, two independent bindings",
            },
            practise: {
              kind: "order", label: "Practise — order the parts of defining and using a function",
              items: ["Call the function with arguments", "Define the function with parameters", "Return the result", "Write the function body"],
              correct: ["Define the function with parameters", "Write the function body", "Return the result", "Call the function with arguments"],
              success: "Correct — define, implement, return, then call.",
            },
            quiz: [
              { q: "What does a function without a return produce?", options: ["0", "None", "An error"], correct: 1, explain: "Python returns None by default." },
              { q: "Two calls to the same function…", options: ["Share parameter values", "Are independent", "Must use the same argument"], correct: 1, explain: "Each call has its own parameters." },
            ],
          },
          {
            id: "py-m3-l2", title: "Scope and reuse", type: "code", minutes: 16, points: 40,
            objectives: ["Keep function state local", "Return values instead of printing inside helpers"],
            intro: "A function should communicate through its parameters and its return value, not through hidden global state. Local variables disappear when the call ends — that is a feature.",
            definition: { term: "Scope", text: "The region of a program where a name is visible. Function parameters and locals live inside the function's scope." },
            explore: { kind: "snippet", label: "Explore — run it, then change the input", inputLabel: "n", sample: 5, runJs: `function main(k) {
  let cache = {};
  for (let i = 1; i <= 3; i++) cache[i] = i * k;
  return cache;
}`, code: `function main(k) {
  let cache = {};
  for (let i = 1; i <= 3; i++) cache[i] = i * k;
  return cache;
}` },
            practise: { kind: "code", language: "javascript", starter: `function doubleAll(list) {
  // Return a NEW array with every value multiplied by 2.
  // Do not modify the input array.
  // TODO: build result in a local array and return it
  return list;
}`, tests: [
              { name: "[1,2,3]", args: [[1, 2, 3]], expected: [2, 4, 6] },
              { name: "[]", args: [[]], expected: [] },
              { name: "[7]", args: [[7]], expected: [14] },
            ], hint: "const out = []; for (const v of list) out.push(v * 2); return out;" },
            quiz: [
              { q: "Where should a counter used only inside a function live?", options: ["Global scope", "Inside the function", "In the caller"], correct: 1, explain: "Locals avoid side effects on other code." },
              { q: "Mutating the input array inside a helper…", options: ["Is encouraged", "Surprises the caller", "Is impossible"], correct: 1, explain: "Hidden mutation makes behaviour hard to track." },
            ],
          },
        ],
      },
      {
        id: "py-m4", title: "Practical Project",
        summary: "Combine variables, loops and functions in one task.",
        lessons: [
          {
            id: "py-m4-l1", title: "Plan before you code", type: "theory", minutes: 12, points: 30,
            objectives: ["Turn a problem statement into steps", "Identify inputs, outputs and edge cases"],
            intro: "Most failed submissions are planning failures. Write down the inputs, the output shape, and two edge cases before opening the editor — the code then becomes a translation exercise.",
            callout: "Edge case first: what happens with an empty list, a single item, or n = 0?",
            definition: { term: "Invariant", text: "A condition that stays true throughout your algorithm; invariants are how you prove a loop produces the right answer." },
            explore: {
              kind: "steps", label: "Explore — planning a statistics function",
              steps: [
                { title: "Input: list of numbers", detail: "Decide what happens for an empty list — return zeros, not an error." },
                { title: "Output: {min, max, mean}", detail: "Define the shape once; callers can rely on it." },
                { title: "Loop once, track three values", detail: "A single pass is enough — no nested loops needed." },
              ],
              result: "One pass · O(n) · empty-safe",
            },
            practise: {
              kind: "order", label: "Practise — order your problem-solving routine",
              items: ["Write edge cases", "State inputs and outputs", "Translate to code", "Read the problem"],
              correct: ["Read the problem", "State inputs and outputs", "Write edge cases", "Translate to code"],
              success: "Correct — reading and specification always come before code.",
            },
            quiz: [
              { q: "An invariant is useful because it…", options: ["Speeds up code", "Helps you prove correctness", "Removes all tests"], correct: 1, explain: "Invariants justify why an algorithm works." },
              { q: "An empty-input case should be decided…", options: ["After submitting", "When planning", "Never"], correct: 1, explain: "Decide it before coding, then encode it in a test." },
            ],
          },
          {
            id: "py-m4-l2", title: "Final practical: summary statistics", type: "code", minutes: 25, points: 60,
            objectives: ["Combine loops, conditionals and functions", "Handle empty input safely"],
            intro: "Build the full solution for the statistics helper: one pass, safe on empty input, returning a defined shape. This is the shape of most competition warm-up problems.",
            definition: { term: "Edge case", text: "An input at the boundary of the valid range — empty, single element, maximum size — where naive code usually breaks." },
            explore: { kind: "snippet", label: "Explore — run it, then change the input", inputLabel: "n", sample: 5, runJs: `function main(values) {
  if (values.length === 0) return { min: 0, max: 0, mean: 0 };
  let min = values[0], max = values[0], sum = 0;
  for (const v of values) { sum += v; min = Math.min(min, v); max = Math.max(max, v); }
  return { min, max, mean: sum / values.length };
}`, code: `function main(values) {
  if (values.length === 0) return { min: 0, max: 0, mean: 0 };
  let min = values[0], max = values[0], sum = 0;
  for (const v of values) { sum += v; min = Math.min(min, v); max = Math.max(max, v); }
  return { min, max, mean: sum / values.length };
}` },
            practise: { kind: "code", language: "javascript", starter: `function summary(values) {
  // Return { min, max, mean }. Empty input → { min: 0, max: 0, mean: 0 }.
  // TODO: guard empty input, then loop once
  return { min: 0, max: 0, mean: 0 };
}`, tests: [
              { name: "[4,2,9]", args: [[4, 2, 9]], expected: { min: 2, max: 9, mean: 5 } },
              { name: "[]", args: [[]], expected: { min: 0, max: 0, mean: 0 } },
              { name: "[-3,-1,-5]", args: [[-3, -1, -5]], expected: { min: -5, max: -1, mean: -3 } },
            ], hint: "Guard length first, then initialise min/max from values[0] and track sum in the same loop." },
            quiz: [
              { q: "Why return an object rather than an array?", options: ["Objects are faster", "Named keys are self-documenting", "Arrays cannot hold numbers"], correct: 1, explain: "Named fields make the result unambiguous." },
              { q: "How many passes over the data are needed?", options: ["One", "Three", "One per statistic"], correct: 0, explain: "Min, max and sum can all be tracked in one loop." },
            ],
          },
        ],
      },
    ],
  },

  {
    id: "comp-fund",
    title: "Computer Fundamentals & Digital Literacy",
    description:
      "What a computer is, how its parts work together, how networks move data, and how to use all of it safely.",
    subject: "Computer Fundamentals",
    pattern: "circuit",
    difficulty: "Beginner",
    patron: "Mr. Daniel Ochieng · Horizon Public",
    level: "Grades 7–10",
    estimatedHours: 9,
    points: 420,
    published: true,
    prerequisites: [],
    objectives: ["Identify core hardware components", "Explain how devices communicate over a network", "Practise safe, responsible digital habits"],
    skills: ["Hardware", "Operating systems", "Networking basics", "Digital safety"],
    modules: [
      {
        id: "cf-m1", title: "Inside the Machine",
        summary: "CPU, memory, storage and how they cooperate.",
        lessons: [
          theoryLesson(
            "cf-m1-l1", "Hardware components and their jobs", 12, 30,
            ["Name the four core components", "Explain why faster storage matters"],
            "Every computer is the same four collaborators: the processor executes instructions, memory holds what is currently in use, storage keeps data when powered off, and the bus moves data between them. Speed differences you feel come from how quickly each part can hand work to the next.",
            { term: "Bus", text: "A shared communication pathway carrying data between the CPU, memory and peripherals." },
            "hardware",
            [
              { id: "cpu", name: "CPU", role: "Executes instructions — the component that actually does the computing." },
              { id: "ram", name: "RAM", role: "Holds programs and data currently in use; contents vanish when powered off." },
              { id: "storage", name: "Storage (SSD)", role: "Keeps files permanently; slower than RAM but non-volatile." },
              { id: "bus", name: "System bus", role: "Carries data and instructions between the other components." },
            ],
            { label: "Practise — order the path of a program starting up", items: ["Loaded into RAM from storage", "Stored on disk", "Fetched as instructions by the CPU", "User double-clicks the file"], correct: ["User double-clicks the file", "Stored on disk", "Loaded into RAM from storage", "Fetched as instructions by the CPU"], success: "Correct — storage → memory → CPU." },
            [
              { q: "Which component loses its contents when power is cut?", options: ["RAM", "SSD", "CPU"], correct: 0, explain: "RAM is volatile; SSD storage is not." },
              { q: "Why does an SSD upgrade speed things up?", options: ["It increases clock speed", "Programs are read from storage faster", "It doubles RAM capacity"], correct: 1, explain: "Programs are loaded from storage, so faster storage shortens load times." },
            ],
            "Tip: click each component to read its role before ordering the steps."
          ),
          theoryLesson(
            "cf-m1-l2", "Operating systems and software layers", 14, 30,
            ["Describe the OS role between hardware and apps", "Distinguish system software from application software"],
            "The operating system is the manager: it allocates memory, schedules processes and gives programs a consistent way to talk to hardware. Applications never touch hardware directly — they ask the OS, which decides who gets what and when.",
            { term: "Process", text: "A program in execution, along with the resources and state the OS tracks for it." },
            "layers",
            [
              { id: "app", name: "Applications", role: "Software you run — browser, editor, IDE." },
              { id: "os", name: "Operating system", role: "Manages memory, processes, files and devices." },
              { id: "drivers", name: "Drivers", role: "Translate OS requests into hardware-specific instructions." },
              { id: "hw", name: "Hardware", role: "The physical components executing the work." },
            ],
            { label: "Practise — order the layers from top (closest to you) to bottom", items: ["Hardware", "Applications", "Operating system", "Drivers"], correct: ["Applications", "Operating system", "Drivers", "Hardware"], success: "Correct — applications sit on the OS, which relies on drivers to reach hardware." },
            [
              { q: "Who decides which process runs next?", options: ["The application", "The OS scheduler", "The browser"], correct: 1, explain: "The OS allocates CPU time between processes." },
              { q: "A driver is best described as…", options: ["An antivirus tool", "A hardware translator", "A file format"], correct: 1, explain: "Drivers translate generic OS requests into device-specific commands." },
            ],
            "Memory aid: applications ask, the OS decides, drivers translate, hardware executes."
          ),
        ],
      },
      {
        id: "cf-m2", title: "Networks & the Internet",
        summary: "How a request becomes a response.",
        lessons: [
          theoryLesson(
            "cf-m2-l1", "How a page reaches your screen", 15, 40,
            ["Trace a request from browser to server", "Explain what DNS does"],
            "When you open a page, your browser asks a name resolver for an address, sends a request to that server, receives data, and renders it. Each hop adds a little delay — the sum is what you experience as loading time.",
            { term: "DNS", text: "The Domain Name System translates readable names like example.com into numeric IP addresses machines can route to." },
            "network",
            [
              { id: "client", name: "Browser / client", role: "Builds and sends the request; renders what comes back." },
              { id: "dns", name: "DNS resolver", role: "Turns the domain name into an IP address." },
              { id: "router", name: "Router", role: "Forwards packets across networks toward the server." },
              { id: "server", name: "Server", role: "Processes the request and returns the page data." },
            ],
            { label: "Practise — order the steps of loading a website", items: ["Server responds with page data", "Browser asks DNS for the IP", "Browser sends the request to that address", "Router forwards the packets"], correct: ["Browser asks DNS for the IP", "Router forwards the packets", "Browser sends the request to that address", "Server responds with page data"], success: "Close — DNS first, then routing and the request itself, then the response." },
            [
              { q: "What does DNS return?", options: ["HTML", "An IP address", "A CSS file"], correct: 1, explain: "DNS maps names to addresses." },
              { q: "HTTPS means the connection is…", options: ["Encrypted", "Faster", "Offline"], correct: 0, explain: "HTTPS wraps the traffic in encryption." },
            ],
            "Security note: a padlock means encrypted transport — it does not by itself prove a site is honest."
          ),
          theoryLesson(
            "cf-m2-l2", "Practical digital safety", 12, 30,
            ["Recognise phishing signals", "Choose strong passwords and enable second factors"],
            "Most account compromises are not clever hacks — they are tricked humans or reused passwords. A short list of habits removes most of the risk: unique passwords in a password manager, a second factor, and a pause before clicking.",
            { term: "Multi-factor authentication", text: "Requiring a second proof — a code or device — so a stolen password alone is not enough to sign in." },
            "network",
            [
              { id: "client", name: "You", role: "Pause before clicking — verify the sender and the URL." },
              { id: "dns", name: "Password manager", role: "Generates and stores unique passwords per site." },
              { id: "router", name: "Second factor", role: "A code or app approval that a stolen password cannot provide." },
              { id: "server", name: "Updates", role: "Patched software removes known attack paths." },
            ],
            { label: "Practise — order your security checklist by first action", items: ["Install available updates", "Turn on multi-factor authentication", "Verify the sender before clicking", "Set a unique password per site"], correct: ["Verify the sender before clicking", "Set a unique password per site", "Turn on multi-factor authentication", "Install available updates"], success: "A sound order — awareness, credentials, second factor, then patching." },
            [
              { q: "Which password practice is safest?", options: ["One password everywhere", "A unique password per site in a manager", "A short memorable password"], correct: 1, explain: "Reuse turns one breach into many." },
              { q: "A surprising invoice email is safest handled by…", options: ["Opening it quickly to check", "Verifying the sender through another channel", "Replying with your details"], correct: 1, explain: "Verify out-of-band before you act." },
            ],
            "Phishing works on urgency. Slowing down is a security control."
          ),
        ],
      },
      {
        id: "cf-m3", title: "Files & Productivity",
        summary: "Organising information so tools can use it.",
        lessons: [
          {
            id: "cf-m3-l1", title: "File formats and structure", type: "theory", minutes: 10, points: 25,
            objectives: ["Choose the right format for a task", "Explain why file extensions matter"],
            intro: "A file format is a contract describing how bytes map to meaning. Choosing the wrong one costs you later: a layout destined for print should not be saved as a lossy image, and raw data shared as a screenshot becomes unusable.",
            callout: "Rule of thumb: keep data as data (CSV, JSON) and design as a document (PDF, editable source) — never both in a screenshot.",
            definition: { term: "Metadata", text: "Data about data — size, timestamps, authorship and format flags stored alongside the content." },
            explore: {
              kind: "steps", label: "Explore — saving a spreadsheet for three audiences",
              steps: [
                { title: "Analyst → .csv", detail: "Plain rows and columns that any tool can parse." },
                { title: "Teacher → .pdf", detail: "Fixed layout, nothing shifts when opened elsewhere." },
                { title: "Teammate → shared sheet link", detail: "Collaborative editing with version history." },
              ],
              result: "Same data, three formats, three purposes",
            },
            practise: {
              kind: "order", label: "Practise — order the steps of a clean file workflow",
              items: ["Export a PDF for sharing", "Name files with a date and version", "Edit the source document", "Archive the final version"],
              correct: ["Edit the source document", "Name files with a date and version", "Export a PDF for sharing", "Archive the final version"],
              success: "Correct — edit, name, share, archive.",
            },
            quiz: [
              { q: "Which format suits raw data for analysis?", options: ["Screenshot", "CSV", "PDF"], correct: 1, explain: "CSV keeps data machine-readable." },
              { q: "A file extension primarily indicates…", options: ["The file's size", "Its expected format", "Who created it"], correct: 1, explain: "The extension tells software how to interpret the bytes." },
            ],
          },
          {
            id: "cf-m3-l2", title: "Productivity tools and shortcuts", type: "code", minutes: 12, points: 35,
            objectives: ["Automate repetitive text processing", "Think in terms of batch transformations"],
            intro: "Productivity beyond clicking is scripting: turning a repetitive manual task into a short program. Here you write a small text formatter — the same idea that later becomes real automation.",
            definition: { term: "Batch processing", text: "Applying one operation across many items at once instead of handling each by hand." },
            explore: { kind: "snippet", label: "Explore — run it, then change the input", inputLabel: "n", sample: 5, runJs: `function main(names) {
  // Sort a contact list alphabetically
  return [...names].sort();
}`, code: `function main(names) {
  // Sort a contact list alphabetically
  return [...names].sort();
}` },
            practise: { kind: "code", language: "javascript", starter: `function formatTitles(lines) {
  // Capitalise the first letter of every line and trim whitespace.
  // "  quarterly report " → "Quarterly Report" is NOT required —
  // just "Quarterly report".
  // TODO: trim each line, uppercase its first character
  return lines;
}`, tests: [
              { name: "['apple','banana']", args: [["apple", "banana"]], expected: ["Apple", "Banana"] },
              { name: "[]", args: [[]], expected: [] },
              { name: "['one']", args: [["one"]], expected: ["One"] },
            ], hint: "Return lines.map(l => l.trim()) then upper-case l[0] — do it in one pass." },
            quiz: [
              { q: "Batch processing means…", options: ["Doing one task at a time", "Applying one operation across many items", "Running tasks overnight only"], correct: 1, explain: "One operation, many items." },
              { q: "Automation saves time mainly when the task is…", options: ["Unique each time", "Repetitive", "Creative"], correct: 1, explain: "Repetition is where scripts pay off." },
            ],
          },
        ],
      },
    ],
  },

  {
    id: "ai-prompt",
    title: "AI Prompting & Prompt Engineering",
    description:
      "Learn to write prompts that produce usable results — context, constraints, format and iteration — and to judge the output critically.",
    subject: "AI & Automation",
    pattern: "neural",
    difficulty: "Intermediate",
    patron: "Ms. Aisha Nakato · Northview Academy",
    level: "Grades 9–12",
    estimatedHours: 8,
    points: 520,
    recommended: true,
    updated: true,
    published: true,
    prerequisites: ["comp-fund"],
    objectives: ["Structure prompts with role, context, constraints and format", "Compare weak and strong prompts", "Evaluate outputs against stated criteria"],
    skills: ["Prompt structure", "Output evaluation", "Iterative refinement"],
    modules: [
      {
        id: "ai-m1", title: "Prompt Foundations",
        summary: "Context, role, constraints, format.",
        lessons: [
          promptLesson(
            "ai-m1-l1", "The four-part prompt", 14, 40,
            ["Identify role, context, constraint and format", "Explain why vagueness produces vague output"],
            "A useful prompt tells the model four things: who it should act as, what the situation is, what limits apply, and what shape the answer should take. Miss one and you will spend your turn asking again.",
            { term: "Constraint", text: "A boundary that narrows possible outputs — length, audience, style, forbidden content or a fixed format." },
            { before: "Explain recursion.", after: "You are a CS teacher. Explain recursion to a Grade 10 student in under 120 words, include one everyday analogy, and end with one question the student can answer to check understanding.", note: "The strong prompt fixes audience, length, structure and a check — the weak one leaves all four to chance." },
            { label: "Practise — strengthen this prompt", brief: "Write a prompt asking for a revision timetable for a two-week exam period.", requires: ["audience", "length", "format"], criteria: ["Mentions who it is for", "States a length limit", "Specifies the output format", "Names a constraint such as daily study hours"], strong: "You are a study coach. Build a two-week revision timetable for a Grade 10 student with 3 hours per day for 5 subjects, as a 7-row table with hours per subject. Keep the plan under 150 words." },
            [
              { q: "Which prompt element fixes the answer's shape?", options: ["Format", "Role", "Greeting"], correct: 0, explain: "Format specifies the structure you want back." },
              { q: "Why list forbidden content?", options: ["It slows the model", "It narrows outputs to safe, relevant ground", "It is not useful"], correct: 1, explain: "Exclusions reduce irrelevant or unsafe material." },
            ],
          ),
          promptLesson(
            "ai-m1-l2", "Iteration: refining an answer", 16, 45,
            ["Refine an output through targeted follow-ups", "Separate style problems from content problems"],
            "The first response is a draft. Good use of AI is a conversation: change one thing per turn — first correctness, then clarity, then format — so you know what caused the improvement.",
            { term: "Iteration", text: "Repeatedly narrowing a result with one specific change per turn rather than rewriting the whole request." },
            { before: "Make it shorter.", after: "Keep all five recommendations, but cut the introduction to one sentence and drop the examples — target 90 words total.", note: "One clear change at a time tells you exactly what worked." },
            { label: "Practise — write the follow-up instruction", brief: "Your first answer was correct but far too long for a slide. Write the single refinement instruction you would send next.", requires: ["length", "keep"], criteria: ["States a target length or medium", "Says what to keep", "Says what to remove", "Changes one dimension only"], strong: "Keep the three main risks exactly as written, but rewrite for a slide: bullet points only, maximum 40 words, no introduction." },
            [
              { q: "Best iteration practice is…", options: ["Rewrite everything each turn", "Change one dimension per turn", "Accept the first answer"], correct: 1, explain: "One change per turn isolates what improved the result." },
              { q: "A style problem and a content problem should be fixed…", options: ["Together in one vague request", "Separately", "By ignoring them"], correct: 1, explain: "Separate fixes keep you from over-correcting." },
            ],
          ),
        ],
      },
      {
        id: "ai-m2", title: "Working With AI Outputs",
        summary: "Checking, critiquing, improving prompts from results.",
        lessons: [
          promptLesson(
            "ai-m2-l1", "Evaluating output critically", 15, 45,
            ["Test a response against explicit criteria", "Spot confident wrong answers"],
            "AI output is a proposal, not a source. Evaluate it the way you would review a teammate's draft: does it satisfy each requirement, is anything factually wrong, and would you stake your name on it?",
            { term: "Hallucination", text: "A plausible-sounding statement that is false — the most common failure mode when a model fills gaps it cannot verify." },
            { before: "Great, that looks right!", after: "Check: (1) does every claim match the brief? (2) can any number be verified? (3) is the format exactly what was requested? (4) what is missing?", note: "A checklist turns agreement into verification." },
            { label: "Practise — write your review checklist prompt", brief: "Ask a model to criticise its own answer against four explicit criteria for your school project.", requires: ["criteria", "four", "critic"], criteria: ["Names at least three concrete criteria", "Asks for self-critique explicitly", "Requests a revision at the end", "Specifies a scoring or pass/fail format"], strong: "Review your last answer against these criteria: accuracy, relevance to a Grade 10 audience, format compliance, and missing context. Score each as pass or fail, then rewrite the answer fixing every failure." },
            [
              { q: "Hallucination means…", options: ["A slow response", "A confident but false claim", "A formatting error"], correct: 1, explain: "Plausible-sounding and wrong." },
              { q: "Who is responsible for verifying output?", options: ["The model", "The student using it", "Nobody"], correct: 1, explain: "You own whatever you submit." },
            ],
          ),
          promptLesson(
            "ai-m2-l2", "Structure and templates", 14, 45,
            ["Apply a reusable prompt template", "Adapt a template to a new task"],
            "Templates compress good practice: a role line, a context block, explicit constraints, a format line, and a check step. Once you own the template, new tasks become fill-in-the-blanks.",
            { term: "Template", text: "A reusable prompt skeleton with fixed structure and variable slots for each new task." },
            { before: "Help me study for the quiz.", after: "Role: quiz setter. Context: I studied variables, conditionals and loops today. Task: write 6 questions at increasing difficulty. Format: numbered list with answers on a separate line. Constraint: no question needs a library.", note: "Every slot is filled; nothing is left to chance." },
            { label: "Practise — build the template for a debugging task", brief: "Write a prompt that asks for help debugging a short Python function, structured as a reusable template.", requires: ["context", "code", "format"], criteria: ["Provides the code or a clear place for it", "States expected vs actual behaviour", "Specifies the desired format", "Sets a length or scope limit"], strong: "Role: Python tutor. Context: my function should return the first duplicate but returns None for the sample below. Code: <paste>. Expected [1,2] → 1. Actual: None. Ask one clarifying question first, then give at most 3 ranked hypotheses." },
            [
              { q: "A good template fixes…", options: ["The exact answer", "The structure of the request", "The model used"], correct: 1, explain: "Structure is reusable across tasks." },
              { q: "Including expected vs actual output helps because it…", options: ["Adds length", "Gives a concrete failure to analyse", "Looks professional"], correct: 1, explain: "Concrete evidence turns vague help into diagnosis." },
            ],
          ),
        ],
      },
    ],
  },

  {
    id: "sys-design",
    title: "System Design Essentials",
    description:
      "Components, trade-offs and diagrams — the vocabulary used in System Design Showdown and your patron's review.",
    subject: "System Design",
    pattern: "layers",
    difficulty: "Advanced",
    patron: "Mr. Daniel Ochieng · Horizon Public",
    level: "Grades 10–12",
    estimatedHours: 11,
    points: 560,
    published: true,
    prerequisites: ["py-mastery"],
    objectives: ["Decompose a system into components", "Reason about bottlenecks and trade-offs", "Document a design so others can build it"],
    skills: ["Architecture", "Databases & caching", "Trade-off analysis"],
    modules: [
      {
        id: "sd-m1", title: "Architecture Fundamentals",
        summary: "Clients, services, data stores and the paths between them.",
        lessons: [
          theoryLesson(
            "sd-m1-l1", "Components and relationships", 15, 45,
            ["Identify client, service and data-store roles", "Read a simple architecture diagram"],
            "Every design is a set of boxes and the arrows that connect them. The boxes answer what exists; the arrows answer how data moves and where it can stall. Draw both before you discuss scaling.",
            { term: "Bottleneck", text: "The component whose capacity limits the whole system — improving anything else does not raise overall throughput." },
            "layers",
            [
              { id: "app", name: "Client", role: "Requests data and renders it for the user." },
              { id: "os", name: "API service", role: "Validates requests and contains business rules." },
              { id: "drivers", name: "Cache", role: "Serves repeated reads quickly, reducing database load." },
              { id: "hw", name: "Database", role: "Source of truth for durable data." },
            ],
            { label: "Practise — order the path of a read request", items: ["Database returns stored record", "Client sends a request", "Cache checks for a stored copy", "API service handles the request"], correct: ["Client sends a request", "API service handles the request", "Cache checks for a stored copy", "Database returns stored record"], success: "Correct — cache first, database only when the cache misses." },
            [
              { q: "A cache miss means…", options: ["An error", "The data was not stored, so fetch it", "The request was rejected"], correct: 1, explain: "Miss = go to the source of truth." },
              { q: "The bottleneck is…", options: ["The fastest component", "The limiting component", "Any database"], correct: 1, explain: "Throughput is capped by the slowest stage." },
            ],
            "Draw arrows with labels: what travels, and how often?"
          ),
          theoryLesson(
            "sd-m1-l2", "Trade-offs you will be asked about", 14, 45,
            ["State a trade-off for a common design choice", "Defend a decision with an explicit reason"],
            "Good design answers are never 'always X'. Caching trades freshness for speed; normalisation trades write overhead for consistency; queues trades latency for reliability. You are judged on whether you can name both sides.",
            { term: "Trade-off", text: "A decision that improves one property while worsening another, chosen deliberately for this system's priorities." },
            "layers",
            [
              { id: "app", name: "Caching", role: "Faster reads, staler data — invalidate on write." },
              { id: "os", name: "Normalisation", role: "Fewer duplicates, more joins on write." },
              { id: "drivers", name: "Message queue", role: "Smooths bursts, adds delivery latency." },
              { id: "hw", name: "Replication", role: "Higher availability, more complex consistency." },
            ],
            { label: "Practise — order a design review conversation", items: ["State the alternative considered", "Name the chosen approach", "Explain what got worse", "Explain what got better"], correct: ["State the alternative considered", "Name the chosen approach", "Explain what got better", "Explain what got worse"], success: "Correct — alternatives, decision, benefit, cost." },
            [
              { q: "Adding a cache mainly improves…", options: ["Read speed", "Write consistency", "Data freshness"], correct: 0, explain: "Repeated reads are served without hitting storage." },
              { q: "A review should hear…", options: ["Only benefits", "Both sides of the trade-off", "No alternatives"], correct: 1, explain: "Both sides show deliberate reasoning." },
            ],
            "Never say 'scalable' without saying what it costs."
          ),
        ],
      },
      {
        id: "sd-m2", title: "Designing Under Constraints",
        summary: "Apply the vocabulary to a real scenario.",
        lessons: [
          {
            id: "sd-m2-l1", title: "Scenario: attendance spikes", type: "design", minutes: 18, points: 60,
            objectives: ["Identify the peak-load constraint", "Propose a component that directly addresses it"],
            intro: "School portals collapse between 07:40 and 08:00 because everyone marks attendance at once. Start by naming the spike, then ask which single component absorbs it.",
            callout: "Name the constraint before naming the technology. The bottleneck tells you where to design.",
            definition: { term: "Write amplification", text: "Doing more writes than the user's single action strictly requires — a common source of peak-time collapse." },
            explore: {
              kind: "steps", label: "Explore — where the spike actually happens",
              steps: [
                { title: "07:45 · 5,000 teachers submit", detail: "Simultaneous writes against one table." },
                { title: "Queue absorbs the burst", detail: "Requests are acknowledged immediately and processed steadily." },
                { title: "Results are cached afterwards", detail: "Reads for parents never touch the write path." },
              ],
              result: "Peak flattened: acknowledge fast, process steady",
            },
            practise: {
              kind: "order", label: "Practise — order your design steps for a spike scenario",
              items: ["Prototype and measure", "Identify the peak constraint", "Choose a component that absorbs it", "State the trade-off introduced"],
              correct: ["Identify the peak constraint", "Choose a component that absorbs it", "State the trade-off introduced", "Prototype and measure"],
              success: "Correct — constraint first, then design, then honesty about cost, then measurement.",
            },
            quiz: [
              { q: "Why ack attendance writes immediately?", options: ["It writes faster", "Users stop retrying while work proceeds steadily", "It removes the database"], correct: 1, explain: "Fast acknowledgement stops retry storms." },
              { q: "The first step of a spike design is…", options: ["Choosing a database", "Naming the constraint", "Writing schema DDL"], correct: 1, explain: "Design follows the bottleneck." },
            ],
          },
          {
            id: "sd-m2-l2", title: "Documenting the decision", type: "theory", minutes: 12, points: 55,
            objectives: ["Write a one-page design rationale", "Include diagrams, alternatives and risks"],
            intro: "A design that exists only in your head cannot be judged. Judges and patrons read documents: a diagram, the constraint, the chosen approach, alternatives rejected, and the risks you accept.",
            callout: "One page. If it needs three, you have not decided yet.",
            definition: { term: "ADR", text: "Architecture Decision Record — a short document capturing context, decision, alternatives and consequences." },
            explore: {
              kind: "steps", label: "Explore — an ADR in four lines",
              steps: [
                { title: "Context", detail: "5,000 concurrent attendance writes between 07:40 and 08:00." },
                { title: "Decision", detail: "Acknowledge immediately; process through a queue; cache reads." },
                { title: "Alternative rejected", detail: "Scaling the database alone — cost before certainty." },
                { title: "Consequence", detail: "Attendance visible after a short delay; retries disappear." },
              ],
              result: "A decision anyone can review",
            },
            practise: {
              kind: "order", label: "Practise — order the ADR sections as they should appear",
              items: ["Consequences (what changes)", "Context (the problem)", "Decision (what we do)", "Alternatives considered"],
              correct: ["Context (the problem)", "Alternatives considered", "Decision (what we do)", "Consequences (what changes)"],
              success: "Correct — context → options → decision → consequences.",
            },
            quiz: [
              { q: "What must an ADR include?", options: ["Only the final schema", "Alternatives and consequences", "Source code"], correct: 1, explain: "The rejected options show your reasoning." },
              { q: "A design document should be…", options: ["As long as possible", "Concise enough to review in a page", "Informal notes"], correct: 1, explain: "Judges review many submissions — clarity wins." },
            ],
          },
        ],
      },
    ],
  },

  /* Draft course — must never appear in the student library */
  {
    id: "robotics-draft",
    title: "Robotics & IoT Foundations",
    description: "Draft course awaiting patron configuration.",
    subject: "Computer Fundamentals", pattern: "circuit", difficulty: "Beginner",
    patron: "—", level: "—", estimatedHours: 0, points: 0, published: false,
    prerequisites: [], objectives: [], skills: [], modules: [],
  },
];

export const courseById = (id: string) => academyCourses.find((c) => c.id === id);

export type LearningPathNode = {
  id: string; courseId: string; label: string; subject: Course["subject"];
  prerequisites: string[]; x: number; y: number; kind: "course" | "milestone";
};

/** Skill relationships — visual only; unlocking still comes from the store. */
export const pathLayout: LearningPathNode[] = [
  { id: "node-comp-fund", courseId: "comp-fund", label: "Computer Fundamentals", subject: "Computer Fundamentals", prerequisites: [], x: 90, y: 200, kind: "course" },
  { id: "node-py-mastery", courseId: "py-mastery", label: "Python Mastery", subject: "Programming", prerequisites: [], x: 90, y: 400, kind: "course" },
  { id: "node-sys-design", courseId: "sys-design", label: "System Design", subject: "System Design", prerequisites: ["py-mastery"], x: 330, y: 300, kind: "course" },
  { id: "node-ai-prompt", courseId: "ai-prompt", label: "AI Prompting", subject: "AI & Automation", prerequisites: ["comp-fund"], x: 330, y: 120, kind: "course" },
  { id: "mile-py-mastery", courseId: "py-mastery", label: "Python certified", subject: "Programming", prerequisites: ["py-mastery"], x: 330, y: 470, kind: "milestone" },
  { id: "mile-sys-design", courseId: "sys-design", label: "Design ready for Showdown", subject: "System Design", prerequisites: ["sys-design"], x: 560, y: 300, kind: "milestone" },
  { id: "mile-ai-prompt", courseId: "ai-prompt", label: "Prompt engineer badge", subject: "AI & Automation", prerequisites: ["ai-prompt"], x: 560, y: 120, kind: "milestone" },
];

export const PATH_EDGES: [string, string][] = [
  ["node-comp-fund", "node-ai-prompt"],
  ["node-comp-fund", "node-py-mastery"],
  ["node-py-mastery", "node-sys-design"],
  ["node-sys-design", "mile-sys-design"],
  ["node-ai-prompt", "mile-ai-prompt"],
  ["node-py-mastery", "mile-py-mastery"],
];

export const ACHIEVEMENTS = [
  { id: "first", name: "First Steps", desc: "Complete your first lesson", check: (s: { lessons: number }) => s.lessons >= 1 },
  { id: "consistency", name: "Consistency", desc: "Complete lessons across three days", check: (s: { days: number }) => s.days >= 3 },
  { id: "solver", name: "Problem Solver", desc: "Finish a practical code activity", check: (s: { codePracticals: number }) => s.codePracticals >= 1 },
  { id: "fast", name: "Fast Learner", desc: "Complete a course in under its estimated period", check: (s: { fastCourses: number }) => s.fastCourses >= 1 },
  { id: "master", name: "Course Master", desc: "Complete an entire course", check: (s: { courses: number }) => s.courses >= 1 },
] as const;

export const certificateFor = (student: string, course: Course) => ({
  reference: `CQ-CERT-${course.id.toUpperCase().slice(0, 6)}-${String(Math.abs(hash(student + course.title)) % 100000).padStart(5, "0")}`,
  issued: new Date().toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" }),
});

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
}
