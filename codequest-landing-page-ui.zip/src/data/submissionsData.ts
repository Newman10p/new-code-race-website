/**
 * PROJECT REVIEW & SHOWCASE CENTRE — prototype content layer.
 *
 * Three independent channels share one project:
 *   patron   → private, collaborative feedback
 *   judging  → official, rubric-scored evaluation
 *   showcase → voluntary community sharing
 *
 * Competition setters control every channel through `ChannelConfig`.
 * PROTOTYPE LIMIT: there is no server. The student UI enforces the config
 * and deadlines locally and labels every record as "recorded locally".
 * Unpublished judging results are simply absent from this module, which is
 * the same guarantee the real API must give.
 */

export type ChannelConfig = {
  patron: { enabled: boolean; required: boolean; patronName: string; patronInitials: string; patronRole: string };
  judging: { enabled: boolean; deadline: string; resubmission: boolean; maxVersions: number; videoEnabled: boolean; extraField?: string };
  showcase: { enabled: boolean; comments: boolean; reactions: boolean; ownerCanUnpublish: boolean; anonymousFeedback: boolean };
  files: { types: string[]; maxMb: number; maxFiles: number };
};

export type ProjectCompetition = {
  id: string;
  name: string;
  category: string;
  resultsPublished: boolean;
  config: ChannelConfig;
};

const days = (d: number) => new Date(Date.now() + d * 86400_000).toISOString();

export const projectCompetitions: ProjectCompetition[] = [
  {
    id: "sysdesign-hack",
    name: "System Design Hack: School Portal Scale",
    category: "System Design",
    resultsPublished: false,
    config: {
      patron: { enabled: true, required: false, patronName: "Ms. Aisha Nakato", patronInitials: "AN", patronRole: "ICT Patron · Northview Academy" },
      judging: { enabled: true, deadline: days(6), resubmission: true, maxVersions: 3, videoEnabled: true, extraField: "Expected peak load and how your design handles it" },
      showcase: { enabled: true, comments: true, reactions: true, ownerCanUnpublish: true, anonymousFeedback: false },
      files: { types: ["pdf", "png", "jpg", "jpeg", "zip", "pptx"], maxMb: 25, maxFiles: 8 },
    },
  },
  {
    id: "ticket-locker",
    name: "Distributed Systems Sprint: Ticket Locker",
    category: "System Design",
    resultsPublished: true,
    config: {
      patron: { enabled: true, required: false, patronName: "Ms. Aisha Nakato", patronInitials: "AN", patronRole: "ICT Patron · Northview Academy" },
      judging: { enabled: true, deadline: days(-20), resubmission: false, maxVersions: 1, videoEnabled: false },
      showcase: { enabled: true, comments: true, reactions: true, ownerCanUnpublish: true, anonymousFeedback: false },
      files: { types: ["pdf", "png", "zip"], maxMb: 20, maxFiles: 6 },
    },
  },
  {
    id: "regional-design",
    name: "Regional Qualifier: Attendance Architecture",
    category: "Regional Qualifier",
    resultsPublished: false,
    config: {
      patron: { enabled: true, required: true, patronName: "Mr. Daniel Ochieng", patronInitials: "DO", patronRole: "Regional Patron · Horizon Public" },
      judging: { enabled: true, deadline: days(2), resubmission: false, maxVersions: 1, videoEnabled: false },
      showcase: { enabled: false, comments: false, reactions: false, ownerCanUnpublish: false, anonymousFeedback: false },
      files: { types: ["pdf", "png"], maxMb: 10, maxFiles: 4 },
    },
  },
];

/* ══════════════════ PROJECT RECORDS ══════════════════ */

export type PatronStatus = "NOT SUBMITTED" | "SUBMITTED" | "UNDER REVIEW" | "FEEDBACK AVAILABLE" | "REVISION REQUESTED" | "REVIEW COMPLETED";
export type JudgingStatus = "NOT SUBMITTED" | "SUBMITTED" | "RECEIVED" | "QUEUED FOR JUDGING" | "UNDER EVALUATION" | "JUDGING COMPLETED" | "RESULTS PUBLISHED" | "DISQUALIFIED";

export type FileMeta = { id: string; name: string; size: number; ext: string; addedAt: string };
export type TimelineStep = { label: string; at: string };

export type Version = {
  no: number;
  createdAt: string;
  submittedAt: string | null;
  destination: "draft" | "patron" | "judges";
  reference: string | null;
  changes: string;
  snapshot: { title: string; summary: string; files: number };
};

export type PatronFeedback = {
  at: string;
  overall: string;
  strengths: string[];
  improvements: string[];
  suggestions: string[];
  attachments: string[];
  recommendation: "Revise and resubmit" | "Ready for official judging" | "Minor polish only";
};

export type JudgingResult = {
  score: number;
  maxScore: number;
  rank: number;
  field: number;
  criteria: { name: string; score: number; max: number; comment: string }[];
  comments: string;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  leaderboard: { rank: number; name: string; school: string; score: number; you?: boolean }[];
};

export type CommunityComment = {
  id: string;
  author: string;
  initials: string;
  kind: "comment" | "question" | "feedback";
  category?: "Usability" | "Creativity" | "Technical implementation" | "Presentation";
  body: string;
  at: string;
  helpful: number;
  markedHelpful?: boolean;
  reported?: boolean;
  own?: boolean;
  replies: CommunityComment[];
};

export type Project = {
  id: string;
  competitionId: string;
  title: string;
  summary: string;
  problem: string;
  solution: string;
  technologies: string[];
  team: string[];
  extra: string;
  links: { label: string; url: string }[];
  videoUrl: string;
  files: FileMeta[];
  updatedAt: string;
  versions: Version[];
  patron: { status: PatronStatus; message: string; timeline: TimelineStep[]; feedback?: PatronFeedback };
  judging: { status: JudgingStatus; reference: string | null; submittedAt: string | null; versionNo: number | null; timeline: TimelineStep[]; result?: JudgingResult };
  showcase: {
    published: boolean;
    publishedAt: string | null;
    description: string;
    commentsEnabled: boolean;
    reactions: number;
    reacted: boolean;
    comments: CommunityComment[];
  };
};

const ago = (h: number) => new Date(Date.now() - h * 3600_000).toISOString();

export const seedProjects: Project[] = [
  {
    id: "proj-portal",
    competitionId: "sysdesign-hack",
    title: "School Management Platform",
    summary: "An attendance and grading platform designed to stay responsive at 50,000 concurrent requests during morning registration.",
    problem: "Every school day starts with a traffic spike: thousands of teachers marking attendance in the same ten minutes, while parents check results. Single-server portals collapse under that burst.",
    solution: "A read-heavy architecture with a write queue for attendance, a Redis cache for timetable and results reads, and per-school database partitions so one large school cannot slow the others.",
    technologies: ["PostgreSQL", "Redis", "Node.js", "Message queue", "CDN"],
    team: ["Farid Bulega"],
    extra: "Peak load of ~50k requests/minute at 07:45; attendance writes are queued and acknowledged within 200ms.",
    links: [{ label: "Repository", url: "https://github.com/example/school-portal" }],
    videoUrl: "",
    files: [
      { id: "f1", name: "architecture-overview.pdf", size: 2_400_000, ext: "pdf", addedAt: ago(30) },
      { id: "f2", name: "component-diagram.png", size: 860_000, ext: "png", addedAt: ago(30) },
    ],
    updatedAt: ago(5),
    versions: [
      { no: 1, createdAt: ago(52), submittedAt: ago(48), destination: "patron", reference: "PAT-4F2A91", changes: "Initial architecture for patron review", snapshot: { title: "School Management Platform", summary: "First draft", files: 1 } },
      { no: 2, createdAt: ago(5), submittedAt: null, destination: "draft", reference: null, changes: "Added caching layer and partitioning after patron feedback", snapshot: { title: "School Management Platform", summary: "Revised draft", files: 2 } },
    ],
    patron: {
      status: "REVISION REQUESTED",
      message: "Could you check whether my queue design is overkill for attendance?",
      timeline: [
        { label: "Submitted to patron", at: ago(48) },
        { label: "Patron started reviewing", at: ago(40) },
        { label: "Feedback returned", at: ago(26) },
      ],
      feedback: {
        at: ago(26),
        overall: "A strong foundation with a clear understanding of the morning traffic problem. The queue is justified, but the read path needs the same care as the write path before you submit to the judges.",
        strengths: ["Clear identification of the 07:45 burst as the core constraint", "Queueing attendance writes is a sound, defensible choice", "Diagrams are readable and consistently labelled"],
        improvements: ["No caching strategy for results reads — parents will hammer the database", "Single database instance is a bottleneck for large schools", "Failure handling for the queue is not described"],
        suggestions: ["Add a cache with explicit invalidation when grades change", "Consider partitioning data per school", "Describe what happens when the queue consumer is down"],
        attachments: ["annotated-architecture-v1.pdf"],
        recommendation: "Revise and resubmit",
      },
    },
    judging: { status: "NOT SUBMITTED", reference: null, submittedAt: null, versionNo: null, timeline: [] },
    showcase: { published: false, publishedAt: null, description: "", commentsEnabled: true, reactions: 0, reacted: false, comments: [] },
  },
  {
    id: "proj-ticket",
    competitionId: "ticket-locker",
    title: "Distributed Event Ticket Locker",
    summary: "A seat-reservation service that prevents double-booking with distributed lock leases and automatic expiry.",
    problem: "When a popular school event opens ticketing, hundreds of students click the same seat at once. Naive systems sell one seat twice.",
    solution: "Seats are held with short Redis lock leases; payment confirmation converts a lease into a booking, and expired leases return seats to the pool automatically.",
    technologies: ["Redis", "Go", "PostgreSQL", "gRPC"],
    team: ["Farid Bulega", "Meera D."],
    extra: "",
    links: [{ label: "Live demo", url: "https://example.com/ticket-locker" }],
    videoUrl: "",
    files: [{ id: "f3", name: "ticket-locker-design.pdf", size: 3_100_000, ext: "pdf", addedAt: ago(600) }],
    updatedAt: ago(500),
    versions: [
      { no: 1, createdAt: ago(620), submittedAt: ago(600), destination: "judges", reference: "JDG-7C19E4", changes: "Final submission", snapshot: { title: "Distributed Event Ticket Locker", summary: "Final", files: 1 } },
    ],
    patron: {
      status: "REVIEW COMPLETED",
      message: "",
      timeline: [{ label: "Submitted to patron", at: ago(700) }, { label: "Review completed", at: ago(650) }],
      feedback: {
        at: ago(650),
        overall: "Ready for the judges. The lease expiry logic is the strongest part of this project.",
        strengths: ["Lease expiry prevents abandoned holds", "Concise documentation"],
        improvements: ["Dead-letter handling is only briefly mentioned"],
        suggestions: ["Add a backoff policy diagram"],
        attachments: [],
        recommendation: "Ready for official judging",
      },
    },
    judging: {
      status: "RESULTS PUBLISHED",
      reference: "JDG-7C19E4",
      submittedAt: ago(600),
      versionNo: 1,
      timeline: [
        { label: "Submitted", at: ago(600) },
        { label: "Received by judging service", at: ago(600) },
        { label: "Queued for judging", at: ago(590) },
        { label: "Under evaluation", at: ago(400) },
        { label: "Judging completed", at: ago(200) },
        { label: "Results published", at: ago(120) },
      ],
      result: {
        score: 92,
        maxScore: 100,
        rank: 2,
        field: 41,
        criteria: [
          { name: "Concurrency & lock leases", score: 24, max: 25, comment: "Excellent: lease timeouts are reasoned about explicitly and tested." },
          { name: "Horizontal scaling strategy", score: 23, max: 25, comment: "Good sharding plan; hot-seat contention could be discussed further." },
          { name: "Data model & normalisation", score: 23, max: 25, comment: "Clean schema with sensible constraints." },
          { name: "Documentation & presentation", score: 22, max: 25, comment: "Clear, though the failure scenarios section is thin." },
        ],
        comments: "One of the most rigorous submissions in the field. The team understood the double-booking problem precisely and designed for it.",
        strengths: ["Precise problem framing", "Lease expiry design", "Readable diagrams"],
        weaknesses: ["Dead-letter queue backoff is under-specified", "Limited discussion of regional failover"],
        recommendations: ["Add an exponential backoff policy for retries", "Model what happens when a Redis node fails mid-lease"],
        leaderboard: [
          { rank: 1, name: "Sarah K.", school: "St. Xavier's School", score: 94 },
          { rank: 2, name: "Farid Bulega & Meera D.", school: "Northview Academy", score: 92, you: true },
          { rank: 3, name: "Daniel O.", school: "Horizon Public", score: 89 },
          { rank: 4, name: "Imran K.", school: "Lake City School", score: 86 },
          { rank: 5, name: "Alex M.", school: "Greenfield High", score: 84 },
        ],
      },
    },
    showcase: {
      published: true,
      publishedAt: ago(110),
      description: "A seat-reservation service that never sells the same seat twice. Built with Redis lock leases that expire automatically, so abandoned checkouts free their seats without manual cleanup.",
      commentsEnabled: true,
      reactions: 23,
      reacted: false,
      comments: [
        {
          id: "c1", author: "Sarah K.", initials: "SK", kind: "question", body: "How did you choose the lease duration? Did you test what happens when payment takes longer than the lease?", at: ago(90), helpful: 6,
          replies: [{ id: "c1r1", author: "Farid Bulega", initials: "FB", kind: "comment", body: "We picked 90 seconds from timing real checkouts. If payment runs over, the client renews the lease once — the second renewal is refused.", at: ago(80), helpful: 4, own: true, replies: [] }],
        },
        { id: "c2", author: "Daniel O.", initials: "DO", kind: "feedback", category: "Technical implementation", body: "The expiry approach is really clean. A sequence diagram of the renewal path would make it even easier to follow.", at: ago(60), helpful: 9, replies: [] },
        { id: "c3", author: "Imran K.", initials: "IK", kind: "feedback", category: "Presentation", body: "Great documentation — the problem statement made it immediately clear why this matters.", at: ago(20), helpful: 2, replies: [] },
      ],
    },
  },
  {
    id: "proj-attendance",
    competitionId: "regional-design",
    title: "Attendance Sync Service",
    summary: "Offline-first attendance capture that synchronises reliably when school connectivity returns.",
    problem: "Rural schools lose connectivity for hours; attendance taken offline is often lost or duplicated.",
    solution: "Devices store attendance locally with idempotent record IDs and sync through a conflict-free merge when online.",
    technologies: ["SQLite", "Python", "REST"],
    team: ["Farid Bulega"],
    extra: "",
    links: [],
    videoUrl: "",
    files: [{ id: "f4", name: "sync-protocol.pdf", size: 1_200_000, ext: "pdf", addedAt: ago(70) }],
    updatedAt: ago(30),
    versions: [
      { no: 1, createdAt: ago(75), submittedAt: ago(72), destination: "patron", reference: "PAT-2B8D30", changes: "Required patron review", snapshot: { title: "Attendance Sync Service", summary: "Patron draft", files: 1 } },
      { no: 2, createdAt: ago(32), submittedAt: ago(30), destination: "judges", reference: "JDG-91AA0C", changes: "Official submission", snapshot: { title: "Attendance Sync Service", summary: "Final", files: 1 } },
    ],
    patron: {
      status: "REVIEW COMPLETED",
      message: "",
      timeline: [{ label: "Submitted to patron", at: ago(72) }, { label: "Review completed", at: ago(40) }],
      feedback: {
        at: ago(40),
        overall: "Approved for the regional qualifier. Idempotent record IDs are exactly the right call.",
        strengths: ["Idempotency handled correctly"],
        improvements: ["Clarify clock-skew handling"],
        suggestions: ["Use server timestamps as the merge authority"],
        attachments: [],
        recommendation: "Ready for official judging",
      },
    },
    judging: {
      status: "UNDER EVALUATION",
      reference: "JDG-91AA0C",
      submittedAt: ago(30),
      versionNo: 2,
      timeline: [
        { label: "Submitted", at: ago(30) },
        { label: "Received by judging service", at: ago(30) },
        { label: "Queued for judging", at: ago(24) },
        { label: "Under evaluation", at: ago(6) },
      ],
    },
    showcase: { published: false, publishedAt: null, description: "", commentsEnabled: false, reactions: 0, reacted: false, comments: [] },
  },
];

export const competitionById = (id: string) => projectCompetitions.find((c) => c.id === id);

export const formatBytes = (n: number) =>
  n >= 1_000_000 ? `${(n / 1_000_000).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1000))} KB`;

export const when = (iso: string) =>
  new Intl.DateTimeFormat(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(iso));

export const makeReference = (prefix: "PAT" | "JDG") =>
  `${prefix}-${Math.random().toString(16).slice(2, 8).toUpperCase()}`;
