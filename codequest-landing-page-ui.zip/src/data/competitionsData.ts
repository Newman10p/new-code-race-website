/**
 * COMPETITION ARENA — published competition records (prototype content layer).
 *
 * These mirror the shape the real service will return: publication status,
 * server-authoritative timestamps, per-competition rules and scoring config,
 * rounds, and question definitions.
 *
 * PROTOTYPE LIMIT (stated honestly in the UI):
 *  • MCQ answer keys and hidden test expectations ship inside this module.
 *    In production they never reach the browser — the server evaluates.
 *  • There is no server, so "server time" is a simulated handshake offset.
 */

export type Accent = "blue" | "cyan" | "violet" | "amber" | "mint" | "danger";

export const accentVar: Record<Accent, string> = {
  blue: "#4D9CFF",
  cyan: "#5DD3C5",
  violet: "#AA8CFF",
  amber: "#F2C94C",
  mint: "#5DD39E",
  danger: "#FF6B6B",
};

export type QuestionKind = "mcq" | "text" | "code";

export type McqQuestion = {
  id: string;
  kind: "mcq";
  title: string;
  points: number;
  options: string[];
  /** PROTOTYPE ONLY — server-side in production. */
  correctIndex: number;
  explanation?: string;
};

export type TextQuestion = {
  id: string;
  kind: "text";
  title: string;
  points: number;
  prompt: string;
  wordLimit: number;
  requirements: string[];
  rubric: string[];
};

export type CodeQuestion = {
  id: string;
  kind: "code";
  title: string;
  points: number;
  scenario: string;
  statement: string;
  inputFormat: string;
  outputFormat: string;
  constraints: string[];
  examples: { input: string; output: string }[];
  languages: string[];
  /** Languages this prototype can actually execute. */
  runnable: string[];
  starter: Record<string, string>;
  visibleTests: { name: string; args: unknown[]; expected: unknown }[];
  hiddenTestCount: number;
  marking: string[];
};

export type ArenaQuestion = McqQuestion | TextQuestion | CodeQuestion;

export type Round = {
  id: string;
  name: string;
  blurb: string;
  durationMinutes: number;
  questions: ArenaQuestion[];
  /** Minutes after competition start before this round unlocks. */
  unlocksAtMinute: number;
};

export type Rules = {
  revisitQuestions: boolean;
  changeAnswers: boolean;
  fixedOrder: boolean;
  progressiveRelease: boolean;
  autoUnlockRounds: boolean;
  submitEarly: boolean;
  showHiddenTests: boolean;
  graceMinutes: number;
  acceptLate: boolean;
  externalResources: boolean;
  leaderboard: "public" | "private";
  monitoring: string[];
  deviceRequirement?: string;
};

export type TimelineEntry = { label: string; at: string; state: "past" | "current" | "future" };

export type Competition = {
  id: string;
  title: string;
  shortDescription: string;
  description: string[];
  category: string;
  difficulty: "All divisions" | "Junior" | "Senior" | "Invitation only";
  accent: Accent;
  publication_status: "published" | "draft" | "cancelled";
  /** Absolute server timestamps, resolved once and persisted. */
  starts_at: string;
  ends_at: string;
  registration_opens: string;
  registration_closes: string;
  waiting_room_opens: string;
  results_at: string | null;
  durationMinutes: number;
  rounds: Round[];
  rules: Rules;
  scoring: string[];
  eligibility: string[];
  languages: string[];
  totalPoints: number;
  registeredCount: number;
  schoolCount: number;
  resultsPublished: boolean;
  studentRegistered: boolean;
  studentEligible: boolean;
  /** Deviations injected by competition control (delay / cancellation). */
  control?: { kind: "delayed" | "cancelled"; note: string; revisedStart?: string };
  waitingRoomAnnouncements: { at: string; text: string; tone: Accent }[];
  participants: { name: string; school: string; ready: boolean }[];
  leaderboard?: { name: string; school: string; score: number; tieBreak: string; delta: number }[];
  studentResult?: {
    score: number;
    rank: number;
    totalParticipants: number;
    accuracy: number;
    completionMinutes: number;
    mcq: { correct: number; total: number };
    written: { awarded: number; total: number };
    coding: { awarded: number; total: number };
    perRound: { round: string; score: number; total: number }[];
    personalBest: boolean;
    previousScore: number;
  };
};

/** Resolved once so refreshing resumes the true remaining time. */
export function resolveSchedule(now: number): Record<string, { starts_at: string; ends_at: string }> {
  return {
    "algorithm-masters": {
      starts_at: new Date(now + 3 * 60_000).toISOString(),
      ends_at: new Date(now + 3 * 60_000 + 45 * 60_000).toISOString(),
    },
    "cq-national": {
      starts_at: new Date(now - 42 * 60_000).toISOString(),
      ends_at: new Date(now + 78 * 60_000).toISOString(),
    },
    "logic-league": {
      starts_at: new Date(now + 4 * 24 * 3600_000).toISOString(),
      ends_at: new Date(now + 4 * 24 * 3600_000 + 90 * 60_000).toISOString(),
    },
    "frontend-innovation": {
      starts_at: new Date(now + 9 * 24 * 3600_000).toISOString(),
      ends_at: new Date(now + 9 * 24 * 3600_000 + 120 * 60_000).toISOString(),
    },
    "python-tournament": {
      starts_at: new Date(now - 6 * 24 * 3600_000).toISOString(),
      ends_at: new Date(now - 6 * 24 * 3600_000 + 75 * 60_000).toISOString(),
    },
    "system-design-showdown": {
      starts_at: new Date(now - 11 * 24 * 3600_000).toISOString(),
      ends_at: new Date(now - 11 * 24 * 3600_000 + 180 * 60_000).toISOString(),
    },
    "unpublished-draft": {
      starts_at: new Date(now + 30 * 24 * 3600_000).toISOString(),
      ends_at: new Date(now + 30 * 24 * 3600_000 + 60 * 60_000).toISOString(),
    },
  };
}

/* ══════════════════ ROUNDS ══════════════════ */

const ALGORITHM_ROUND_1: Round = {
  id: "am-r1",
  name: "Round 1 — Qualifier",
  blurb: "Six questions across reasoning, written explanation and one implementation task.",
  durationMinutes: 25,
  unlocksAtMinute: 0,
  questions: [
    {
      id: "am-q1",
      kind: "mcq",
      title: "Complexity of binary search",
      points: 10,
      options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
      correctIndex: 1,
      explanation: "Each comparison halves the remaining search space, giving logarithmic time.",
    },
    {
      id: "am-q2",
      kind: "mcq",
      title: "First-In, First-Out structure",
      points: 10,
      options: ["Stack", "Queue", "Binary tree", "Hash map"],
      correctIndex: 1,
      explanation: "A queue serves the earliest arrival first; a stack is LIFO.",
    },
    {
      id: "am-q3",
      kind: "mcq",
      title: "Worst case of quicksort",
      points: 15,
      options: ["O(n)", "O(n log n)", "O(n²)", "O(log n)"],
      correctIndex: 2,
      explanation: "A consistently poor pivot degrades partitioning to quadratic time.",
    },
    {
      id: "am-q4",
      kind: "text",
      title: "Explain the difference",
      points: 20,
      prompt:
        "Explain the difference between a stack and a queue. Include one practical example of where each could be used in a real system.",
      wordLimit: 250,
      requirements: [
        "Name the ordering principle of each structure.",
        "Give one concrete system example per structure.",
        "Stay within 250 words.",
      ],
      rubric: [
        "Correct ordering principles — 8 points",
        "Practical examples that fit the structures — 8 points",
        "Clarity and precision — 4 points",
      ],
    },
    {
      id: "am-q5",
      kind: "mcq",
      title: "Detecting a cycle in a directed graph",
      points: 15,
      options: [
        "Breadth-first search only",
        "Three-colour depth-first search",
        "Binary search on edges",
        "Union-find is impossible here",
      ],
      correctIndex: 1,
      explanation: "A back edge to a node still on the current DFS stack proves a cycle.",
    },
    {
      id: "am-q6",
      kind: "code",
      title: "Sliding window maximum",
      points: 40,
      scenario:
        "A sensor array streams readings. Your task reports the peak reading inside every fixed-width window as it slides across the stream.",
      statement:
        "Given an array nums and a window size k, return an array containing the maximum value of each contiguous window of length k, in order.",
      inputFormat: "solve(nums, k) — nums is an array of integers, k >= 1 and k <= nums.length.",
      outputFormat: "An array of integers, length nums.length - k + 1.",
      constraints: [
        "1 <= k <= nums.length <= 10^5",
        "-10^4 <= nums[i] <= 10^4",
        "A naive O(n·k) scan will not pass the timing test",
      ],
      examples: [
        { input: "nums = [1, 3, -1, -3, 5, 3, 6, 7], k = 3", output: "[3, 3, 5, 5, 6, 7]" },
        { input: "nums = [1], k = 1", output: "[1]" },
      ],
      languages: ["javascript", "python"],
      runnable: ["javascript"],
      starter: {
        javascript: `function solve(nums, k) {
  // TODO: return the maximum of every window of size k
}
`,
        python: `def solve(nums, k):
    # TODO: return the maximum of every window of size k
    pass
`,
      },
      visibleTests: [
        { name: "Sample 1", args: [[1, 3, -1, -3, 5, 3, 6, 7], 3], expected: [3, 3, 5, 5, 6, 7] },
        { name: "Sample 2", args: [[1], 1], expected: [1] },
      ],
      hiddenTestCount: 6,
      marking: [
        "Visible samples are worth 30% of the 40 points.",
        "Six hidden tests are worth 70% and include the maximum-size timing case.",
        "Partial credit is awarded per passing test.",
      ],
    },
  ],
};

const ALGORITHM_ROUND_2: Round = {
  id: "am-r2",
  name: "Round 2 — Pressure Round",
  blurb: "Unlocks 25 minutes after the competition start.",
  durationMinutes: 20,
  unlocksAtMinute: 25,
  questions: [
    {
      id: "am-r2-q1",
      kind: "mcq",
      title: "Heap property after extraction",
      points: 15,
      options: [
        "The array is re-sorted",
        "The root is replaced and sifted down",
        "Nothing changes",
        "The heap becomes a binary search tree",
      ],
      correctIndex: 1,
      explanation: "Extract-min moves the last element to the root, then sifts it down.",
    },
    {
      id: "am-r2-q2",
      kind: "code",
      title: "Merge overlapping intervals",
      points: 45,
      scenario:
        "The scheduling office stores meeting windows as intervals. Overlapping bookings must be merged before the room list is published.",
      statement:
        "Given a list of intervals [start, end], merge all overlapping intervals and return the result sorted by start time.",
      inputFormat: "solve(intervals) — an array of two-element arrays.",
      outputFormat: "An array of merged two-element arrays.",
      constraints: [
        "1 <= intervals.length <= 10^4",
        "0 <= start <= end <= 10^5",
        "Intervals may arrive unsorted",
      ],
      examples: [
        { input: "[[1,3],[2,6],[8,10],[15,18]]", output: "[[1,6],[8,10],[15,18]]" },
        { input: "[[1,4],[4,5]]", output: "[[1,5]]" },
      ],
      languages: ["javascript", "python"],
      runnable: ["javascript"],
      starter: {
        javascript: `function solve(intervals) {
  // TODO: merge overlapping intervals
}
`,
        python: `def solve(intervals):
    # TODO: merge overlapping intervals
    pass
`,
      },
      visibleTests: [
        { name: "Sample 1", args: [[[1, 3], [2, 6], [8, 10], [15, 18]]], expected: [[1, 6], [8, 10], [15, 18]] },
        { name: "Sample 2", args: [[[1, 4], [4, 5]]], expected: [[1, 5]] },
      ],
      hiddenTestCount: 5,
      marking: [
        "Touching intervals (end equals next start) must merge — that is a hidden test.",
        "Unsorted input is a hidden test worth 15 points.",
      ],
    },
  ],
};

/* ══════════════════ SHARED RULE PRESETS ══════════════════ */

const strictRules: Rules = {
  revisitQuestions: true,
  changeAnswers: true,
  fixedOrder: true,
  progressiveRelease: false,
  autoUnlockRounds: true,
  submitEarly: true,
  showHiddenTests: false,
  graceMinutes: 2,
  acceptLate: false,
  externalResources: false,
  leaderboard: "public",
  monitoring: [
    "Submission timestamps recorded",
    "Question navigation log kept for review",
    "Code execution records retained",
    "Unusual activity flagged for authorised review",
  ],
  deviceRequirement:
    "The coding round needs a keyboard and a screen of at least 1024px wide. You can read questions on a phone, but code comfortably on a laptop.",
};

/* ══════════════════ COMPETITIONS ══════════════════ */

export const competitionsSeed: Omit<Competition, "starts_at" | "ends_at">[] = [
  {
    id: "algorithm-masters",
    title: "Algorithm Masters",
    shortDescription:
      "A fast two-round reasoning and implementation tournament. Qualifier now, pressure round at the half-hour mark.",
    description: [
      "Algorithm Masters is CodeQuest's core individual tournament: short rounds, hard constraints and no partial hints. Round 1 tests reasoning and one implementation task. Round 2 opens 25 minutes after the start and raises the difficulty.",
      "The objective is not just to pass — it is to pass efficiently. Several questions carry timing tests that reject brute force.",
    ],
    category: "Algorithms",
    difficulty: "Senior",
    accent: "blue",
    publication_status: "published",
    registration_opens: new Date(Date.now() - 12 * 24 * 3600_000).toISOString(),
    registration_closes: new Date(Date.now() - 3600_000).toISOString(),
    waiting_room_opens: new Date(Date.now() - 30 * 60_000).toISOString(),
    results_at: new Date(Date.now() + 3600_000).toISOString(),
    durationMinutes: 45,
    rounds: [ALGORITHM_ROUND_1, ALGORITHM_ROUND_2],
    rules: strictRules,
    scoring: [
      "110 points available in Round 1, 60 in Round 2.",
      "Coding questions award partial credit per passing test.",
      "Hidden tests are graded server-side; only your visible run is shown live.",
      "Ties are broken by total completion time.",
    ],
    eligibility: [
      "Verified students of partner schools.",
      "Senior division (Grades 10–12).",
      "Individual entry only — no team submissions.",
    ],
    languages: ["JavaScript", "Python 3"],
    totalPoints: 170,
    registeredCount: 214,
    schoolCount: 19,
    resultsPublished: false,
    studentRegistered: true,
    studentEligible: true,
    waitingRoomAnnouncements: [
      { at: new Date(Date.now() - 12 * 60_000).toISOString(), text: "Waiting room open. Your seat is confirmed — check the rules panel before the countdown ends.", tone: "blue" },
      { at: new Date(Date.now() - 4 * 60_000).toISOString(), text: "Reminder: Round 2 unlocks automatically 25 minutes after start. Do not submit early expecting to skip it.", tone: "amber" },
      { at: new Date(Date.now() - 60_000).toISOString(), text: "Judges are online. External resources are not permitted; the attempt log is retained.", tone: "blue" },
    ],
    participants: [
      { name: "Farid Bulega", school: "Northview Academy", ready: true },
      { name: "Sarah K.", school: "St. Xavier's School", ready: true },
      { name: "Daniel O.", school: "Horizon Public", ready: true },
      { name: "Meera D.", school: "Northview Academy", ready: false },
      { name: "Imran K.", school: "Lake City School", ready: true },
      { name: "Alex M.", school: "Greenfield High", ready: false },
    ],
  },
  {
    id: "cq-national",
    title: "CodeQuest National Coding Championship",
    shortDescription:
      "Season 01's flagship event — already underway. Three rounds, live leaderboard, judged system design finale.",
    description: [
      "The National Championship is the flagship competition of Season 01. Round 1 is a qualifier, Round 2 narrows the field, and the final round is a judged system design submission.",
      "This event started 42 minutes ago. Late entry is not accepted, so the arena shows the current state rather than offering you a seat.",
    ],
    category: "Championship",
    difficulty: "All divisions",
    accent: "blue",
    publication_status: "published",
    registration_opens: new Date(Date.now() - 30 * 24 * 3600_000).toISOString(),
    registration_closes: new Date(Date.now() - 3 * 24 * 3600_000).toISOString(),
    waiting_room_opens: new Date(Date.now() - 3 * 3600_000).toISOString(),
    results_at: new Date(Date.now() + 2 * 24 * 3600_000).toISOString(),
    durationMinutes: 120,
    rounds: [ALGORITHM_ROUND_1],
    rules: { ...strictRules, revisitQuestions: false, changeAnswers: false, acceptLate: false, monitoring: [...strictRules.monitoring, "Round lock enforced server-side"] },
    scoring: [
      "300 points across three rounds.",
      "The final round is judged against four published rubrics.",
      "Live leaderboard updates as submissions are graded.",
    ],
    eligibility: ["All verified students", "Registered before the close date", "One attempt per student"],
    languages: ["Python 3", "C++20", "Java 17", "JavaScript", "TypeScript"],
    totalPoints: 300,
    registeredCount: 342,
    schoolCount: 24,
    resultsPublished: false,
    studentRegistered: true,
    studentEligible: true,
    waitingRoomAnnouncements: [],
    participants: [],
  },
  {
    id: "logic-league",
    title: "The Logic League",
    shortDescription:
      "Reasoning-first league for younger divisions. Puzzles, proofs and short written justifications.",
    description: [
      "The Logic League favours clear reasoning over fast typing. Most questions are multiple choice or short written justifications, with one light implementation task per round.",
      "Registration is open and closes four days before the event.",
    ],
    category: "Problem Solving",
    difficulty: "Junior",
    accent: "amber",
    publication_status: "published",
    registration_opens: new Date(Date.now() - 5 * 24 * 3600_000).toISOString(),
    registration_closes: new Date(Date.now() + 3 * 24 * 3600_000).toISOString(),
    waiting_room_opens: new Date(Date.now() + 4 * 24 * 3600_000 - 3600_000).toISOString(),
    results_at: new Date(Date.now() + 5 * 24 * 3600_000).toISOString(),
    durationMinutes: 60,
    rounds: [ALGORITHM_ROUND_1],
    rules: { ...strictRules, externalResources: false, showHiddenTests: false, graceMinutes: 5, deviceRequirement: undefined },
    scoring: ["150 points", "Written answers graded against a published rubric", "No negative marking"],
    eligibility: ["Junior division (Grades 7–9)", "Partner schools", "Individual entry"],
    languages: ["Python 3", "JavaScript"],
    totalPoints: 150,
    registeredCount: 96,
    schoolCount: 12,
    resultsPublished: false,
    studentRegistered: false,
    studentEligible: false,
    waitingRoomAnnouncements: [],
    participants: [],
  },
  {
    id: "frontend-innovation",
    title: "Frontend Innovation Challenge",
    shortDescription:
      "Build a small interface against a brief. Judged on craft, accessibility and behaviour — not speed.",
    description: [
      "Teams receive a short brief and produce a working interface. Judging weighs accessibility, interaction quality and code organisation.",
      "Registration for this edition has closed. The brief becomes visible when the waiting room opens.",
    ],
    category: "Frontend",
    difficulty: "Senior",
    accent: "cyan",
    publication_status: "published",
    registration_opens: new Date(Date.now() - 20 * 24 * 3600_000).toISOString(),
    registration_closes: new Date(Date.now() - 2 * 24 * 3600_000).toISOString(),
    waiting_room_opens: new Date(Date.now() + 9 * 24 * 3600_000 - 7200_000).toISOString(),
    results_at: new Date(Date.now() + 11 * 24 * 3600_000).toISOString(),
    durationMinutes: 120,
    rounds: [ALGORITHM_ROUND_1],
    rules: { ...strictRules, externalResources: true, leaderboard: "private", monitoring: ["Submission timestamps recorded", "Judged rubric scoring"] },
    scoring: ["Judged across four rubrics: craft, accessibility, behaviour, structure", "No live leaderboard — results are private until publication"],
    eligibility: ["Teams of 2–4 from one school", "Registration closed"],
    languages: ["JavaScript", "TypeScript", "HTML", "CSS"],
    totalPoints: 100,
    registeredCount: 48,
    schoolCount: 14,
    resultsPublished: false,
    studentRegistered: false,
    studentEligible: true,
    waitingRoomAnnouncements: [],
    participants: [],
  },
  {
    id: "python-tournament",
    title: "Python Problem Solving Tournament",
    shortDescription:
      "Completed six days ago. Results published — full review of your answers and code is available.",
    description: [
      "A Python-focused tournament covering data handling, algorithmic thinking and one debugging task.",
      "Results are published and question review is enabled, so you can compare your submission against the reference solutions.",
    ],
    category: "Python",
    difficulty: "All divisions",
    accent: "mint",
    publication_status: "published",
    registration_opens: new Date(Date.now() - 24 * 24 * 3600_000).toISOString(),
    registration_closes: new Date(Date.now() - 7 * 24 * 3600_000).toISOString(),
    waiting_room_opens: new Date(Date.now() - 6 * 24 * 3600_000 - 3600_000).toISOString(),
    results_at: new Date(Date.now() - 5 * 24 * 3600_000).toISOString(),
    durationMinutes: 75,
    rounds: [ALGORITHM_ROUND_1],
    rules: { ...strictRules, showHiddenTests: true },
    scoring: ["200 points", "Partial credit per test", "Accuracy and completion time published"],
    eligibility: ["All verified students", "Individual entry"],
    languages: ["Python 3"],
    totalPoints: 200,
    registeredCount: 188,
    schoolCount: 18,
    resultsPublished: true,
    studentRegistered: true,
    studentEligible: true,
    waitingRoomAnnouncements: [],
    participants: [],
    leaderboard: [
      { name: "Alex M.", school: "Greenfield High", score: 192, tieBreak: "58m 12s", delta: 0 },
      { name: "Sarah K.", school: "St. Xavier's School", score: 186, tieBreak: "61m 40s", delta: 2 },
      { name: "Farid Bulega", school: "Northview Academy", score: 171, tieBreak: "64m 05s", delta: 1 },
      { name: "Daniel O.", school: "Horizon Public", score: 168, tieBreak: "66m 30s", delta: -2 },
      { name: "Meera D.", school: "Northview Academy", score: 154, tieBreak: "68m 51s", delta: 0 },
      { name: "Imran K.", school: "Lake City School", score: 149, tieBreak: "70m 02s", delta: -1 },
    ],
    studentResult: {
      score: 171,
      rank: 3,
      totalParticipants: 188,
      accuracy: 86,
      completionMinutes: 64,
      mcq: { correct: 4, total: 5 },
      written: { awarded: 16, total: 20 },
      coding: { awarded: 32, total: 40 },
      perRound: [{ round: "Round 1 — Qualifier", score: 171, total: 200 }],
      personalBest: true,
      previousScore: 148,
    },
  },
  {
    id: "system-design-showdown",
    title: "System Design Showdown",
    shortDescription:
      "Completed eleven days ago. Results are still under jury review — publication pending.",
    description: [
      "Participants designed an attendance and grading architecture for a 50,000-request school portal.",
      "The jury is still scoring submissions, so review and standings are not yet available.",
    ],
    category: "System Design",
    difficulty: "Invitation only",
    accent: "violet",
    publication_status: "published",
    registration_opens: new Date(Date.now() - 40 * 24 * 3600_000).toISOString(),
    registration_closes: new Date(Date.now() - 13 * 24 * 3600_000).toISOString(),
    waiting_room_opens: new Date(Date.now() - 11 * 24 * 3600_000 - 7200_000).toISOString(),
    results_at: new Date(Date.now() + 2 * 24 * 3600_000).toISOString(),
    durationMinutes: 180,
    rounds: [ALGORITHM_ROUND_1],
    rules: { ...strictRules, leaderboard: "private", showHiddenTests: false, monitoring: ["Judged rubric scoring", "Submission timestamps recorded"] },
    scoring: ["Judged across four rubrics", "Results withheld until jury sign-off"],
    eligibility: ["Invitation only", "Senior division"],
    languages: ["Architecture spec", "Python", "TypeScript"],
    totalPoints: 100,
    registeredCount: 62,
    schoolCount: 11,
    resultsPublished: false,
    studentRegistered: true,
    studentEligible: true,
    waitingRoomAnnouncements: [],
    participants: [],
  },
  {
    id: "unpublished-draft",
    title: "Winter Invitational (draft)",
    shortDescription:
      "Internal draft record. Publication status is draft, so it must never appear in the student lobby.",
    description: ["This record exists to verify the visibility rule: only published competitions reach students."],
    category: "Championship",
    difficulty: "All divisions",
    accent: "blue",
    publication_status: "draft",
    registration_opens: new Date(Date.now() + 20 * 24 * 3600_000).toISOString(),
    registration_closes: new Date(Date.now() + 27 * 24 * 3600_000).toISOString(),
    waiting_room_opens: new Date(Date.now() + 30 * 24 * 3600_000).toISOString(),
    results_at: null,
    durationMinutes: 90,
    rounds: [],
    rules: strictRules,
    scoring: [],
    eligibility: [],
    languages: [],
    totalPoints: 0,
    registeredCount: 0,
    schoolCount: 0,
    resultsPublished: false,
    studentRegistered: false,
    studentEligible: false,
    waitingRoomAnnouncements: [],
    participants: [],
  },
];

/* ══════════════════ DERIVED HELPERS ══════════════════ */

export type ArenaPhase = "lobby" | "details" | "waiting" | "live" | "completed" | "results";

export function phaseFor(c: Competition, now: number, attemptSubmitted: boolean): ArenaPhase {
  if (c.publication_status === "cancelled") return "lobby";
  const start = new Date(c.starts_at).getTime();
  const end = new Date(c.ends_at).getTime();
  const graceEnd = end + c.rules.graceMinutes * 60_000;
  if (c.resultsPublished) return "results";
  if (attemptSubmitted) return "completed";
  if (now >= start && now <= graceEnd) return "live";
  if (now >= new Date(c.waiting_room_opens).getTime() && now < start) return "waiting";
  if (now > graceEnd) return "completed";
  return "lobby";
}

export function countdownParts(ms: number) {
  const clamped = Math.max(0, ms);
  return {
    hours: Math.floor(clamped / 3600_000),
    minutes: Math.floor((clamped % 3600_000) / 60_000),
    seconds: Math.floor((clamped % 60_000) / 1000),
    totalSeconds: Math.floor(clamped / 1000),
    done: clamped <= 0,
  };
}

export const dateLong = (iso: string) =>
  new Intl.DateTimeFormat(undefined, {
    weekday: "short", day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
  }).format(new Date(iso));

export const timeShort = (iso: string) =>
  new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit" }).format(new Date(iso));

export const CHECKLIST = [
  "Review competition rules",
  "Confirm your display name",
  "Check your internet connection",
  "Confirm the competition language requirements",
  "Ensure your device is ready",
];
