export type StudentProfile = {
  name: string;
  avatarText: string;
  role: string;
  school: string;
  grade: string;
  studentId: string;
  xp: number;
  level: number;
  nextLevelXp: number;
  schoolRank: number;
  schoolTotal: number;
  regionalRank: number;
  streakDays: number;
  weeklyStreak: { day: string; active: boolean; today?: boolean }[];
  problemsSolved: number;
  problemsTotal: number;
  acceptedSubmissions: number;
  acceptanceRate: string;
};

export const currentStudent: StudentProfile = {
  name: "Farid Bulega",
  avatarText: "FB",
  role: "Student Competitor",
  school: "Northview Academy",
  grade: "Grade 11 · Senior Division",
  studentId: "CQ-2026-904",
  xp: 2840,
  level: 6,
  nextLevelXp: 3500,
  schoolRank: 14,
  schoolTotal: 80,
  regionalRank: 42,
  streakDays: 7,
  weeklyStreak: [
    { day: "M", active: true },
    { day: "T", active: true },
    { day: "W", active: true },
    { day: "T", active: true },
    { day: "F", active: true },
    { day: "S", active: true },
    { day: "S", active: true, today: true },
  ],
  problemsSolved: 86,
  problemsTotal: 150,
  acceptedSubmissions: 114,
  acceptanceRate: "76.4%",
};

export type Course = {
  id: string;
  track: string;
  title: string;
  description: string;
  progressPercent: number;
  currentLessonNum: number;
  totalLessons: number;
  currentLessonTitle: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  estimatedHours: string;
  enrolled: boolean;
  syllabus: { chapter: string; lessons: { title: string; completed: boolean; duration: string }[] }[];
};

export const coursesData: Course[] = [
  {
    id: "py-fundamentals",
    track: "Language Mastery",
    title: "Python Fundamentals & Data Structures",
    description: "Master list comprehensions, recursion, heaps, and tree traversal in idiomatic Python 3 for competition speed.",
    progressPercent: 78,
    currentLessonNum: 8,
    totalLessons: 10,
    currentLessonTitle: "Loops, Recursion & Stack Frames",
    difficulty: "Intermediate",
    estimatedHours: "14h total · 2.5h left",
    enrolled: true,
    syllabus: [
      {
        chapter: "Chapter 1: Execution Model & Complexity",
        lessons: [
          { title: "Big-O in Python internals (Dict vs List)", completed: true, duration: "25 min" },
          { title: "Memory references & mutable defaults", completed: true, duration: "30 min" },
        ],
      },
      {
        chapter: "Chapter 2: Sequences, Slices & Comprehensions",
        lessons: [
          { title: "Two-pointer slice patterns", completed: true, duration: "35 min" },
          { title: "Nested generator pipelines", completed: true, duration: "40 min" },
          { title: "Heapq & Priority Queues", completed: true, duration: "30 min" },
        ],
      },
      {
        chapter: "Chapter 3: Recursive Decomposition",
        lessons: [
          { title: "Call stack mechanics & tail recursion", completed: true, duration: "45 min" },
          { title: "Backtracking template for permutations", completed: true, duration: "50 min" },
          { title: "Loops, Recursion & Stack Frames", completed: false, duration: "45 min" },
          { title: "Memoization & LRU Cache", completed: false, duration: "40 min" },
          { title: "Final Practice Contest", completed: false, duration: "60 min" },
        ],
      },
    ],
  },
  {
    id: "comp-algorithms",
    track: "Algorithms & DS",
    title: "Competitive Problem Solving 101",
    description: "Binary search on answers, dynamic programming state formulation, and graph traversal for speed under pressure.",
    progressPercent: 42,
    currentLessonNum: 5,
    totalLessons: 12,
    currentLessonTitle: "Dijkstra & Shortest Path Variants",
    difficulty: "Advanced",
    estimatedHours: "20h total · 11h left",
    enrolled: true,
    syllabus: [
      {
        chapter: "Chapter 1: Search & Invariants",
        lessons: [
          { title: "Binary search on monotonic predicates", completed: true, duration: "40 min" },
          { title: "Prefix sums & difference arrays", completed: true, duration: "35 min" },
        ],
      },
      {
        chapter: "Chapter 2: Graphs & Trees",
        lessons: [
          { title: "BFS for unweighted shortest paths", completed: true, duration: "45 min" },
          { title: "DFS & topological sort", completed: true, duration: "50 min" },
          { title: "Dijkstra & Shortest Path Variants", completed: false, duration: "55 min" },
          { title: "Disjoint Set Union (DSU)", completed: false, duration: "45 min" },
        ],
      },
    ],
  },
  {
    id: "sys-design",
    track: "System Design",
    title: "System Design for Inter-School Challenges",
    description: "Architect school portals, event ticket queues, and distributed key-value stores with clear trade-offs and schemas.",
    progressPercent: 20,
    currentLessonNum: 2,
    totalLessons: 8,
    currentLessonTitle: "Database Normalization & Indexing",
    difficulty: "Intermediate",
    estimatedHours: "16h total · 13h left",
    enrolled: true,
    syllabus: [
      {
        chapter: "Chapter 1: Architectural Foundations",
        lessons: [
          { title: "Client-Server & REST / RPC boundaries", completed: true, duration: "40 min" },
          { title: "Database Normalization & Indexing", completed: false, duration: "50 min" },
        ],
      },
    ],
  },
  {
    id: "cpp-mastery",
    track: "Language Mastery",
    title: "C++ STL for Fast Competitive I/O",
    description: "Fast I/O, vector sizing, map vs unordered_map collisions, bitmasks, and cache-conscious data structures.",
    progressPercent: 0,
    currentLessonNum: 0,
    totalLessons: 8,
    currentLessonTitle: "Fast I/O & Memory Layout",
    difficulty: "Intermediate",
    estimatedHours: "10h total",
    enrolled: false,
    syllabus: [],
  },
];

export type PracticeProblem = {
  id: string;
  title: string;
  category: "Algorithms" | "Data Structures" | "System Design" | "Debugging" | "Math";
  difficulty: "Easy" | "Medium" | "Hard";
  points: number;
  acceptanceRate: string;
  status: "Solved" | "Attempted" | "Todo";
  tags: string[];
  description: string;
  starterCode: {
    python: string;
    cpp: string;
    java: string;
    typescript: string;
  };
  sampleTestCases: {
    input: string;
    expected: string;
  }[];
  constraints: string[];
  hints: string[];
};

export const dailyChallengeProblem: PracticeProblem = {
  id: "daily-two-sum-2",
  title: "Two Sum II — Input Array Is Sorted",
  category: "Algorithms",
  difficulty: "Easy",
  points: 50,
  acceptanceRate: "82.4%",
  status: "Todo",
  tags: ["Array", "Two Pointers", "Binary Search"],
  description: `Given a 1-indexed array of integers \`numbers\` that is already sorted in non-decreasing order, find two numbers such that they add up to a specific \`target\` number.

Return the indices of the two numbers, \`index1\` and \`index2\`, added by one as an integer array \`[index1, index2]\` of length 2.

The tests are generated such that there is exactly one solution. You may not use the same element twice. Your solution must use only constant extra space $O(1)$.`,
  constraints: [
    "2 <= numbers.length <= 3 * 10^4",
    "-1000 <= numbers[i] <= 1000",
    "numbers is sorted in non-decreasing order.",
    "-1000 <= target <= 1000",
    "The tests are generated such that there is exactly one solution.",
  ],
  hints: [
    "Since the array is sorted, think about two pointers starting from opposite ends.",
    "If numbers[left] + numbers[right] > target, how do you reduce the sum?",
    "If the sum is too small, advance the left pointer.",
  ],
  starterCode: {
    python: `def two_sum(numbers: list[int], target: int) -> list[int]:
    # Write your solution here
    left, right = 0, len(numbers) - 1
    while left < right:
        curr = numbers[left] + numbers[right]
        if curr == target:
            return [left + 1, right + 1]
        elif curr < target:
            left += 1
        else:
            right -= 1
    return []
`,
    cpp: `class Solution {
public:
    vector<int> twoSum(vector<int>& numbers, int target) {
        int left = 0, right = numbers.size() - 1;
        while (left < right) {
            int sum = numbers[left] + numbers[right];
            if (sum == target) return {left + 1, right + 1};
            if (sum < target) left++;
            else right--;
        }
        return {};
    }
};`,
    java: `class Solution {
    public int[] twoSum(int[] numbers, int target) {
        int left = 0, right = numbers.length - 1;
        while (left < right) {
            int sum = numbers[left] + numbers[right];
            if (sum == target) return new int[]{left + 1, right + 1};
            if (sum < target) left++;
            else right--;
        }
        return new int[]{};
    }
}`,
    typescript: `function twoSum(numbers: number[], target: number): number[] {
    let left = 0, right = numbers.length - 1;
    while (left < right) {
        const sum = numbers[left] + numbers[right];
        if (sum === target) return [left + 1, right + 1];
        if (sum < target) left++;
        else right--;
    }
    return [];
}`,
  },
  sampleTestCases: [
    { input: "numbers = [2, 7, 11, 15], target = 9", expected: "[1, 2]" },
    { input: "numbers = [2, 3, 4], target = 6", expected: "[1, 3]" },
    { input: "numbers = [-1, 0], target = -1", expected: "[1, 2]" },
  ],
};

export const practiceProblemsList: PracticeProblem[] = [
  dailyChallengeProblem,
  {
    id: "p-valid-parentheses",
    title: "Valid Parentheses Stream",
    category: "Data Structures",
    difficulty: "Easy",
    points: 40,
    acceptanceRate: "79.1%",
    status: "Solved",
    tags: ["Stack", "String"],
    description: "Given a string s containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.",
    constraints: ["1 <= s.length <= 10^4", "s consists of parentheses only."],
    hints: ["Use a stack to match every closing bracket with the most recent open bracket."],
    starterCode: {
      python: "def isValid(s: str) -> bool:\n    pass\n",
      cpp: "bool isValid(string s) {\n    return true;\n}",
      java: "public boolean isValid(String s) {\n    return true;\n}",
      typescript: "function isValid(s: string): boolean {\n    return true;\n}",
    },
    sampleTestCases: [{ input: 's = "()[]{}"', expected: "true" }],
  },
  {
    id: "p-longest-subarray",
    title: "Longest Substring Without Repeating Characters",
    category: "Algorithms",
    difficulty: "Medium",
    points: 75,
    acceptanceRate: "61.3%",
    status: "Attempted",
    tags: ["Sliding Window", "Hash Table"],
    description: "Given a string s, find the length of the longest substring without duplicate characters.",
    constraints: ["0 <= s.length <= 5 * 10^4", "s consists of English letters, digits, symbols and spaces."],
    hints: ["Maintain a sliding window [left, right] and record the last seen index of each character."],
    starterCode: {
      python: "def lengthOfLongestSubstring(s: str) -> int:\n    pass\n",
      cpp: "int lengthOfLongestSubstring(string s) {\n    return 0;\n}",
      java: "public int lengthOfLongestSubstring(String s) {\n    return 0;\n}",
      typescript: "function lengthOfLongestSubstring(s: string): number {\n    return 0;\n}",
    },
    sampleTestCases: [{ input: 's = "abcabcbb"', expected: "3" }],
  },
  {
    id: "p-lru-cache",
    title: "Design LRU Eviction Cache",
    category: "System Design",
    difficulty: "Medium",
    points: 90,
    acceptanceRate: "54.0%",
    status: "Todo",
    tags: ["Hash Table", "Linked List", "Design"],
    description: "Design a data structure that follows the constraints of a Least Recently Used (LRU) cache with O(1) get and put operations.",
    constraints: ["1 <= capacity <= 3000", "At most 2 * 10^5 calls to get and put"],
    hints: ["Combine a hash map with a doubly linked list for O(1) access and removal."],
    starterCode: {
      python: "class LRUCache:\n    def __init__(self, capacity: int):\n        pass\n    def get(self, key: int) -> int:\n        pass\n    def put(self, key: int, value: int) -> None:\n        pass\n",
      cpp: "class LRUCache {\npublic:\n    LRUCache(int capacity) {}\n    int get(int key) { return -1; }\n    void put(int key, int value) {}\n};",
      java: "class LRUCache {\n    public LRUCache(int capacity) {}\n    public int get(int key) { return -1; }\n    public void put(int key, int value) {}\n}",
      typescript: "class LRUCache {\n    constructor(capacity: number) {}\n    get(key: number): number { return -1; }\n    put(key: number, value: number): void {}\n}",
    },
    sampleTestCases: [{ input: 'LRUCache(2); put(1, 1); put(2, 2); get(1);', expected: "1" }],
  },
  {
    id: "p-course-schedule",
    title: "Course Schedule Cycle Detection",
    category: "Algorithms",
    difficulty: "Medium",
    points: 80,
    acceptanceRate: "48.2%",
    status: "Solved",
    tags: ["Graph", "Topological Sort", "DFS"],
    description: "There are a total of numCourses courses you have to take, labeled from 0 to numCourses - 1. Determine if you can finish all courses given prerequisite pairs.",
    constraints: ["1 <= numCourses <= 2000", "0 <= prerequisites.length <= 5000"],
    hints: ["Detect if there is a directed cycle in the prerequisites graph using Kahn's algorithm or 3-color DFS."],
    starterCode: {
      python: "def canFinish(numCourses: int, prerequisites: list[list[int]]) -> bool:\n    pass\n",
      cpp: "bool canFinish(int numCourses, vector<vector<int>>& prerequisites) {\n    return true;\n}",
      java: "public boolean canFinish(int numCourses, int[][] prerequisites) {\n    return true;\n}",
      typescript: "function canFinish(numCourses: number, prerequisites: number[][]): boolean {\n    return true;\n}",
    },
    sampleTestCases: [{ input: "numCourses = 2, prerequisites = [[1, 0]]", expected: "true" }],
  },
  {
    id: "p-merge-k-lists",
    title: "Merge K Sorted Interval Lists",
    category: "Data Structures",
    difficulty: "Hard",
    points: 120,
    acceptanceRate: "42.1%",
    status: "Todo",
    tags: ["Heap", "Divide and Conquer"],
    description: "You are given an array of k linked-lists lists, each linked-list is sorted in ascending order. Merge all the linked-lists into one sorted linked-list and return it.",
    constraints: ["k == lists.length", "0 <= k <= 10^4", "0 <= lists[i].length <= 500"],
    hints: ["Insert the head of each list into a min-heap of size k. Poll and advance."],
    starterCode: {
      python: "def mergeKLists(lists: list) -> list:\n    pass\n",
      cpp: "ListNode* mergeKLists(vector<ListNode*>& lists) {\n    return nullptr;\n}",
      java: "public ListNode mergeKLists(ListNode[] lists) {\n    return null;\n}",
      typescript: "function mergeKLists(lists: any[]): any {\n    return null;\n}",
    },
    sampleTestCases: [{ input: "lists = [[1,4,5],[1,3,4],[2,6]]", expected: "[1,1,2,3,4,4,5,6]" }],
  },
];

export type Competition = {
  id: string;
  name: string;
  tagline: string;
  category: "Inter-School" | "System Design" | "Regional Qualifier" | "Practice Sprint";
  status: "LIVE" | "REGISTRATION OPEN" | "UPCOMING" | "COMPLETED";
  statusColor: string;
  startsAt: string;
  startsInDays: number;
  duration: string;
  problemsCount: number;
  participantsCount: number;
  schoolsCount: number;
  languages: string[];
  difficulty: "All Divisions" | "Senior" | "Junior";
  registered: boolean;
  score?: number;
  rank?: number;
  rulesSummary: string[];
};

export const competitionsData: Competition[] = [
  {
    id: "season-01-r1",
    name: "Season 01: Round 1 — Inter-School Qualifier",
    tagline: "The official season opener. Rank your school against 24 partner academies.",
    category: "Inter-School",
    status: "REGISTRATION OPEN",
    statusColor: "var(--blue)",
    startsAt: "Saturday, Mar 07, 2026 · 15:00 UTC",
    startsInDays: 4,
    duration: "120 Mins",
    problemsCount: 4,
    participantsCount: 342,
    schoolsCount: 24,
    languages: ["Python 3", "C++20", "Java 17", "TypeScript"],
    difficulty: "All Divisions",
    registered: true,
    rulesSummary: [
      "Standard individual scoring: 100 points per problem.",
      "Time bonus decays linearly over the round.",
      "Strict automated plagiarism & syntax similarity detection in place.",
      "Top 50% of scores qualify for Round 2 brackets.",
    ],
  },
  {
    id: "weekly-sprint-06",
    name: "Weekly Speed Sprint #06 — Two Pointers & Windows",
    tagline: "Fast 45-minute sprint to practice algorithmic execution under time limits.",
    category: "Practice Sprint",
    status: "LIVE",
    statusColor: "#5DD39E",
    startsAt: "Closes in 02h 45m",
    startsInDays: 0,
    duration: "45 Mins",
    problemsCount: 3,
    participantsCount: 188,
    schoolsCount: 18,
    languages: ["Python 3", "C++20", "Java 17"],
    difficulty: "All Divisions",
    registered: false,
    rulesSummary: [
      "Speed bonus is weighted 2x higher than standard rounds.",
      "Instant test case feedback upon each test execution.",
    ],
  },
  {
    id: "sysdesign-challenge-01",
    name: "Inter-School System Design Hack: School Portal Scale",
    tagline: "Design an attendance & grading architecture capable of 50k concurrent requests.",
    category: "System Design",
    status: "UPCOMING",
    statusColor: "var(--text-2)",
    startsAt: "Saturday, Mar 28, 2026 · 10:00 UTC",
    startsInDays: 25,
    duration: "360 Mins",
    problemsCount: 1,
    participantsCount: 120,
    schoolsCount: 16,
    languages: ["Architecture Spec", "JSON Schema", "Python / Go / TS"],
    difficulty: "Senior",
    registered: false,
    rulesSummary: [
      "Submit architectural document, component diagram, and schema.",
      "Judged by faculty & senior software engineers across 4 rubrics.",
    ],
  },
  {
    id: "pre-season-qual",
    name: "Pre-Season Warmup & Verification Round",
    tagline: "System test and diagnostic round to baseline student scoring rubrics.",
    category: "Regional Qualifier",
    status: "COMPLETED",
    statusColor: "var(--text-3)",
    startsAt: "Completed Feb 14, 2026",
    startsInDays: -15,
    duration: "90 Mins",
    problemsCount: 5,
    participantsCount: 412,
    schoolsCount: 22,
    languages: ["Python 3", "C++20", "Java 17"],
    difficulty: "All Divisions",
    registered: true,
    score: 420,
    rank: 18,
    rulesSummary: ["Diagnostic round: top 75% earned Season 01 verified badge."],
  },
];

export type Submission = {
  id: string;
  projectOrProblem: string;
  type: "System Design" | "Algorithm" | "Daily Practice";
  submittedAt: string;
  status: "UNDER REVIEW" | "SCORED" | "ACCEPTED" | "NEEDS REVISION";
  scoreText: string;
  language: string;
  runtime?: string;
  memory?: string;
  reviewFeedback?: string;
  rubrics?: { name: string; score: number; max: number }[];
};

export const submissionsData: Submission[] = [
  {
    id: "SUB-8492",
    projectOrProblem: "School Management Platform Architecture",
    type: "System Design",
    submittedAt: "2 hours ago",
    status: "UNDER REVIEW",
    scoreText: "Pending Review",
    language: "Markdown + Architecture Schema",
    rubrics: [
      { name: "Modularity & Component Isolation", score: 9, max: 10 },
      { name: "Data Consistency & ACID Compliance", score: 8, max: 10 },
      { name: "Failure Recovery & Caching Layer", score: 8, max: 10 },
    ],
    reviewFeedback: "Architectural blueprint submitted to jury panel. Initial automated linting passed 100%. Awaiting mentor scoring.",
  },
  {
    id: "SUB-8120",
    projectOrProblem: "Valid Parentheses Stream",
    type: "Algorithm",
    submittedAt: "Yesterday at 17:42",
    status: "ACCEPTED",
    scoreText: "100 / 100 pts",
    language: "Python 3",
    runtime: "38 ms (Faster than 89%)",
    memory: "14.2 MB",
    reviewFeedback: "All 24/24 edge cases passed cleanly. O(n) space and time verified.",
  },
  {
    id: "SUB-7841",
    projectOrProblem: "Course Schedule Cycle Detection",
    type: "Algorithm",
    submittedAt: "3 days ago",
    status: "ACCEPTED",
    scoreText: "80 / 80 pts",
    language: "Python 3",
    runtime: "62 ms",
    memory: "17.1 MB",
    reviewFeedback: "Clean topological sort implementation using Kahn's queue.",
  },
  {
    id: "SUB-7390",
    projectOrProblem: "Distributed Event Ticket Locker",
    type: "System Design",
    submittedAt: "Feb 18, 2026",
    status: "SCORED",
    scoreText: "92 / 100 pts",
    language: "YAML + Python Proto",
    rubrics: [
      { name: "Concurrency & Lock Leases", score: 9.5, max: 10 },
      { name: "Horizontal Sharding Strategy", score: 9, max: 10 },
      { name: "Schema Normalization", score: 9, max: 10 },
    ],
    reviewFeedback: "Excellent use of Redis distributed lock lease timeouts. Suggested improving dead-letter queue backoff.",
  },
];

export type HubRoom = {
  id: string;
  name: string;
  description: string;
  unreadCount?: number;
  onlineCount: number;
};

export const hubRoomsData: HubRoom[] = [
  { id: "general", name: "#general", description: "Inter-school discussions, introductions, and questions", onlineCount: 42 },
  { id: "python", name: "#python-mastery", description: "Python tips, recursion patterns, and complexity tricks", unreadCount: 3, onlineCount: 19 },
  { id: "algorithms", name: "#algorithms-ds", description: "Breaking down tricky problems and edge cases", onlineCount: 28 },
  { id: "system-design", name: "#system-design", description: "Architecture diagrams, API contracts, database design", onlineCount: 14 },
  { id: "season-01-prep", name: "#season-01-prep", description: "Official Season 01 prep discussions & scrimmage teams", unreadCount: 5, onlineCount: 36 },
  { id: "showcase", name: "#showcase", description: "Show off personal projects, competitive milestones, and clean code", onlineCount: 12 },
];

export type HubMessage = {
  id: string;
  roomId: string;
  sender: string;
  school: string;
  role: string;
  timestamp: string;
  avatarText: string;
  verified: boolean;
  content: string;
  codeSnippet?: {
    language: string;
    code: string;
  };
  reactions: { emoji: string; count: number; reacted?: boolean }[];
};

export const initialHubMessages: HubMessage[] = [
  {
    id: "msg-1",
    roomId: "general",
    sender: "Sarah K.",
    school: "St. Xavier's School",
    role: "Rank #2",
    timestamp: "14:15",
    avatarText: "SK",
    verified: true,
    content: "Has anyone started revising graphs for Round 1 next week? Make sure you understand the difference between 0-1 BFS with a deque vs standard Dijkstra.",
    reactions: [
      { emoji: "⚡", count: 8, reacted: true },
      { emoji: "🙌", count: 4 },
    ],
  },
  {
    id: "msg-2",
    roomId: "general",
    sender: "Daniel O.",
    school: "Horizon Public",
    role: "Rank #3",
    timestamp: "14:22",
    avatarText: "DO",
    verified: true,
    content: "Definitely! Especially since Python's `heapq` is O(log V) while `collections.deque` gives O(1) push/pop on both ends for unweighted or binary edge weights.",
    codeSnippet: {
      language: "python",
      code: `from collections import deque
dq = deque([(start_node, 0)])
while dq:
    u, cost = dq.popleft()
    # If edge weight is 0: dq.appendleft()
    # If edge weight is 1: dq.append()`,
    },
    reactions: [
      { emoji: "🔥", count: 12 },
      { emoji: "💡", count: 6 },
    ],
  },
  {
    id: "msg-3",
    roomId: "general",
    sender: "Ayaan K.",
    school: "CodeQuest Lead",
    role: "Lead Organizer",
    timestamp: "14:30",
    avatarText: "AK",
    verified: true,
    content: "Reminder to all schools: test environment verification closes Friday night. Please make sure you can run the mock judge before Round 1 begins on Saturday!",
    reactions: [
      { emoji: "🫡", count: 18 },
      { emoji: "⬡", count: 15, reacted: true },
    ],
  },
  {
    id: "msg-4",
    roomId: "python",
    sender: "Farid Bulega",
    school: "Northview Academy",
    role: "You",
    timestamp: "14:38",
    avatarText: "FB",
    verified: true,
    content: "Working through the Two Sum II daily practice right now. The opposite pointer approach saves so much overhead compared to a hash map.",
    reactions: [{ emoji: "🚀", count: 3 }],
  },
];

export type Announcement = {
  id: string;
  category: "COMPETITION" | "PLATFORM" | "ACADEMIC" | "SYSTEM";
  badgeColor: string;
  importance: "HIGH PRIORITY" | "SEASON 01" | "FEATURE UPDATE" | "ROUTINE";
  title: string;
  date: string;
  unread: boolean;
  summary: string;
  content: string[];
};

export const announcementsData: Announcement[] = [
  {
    id: "ann-1",
    category: "COMPETITION",
    badgeColor: "var(--blue)",
    importance: "HIGH PRIORITY",
    title: "Season 01: Round 1 Server Cluster Diagnostics & Rules Published",
    date: "Today, 11:00 UTC",
    unread: true,
    summary: "The official problem specifications and scoring rubric for Season 01 Round 1 have been released. Verification required before Saturday.",
    content: [
      "All registered schools must confirm their team rosters by Friday 23:59 UTC.",
      "Round 1 consists of 4 ranked problems: 1 Easy, 2 Medium, 1 Hard. Problem statements unlock precisely at 15:00 UTC.",
      "A 90-second grace period is granted for final test submissions. Ensure your local network permits WebSocket streams to judge.codequest.dev.",
    ],
  },
  {
    id: "ann-2",
    category: "PLATFORM",
    badgeColor: "#5DD39E",
    importance: "FEATURE UPDATE",
    title: "AI Concept Studio Upgraded with Interactive Call-Stack Visualizer",
    date: "Yesterday",
    unread: true,
    summary: "You can now request visual ASCII and flowchart diagrams of recursion trees and memory frames directly inside the AI Tutor workspace.",
    content: [
      "Ask the AI Tutor to 'show me a diagram' on any recursion or graph problem.",
      "Step through stack frames frame-by-frame with variable tracking.",
      "Export diagrams directly to your personal notes.",
    ],
  },
  {
    id: "ann-3",
    category: "ACADEMIC",
    badgeColor: "var(--text-2)",
    importance: "SEASON 01",
    title: "Northview Academy Coordinates 14 Practice Scrimmages",
    date: "Feb 28, 2026",
    unread: false,
    summary: "Northview High has opened its weekend scrimmage lobby to partner schools. Sign up in the #season-01-prep community room.",
    content: [
      "Scrimmage sessions are unrated practice rounds designed to simulate live tournament pressure.",
      "Solutions will be reviewed live by faculty advisors.",
    ],
  },
  {
    id: "ann-4",
    category: "SYSTEM",
    badgeColor: "var(--text-3)",
    importance: "ROUTINE",
    title: "Scheduled Maintenance Window Completed Successfully",
    date: "Feb 24, 2026",
    unread: false,
    summary: "All judging queues and container sandboxes have been patched with C++23 runtime libraries and Python 3.12.2 updates.",
    content: [
      "No downtime expected for the remainder of Season 01 qualifiers.",
    ],
  },
];

export type NotificationItem = {
  id: string;
  type: "competition" | "submission" | "achievement" | "practice" | "announcement";
  title: string;
  time: string;
  unread: boolean;
  linkText: string;
  targetTab: string;
};

export const notificationsData: NotificationItem[] = [
  {
    id: "notif-1",
    type: "competition",
    title: "Season 01 Round 1 starts in 4 days. Your seat is confirmed.",
    time: "20m ago",
    unread: true,
    linkText: "View Arena Details",
    targetTab: "competitions",
  },
  {
    id: "notif-2",
    type: "submission",
    title: "Submission #SUB-8492 received by jury. Linting score: 100/100.",
    time: "2h ago",
    unread: true,
    linkText: "Review Submission",
    targetTab: "submissions",
  },
  {
    id: "notif-3",
    type: "achievement",
    title: "Octagon Badge Earned: 7-Day Flame Streak unlocked! (+120 XP)",
    time: "5h ago",
    unread: true,
    linkText: "View in Profile",
    targetTab: "profile",
  },
  {
    id: "notif-4",
    type: "practice",
    title: "Today's daily challenge 'Two Sum II' is waiting for your submission.",
    time: "9h ago",
    unread: false,
    linkText: "Start Daily Challenge",
    targetTab: "daily-practice",
  },
];

export type AiTutorPrompt = {
  id: string;
  title: string;
  category: "Algorithms" | "Diagrams" | "Deep Dive" | "Challenge";
  question: string;
  response: {
    explanation: string;
    diagram?: string;
    code: string;
    practicePrompt: string;
  };
};

export const aiTutorSamplePrompts: AiTutorPrompt[] = [
  {
    id: "recursion",
    title: "Explain recursion with call stack diagram",
    category: "Diagrams",
    question: "Explain recursion with call stack diagram and step-by-step memory frame execution",
    response: {
      explanation: `Recursion is when a function solves a smaller sub-instance of itself until reaching a base condition.

In memory, every recursive call creates a new **Stack Frame** containing its local parameters and return address. When the base case triggers, the stack unwinds (pops) in Last-In-First-Out (LIFO) order.`,
      diagram: `
+------------------------------------------+
|  CALL STACK FRAMES (Memory Layout)       |
+------------------------------------------+
|  [Frame 4] factorial(1) -> returns 1    |  <-- Base Case Hit!
|  [Frame 3] factorial(2) -> 2 * fact(1)  |
|  [Frame 2] factorial(3) -> 3 * fact(2)  |
|  [Frame 1] factorial(4) -> 4 * fact(3)  |
|  [Frame 0] main()                       |
+------------------------------------------+
       | Unwinding: 1 -> 2 -> 6 -> 24
`,
      code: `def factorial(n: int) -> int:
    # 1. Base case: prevents stack overflow
    if n <= 1:
        return 1
    # 2. Recursive breakdown: n * subproblem
    return n * factorial(n - 1)

# Complexity: O(n) Time | O(n) Space on call stack`,
      practicePrompt: "Now challenge yourself: How would you convert this into tail recursion or iteration to achieve O(1) auxiliary space?",
    },
  },
  {
    id: "sliding-window",
    title: "Sliding Window template for subarray problems",
    category: "Algorithms",
    question: "Show me the standard Sliding Window template for dynamic window sizing",
    response: {
      explanation: `The Sliding Window technique turns what looks like an O(N²) nested loop into an O(N) linear scan by expanding the right pointer and contracting the left pointer only when invariants are violated.`,
      diagram: `
Array: [ 2 , 1 , 5 , 2 , 3 , 2 ]   Target Sum >= 7
Window: [--------]               Sum = 8 (Valid! Contract left)
           [----]               Sum = 6 (Too small, expand right)
`,
      code: `def min_subarray_len(target: int, nums: list[int]) -> int:
    left = 0
    curr_sum = 0
    min_len = float('inf')

    for right in range(len(nums)):
        curr_sum += nums[right]
        # Invariant check: shrink from left
        while curr_sum >= target:
            min_len = min(min_len, right - left + 1)
            curr_sum -= nums[left]
            left += 1

    return min_len if min_len != float('inf') else 0`,
      practicePrompt: "Try problem #3: Longest Substring Without Repeating Characters using this exact pattern!",
    },
  },
  {
    id: "dp-tabulation",
    title: "Tabulation vs Memoization in Dynamic Programming",
    category: "Deep Dive",
    question: "What is the concrete difference between Top-Down Memoization and Bottom-Up Tabulation?",
    response: {
      explanation: `Both solve overlapping subproblems, but they differ fundamentally in memory structure:
• **Top-Down (Memoization)** starts at the goal state and recurses down, caching answers in a hash map.
• **Bottom-Up (Tabulation)** starts at the base cases and fills an iterative table (array), avoiding call-stack overhead and often permitting space optimization.`,
      diagram: `
TOP-DOWN:    Goal f(5) -> f(4) + f(3) -> ... -> Base f(0)
             (Recursive call stack + memo dict)

BOTTOM-UP:   Base dp[0]=0, dp[1]=1 -> dp[2] -> dp[3] -> Goal dp[5]
             (Iterative array, O(1) space if tracking last 2 items)
`,
      code: `# Bottom-up space-optimized Fibonacci
def fib(n: int) -> int:
    if n <= 1:
        return n
    prev2, prev1 = 0, 1
    for _ in range(2, n + 1):
        prev2, prev1 = prev1, prev2 + prev1
    return prev1`,
      practicePrompt: "Exercise: Write the recurrence relation for the 0/1 Knapsack problem.",
    },
  },
];
